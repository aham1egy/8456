# 🚀 دليل نشر تطبيق KemetNet على Vercel

## المتطلبات

1. **حساب Vercel** — [vercel.com](https://vercel.com) (مجاني)
2. **حساب GitHub** — لرفع الكود
3. **مشروع Supabase** — `bhzrhvesrpyvrsshavow.supabase.co` (موجود بالفعل)

---

## الخطوة 1: رفع الكود على GitHub

```bash
# في مجلد المشروع
git init
git add .
git commit -m "KemetNet - Production Ready"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/kemetnet.git
git push -u origin main
```

---

## الخطوة 2: النشر على Vercel

1. اذهب إلى [vercel.com/new](https://vercel.com/new)
2. اختر **Import Git Repository**
3. ابحث عن `kemetnet` واختر المستودع
4. اضغط **Deploy**

### إعدادات Vercel (تلقائية):
- **Framework**: Next.js
- **Build Command**: `next build` (تلقائي)
- **Output Directory**: `.next` (تلقائي)
- **Install Command**: `npm install` (تلقائي)

---

## الخطوة 3: إضافة متغيرات البيئة

في صفحة المشروع على Vercel:

1. اذهب إلى **Settings → Environment Variables**
2. أضف المتغيرات التالية:

| Name | Value |
|------|-------|
| `NEXT_PUBLIC_SUPABASE_URL` | `https://bhzrhvesrpyvrsshavow.supabase.co` |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | `sb_publishable_AO6P04L0WlDaCK2Ot38YTQ_90FnOQc_` |
| `DATABASE_URL` | `file:./db/custom.db` |

3. اضغط **Save** لكل متغير
4. اذهب إلى **Deployments** → **Redeploy**

---

## الخطوة 4: إعداد Supabase

في Supabase Dashboard، أضف رابط Vercel للـ CORS:

1. اذهب إلى [Supabase Dashboard](https://supabase.com/dashboard/project/bhzrhvesrpyvrsshavow/settings/api)
2. في **URL Configuration**:
   - **Site URL**: `https://YOUR_APP.vercel.app`
   - **Redirect URLs**: أضف `https://YOUR_APP.vercel.app/**`

---

## الخطوة 5: تشغيل SQL (مرة واحدة فقط)

في Supabase Dashboard → SQL Editor، شغّل هذه الملفات بالترتيب:

1. `scripts/supabase-schema.sql` — المخطط الرئيسي
2. `scripts/admin-roles.sql` — نظام الأدوار
3. `scripts/admin-rpcs-final-v2.sql` — RPC functions
4. `scripts/fix-blocks-rls.sql` — إصلاح الحجب
5. `scripts/reports-management-upgrade.sql` — نظام البلاغات
6. `scripts/verification-fix.sql` — نظام التوثيق

---

## الخطوة 6: إنشاء Storage Buckets

في Supabase Dashboard → Storage:

1. أنشئ bucket باسم `avatars` (Public ✅)
2. أنشئ bucket باسم `post-images` (Public ✅)
3. أنشئ bucket باسم `message-images` (Public ✅)

---

## بيانات الدخول

| الحساب | اليوزرنيم | كلمة المرور |
|--------|----------|------------|
| المالك | `kemetnet_admin` | `kemetnet_admin` |

---

## هيكل المشروع

```
kemetnet/
├── src/
│   ├── app/              # 17 صفحة
│   ├── components/        # 41 مكون
│   ├── hooks/            # 14 hook
│   ├── lib/              # 40+ مكتبة
│   │   ├── ai/           # 6 محركات ذكية
│   │   └── supabase/     # عميل قاعدة البيانات
│   ├── store/            # إدارة الحالة
│   └── middleware.ts     # حماية الطرق
├── public/               # أيقونات + manifest + sw.js
├── scripts/              # ملفات SQL + أدوات
├── package.json
├── next.config.ts
├── vercel.json
└── .env (محلي فقط)
```

---

## المميزات

- ✅ 17 صفحة (home, explore, create, profile, messages, etc.)
- ✅ لوحة إدارة احترافية (6 تبويبات)
- ✅ نظام موظفين بصلاحيات محددة
- ✅ نظام بلاغات متقدم (4 حالات + 5 أنواع إجراءات)
- ✅ نظام توثيق Instagram-style
- ✅ بث مباشر للإشعارات والرسائل
- ✅ PWA كامل (offline support)
- ✅ خوارزميات ذكية في الخلفية
- ✅ نظام حجب متكامل مثل Facebook
- ✅ Security headers + middleware
- ✅ تصميم Egyptian Lapis & Gold

---

## حل المشاكل

### المشكلة: التطبيق لا يفتح
- تأكد من إضافة متغيرات البيئة في Vercel
- تأكد من تشغيل SQL في Supabase

### المشكلة: تسجيل الدخول لا يعمل
- تأكد من Site URL في Supabase = رابط Vercel
- تأكد من إضافة Redirect URLs

### المشكلة: الصور لا تظهر
- تأكد من إنشاء Storage Buckets الثلاثة

---

## الدعم

- **Vercel Docs**: [vercel.com/docs](https://vercel.com/docs)
- **Supabase Docs**: [supabase.com/docs](https://supabase.com/docs)
- **Next.js Docs**: [nextjs.org/docs](https://nextjs.org/docs)

---

صُنع بحب في العالم العربي 🌹
