import type { NextConfig } from "next";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "https://bhzrhvesrpyvrsshavow.supabase.co";

const nextConfig: NextConfig = {
  reactStrictMode: false,
  allowedDevOrigins: ["*.space-z.ai", "localhost", "127.0.0.1"],
  compress: true,
  poweredByHeader: false,
  productionBrowserSourceMaps: false,
  experimental: {
    staleTimes: {
      dynamic: 30,
      static: 300,
    },
    optimizeCss: true,
    optimizePackageImports: [
      'lucide-react',
      'date-fns',
      '@supabase/supabase-js',
    ],
  },
  images: {
    formats: ["image/avif", "image/webp"],
    deviceSizes: [640, 750, 828, 1080],
    imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],
    minimumCacheTTL: 86400,
    remotePatterns: [
      { protocol: "https", hostname: "**.supabase.co" },
      { protocol: "https", hostname: "**.supabase.in" },
    ],
  },
  async headers() {
    const securityHeaders = [
      { key: "X-Content-Type-Options", value: "nosniff" },
      { key: "X-Frame-Options", value: "DENY" },
      { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
      { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=(), browsing-topics=()" },
      { key: "Strict-Transport-Security", value: "max-age=63072000; includeSubDomains; preload" },
      { key: "X-XSS-Protection", value: "1; mode=block" },
      {
        key: "Content-Security-Policy",
        value: [
          "default-src 'self'",
          `script-src 'self' 'unsafe-inline' ${supabaseUrl}`,
          "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
          "font-src 'self' https://fonts.gstatic.com data:",
          `img-src 'self' ${supabaseUrl} data: blob:`,
          `connect-src 'self' ${supabaseUrl} wss://${supabaseUrl.replace('https://', '')}`,
          "frame-ancestors 'none'",
          "base-uri 'self'",
          "form-action 'self'",
          "object-src 'none'",
          "worker-src 'self' blob:",
        ].join("; "),
      },
    ]

    return [
      { source: "/_next/static/:path*", headers: [{ key: "Cache-Control", value: "public, max-age=31536000, immutable" }, ...securityHeaders] },
      { source: "/icons/:path*", headers: [{ key: "Cache-Control", value: "public, max-age=31536000, immutable" }, ...securityHeaders] },
      { source: "/manifest.json", headers: [{ key: "Cache-Control", value: "public, max-age=86400" }, ...securityHeaders] },
      { source: "/sw.js", headers: [{ key: "Cache-Control", value: "no-store" }, ...securityHeaders] },
      { source: "/((?!_next/static).*)", headers: [{ key: "Cache-Control", value: "public, max-age=0, stale-while-revalidate=86400, must-revalidate" }, ...securityHeaders] },
    ]
  },
}

export default nextConfig
