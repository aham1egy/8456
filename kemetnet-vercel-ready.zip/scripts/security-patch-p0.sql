-- =====================================================
-- مشرق - إصلاح أمني شامل (Security Patch)
-- يصلح كل الثغرات الحرجة (P0) المكتشفة
-- آمن للتشغيل المتكرر
-- =====================================================

-- =====================================================
-- 1. حماية RPC functions: التحقق من auth.uid() = target_user_id
-- =====================================================

-- delete_user_account
CREATE OR REPLACE FUNCTION public.delete_user_account(target_user_id UUID)
RETURNS VOID AS $$
DECLARE
  user_email TEXT;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'غير مصادق';
  END IF;
  IF auth.uid() != target_user_id THEN
    RAISE EXCEPTION 'لا يمكنك حذف حساب مستخدم آخر';
  END IF;
  
  SELECT email INTO user_email FROM auth.users WHERE id = target_user_id;
  IF user_email IS NULL THEN
    RAISE EXCEPTION 'المستخدم غير موجود';
  END IF;
  
  DELETE FROM public.notifications WHERE user_id = target_user_id OR actor_id = target_user_id;
  DELETE FROM public.comment_likes WHERE user_id = target_user_id;
  DELETE FROM public.likes WHERE user_id = target_user_id;
  DELETE FROM public.comments WHERE user_id = target_user_id;
  DELETE FROM public.follows WHERE follower_id = target_user_id OR following_id = target_user_id;
  DELETE FROM public.message_requests WHERE sender_id = target_user_id OR receiver_id = target_user_id;
  DELETE FROM public.messages WHERE sender_id = target_user_id;
  DELETE FROM public.conversations WHERE participant_1 = target_user_id OR participant_2 = target_user_id;
  DELETE FROM public.posts WHERE user_id = target_user_id;
  DELETE FROM public.profiles WHERE id = target_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- claim_daily_reward
CREATE OR REPLACE FUNCTION public.claim_daily_reward(target_user_id UUID)
RETURNS TABLE(
  success BOOLEAN, streak INTEGER, day_in_cycle INTEGER,
  points_awarded INTEGER, reward_type TEXT,
  is_new_streak BOOLEAN, streak_broken BOOLEAN
) AS $$
DECLARE
  user_record RECORD;
  today DATE := CURRENT_DATE;
  yesterday DATE := CURRENT_DATE - 1;
  new_streak INTEGER;
  day_in_cycle INTEGER;
  points_to_award INTEGER;
  reward_type_val TEXT := 'points';
  is_new_streak_val BOOLEAN := FALSE;
  streak_broken_val BOOLEAN := FALSE;
  already_claimed BOOLEAN;
BEGIN
  IF auth.uid() IS NULL OR auth.uid() != target_user_id THEN
    RETURN QUERY SELECT FALSE, 0, 0, 0, NULL::TEXT, FALSE, FALSE;
    RETURN;
  END IF;
  
  SELECT * INTO user_record FROM public.profiles WHERE id = target_user_id;
  IF NOT FOUND THEN
    RETURN QUERY SELECT FALSE, 0, 0, 0, NULL::TEXT, FALSE, FALSE;
    RETURN;
  END IF;
  
  SELECT EXISTS(SELECT 1 FROM public.daily_rewards_log WHERE user_id = target_user_id AND reward_date = today) INTO already_claimed;
  
  IF already_claimed THEN
    day_in_cycle := ((user_record.login_streak - 1) % 7) + 1;
    RETURN QUERY SELECT FALSE, user_record.login_streak, day_in_cycle, 0, NULL::TEXT, FALSE, FALSE;
    RETURN;
  END IF;
  
  IF user_record.last_login_date IS NULL THEN
    new_streak := 1;
    is_new_streak_val := TRUE;
  ELSIF user_record.last_login_date = yesterday THEN
    new_streak := user_record.login_streak + 1;
    is_new_streak_val := (new_streak = 2);
  ELSIF user_record.last_login_date = today THEN
    new_streak := user_record.login_streak;
  ELSE
    IF user_record.streak_freeze_available THEN
      new_streak := user_record.login_streak + 1;
      UPDATE public.profiles SET streak_freeze_available = FALSE, streak_freeze_used = streak_freeze_used + 1 WHERE id = target_user_id;
      reward_type_val := 'streak_freeze';
    ELSE
      new_streak := 1;
      streak_broken_val := TRUE;
      is_new_streak_val := TRUE;
    END IF;
  END IF;
  
  day_in_cycle := ((new_streak - 1) % 7) + 1;
  points_to_award := CASE day_in_cycle WHEN 1 THEN 10 WHEN 2 THEN 15 WHEN 3 THEN 20 WHEN 4 THEN 25 WHEN 5 THEN 30 WHEN 6 THEN 40 WHEN 7 THEN 50 ELSE 10 END;
  
  IF day_in_cycle = 7 THEN
    UPDATE public.profiles SET streak_freeze_available = TRUE WHERE id = target_user_id;
    reward_type_val := 'bonus';
  END IF;
  
  INSERT INTO public.daily_rewards_log (user_id, reward_date, streak_day, points_awarded, reward_type)
  VALUES (target_user_id, today, day_in_cycle, points_to_award, reward_type_val);
  
  UPDATE public.profiles 
  SET login_streak = new_streak, longest_streak = GREATEST(longest_streak, new_streak),
      last_login_date = today, total_logins = total_logins + 1,
      reputation_points = reputation_points + points_to_award,
      total_earned_points = total_earned_points + points_to_award,
      reputation_level = GREATEST(1, FLOOR(SQRT((reputation_points + points_to_award) / 100.0))::INTEGER + 1)
  WHERE id = target_user_id;
  
  RETURN QUERY SELECT TRUE, new_streak, day_in_cycle, points_to_award, reward_type_val, is_new_streak_val, streak_broken_val;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- update_achievement_progress
CREATE OR REPLACE FUNCTION public.update_achievement_progress(
  target_user_id UUID, achievement_slug TEXT, new_progress INTEGER
) RETURNS VOID AS $$
DECLARE
  achievement_record RECORD;
  should_complete BOOLEAN;
BEGIN
  IF auth.uid() IS NULL OR auth.uid() != target_user_id THEN
    RETURN;
  END IF;
  
  SELECT * INTO achievement_record FROM public.achievements WHERE slug = achievement_slug;
  IF NOT FOUND THEN RETURN; END IF;
  
  should_complete := achievement_record.target_value IS NULL OR new_progress >= achievement_record.target_value;
  
  INSERT INTO public.user_achievements (user_id, achievement_slug, progress, completed, completed_at, updated_at)
  VALUES (target_user_id, achievement_slug,
    LEAST(new_progress, COALESCE(achievement_record.target_value, new_progress)),
    should_complete, CASE WHEN should_complete THEN NOW() ELSE NULL END, NOW())
  ON CONFLICT (user_id, achievement_slug) DO UPDATE
  SET progress = GREATEST(user_achievements.progress, LEAST(new_progress, COALESCE(achievement_record.target_value, new_progress))),
      completed = user_achievements.completed OR should_complete,
      completed_at = CASE WHEN should_complete AND user_achievements.completed_at IS NULL THEN NOW() ELSE user_achievements.completed_at END,
      updated_at = NOW();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- award_reputation_points
CREATE OR REPLACE FUNCTION public.award_reputation_points(
  target_user_id UUID, activity_type TEXT, related_id UUID DEFAULT NULL, related_type TEXT DEFAULT NULL
) RETURNS VOID AS $$
DECLARE
  points INTEGER;
BEGIN
  -- فقط الـ triggers (SECURITY DEFINER) يمكنها استدعاء هذه الدالة مباشرة
  -- المستخدمون العاديون لا يمكنهم استدعاءها (لا تُمنح صلاحية EXECUTE لـ authenticated)
  points := public.get_activity_points(activity_type);
  IF points = 0 THEN RETURN; END IF;
  
  INSERT INTO public.reputation_log (user_id, activity_type, points_earned, related_id, related_type)
  VALUES (target_user_id, activity_type, points, related_id, related_type);
  
  UPDATE public.profiles 
  SET reputation_points = reputation_points + points,
      total_earned_points = total_earned_points + points,
      reputation_level = GREATEST(1, FLOOR(SQRT((reputation_points + points) / 100.0))::INTEGER + 1)
  WHERE id = target_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- إلغاء صلاحية EXECUTE من authenticated على award_reputation_points
-- (فقط الـ triggers يمكنها استدعاؤها عبر SECURITY DEFINER)
REVOKE EXECUTE ON FUNCTION public.award_reputation_points(UUID, TEXT, UUID, TEXT) FROM authenticated;

-- update_last_seen
CREATE OR REPLACE FUNCTION public.update_last_seen(target_user_id UUID)
RETURNS VOID AS $$
BEGIN
  IF auth.uid() IS NULL OR auth.uid() != target_user_id THEN
    RETURN;
  END IF;
  UPDATE public.profiles SET last_seen = NOW() WHERE id = target_user_id AND show_last_seen = TRUE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- update_achievement_progress: أيضاً نتحقق من auth.uid()
-- (تمت إضافته في الأعلى)

-- =====================================================
-- 2. حماية profiles: منع تحديث حقول السمعة والـ streak
-- =====================================================
CREATE OR REPLACE FUNCTION public.prevent_profile_restricted_fields_update()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.reputation_points IS DISTINCT FROM OLD.reputation_points
     OR NEW.reputation_level IS DISTINCT FROM OLD.reputation_level
     OR NEW.total_earned_points IS DISTINCT FROM OLD.total_earned_points
     OR NEW.login_streak IS DISTINCT FROM OLD.login_streak
     OR NEW.longest_streak IS DISTINCT FROM OLD.longest_streak
     OR NEW.total_logins IS DISTINCT FROM OLD.total_logins
     OR NEW.streak_freeze_available IS DISTINCT FROM OLD.streak_freeze_available
     OR NEW.streak_freeze_used IS DISTINCT FROM OLD.streak_freeze_used
     OR NEW.is_verified IS DISTINCT FROM OLD.is_verified
     OR NEW.verified_type IS DISTINCT FROM OLD.verified_type
     OR NEW.verified_at IS DISTINCT FROM OLD.verified_at
     OR NEW.followers_count IS DISTINCT FROM OLD.followers_count
     OR NEW.following_count IS DISTINCT FROM OLD.following_count
     OR NEW.posts_count IS DISTINCT FROM OLD.posts_count THEN
    RAISE EXCEPTION 'لا يمكنك تعديل هذه الحقول بنفسك';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trigger_prevent_profile_restricted_fields ON public.profiles;
CREATE TRIGGER trigger_prevent_profile_restricted_fields
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.prevent_profile_restricted_fields_update();

-- ملاحظة: دوال SECURITY DEFINER تتجاوز هذا الـ trigger
-- لكن المستخدمين العاديين (عبر RLS) سيمنعون

-- =====================================================
-- 3. إضافة UPDATE RLS policy لجدول comments
-- =====================================================
DROP POLICY IF EXISTS "comments_update_own" ON public.comments;
CREATE POLICY "comments_update_own" ON public.comments FOR UPDATE 
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "comments_update_post_owner_pin" ON public.comments;
CREATE POLICY "comments_update_post_owner_pin" ON public.comments FOR UPDATE 
  USING (
    EXISTS (
      SELECT 1 FROM public.posts p
      WHERE p.id = comments.post_id AND p.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.posts p
      WHERE p.id = comments.post_id AND p.user_id = auth.uid()
    )
  );

-- =====================================================
-- 4. إنشاء جدول comment_likes المفقود + RLS
-- =====================================================
CREATE TABLE IF NOT EXISTS public.comment_likes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  comment_id UUID NOT NULL REFERENCES public.comments(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  UNIQUE(comment_id, user_id)
);

CREATE INDEX IF NOT EXISTS idx_comment_likes_comment ON public.comment_likes (comment_id);
CREATE INDEX IF NOT EXISTS idx_comment_likes_user ON public.comment_likes (user_id);

ALTER TABLE public.comment_likes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "comment_likes_select_own" ON public.comment_likes;
CREATE POLICY "comment_likes_select_own" ON public.comment_likes FOR SELECT USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "comment_likes_insert_own" ON public.comment_likes;
CREATE POLICY "comment_likes_insert_own" ON public.comment_likes FOR INSERT WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "comment_likes_delete_own" ON public.comment_likes;
CREATE POLICY "comment_likes_delete_own" ON public.comment_likes FOR DELETE USING (auth.uid() = user_id);

-- =====================================================
-- 5. إصلاح RLS لجدول messages: تضييق update_recipient_read
-- =====================================================
DROP POLICY IF EXISTS "msg_update_recipient_read" ON public.messages;
-- استبدالها بدالة RPC مخصصة بدلاً من سياسة واسعة
CREATE OR REPLACE FUNCTION public.mark_messages_read(conv_id UUID, reader_id UUID)
RETURNS VOID AS $$
BEGIN
  IF auth.uid() IS NULL OR auth.uid() != reader_id THEN
    RETURN;
  END IF;
  UPDATE public.messages SET read_at = NOW()
  WHERE conversation_id = conv_id
    AND sender_id != reader_id
    AND read_at IS NULL
    AND EXISTS (
      SELECT 1 FROM public.conversations c
      WHERE c.id = conv_id AND (c.participant_1 = reader_id OR c.participant_2 = reader_id)
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

GRANT EXECUTE ON FUNCTION public.mark_messages_read(UUID, UUID) TO authenticated;

-- =====================================================
-- ملاحظات:
-- 1. كل دوال SECURITY DEFINER الآن تتحقق من auth.uid()
-- 2. profiles محمي بـ trigger يمنع تحديث حقول السمعة
-- 3. comments لديه UPDATE RLS policy
-- 4. comment_likes جدول موجود الآن
-- 5. messages RLS مُضيّق (mark_messages_read RPC بدلاً من سياسة واسعة)
-- =====================================================
