-- =====================================================
-- مشرق - نظام الإبلاغ + حجب المستخدمين
-- آمن للتشغيل المتكرر - يستخدم IF NOT EXISTS
-- =====================================================

-- =====================================================
-- 1. جدول البلاغات (reports)
-- =====================================================
CREATE TABLE IF NOT EXISTS public.reports (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  reporter_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  -- نوع المحتوى المُبلّغ عنه
  target_type TEXT NOT NULL CHECK (target_type IN ('post', 'comment', 'message', 'profile')),
  -- معرف المحتوى (UUID كنص لأي نوع)
  target_id UUID NOT NULL,
  -- المستخدم المُبلّغ عنه (المالك الأصلي للمحتوى)
  reported_user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  -- سبب البلاغ
  reason TEXT NOT NULL CHECK (reason IN (
    'spam',           -- محتوى مزعج
    'harassment',    -- مضايقة أو تنمر
    'hate',          -- خطاب كراهية
    'violence',      -- عنف أو تحريض
    'adult',         -- محتوى للبالغين
    'illegal',       -- نشاط غير قانوني
    'impersonation', -- انتحال شخصية
    'misinformation',-- معلومات مضللة
    'other'          -- أخرى
  )),
  -- وصف اختياري للبلاغ
  description TEXT CHECK (description IS NULL OR length(description) <= 500),
  -- حالة البلاغ
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'reviewing', 'resolved', 'dismissed')),
  -- ملاحظات الإدارة (داخلية)
  admin_notes TEXT,
  -- التواريخ
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  resolved_at TIMESTAMPTZ,
  resolved_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  -- منع تكرار البلاغ من نفس المستخدم لنفس المحتوى
  UNIQUE(reporter_id, target_type, target_id)
);

CREATE INDEX IF NOT EXISTS idx_reports_reporter ON public.reports (reporter_id);
CREATE INDEX IF NOT EXISTS idx_reports_reported_user ON public.reports (reported_user_id);
CREATE INDEX IF NOT EXISTS idx_reports_status ON public.reports (status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_reports_target ON public.reports (target_type, target_id);

-- =====================================================
-- 2. جدول الحجب (blocks)
-- =====================================================
CREATE TABLE IF NOT EXISTS public.blocks (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  blocker_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  blocked_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  -- عند الحجب، نزيل المتابعة تلقائياً (في trigger)
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  UNIQUE(blocker_id, blocked_id),
  CHECK (blocker_id != blocked_id)
);

CREATE INDEX IF NOT EXISTS idx_blocks_blocker ON public.blocks (blocker_id);
CREATE INDEX IF NOT EXISTS idx_blocks_blocked ON public.blocks (blocked_id);

-- =====================================================
-- 3. تفعيل RLS
-- =====================================================
ALTER TABLE public.reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.blocks ENABLE ROW LEVEL SECURITY;

-- =====================================================
-- 4. سياسات RLS للبلاغات
-- =====================================================
-- المستخدم يرى بلاغاته فقط
DROP POLICY IF EXISTS "reports_select_own" ON public.reports;
CREATE POLICY "reports_select_own" ON public.reports FOR SELECT 
  USING (auth.uid() = reporter_id OR auth.uid() = reported_user_id);

-- المستخدم يُدرج بلاغاته فقط
DROP POLICY IF EXISTS "reports_insert_own" ON public.reports;
CREATE POLICY "reports_insert_own" ON public.reports FOR INSERT 
  WITH CHECK (auth.uid() = reporter_id);

-- المستخدم يمكنه حذف بلاغاته (سحب البلاغ)
DROP POLICY IF EXISTS "reports_delete_own" ON public.reports;
CREATE POLICY "reports_delete_own" ON public.reports FOR DELETE 
  USING (auth.uid() = reporter_id);

-- =====================================================
-- 5. سياسات RLS للحجب
-- =====================================================
-- المستخدم يرى قائمة من حجبهم فقط
DROP POLICY IF EXISTS "blocks_select_own" ON public.blocks;
CREATE POLICY "blocks_select_own" ON public.blocks FOR SELECT 
  USING (auth.uid() = blocker_id OR auth.uid() = blocked_id);

-- المستخدم يُدرج حجبه فقط
DROP POLICY IF EXISTS "blocks_insert_own" ON public.blocks;
CREATE POLICY "blocks_insert_own" ON public.blocks FOR INSERT 
  WITH CHECK (auth.uid() = blocker_id);

-- المستخدم يحذف حجبه فقط (إلغاء الحجب)
DROP POLICY IF EXISTS "blocks_delete_own" ON public.blocks;
CREATE POLICY IF EXISTS "blocks_delete_own" ON public.blocks FOR DELETE 
  USING (auth.uid() = blocker_id);

-- إعادة إنشاء بدون IF EXISTS (DROP POLICY لا يدعم IF EXISTS في كل الإصدارات)
DROP POLICY IF EXISTS "blocks_delete_own" ON public.blocks;
CREATE POLICY "blocks_delete_own" ON public.blocks FOR DELETE 
  USING (auth.uid() = blocker_id);

-- =====================================================
-- 6. Trigger: عند الحجب، احذف المتابعة في الاتجاهين
-- =====================================================
CREATE OR REPLACE FUNCTION public.handle_block_unfollow()
RETURNS TRIGGER AS $$
BEGIN
  -- حذف متابعة الحاجب للمحجوب
  DELETE FROM public.follows 
  WHERE follower_id = NEW.blocker_id AND following_id = NEW.blocked_id;
  
  -- حذف متابعة المحجوب للحاجب
  DELETE FROM public.follows 
  WHERE follower_id = NEW.blocked_id AND following_id = NEW.blocker_id;
  
  -- حذف أي طلبات مراسلة معلّقة بينهما
  DELETE FROM public.message_requests
  WHERE (sender_id = NEW.blocker_id AND receiver_id = NEW.blocked_id)
     OR (sender_id = NEW.blocked_id AND receiver_id = NEW.blocker_id);
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trigger_handle_block_unfollow ON public.blocks;
CREATE TRIGGER trigger_handle_block_unfollow
  AFTER INSERT ON public.blocks
  FOR EACH ROW EXECUTE FUNCTION public.handle_block_unfollow();

-- =====================================================
-- 7. تفعيل Realtime
-- =====================================================
ALTER PUBLICATION supabase_realtime ADD TABLE public.reports;
ALTER PUBLICATION supabase_realtime ADD TABLE public.blocks;

-- =====================================================
-- ملاحظات:
-- 1. البلاغات: المستخدم يرى بلاغاته وبلاغات ضده فقط
-- 2. الحجب: عند الحجب يتم حذف المتابعة في الاتجاهين + طلبات المراسلة
-- 3. المحتوى المحجوب يُصفّى في الواجهة الأمامية (frontend filtering)
-- 4. لا توجد حالياً أدوات إدارة (admin) — يُمكن إضافتها لاحقاً
-- =====================================================
