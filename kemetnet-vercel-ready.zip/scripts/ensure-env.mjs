// scripts/ensure-env.mjs
// يتأكد من وجود متغيرات Supabase في .env قبل البناء
// إذا كانت مفقودة، يكتبها تلقائيًا

import { readFileSync, writeFileSync, existsSync } from 'fs'
import { resolve } from 'path'

const ENV_PATH = resolve(process.cwd(), '.env')

const REQUIRED_ENV = `DATABASE_URL=file:/home/z/my-project/db/custom.db

# Supabase - KemetNet
NEXT_PUBLIC_SUPABASE_URL=https://bhzrhvesrpyvrsshavow.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=sb_publishable_AO6P04L0WlDaCK2Ot38YTQ_90FnOQc_
`

console.log('→ فحص متغيرات Supabase في .env...')

let envContent = ''
if (existsSync(ENV_PATH)) {
  envContent = readFileSync(ENV_PATH, 'utf-8')
}

const hasUrl = envContent.includes('NEXT_PUBLIC_SUPABASE_URL=https://bhzrhvesrpyvrsshavow.supabase.co')
const hasKey = envContent.includes('sb_publishable_')

if (hasUrl && hasKey) {
  console.log('  ✓ متغيرات Supabase موجودة')
  process.exit(0)
}

console.log('  ⚠️  متغيرات Supabase مفقودة — إعادة كتابة .env...')

// اكتب المحتوى المطلوب
writeFileSync(ENV_PATH, REQUIRED_ENV, 'utf-8')

// تحقق من الكتابة
const newContent = readFileSync(ENV_PATH, 'utf-8')
if (newContent.includes('NEXT_PUBLIC_SUPABASE_URL') && newContent.includes('sb_publishable_')) {
  console.log('  ✓ تمت إعادة كتابة .env بنجاح')
} else {
  console.error('  ❌ فشلت كتابة .env!')
  process.exit(1)
}
