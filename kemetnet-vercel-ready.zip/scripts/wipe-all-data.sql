-- ============================================================
-- KemetNet — Wipe All Data from Database
-- ============================================================
-- يُشغّل هذا السكربت في Supabase Dashboard → SQL Editor → New query
-- يقوم بحذف كل البيانات من كل الجداول (مع تجاوز RLS عبر bypass)
-- لا يحذف auth.users (يحتاج حذف منفصل من Authentication → Users)
-- ============================================================

-- تعطيل RLS checks مؤقتًا لهذه الجلسة (يجب أن تُشغّل كـ postgres/service_role)
SET row_security = off;

-- إيقاف triggers مؤقتًا لتسريع الحذف (تجنب cascade issues)
BEGIN;

-- ===== Level 1: الجداول التي تشير لجداول أخرى =====
DELETE FROM public.message_reactions;
DELETE FROM public.comment_likes;
DELETE FROM public.saved_posts;
DELETE FROM public.feature_votes;
DELETE FROM public.reputation_log;
DELETE FROM public.daily_rewards_log;
DELETE FROM public.user_achievements;
DELETE FROM public.verification_requests;
DELETE FROM public.notifications;
DELETE FROM public.reports;
DELETE FROM public.blocks;
DELETE FROM public.follows;
DELETE FROM public.likes;

-- ===== Level 2: تعتمد على posts / messages =====
DELETE FROM public.comments;
DELETE FROM public.messages;
DELETE FROM public.message_requests;

-- ===== Level 3: تعتمد على conversations / profiles =====
DELETE FROM public.conversations;
DELETE FROM public.posts;
DELETE FROM public.achievements;

-- ===== Level 4: profiles أخيرًا =====
DELETE FROM public.profiles;

COMMIT;

-- إعادة تفعيل RLS
SET row_security = on;

-- ============================================================
-- Reset auto-increment sequences (إن وُجدت)
-- ============================================================
-- ملاحظة: كل الجداول تستخدم UUID كـ PK، فلا توجد sequences لإعادة تعيينها

-- ============================================================
-- التحقق: عدّ الصفوف في كل جدول بعد الحذف
-- ============================================================
SELECT 'posts' AS table_name, COUNT(*) AS rows FROM public.posts
UNION ALL SELECT 'comments', COUNT(*) FROM public.comments
UNION ALL SELECT 'profiles', COUNT(*) FROM public.profiles
UNION ALL SELECT 'messages', COUNT(*) FROM public.messages
UNION ALL SELECT 'notifications', COUNT(*) FROM public.notifications
UNION ALL SELECT 'follows', COUNT(*) FROM public.follows
UNION ALL SELECT 'likes', COUNT(*) FROM public.likes
UNION ALL SELECT 'saved_posts', COUNT(*) FROM public.saved_posts
UNION ALL SELECT 'blocks', COUNT(*) FROM public.blocks
UNION ALL SELECT 'reports', COUNT(*) FROM public.reports
UNION ALL SELECT 'conversations', COUNT(*) FROM public.conversations
UNION ALL SELECT 'message_requests', COUNT(*) FROM public.message_requests
UNION ALL SELECT 'message_reactions', COUNT(*) FROM public.message_reactions
UNION ALL SELECT 'comment_likes', COUNT(*) FROM public.comment_likes
UNION ALL SELECT 'feature_votes', COUNT(*) FROM public.feature_votes
UNION ALL SELECT 'reputation_log', COUNT(*) FROM public.reputation_log
UNION ALL SELECT 'daily_rewards_log', COUNT(*) FROM public.daily_rewards_log
UNION ALL SELECT 'user_achievements', COUNT(*) FROM public.user_achievements
UNION ALL SELECT 'verification_requests', COUNT(*) FROM public.verification_requests
UNION ALL SELECT 'achievements', COUNT(*) FROM public.achievements
ORDER BY rows DESC;

-- ============================================================
-- ملاحظة حول auth.users:
-- لم يتم حذف المستخدمين من auth.users أعلاه.
-- لحذفهم أيضًا، استخدم الكود التالي (يحذف كل المستخدمين ما عدا أول مستخدم):
--
-- DELETE FROM auth.users
-- WHERE id NOT IN (
--   SELECT id FROM auth.users ORDER BY created_at LIMIT 1
-- );
--
-- أو لحذف كل المستخدمين بدون استثناء:
-- DELETE FROM auth.users;
-- DELETE FROM auth.identities;
-- DELETE FROM auth.sessions;
-- DELETE FROM auth.refresh_tokens;
-- DELETE FROM auth.mfa_factors;
-- DELETE FROM auth.mfa_challenges;
-- ============================================================

-- ============================================================
-- إعادة إنشاء إنجازات افتراضية (اختياري)
-- ============================================================
-- إذا أردت إعادة تعريف الإنجازات الافتراضية بعد الحذف،
-- شغّل ملف scripts/achievements-system-upgrade.sql

-- ✅ انتهى. ستجد جدولًا أعلاه يوضح عدد الصفوف في كل جدول بعد الحذف.
