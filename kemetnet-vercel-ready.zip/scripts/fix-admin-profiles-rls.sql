-- ============================================================
-- KemetNet — Fix Admin RLS on Profiles
-- ============================================================
-- المشكلة: profiles لها سياسة UPDATE فقط للمالك نفسه
--   (profiles_update_self: id = auth.uid())
--   المدراء لا يستطيعون تعديل حسابات الآخرين (توثيق/حذف/تقييد)
--
-- الحل: إضافة صلاحية UPDATE للمدراء بصلاحية manage_users
-- ============================================================
-- يُشغّل في Supabase Dashboard → SQL Editor → New query
-- ============================================================

-- 1) حذف السياسة القديمة (تسمح فقط للمالك نفسه)
DROP POLICY IF EXISTS "profiles_update_self" ON public.profiles;
DROP POLICY IF EXISTS "profiles_update_self_or_admin" ON public.profiles;
DROP POLICY IF EXISTS "Staff can restrict users" ON public.profiles;

-- 2) سياسة جديدة: المالك نفسه أو من يملك صلاحية manage_users
CREATE POLICY "profiles_update_self_or_staff" ON public.profiles
  FOR UPDATE USING (
    id = auth.uid()
    OR public.has_permission('manage_users')
  );

-- 3) سياسة DELETE: المالك نفسه أو من يملك صلاحية manage_users
DROP POLICY IF EXISTS "profiles_delete_self" ON public.profiles;
CREATE POLICY "profiles_delete_self_or_staff" ON public.profiles
  FOR DELETE USING (
    id = auth.uid()
    OR public.has_permission('manage_users')
  );

-- 4) توثيق حسابات المالكين تلقائيًا
UPDATE public.profiles
SET is_verified = true,
    verified_type = 'official',
    verified_at = COALESCE(verified_at, now())
WHERE username IN ('kemetnet', 'kemetnet_admin')
  AND (is_verified = false OR is_verified IS NULL);

-- 5) التحقق
SELECT '✅ Admin RLS on profiles fixed' AS status;

SELECT username, is_verified, verified_type, role, is_admin
FROM public.profiles
WHERE username IN ('kemetnet', 'kemetnet_admin')
ORDER BY username;
