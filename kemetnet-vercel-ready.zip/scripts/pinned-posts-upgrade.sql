-- =====================================================
-- مشرق - المنشورات المثبتة (Pinned Posts) + العدّادات الإضافية
-- آمن للتشغيل المتكرر
-- =====================================================

-- =====================================================
-- 1. إضافة حقل is_pinned لجدول posts
-- =====================================================
ALTER TABLE public.posts ADD COLUMN IF NOT EXISTS is_pinned BOOLEAN DEFAULT FALSE;
ALTER TABLE public.posts ADD COLUMN IF NOT EXISTS pinned_at TIMESTAMPTZ;

-- فهرس لتسريع جلب المنشورات المثبتة لكل مستخدم
CREATE INDEX IF NOT EXISTS idx_posts_pinned ON public.posts (user_id, is_pinned) WHERE is_pinned = TRUE;

-- =====================================================
-- 2. Trigger: ضمان أن المنشور المثبت واحد فقط لكل مستخدم
-- =====================================================
CREATE OR REPLACE FUNCTION public.ensure_single_pinned_post()
RETURNS TRIGGER AS $$
BEGIN
  -- إذا كان المنشور الجديد مثبتاً، أزل التثبيت عن باقي منشورات المستخدم
  IF NEW.is_pinned = TRUE THEN
    UPDATE public.posts 
    SET is_pinned = FALSE, pinned_at = NULL
    WHERE user_id = NEW.user_id 
      AND id != NEW.id 
      AND is_pinned = TRUE;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trigger_ensure_single_pinned ON public.posts;
CREATE TRIGGER trigger_ensure_single_pinned
  BEFORE INSERT OR UPDATE OF is_pinned ON public.posts
  FOR EACH ROW
  WHEN (NEW.is_pinned = TRUE)
  EXECUTE FUNCTION public.ensure_single_pinned_post();

-- =====================================================
-- ملاحظات:
-- 1. كل مستخدم يمكنه تثبيت منشور واحد فقط (يُلغي القديم تلقائياً)
-- 2. المنشور المثبت يظهر في أعلى ملفه الشخصي
-- 3. RLS الموجودة تكفي (المستخدم يعدّل منشوراته فقط)
-- =====================================================
