-- =====================================================
-- مشرق - آخر ظهور (Last Seen) + إعدادات الخصوصية
-- آمن للتشغيل المتكرر
-- =====================================================

-- =====================================================
-- 1. إضافة حقول آخر ظهور + إعدادات الخصوصية لجدول profiles
-- =====================================================
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS last_seen TIMESTAMPTZ;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS show_last_seen BOOLEAN DEFAULT TRUE;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS show_online_status BOOLEAN DEFAULT TRUE;

-- =====================================================
-- 2. تحديث last_seen عند تسجيل الدخول أو النشاط
-- =====================================================
CREATE OR REPLACE FUNCTION public.update_last_seen(target_user_id UUID)
RETURNS VOID AS $$
BEGIN
  UPDATE public.profiles 
  SET last_seen = NOW()
  WHERE id = target_user_id AND show_last_seen = TRUE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

GRANT EXECUTE ON FUNCTION public.update_last_seen(UUID) TO authenticated;

-- =====================================================
-- ملاحظات:
-- 1. last_seen: يُحدّث فقط إذا كان show_last_seen = TRUE
-- 2. show_online_status: يتحكم في إظهار online/away/offline
-- 3. يمكن للمستخدم إخفاء آخر ظهور من الإعدادات
-- =====================================================
