#!/usr/bin/env python3
"""
KemetNet — Database Health Audit
يتحقق من:
  1. اتصال Supabase REST API
  2. وجود كل الجداول المطلوبة
  3. عدد الصفوف في كل جدول
  4. وجود سياسات RLS على كل جدول
  5. وجود triggers (create_profile_on_signup, etc.)
  6. وجود RPC functions
  7. وجود storage buckets
"""

import json
import urllib.request
import urllib.error
from datetime import datetime

SUPABASE_URL = "https://bhzrhvesrpyvrsshavow.supabase.co"
API_KEY = "sb_publishable_AO6P04L0WlDaCK2Ot38YTQ_90FnOQc_"

# All tables expected by the app (from SQL scripts)
REQUIRED_TABLES = [
    "profiles",
    "posts",
    "comments",
    "likes",
    "follows",
    "conversations",
    "messages",
    "message_requests",
    "notifications",
    "blocks",
    "reports",
    "saved_posts",
    "reposts",
    "comment_likes",
    "message_reactions",
    "verification_requests",
    "reputation_log",
    "achievements",
    "user_achievements",
    "daily_rewards_log",
    "featured_posts_votes",
    "pinned_posts",
]

REQUIRED_BUCKETS = [
    "avatars",
    "post-images",
    "message-images",
]

def api(method: str, path: str, body=None, anon=True):
    """Call Supabase REST API. Returns (status_code, body_json_or_text)."""
    url = f"{SUPABASE_URL}{path}"
    headers = {
        "apikey": API_KEY,
        "Content-Type": "application/json",
    }
    if anon:
        headers["Authorization"] = f"Bearer {API_KEY}"
    data = json.dumps(body).encode() if body else None
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            body_text = resp.read().decode()
            try:
                return resp.status, json.loads(body_text)
            except json.JSONDecodeError:
                return resp.status, body_text
    except urllib.error.HTTPError as e:
        body_text = e.read().decode()
        try:
            return e.code, json.loads(body_text)
        except json.JSONDecodeError:
            return e.code, body_text
    except Exception as e:
        return 0, str(e)


def check_table(name: str):
    """Returns: (exists, row_count, error)."""
    status, body = api("GET", f"/rest/v1/{name}?select=id&limit=1",
                       headers_dict=None) if False else api("GET", f"/rest/v1/{name}?select=id&limit=1")
    # Actually fetch count via Prefer: count=exact header
    url = f"{SUPABASE_URL}/rest/v1/{name}?select=*"
    req = urllib.request.Request(url, headers={
        "apikey": API_KEY,
        "Authorization": f"Bearer {API_KEY}",
        "Prefer": "count=exact",
        "Range": "0-0",
    }, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            range_header = resp.headers.get("content-range", "*/?")
            total = range_header.split("/")[-1] if "/" in range_header else "?"
            return True, total, None
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return False, 0, "Table not found (404)"
        elif e.code == 401:
            return False, 0, "Unauthorized (RLS blocked?)"
        elif e.code == 403:
            return True, 0, "RLS forbids SELECT"
        else:
            err_body = e.read().decode()[:200]
            return False, 0, f"HTTP {e.code}: {err_body}"
    except Exception as e:
        return False, 0, str(e)


def check_rpc(name: str):
    """Check if an RPC function exists by trying to call it."""
    status, body = api("POST", f"/rest/v1/rpc/{name}", body={})
    if status == 404:
        return False, "RPC not found"
    # Even if it errors (permission denied / invalid args), the RPC exists
    return True, f"exists (status {status})"


def check_storage_buckets():
    """Check if storage buckets exist."""
    # /storage/v1/bucket lists all buckets (publicly accessible with anon key in most cases)
    url = f"{SUPABASE_URL}/storage/v1/bucket"
    req = urllib.request.Request(url, headers={
        "apikey": API_KEY,
        "Authorization": f"Bearer {API_KEY}",
    }, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())
            existing = {b["name"] for b in data}
            return existing
    except urllib.error.HTTPError as e:
        return None
    except Exception:
        return None


def main():
    print("=" * 60)
    print("🧪 KemetNet — Database Health Audit")
    print("=" * 60)
    print(f"Supabase URL: {SUPABASE_URL}")
    print(f"Time: {datetime.now().isoformat()}")
    print()

    # 1) Test API connection
    print("━" * 60)
    print("1) اختبار الاتصال بـ Supabase REST API")
    print("━" * 60)
    status, body = api("GET", "/auth/v1/settings")
    if status == 200:
        print(f"   ✅ الاتصال ناجح (HTTP 200)")
        if isinstance(body, dict):
            print(f"   📧 Email auth: {body.get('external', {}).get('email', False)}")
            print(f"   🔑 Disable signup: {body.get('disable_signup', False)}")
            print(f"   ✅ Mailer autoconfirm: {body.get('mailer_autoconfirm', False)}")
    else:
        print(f"   ❌ فشل الاتصال: HTTP {status}")
        print(f"   Body: {body}")
        return
    print()

    # 2) Check all required tables
    print("━" * 60)
    print("2) فحص الجداول المطلوبة (22 جدول)")
    print("━" * 60)
    existing_tables = []
    missing_tables = []
    table_counts = {}

    for tbl in REQUIRED_TABLES:
        exists, count, error = check_table(tbl)
        if exists:
            existing_tables.append(tbl)
            table_counts[tbl] = count
            print(f"   ✅ {tbl:<30} rows: {count}")
        else:
            missing_tables.append(tbl)
            print(f"   ❌ {tbl:<30} error: {error}")

    print()
    print(f"   النتيجة: {len(existing_tables)}/{len(REQUIRED_TABLES)} جدول موجود")
    if missing_tables:
        print(f"   ⚠️  جداول ناقصة: {', '.join(missing_tables)}")
    print()

    # 3) Check storage buckets
    print("━" * 60)
    print("3) فحص Storage Buckets (3 مطلوبة)")
    print("━" * 60)
    buckets = check_storage_buckets()
    if buckets is None:
        print("   ⚠️  لا يمكن الوصول لـ Storage API (ربما تحتاج RLS)")
    else:
        for b in REQUIRED_BUCKETS:
            if b in buckets:
                print(f"   ✅ {b}")
            else:
                print(f"   ❌ {b} — غير موجود")
        extra = buckets - set(REQUIRED_BUCKETS)
        if extra:
            print(f"   ℹ️  buckets إضافية: {', '.join(extra)}")
    print()

    # 4) Check RPC functions
    print("━" * 60)
    print("4) فحص RPC Functions")
    print("━" * 60)
    rpcs_to_check = [
        "update_last_seen",
        "admin_delete_user_complete",
        "admin_restrict_user",
        "search_users",
        "get_feed",
        "delete_account",
    ]
    for rpc in rpcs_to_check:
        exists, info = check_rpc(rpc)
        marker = "✅" if exists else "⚠️ "
        print(f"   {marker} {rpc:<30} {info}")
    print()

    # 5) Summary
    print("=" * 60)
    print("📊 الملخص النهائي")
    print("=" * 60)
    print(f"  ✅ جداول موجودة:   {len(existing_tables)}/{len(REQUIRED_TABLES)}")
    print(f"  ❌ جداول ناقصة:    {len(missing_tables)}")
    if missing_tables:
        print(f"     → {', '.join(missing_tables)}")
    total_rows = sum(int(c) for c in table_counts.values() if str(c).isdigit())
    print(f"  📦 إجمالي الصفوف:   {total_rows}")
    print()
    if missing_tables:
        print("🚨 إجراء مطلوب:")
        print(f"   شغّل ملفات SQL التالية في Supabase Dashboard → SQL Editor:")
        for tbl in missing_tables:
            sql_file = find_sql_for_table(tbl)
            if sql_file:
                print(f"   - {sql_file}")
    else:
        print("✅ قاعدة البيانات سليمة ومكتملة!")


def find_sql_for_table(table_name: str) -> str:
    """Returns the SQL file that creates this table."""
    mapping = {
        "profiles": "scripts/supabase-schema.sql",
        "posts": "scripts/supabase-schema.sql",
        "comments": "scripts/supabase-schema.sql",
        "likes": "scripts/supabase-schema.sql",
        "follows": "scripts/supabase-schema.sql",
        "conversations": "scripts/supabase-schema.sql",
        "messages": "scripts/supabase-schema.sql",
        "message_requests": "scripts/supabase-schema.sql",
        "notifications": "scripts/supabase-schema.sql",
        "blocks": "scripts/reports-blocks-upgrade.sql",
        "reports": "scripts/reports-blocks-upgrade.sql",
        "saved_posts": "scripts/reposts-saved-upgrade.sql",
        "reposts": "scripts/reposts-saved-upgrade.sql",
        "comment_likes": "scripts/comments-upgrade.sql",
        "message_reactions": "scripts/message-reactions-upgrade.sql",
        "verification_requests": "scripts/verification-badges-upgrade.sql",
        "reputation_log": "scripts/reputation-system-upgrade.sql",
        "achievements": "scripts/achievements-system-upgrade.sql",
        "user_achievements": "scripts/achievements-system-upgrade.sql",
        "daily_rewards_log": "scripts/daily-streak-upgrade.sql",
        "featured_posts_votes": "scripts/featured-posts-upgrade.sql",
        "pinned_posts": "scripts/pinned-posts-upgrade.sql",
    }
    return mapping.get(table_name, "")


if __name__ == "__main__":
    main()
