-- ============================================================
-- KemetNet — Fix Blocks RLS Policies
-- ============================================================
-- المشكلة: "تعذّر حجب المستخدم" — RLS على blocks table يمنع INSERT
-- الحل: إعادة تفعيل RLS + إنشاء سياسات صحيحة
-- ============================================================
-- يُشغّل في Supabase Dashboard → SQL Editor
-- ============================================================

-- 1) تفعيل RLS على blocks
ALTER TABLE public.blocks ENABLE ROW LEVEL SECURITY;

-- 2) حذف السياسات القديمة
DROP POLICY IF EXISTS "blocks_select_own" ON public.blocks;
DROP POLICY IF EXISTS "blocks_insert_own" ON public.blocks;
DROP POLICY IF EXISTS "blocks_delete_own" ON public.blocks;

-- 3) إنشاء سياسات جديدة
-- SELECT: المستخدم يرى من حجبهم فقط
CREATE POLICY "blocks_select_own" ON public.blocks
  FOR SELECT USING (
    auth.uid() = blocker_id OR auth.uid() = blocked_id
  );

-- INSERT: المستخدم يُدرج حجبه فقط (blocker_id = auth.uid())
CREATE POLICY "blocks_insert_own" ON public.blocks
  FOR INSERT WITH CHECK (
    auth.uid() = blocker_id
  );

-- DELETE: المستخدم يحذف حجبه فقط
CREATE POLICY "blocks_delete_own" ON public.blocks
  FOR DELETE USING (
    auth.uid() = blocker_id
  );

-- 4) التحقق
SELECT '✅ Blocks RLS fixed' AS status;

SELECT policyname, cmd, qual
FROM pg_policies
WHERE schemaname = 'public' AND tablename = 'blocks';
