#!/usr/bin/env python3
"""
زرع بيانات تجريبية في قاعدة بيانات Supabase لمشروع مشرق
يدخل صفوفًا في جدول profiles (بشكل مباشر، مع IDs ثابتة) ثم في posts
"""
import json
import urllib.request
import urllib.error

SUPABASE_URL = "https://bhzrhvesrpyvrsshavow.supabase.co"
SUPABASE_ANON_KEY = "sb_publishable_AO6P04L0WlDaCK2Ot38YTQ_90FnOQc_"
REST_URL = f"{SUPABASE_URL}/rest/v1"

def post(path: str, data: dict | list, headers: dict = None):
    url = f"{REST_URL}/{path}"
    body = json.dumps(data).encode()
    default_headers = {
        "apikey": SUPABASE_ANON_KEY,
        "Authorization": f"Bearer {SUPABASE_ANON_KEY}",
        "Content-Type": "application/json",
        "Prefer": "return=representation,resolution=ignore-duplicates",
    }
    if headers:
        default_headers.update(headers)

    req = urllib.request.Request(url, data=body, method="POST", headers=default_headers)
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            rbody = resp.read().decode()
            return {"status": resp.status, "data": json.loads(rbody) if rbody else None}
    except urllib.error.HTTPError as e:
        return {"status": e.code, "error": e.read().decode()}
    except Exception as e:
        return {"status": 0, "error": str(e)}


def get(path: str):
    url = f"{REST_URL}/{path}"
    req = urllib.request.Request(url, headers={
        "apikey": SUPABASE_ANON_KEY,
        "Authorization": f"Bearer {SUPABASE_ANON_KEY}",
    })
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            body = resp.read().decode()
            return {"status": resp.status, "data": json.loads(body) if body else None}
    except urllib.error.HTTPError as e:
        return {"status": e.code, "error": e.read().decode()}
    except Exception as e:
        return {"status": 0, "error": str(e)}


# ملفات شخصية تجريبية (بـ IDs ثابتة UUID v4 صالحة)
SEED_PROFILES = [
    {"id": "a0000000-0000-0000-0000-000000000001", "username": "sunset_dreamer", "display_name": "حالم الغروب", "bio": "أكتب عن الأحلام والآمال ✨", "avatar_color": "#FB7185", "followers_count": 248, "following_count": 92, "posts_count": 18},
    {"id": "a0000000-0000-0000-0000-000000000002", "username": "tech_wizard", "display_name": "ساحر التقنية", "bio": "مهووس بالكود والابتكار ⚡", "avatar_color": "#A78BFA", "followers_count": 412, "following_count": 105, "posts_count": 32},
    {"id": "a0000000-0000-0000-0000-000000000003", "username": "wandering_soul", "display_name": "روحٌ ضائعة", "bio": "أبحث عن الجمال في كل زاوية 🌍", "avatar_color": "#34D399", "followers_count": 189, "following_count": 78, "posts_count": 24},
    {"id": "a0000000-0000-0000-0000-000000000004", "username": "kitchen_queen", "display_name": "ملكة المطبخ", "bio": "وصفات من القلب 🍯", "avatar_color": "#FBBF24", "followers_count": 567, "following_count": 41, "posts_count": 47},
    {"id": "a0000000-0000-0000-0000-000000000005", "username": "midnight_poet", "display_name": "شاعر منتصف الليل", "bio": "كلمات تنبض في السكون 🌙", "avatar_color": "#60A5FA", "followers_count": 321, "following_count": 67, "posts_count": 28},
]

SEED_POSTS = [
    {"user_id": "a0000000-0000-0000-0000-000000000001", "content": "كل غروب يحمل وعدًا بفجر جديد. لا تتوقف عن الحلم ✨", "category": "inspire", "mood": "reflective", "tags": ["غروب", "حلم", "أمل"], "likes_count": 248, "comments_count": 12},
    {"user_id": "a0000000-0000-0000-0000-000000000002", "content": "الذكاء الاصطناعي لا يحل محل البشر، بل يحررهم للإبداع الحقيقي 🤖⚡", "category": "tech", "mood": "energetic", "tags": ["AI", "تقنية", "مستقبل"], "likes_count": 412, "comments_count": 28},
    {"user_id": "a0000000-0000-0000-0000-000000000003", "content": "في زاويةٍ صغيرة من طوكيو، وجدت مقهى يبيع الزمن مع القهوة ☕", "category": "travel", "mood": "calm", "tags": ["طوكيو", "سفر"], "likes_count": 189, "comments_count": 9},
    {"user_id": "a0000000-0000-0000-0000-000000000004", "content": "وصفة اليوم: كعك العسل بالزعفران. الحلاوة تبدأ من الصبر 🍯✨", "category": "food", "mood": "happy", "tags": ["وصفة", "عسل"], "likes_count": 567, "comments_count": 34},
    {"user_id": "a0000000-0000-0000-0000-000000000005", "content": "في منتصف الليل، تكتب الكلمات ما يعجز عنه النهار 🌙", "category": "thoughts", "mood": "reflective", "tags": ["شعر", "ليل"], "likes_count": 321, "comments_count": 18},
    {"user_id": "a0000000-0000-0000-0000-000000000001", "content": "النجوم لا تنطفئ، فقط نحن نتوقف عن النظر إليها 🌟", "category": "inspire", "mood": "grateful", "tags": ["نجوم", "تأمل"], "likes_count": 432, "comments_count": 22},
    {"user_id": "a0000000-0000-0000-0000-000000000002", "content": "بنيت تطبيقًا جديدًا بـ Next.js و Supabase في يوم واحد. القوة في البساطة 💪", "category": "tech", "mood": "energetic", "tags": ["NextJS", "Supabase", "dev"], "likes_count": 678, "comments_count": 41},
    {"user_id": "a0000000-0000-0000-0000-000000000003", "content": "الجبال تذكرنا بأن العلو يتطلب صبرًا وأنفاسًا صادقة ⛰️", "category": "travel", "mood": "calm", "tags": ["جبال", "طبيعة"], "likes_count": 298, "comments_count": 14},
    {"user_id": "a0000000-0000-0000-0000-000000000004", "content": "الحلوى العربية ليست طعامًا، بل قصص تُروى على مائدة الإفطار 🍮", "category": "food", "mood": "happy", "tags": ["حلوى", "تراث"], "likes_count": 384, "comments_count": 19},
    {"user_id": "a0000000-0000-0000-0000-000000000005", "content": "الكتابة في الظلام أصدق من الكتابة في النور 🌙✍️", "category": "thoughts", "mood": "reflective", "tags": ["كتابة", "ليل"], "likes_count": 267, "comments_count": 15},
]


def main():
    print("=" * 60)
    print("🌱 زرع بيانات تجريبية في قاعدة بيانات مشرق")
    print("=" * 60)
    print()

    # 1. فحص الحالة الحالية
    print("📊 الفحص الحالي...")
    r = get("profiles?select=*&limit=1")
    profiles_empty = r["status"] == 200 and (not r["data"] or len(r["data"]) == 0)
    print(f"  - profiles: {'فارغ' if profiles_empty else 'يحتوي على بيانات'}")

    r = get("posts?select=*&limit=1")
    posts_empty = r["status"] == 200 and (not r["data"] or len(r["data"]) == 0)
    print(f"  - posts: {'فارغ' if posts_empty else 'يحتوي على بيانات'}")
    print()

    # 2. إدخال الملفات الشخصية
    if profiles_empty:
        print("➕ إدخال الملفات الشخصية التجريبية...")
        # الإدخال دفعة واحدة
        r = post("profiles", SEED_PROFILES)
        if r["status"] in (200, 201):
            print(f"  ✅ تم إدخال {len(SEED_PROFILES)} ملف شخصي")
        else:
            print(f"  ❌ فشل: {r}")
            print("  ℹ️  قد تحتاج الجداول إلى سياسة INSERT مختلفة")
            # محاولة إدخال فردي
            print("  🔄 محاولة إدخال فردي...")
            success = 0
            for p in SEED_PROFILES:
                r = post("profiles", p)
                if r["status"] in (200, 201):
                    success += 1
                else:
                    print(f"    - {p['username']}: {r.get('error', '')[:80]}")
            print(f"  ✅ نجح {success}/{len(SEED_PROFILES)}")
    else:
        print("⏭️  الملفات الشخصية تحتوي بالفعل على بيانات، تخطٍٍ")
    print()

    # 3. إدخال المنشورات
    if posts_empty:
        print("➕ إدخال المنشورات التجريبية...")
        r = post("posts", SEED_POSTS)
        if r["status"] in (200, 201):
            print(f"  ✅ تم إدخال {len(SEED_POSTS)} منشور")
        else:
            print(f"  ❌ فشل: {r.get('error', '')[:200]}")
            # محاولة فردية
            print("  🔄 محاولة إدخال فردي...")
            success = 0
            for p in SEED_POSTS:
                r = post("posts", p)
                if r["status"] in (200, 201):
                    success += 1
                else:
                    print(f"    - خطأ: {r.get('error', '')[:80]}")
            print(f"  ✅ نجح {success}/{len(SEED_POSTS)}")
    else:
        print("⏭️  المنشورات تحتوي بالفعل على بيانات، تخطٍٍ")
    print()

    # 4. التحقق النهائي
    print("🔍 التحقق النهائي...")
    r = get("profiles?select=*")
    if r["status"] == 200:
        print(f"  - profiles: {len(r['data'])} صف")
    r = get("posts?select=*")
    if r["status"] == 200:
        print(f"  - posts: {len(r['data'])} صف")
    print()
    print("✨ تم!")


if __name__ == "__main__":
    main()
