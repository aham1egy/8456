-- =====================================================
-- مشرق - نظام إعادة النشر (Reposts) + المشاركة كصورة + الحفظ الدائم
-- آمن للتشغيل المتكرر
-- =====================================================

-- =====================================================
-- 1. إضافة حقول إعادة النشر لجدول posts
-- =====================================================
ALTER TABLE public.posts ADD COLUMN IF NOT EXISTS repost_of UUID REFERENCES public.posts(id) ON DELETE SET NULL;
ALTER TABLE public.posts ADD COLUMN IF NOT EXISTS reposts_count INTEGER DEFAULT 0;

CREATE INDEX IF NOT EXISTS idx_posts_repost_of ON public.posts (repost_of) WHERE repost_of IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_posts_reposts_count ON public.posts (reposts_count DESC);

-- تحديث CHECK constraint للسماح بمحتوى فارغ إذا كان repost (لا حاجة لمحتوى أصلي)
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.check_constraints
    WHERE constraint_name = 'posts_content_check'
  ) THEN
    ALTER TABLE public.posts DROP CONSTRAINT posts_content_check;
  END IF;
END $$;

ALTER TABLE public.posts ADD CONSTRAINT posts_content_check
  CHECK (length(content) BETWEEN 1 AND 2000 OR repost_of IS NOT NULL);

-- =====================================================
-- 2. جدول المنشورات المحفوظة دائماً (saved_posts)
-- =====================================================
CREATE TABLE IF NOT EXISTS public.saved_posts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  post_id UUID NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  UNIQUE(user_id, post_id)
);

CREATE INDEX IF NOT EXISTS idx_saved_posts_user ON public.saved_posts (user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_saved_posts_post ON public.saved_posts (post_id);

ALTER TABLE public.saved_posts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "saved_posts_select_own" ON public.saved_posts;
CREATE POLICY "saved_posts_select_own" ON public.saved_posts FOR SELECT 
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "saved_posts_insert_own" ON public.saved_posts;
CREATE POLICY "saved_posts_insert_own" ON public.saved_posts FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "saved_posts_delete_own" ON public.saved_posts;
CREATE POLICY "saved_posts_delete_own" ON public.saved_posts FOR DELETE 
  USING (auth.uid() = user_id);

-- =====================================================
-- 3. Trigger لتحديث reposts_count
-- =====================================================
CREATE OR REPLACE FUNCTION public.update_reposts_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NEW.repost_of IS NOT NULL THEN
      UPDATE public.posts SET reposts_count = reposts_count + 1 WHERE id = NEW.repost_of;
    END IF;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    IF OLD.repost_of IS NOT NULL THEN
      UPDATE public.posts SET reposts_count = GREATEST(reposts_count - 1, 0) WHERE id = OLD.repost_of;
    END IF;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trigger_update_reposts_count ON public.posts;
CREATE TRIGGER trigger_update_reposts_count
  AFTER INSERT OR DELETE ON public.posts
  FOR EACH ROW EXECUTE FUNCTION public.update_reposts_count();

-- =====================================================
-- 4. إشعار عند إعادة النشر
-- =====================================================
CREATE OR REPLACE FUNCTION public.notify_on_repost()
RETURNS TRIGGER AS $$
DECLARE
  original_owner UUID;
  reposter_name TEXT;
BEGIN
  IF NEW.repost_of IS NULL THEN
    RETURN NEW;
  END IF;

  SELECT user_id INTO original_owner FROM public.posts WHERE id = NEW.repost_of;
  IF original_owner IS NULL OR original_owner = NEW.user_id THEN
    RETURN NEW;
  END IF;

  SELECT display_name INTO reposter_name FROM public.profiles WHERE id = NEW.user_id;

  INSERT INTO public.notifications (user_id, actor_id, type, title, body, post_id)
  VALUES (
    original_owner,
    NEW.user_id,
    'system',
    COALESCE(reposter_name, 'مستخدم') || ' أعادة نشر منشورك',
    NULL,
    NEW.repost_of
  );

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trigger_notify_on_repost ON public.posts;
CREATE TRIGGER trigger_notify_on_repost
  AFTER INSERT ON public.posts
  FOR EACH ROW
  WHEN (NEW.repost_of IS NOT NULL)
  EXECUTE FUNCTION public.notify_on_repost();

-- =====================================================
-- 5. تفعيل Realtime
-- =====================================================
ALTER PUBLICATION supabase_realtime ADD TABLE public.saved_posts;

-- =====================================================
-- ملاحظات:
-- 1. repost_of: معرف المنشور الأصلي (NULL للمنشورات العادية)
-- 2. reposts_count: عدد المرات التي أُعيد فيها نشر المنشور
-- 3. saved_posts: منشورات محفوظة دائماً (مختلفة عن الإعجاب)
-- 4. عند إعادة النشر: إشعار تلقائي لصاحب المنشور الأصلي
-- 5. المستخدم يمكنه إعادة نشر منشور واحد فقط (UNIQUE على user_id + repost_of)
-- =====================================================
