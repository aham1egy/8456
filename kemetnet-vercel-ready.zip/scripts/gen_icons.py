#!/usr/bin/env python3
# إنشاء أيقونات مشروع مشرق - Mishri PWA Icons
# يولّد أيقونات بتصميم شروق الشمس الفريد

import struct
import zlib
import os
import math
from pathlib import Path

OUT_DIR = Path("/home/z/my-project/public/icons")
OUT_DIR.mkdir(parents=True, exist_ok=True)


def make_png(width: int, height: int, pixels: bytes) -> bytes:
    """توليد PNG من بيانات البكسلات RGBA"""
    def chunk(ctype: bytes, data: bytes) -> bytes:
        c = ctype + data
        return struct.pack(">I", len(data)) + c + struct.pack(">I", zlib.crc32(c) & 0xffffffff)

    sig = b"\x89PNG\r\n\x1a\n"
    ihdr = struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0)
    raw = b""
    stride = width * 4
    for y in range(height):
        raw += b"\x00" + pixels[y * stride:(y + 1) * stride]
    comp = zlib.compress(raw, 9)
    return sig + chunk(b"IHDR", ihdr) + chunk(b"IDAT", comp) + chunk(b"IEND", b"")


def lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


def mix(c1, c2, t):
    return tuple(int(lerp(c1[i], c2[i], t)) for i in range(3))


def render_mishri_icon(size: int) -> bytes:
    """توليد أيقونة مشريق: خلفية متدرجة + شمس مشععة"""
    pixels = bytearray(size * size * 4)

    # ألوان مشرق
    SUN_TOP = (252, 211, 77)     # FCD34D
    SUN_BOT = (245, 158, 11)     # F59E0B
    BG_TOP = (251, 113, 133)     # FB7185
    BG_MID = (167, 139, 250)     # A78BFA
    BG_BOT = (30, 27, 75)        # 1E1B4B
    RAY = (252, 211, 77, 200)    # شعاع ذهبي

    cx = size / 2
    cy = size * 0.55  # الشمس أقرب للأسفل قليلاً (شروق)
    sun_r = size * 0.22
    ray_r = size * 0.45

    for y in range(size):
        for x in range(size):
            idx = (y * size + x) * 4

            # خلفية متدرجة عمودية
            t_bg = y / size
            if t_bg < 0.5:
                bg = mix(BG_TOP, BG_MID, t_bg * 2)
            else:
                bg = mix(BG_MID, BG_BOT, (t_bg - 0.5) * 2)

            dx = x - cx
            dy = y - cy
            dist = math.sqrt(dx * dx + dy * dy)

            # الشعاع الشمسي
            angle = math.atan2(dy, dx)
            ray_intensity = 0.0
            for i in range(12):
                a = (i / 12) * 2 * math.pi
                ray_dir = abs(((angle - a + math.pi) % (2 * math.pi)) - math.pi)
                if ray_dir < 0.18:  # عرض الشعاع
                    intensity = (1 - ray_dir / 0.18) * max(0, 1 - dist / ray_r)
                    ray_intensity = max(ray_intensity, intensity * 0.6)

            # الشمس نفسها
            if dist < sun_r:
                sun_t = dist / sun_r
                sun_color = mix(SUN_TOP, SUN_BOT, sun_t)
                # دمج الشمس فوق الخلفية
                alpha = 1.0
                r, g, b = sun_color
            elif dist < sun_r + 4:
                # هالة حول الشمس
                halo_t = (dist - sun_r) / 4
                halo_alpha = (1 - halo_t) * 0.8
                sun_color = mix(SUN_TOP, SUN_BOT, 0.5)
                r = int(bg[0] * (1 - halo_alpha) + sun_color[0] * halo_alpha)
                g = int(bg[1] * (1 - halo_alpha) + sun_color[1] * halo_alpha)
                b = int(bg[2] * (1 - halo_alpha) + sun_color[2] * halo_alpha)
                alpha = 1.0
            else:
                # إضافة الشعاع فوق الخلفية
                if ray_intensity > 0:
                    ray_color = SUN_TOP
                    r = int(bg[0] * (1 - ray_intensity) + ray_color[0] * ray_intensity)
                    g = int(bg[1] * (1 - ray_intensity) + ray_color[1] * ray_intensity)
                    b = int(bg[2] * (1 - ray_intensity) + ray_color[2] * ray_intensity)
                else:
                    r, g, b = bg
                alpha = 1.0

            # إضافة حدود دائرية ناعمة
            margin = 1
            if x < margin or x >= size - margin or y < margin or y >= size - margin:
                r, g, b = mix((r, g, b), bg, 0.5)

            pixels[idx] = r
            pixels[idx + 1] = g
            pixels[idx + 2] = b
            pixels[idx + 3] = 255

    return bytes(pixels)


def main():
    for size in [192, 256, 384, 512]:
        print(f"Generating icon-{size}.png ...")
        pixels = render_mishri_icon(size)
        png_data = make_png(size, size, pixels)
        path = OUT_DIR / f"icon-{size}.png"
        path.write_bytes(png_data)
        print(f"  -> {path} ({len(png_data)} bytes)")

    # أيقونة favicon صغيرة
    print("Generating favicon-32.png ...")
    pixels = render_mishri_icon(32)
    (OUT_DIR / "favicon-32.png").write_bytes(make_png(32, 32, pixels))

    print("Done!")


if __name__ == "__main__":
    main()
