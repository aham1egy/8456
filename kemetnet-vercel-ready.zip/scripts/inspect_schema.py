#!/usr/bin/env python3
"""فحص الأعمدة الفعلية في الجداول الموجودة"""
import json
import urllib.request

SUPABASE_URL = "https://bhzrhvesrpyvrsshavow.supabase.co"
SUPABASE_ANON_KEY = "sb_publishable_AO6P04L0WlDaCK2Ot38YTQ_90FnOQc_"

# جلب OpenAPI spec
url = f"{SUPABASE_URL}/rest/v1/?apikey={SUPABASE_ANON_KEY}"
req = urllib.request.Request(url, headers={
    "apikey": SUPABASE_ANON_KEY,
    "Authorization": f"Bearer {SUPABASE_ANON_KEY}",
})
try:
    with urllib.request.urlopen(req, timeout=15) as resp:
        data = json.loads(resp.read().decode())
        # عرض تعريفات الجداول
        defs = data.get("definitions", {})
        for table_name in ["profiles", "posts", "comments", "Row"]:
            if table_name in defs:
                print(f"\n📋 جدول: {table_name}")
                props = defs[table_name].get("properties", {})
                for col, info in props.items():
                    col_type = info.get("type", info.get("format", "unknown"))
                    print(f"  - {col}: {col_type}")
        # عرض المسارات
        paths = data.get("paths", {})
        print(f"\n📁 المسارات المتاحة:")
        for path in sorted(paths.keys())[:20]:
            print(f"  {path}")
except Exception as e:
    print(f"Error: {e}")
