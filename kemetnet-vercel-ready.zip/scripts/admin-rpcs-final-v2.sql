-- ============================================================
-- KemetNet — Admin RPCs Final Fix (CORRECTED)
-- ============================================================
-- نسخة مصححة — لا تشير إلى أعمدة قد لا تكون موجودة
-- يضيف الأعمدة المفقودة أولاً، ثم ينشئ RPCs
-- ============================================================
-- يُشغّل في Supabase Dashboard → SQL Editor → New query
-- آمن للتشغيل المتكرر (idempotent)
-- ============================================================

BEGIN;

-- ============================================================
-- 1) إضافة كل الأعمدة المفقودة إلى reports
-- ============================================================
-- (الجدول الحالي يحتوي: id, reporter_id, target_type, target_id, reason, description, status, created_at)
-- نضيف: reported_user_id (للحفاظ على توافق الكود)

ALTER TABLE public.reports ADD COLUMN IF NOT EXISTS reported_user_id uuid REFERENCES public.profiles(id) ON DELETE CASCADE;
ALTER TABLE public.reports ADD COLUMN IF NOT EXISTS post_id uuid;
ALTER TABLE public.reports ADD COLUMN IF NOT EXISTS comment_id uuid;
ALTER TABLE public.reports ADD COLUMN IF NOT EXISTS details text;
ALTER TABLE public.reports ADD COLUMN IF NOT EXISTS action_taken text;
ALTER TABLE public.reports ADD COLUMN IF NOT EXISTS admin_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL;
ALTER TABLE public.reports ADD COLUMN IF NOT EXISTS admin_note text;
ALTER TABLE public.reports ADD COLUMN IF NOT EXISTS resolved_at timestamptz;
ALTER TABLE public.reports ADD COLUMN IF NOT EXISTS updated_at timestamptz DEFAULT now();

-- نسخ description إلى details إذا كانت details فارغة (للتوافق)
UPDATE public.reports SET details = description WHERE details IS NULL AND description IS NOT NULL;

-- ============================================================
-- 2) RPC Functions (15 function)
-- ============================================================

CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.id = auth.uid()
      AND (
        p.is_admin = true
        OR p.role IN ('owner', 'admin')
        OR p.username IN ('admin', 'kemetnet', 'kemetnet_admin', 'kemet_admin', 'mohamed')
      )
  );
$$;

CREATE OR REPLACE FUNCTION public.is_owner()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.id = auth.uid()
      AND (
        p.role = 'owner'
        OR p.username = 'kemetnet'
      )
  );
$$;

CREATE OR REPLACE FUNCTION public.has_permission(perm text)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.id = auth.uid()
    AND (
      p.role = 'owner'
      OR p.username = 'kemetnet'
      OR p.role = 'admin'
      OR EXISTS (
        SELECT 1 FROM public.staff_members sm
        WHERE sm.user_id = p.id
          AND sm.active = true
          AND (
            sm.permissions @> jsonb_build_array(perm)
            OR sm.permissions @> jsonb_build_array('*')
          )
      )
    )
  );
$$;

CREATE OR REPLACE FUNCTION public.add_staff_member(
  target_user_id uuid,
  staff_role text DEFAULT 'moderator',
  perms jsonb DEFAULT '[]'::jsonb,
  staff_notes text DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  new_id uuid;
BEGIN
  IF NOT public.is_owner() THEN
    RAISE EXCEPTION 'Unauthorized: owner access required';
  END IF;
  IF target_user_id = auth.uid() THEN
    RAISE EXCEPTION 'Cannot add yourself as staff';
  END IF;
  IF EXISTS (SELECT 1 FROM public.staff_members WHERE user_id = target_user_id) THEN
    RAISE EXCEPTION 'User is already a staff member';
  END IF;
  INSERT INTO public.staff_members (user_id, role, permissions, added_by, notes)
  VALUES (target_user_id, staff_role, perms, auth.uid(), staff_notes)
  RETURNING id INTO new_id;
  UPDATE public.profiles
  SET role = staff_role, is_admin = true
  WHERE id = target_user_id;
  RETURN new_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_staff_permissions(
  target_user_id uuid,
  new_permissions jsonb,
  new_role text DEFAULT NULL,
  new_active boolean DEFAULT NULL,
  new_notes text DEFAULT NULL
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_owner() THEN
    RAISE EXCEPTION 'Unauthorized: owner access required';
  END IF;
  UPDATE public.staff_members
  SET
    permissions = COALESCE(new_permissions, permissions),
    role = COALESCE(new_role, role),
    active = COALESCE(new_active, active),
    notes = COALESCE(new_notes, notes),
    updated_at = now()
  WHERE user_id = target_user_id;
  IF new_role IS NOT NULL THEN
    UPDATE public.profiles SET role = new_role WHERE id = target_user_id;
  END IF;
  IF new_active = false THEN
    UPDATE public.profiles
    SET role = 'user', is_admin = false
    WHERE id = target_user_id AND role != 'owner';
  END IF;
  RETURN true;
END;
$$;

CREATE OR REPLACE FUNCTION public.remove_staff_member(target_user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_owner() THEN
    RAISE EXCEPTION 'Unauthorized: owner access required';
  END IF;
  IF target_user_id = auth.uid() THEN
    RAISE EXCEPTION 'Cannot remove yourself';
  END IF;
  DELETE FROM public.staff_members WHERE user_id = target_user_id;
  UPDATE public.profiles
  SET role = 'user', is_admin = false
  WHERE id = target_user_id AND role != 'owner';
  RETURN true;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_delete_user_complete(target_user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_admin() THEN
    RAISE EXCEPTION 'Unauthorized: admin access required';
  END IF;
  IF target_user_id = auth.uid() THEN
    RAISE EXCEPTION 'Cannot delete yourself';
  END IF;
  DELETE FROM auth.users WHERE id = target_user_id;
  RETURN true;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_restrict_user(
  target_user_id uuid,
  reason text,
  days int DEFAULT 7
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_admin() THEN
    RAISE EXCEPTION 'Unauthorized: admin access required';
  END IF;
  UPDATE public.profiles
  SET restricted_until = NOW() + (days || ' days')::interval,
      restriction_reason = reason
  WHERE id = target_user_id;
  RETURN true;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_unrestrict_user(target_user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_admin() THEN
    RAISE EXCEPTION 'Unauthorized: admin access required';
  END IF;
  UPDATE public.profiles
  SET restricted_until = NULL,
      restriction_reason = NULL
  WHERE id = target_user_id;
  RETURN true;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_verify_user(
  target_user_id uuid,
  verified_type text DEFAULT 'official'
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_admin() THEN
    RAISE EXCEPTION 'Unauthorized: admin access required';
  END IF;
  UPDATE public.profiles
  SET is_verified = true,
      verified_type = verified_type,
      verified_at = now()
  WHERE id = target_user_id;
  RETURN true;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_unverify_user(target_user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_admin() THEN
    RAISE EXCEPTION 'Unauthorized: admin access required';
  END IF;
  UPDATE public.profiles
  SET is_verified = false,
      verified_type = NULL,
      verified_at = NULL
  WHERE id = target_user_id;
  RETURN true;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_last_seen(target_user_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF target_user_id = auth.uid() OR public.is_admin() THEN
    UPDATE public.profiles
    SET last_seen = now()
    WHERE id = target_user_id;
  END IF;
END;
$$;

CREATE OR REPLACE FUNCTION public.search_users(query text, limit_count int DEFAULT 20)
RETURNS TABLE (
  id uuid,
  username text,
  display_name text,
  avatar_url text,
  avatar_color text,
  is_verified boolean,
  followers_count int
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT id, username, display_name, avatar_url, avatar_color, is_verified, followers_count
  FROM public.profiles
  WHERE username ILIKE '%' || query || '%'
     OR display_name ILIKE '%' || query || '%'
  ORDER BY
    CASE
      WHEN username ILIKE query || '%' THEN 1
      WHEN display_name ILIKE query || '%' THEN 2
      ELSE 3
    END,
    followers_count DESC
  LIMIT COALESCE(limit_count, 20);
$$;

CREATE OR REPLACE FUNCTION public.get_feed(
  feed_type text DEFAULT 'for-you',
  p_limit int DEFAULT 20,
  p_offset int DEFAULT 0
)
RETURNS SETOF public.posts
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF feed_type = 'following' THEN
    RETURN QUERY
      SELECT p.* FROM public.posts p
      WHERE p.user_id IN (
        SELECT followed_id FROM public.follows WHERE follower_id = auth.uid()
      )
      AND p.repost_of IS NULL
      ORDER BY p.created_at DESC
      LIMIT p_limit OFFSET p_offset;
  ELSIF feed_type = 'trending' THEN
    RETURN QUERY
      SELECT p.* FROM public.posts p
      WHERE p.repost_of IS NULL
        AND p.created_at > now() - INTERVAL '7 days'
      ORDER BY (p.likes_count + p.comments_count * 2 + p.reposts_count * 3) DESC
      LIMIT p_limit OFFSET p_offset;
  ELSE
    RETURN QUERY
      SELECT p.* FROM public.posts p
      WHERE p.repost_of IS NULL
      ORDER BY p.is_pinned DESC, p.is_featured DESC, p.created_at DESC
      LIMIT p_limit OFFSET p_offset;
  END IF;
END;
$$;

CREATE OR REPLACE FUNCTION public.delete_account(password_check text DEFAULT NULL)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  current_user_id uuid := auth.uid();
BEGIN
  IF current_user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;
  DELETE FROM public.profiles WHERE id = current_user_id;
  DELETE FROM auth.users WHERE id = current_user_id;
  RETURN true;
END;
$$;

-- ============================================================
-- 3) Indexes (فقط على أعمدة موجودة)
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_reports_status ON public.reports(status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_reports_admin ON public.reports(admin_id) WHERE admin_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_reports_pending ON public.reports(created_at DESC) WHERE status = 'pending';
CREATE INDEX IF NOT EXISTS idx_reports_reporter ON public.reports(reporter_id);

-- ============================================================
-- 4) Trigger لتحديث updated_at في reports
-- ============================================================
CREATE OR REPLACE FUNCTION public.update_reports_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS reports_updated_at ON public.reports;
CREATE TRIGGER reports_updated_at
  BEFORE UPDATE ON public.reports
  FOR EACH ROW
  EXECUTE FUNCTION public.update_reports_updated_at();

-- ============================================================
-- 5) سياسات RLS
-- ============================================================

-- profiles: SELECT all (بسيطة، لا recursion)
DO $$
DECLARE pol RECORD;
BEGIN
  FOR pol IN
    SELECT policyname FROM pg_policies
    WHERE schemaname = 'public' AND tablename = 'profiles'
  LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.profiles', pol.policyname);
  END LOOP;
END $$;

CREATE POLICY "profiles_select_all" ON public.profiles
  FOR SELECT USING (true);
CREATE POLICY "profiles_update_self" ON public.profiles
  FOR UPDATE USING (id = auth.uid());
CREATE POLICY "profiles_insert_self" ON public.profiles
  FOR INSERT WITH CHECK (id = auth.uid());
CREATE POLICY "profiles_delete_self" ON public.profiles
  FOR DELETE USING (id = auth.uid());

-- posts: staff with manage_posts can update/delete
DROP POLICY IF EXISTS "Staff can update all posts" ON public.posts;
DROP POLICY IF EXISTS "Staff can delete all posts" ON public.posts;
CREATE POLICY "Staff can update all posts" ON public.posts
  FOR UPDATE USING (public.has_permission('manage_posts'));
CREATE POLICY "Staff can delete all posts" ON public.posts
  FOR DELETE USING (public.has_permission('manage_posts'));

-- reports: staff with manage_reports
DROP POLICY IF EXISTS "Staff can update all reports" ON public.reports;
CREATE POLICY "Staff can update all reports" ON public.reports
  FOR UPDATE USING (public.has_permission('manage_reports'));

DROP POLICY IF EXISTS "reports_select" ON public.reports;
CREATE POLICY "reports_select" ON public.reports
  FOR SELECT USING (
    reporter_id = auth.uid() OR public.has_permission('manage_reports')
  );

-- verification_requests: staff with manage_verifications
DROP POLICY IF EXISTS "Staff can update verification_requests" ON public.verification_requests;
CREATE POLICY "Staff can update verification_requests" ON public.verification_requests
  FOR UPDATE USING (public.has_permission('manage_verifications'));

-- comments: staff with manage_comments
DROP POLICY IF EXISTS "Staff can delete all comments" ON public.comments;
CREATE POLICY "Staff can delete all comments" ON public.comments
  FOR DELETE USING (public.has_permission('manage_comments'));

-- staff_members: only owner can manage
DROP POLICY IF EXISTS "staff_select_admin_or_owner" ON public.staff_members;
DROP POLICY IF EXISTS "staff_insert_owner_only" ON public.staff_members;
DROP POLICY IF EXISTS "staff_update_owner_only" ON public.staff_members;
DROP POLICY IF EXISTS "staff_delete_owner_only" ON public.staff_members;

CREATE POLICY "staff_select_admin_or_owner" ON public.staff_members
  FOR SELECT USING (public.is_admin());
CREATE POLICY "staff_insert_owner_only" ON public.staff_members
  FOR INSERT WITH CHECK (public.is_owner());
CREATE POLICY "staff_update_owner_only" ON public.staff_members
  FOR UPDATE USING (public.is_owner());
CREATE POLICY "staff_delete_owner_only" ON public.staff_members
  FOR DELETE USING (public.is_owner());

COMMIT;

-- ============================================================
-- التحقق
-- ============================================================
SELECT '✅ All admin RPCs + reports columns installed (corrected v2)' AS status;

-- عرض كل الأعمدة في reports
SELECT column_name, data_type
FROM information_schema.columns
WHERE table_schema = 'public' AND table_name = 'reports'
ORDER BY ordinal_position;

-- عدّ RPC functions
SELECT COUNT(*) AS total_admin_rpcs
FROM information_schema.routines
WHERE routine_schema = 'public'
  AND routine_type = 'FUNCTION'
  AND (routine_name LIKE 'admin_%' OR routine_name = 'is_admin' OR routine_name = 'is_owner'
       OR routine_name = 'has_permission' OR routine_name = 'update_last_seen'
       OR routine_name = 'search_users' OR routine_name = 'get_feed'
       OR routine_name = 'delete_account' OR routine_name LIKE 'add_staff%'
       OR routine_name LIKE 'update_staff%' OR routine_name LIKE 'remove_staff%');
