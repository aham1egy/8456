#!/usr/bin/env python3
"""
KemetNet — Professional app icon generator.
Design: Eye of Horus (Wedjat) + sun disk (Aten) on deep lapis blue gradient.
Symbolism:
  - Eye of Horus = protection, healing, vision (perfect for a content platform)
  - Sun disk = Aten, source of life and inspiration
  - Lapis blue = Egyptian heritage (lapis lazuli prized in ancient Egypt)
  - Gold = eternity, divinity, the gods
"""

from pathlib import Path
import cairosvg
from PIL import Image
import io

PUBLIC_DIR = Path("/home/z/my-project/public")
ICONS_DIR = PUBLIC_DIR / "icons"
ICONS_DIR.mkdir(parents=True, exist_ok=True)

# Egyptian palette
LAPIS_DEEP   = "#0E2A4F"   # deep lapis (Nile night)
LAPIS_MID    = "#1F4E8C"   # mid lapis
LAPIS_LIGHT  = "#2E5C8A"   # brighter lapis
GOLD_LIGHT   = "#F5D78A"   # pale gold
GOLD_PRIMARY = "#D4A644"   # primary gold
GOLD_DARK    = "#A87A1F"   # dark gold
TERRACOTTA   = "#C97D60"   # warm accent
CREAM        = "#FFF8EB"   # background

# -----------------------------
# Main icon — Eye of Horus + sun disk on lapis background
# -----------------------------
ICON_SVG = """<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="{size}" height="{size}">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="{lapis_mid}"/>
      <stop offset="50%" stop-color="{lapis_deep}"/>
      <stop offset="100%" stop-color="#081F38"/>
    </linearGradient>
    <linearGradient id="gold" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="{gold_light}"/>
      <stop offset="50%" stop-color="{gold_primary}"/>
      <stop offset="100%" stop-color="{gold_dark}"/>
    </linearGradient>
    <linearGradient id="goldH" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="{gold_dark}"/>
      <stop offset="50%" stop-color="{gold_light}"/>
      <stop offset="100%" stop-color="{gold_dark}"/>
    </linearGradient>
    <radialGradient id="glow" cx="50%" cy="50%" r="55%">
      <stop offset="0%" stop-color="{gold_primary}" stop-opacity="0.30"/>
      <stop offset="60%" stop-color="{gold_primary}" stop-opacity="0.10"/>
      <stop offset="100%" stop-color="{gold_primary}" stop-opacity="0"/>
    </radialGradient>
    <filter id="softShadow" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur in="SourceAlpha" stdDeviation="3"/>
      <feOffset dx="0" dy="2" result="offsetblur"/>
      <feComponentTransfer><feFuncA type="linear" slope="0.5"/></feComponentTransfer>
      <feMerge>
        <feMergeNode/>
        <feMergeNode in="SourceGraphic"/>
      </feMerge>
    </filter>
  </defs>

  <!-- Background: deep lapis gradient -->
  <rect width="512" height="512" fill="url(#bg)"/>

  <!-- Soft gold glow behind eye -->
  <circle cx="256" cy="256" r="220" fill="url(#glow)"/>

  <!-- Hieroglyph-inspired cartouche frame (subtle) -->
  <rect x="28" y="28" width="456" height="456" fill="none"
        stroke="{gold_primary}" stroke-width="2.5" opacity="0.30" rx="10"/>
  <rect x="38" y="38" width="436" height="436" fill="none"
        stroke="{gold_primary}" stroke-width="1" opacity="0.18" rx="6"/>

  <!-- Corner accents (Egyptian lotus-petal motif, very subtle) -->
  <g fill="{gold_primary}" opacity="0.35">
    <path d="M 48 48 L 70 48 L 48 70 Z"/>
    <path d="M 464 48 L 442 48 L 464 70 Z"/>
    <path d="M 48 464 L 70 464 L 48 442 Z"/>
    <path d="M 464 464 L 442 464 L 464 442 Z"/>
  </g>

  <!-- Sun disk (Aten) above the eye — symbol of life -->
  <g filter="url(#softShadow)">
    <circle cx="256" cy="135" r="34" fill="url(#gold)"/>
    <circle cx="256" cy="135" r="24" fill="{lapis_deep}"/>
    <circle cx="256" cy="135" r="14" fill="url(#gold)"/>
    <circle cx="250" cy="129" r="4" fill="{gold_light}" opacity="0.95"/>
  </g>

  <!-- Sun rays connecting disk to eye -->
  <g stroke="url(#gold)" stroke-width="2.5" opacity="0.55" stroke-linecap="round">
    <line x1="256" y1="170" x2="256" y2="195"/>
    <line x1="230" y1="170" x2="222" y2="190"/>
    <line x1="282" y1="170" x2="290" y2="190"/>
  </g>

  <!-- ============== EYE OF HORUS (Wedjat) ============== -->
  <g filter="url(#softShadow)">
    <!-- Eyebrow (sweeping top curve) -->
    <path d="M 130 200
             Q 256 165 382 200
             Q 378 218 365 220
             Q 256 188 147 220
             Q 134 218 130 200 Z"
          fill="url(#gold)"/>

    <!-- Eye outline (almond) -->
    <path d="M 122 256
             Q 256 212 390 256
             Q 256 300 122 256 Z"
          fill="url(#gold)"/>

    <!-- Eye interior (dark lapis) -->
    <path d="M 138 256
             Q 256 222 374 256
             Q 256 290 138 256 Z"
          fill="{lapis_deep}"/>

    <!-- Pupil — concentric rings (Egyptian style) -->
    <circle cx="256" cy="256" r="34" fill="url(#gold)"/>
    <circle cx="256" cy="256" r="26" fill="{lapis_deep}"/>
    <circle cx="256" cy="256" r="16" fill="url(#gold)"/>
    <circle cx="256" cy="256" r="9"  fill="{lapis_deep}"/>

    <!-- Highlight on pupil -->
    <circle cx="247" cy="247" r="4.5" fill="{gold_light}" opacity="0.95"/>

    <!-- Teardrop (vertical line below pupil, falcon cheek marking) -->
    <path d="M 256 290
             L 256 380
             Q 256 402 238 405
             Q 218 405 218 386
             Q 218 372 234 372
             L 244 372
             L 244 290 Z"
          fill="url(#gold)"/>

    <!-- Side spiral (outer corner curl — falcon tail) -->
    <path d="M 390 256
             Q 415 272 418 296
             Q 420 320 398 332
             Q 380 338 366 328
             Q 384 322 393 308
             Q 402 290 393 277
             Q 384 266 374 264 Z"
          fill="url(#gold)"/>

    <!-- Small accent dots on eye corners (hieroglyph-style) -->
    <circle cx="138" cy="256" r="3.5" fill="{gold_light}"/>
    <circle cx="374" cy="256" r="3.5" fill="{gold_light}"/>
  </g>

  <!-- Bottom accent line (water/Nile symbol — fertility) -->
  <g stroke="url(#goldH)" stroke-width="2" opacity="0.45" stroke-linecap="round" fill="none">
    <path d="M 130 440 Q 180 432 220 440 Q 256 446 292 440 Q 332 432 382 440"/>
  </g>
</svg>
"""

# -----------------------------
# Favicon (32px) — minimal Eye of Horus for tiny sizes
# -----------------------------
FAVICON_SVG = """<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="32" height="32">
  <defs>
    <linearGradient id="fbg" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#1F4E8C"/>
      <stop offset="100%" stop-color="#0E2A4F"/>
    </linearGradient>
    <linearGradient id="fgold" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#F5D78A"/>
      <stop offset="100%" stop-color="#A87A1F"/>
    </linearGradient>
  </defs>
  <rect width="64" height="64" fill="url(#fbg)"/>
  <!-- eyebrow -->
  <path d="M 12 24 Q 32 18 52 24 Q 51 28 49 29 Q 32 22 15 29 Q 13 28 12 24 Z"
        fill="url(#fgold)"/>
  <!-- eye almond -->
  <path d="M 10 32 Q 32 26 54 32 Q 32 38 10 32 Z" fill="url(#fgold)"/>
  <path d="M 13 32 Q 32 28 51 32 Q 32 36 13 32 Z" fill="#0E2A4F"/>
  <!-- pupil -->
  <circle cx="32" cy="32" r="5" fill="url(#fgold)"/>
  <circle cx="32" cy="32" r="3" fill="#0E2A4F"/>
  <!-- teardrop -->
  <rect x="30" y="36" width="4" height="14" fill="url(#fgold)"/>
  <path d="M 34 50 Q 34 54 30 54 Q 26 54 26 50 Q 26 47 30 47 L 30 50 Z" fill="url(#fgold)"/>
</svg>
"""

# -----------------------------
# React component SVG (used in MishriLogo.tsx, 100x100 viewBox)
# -----------------------------
LOGO_SVG = """<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="100" height="100">
  <defs>
    <linearGradient id="lbg" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#1F4E8C"/>
      <stop offset="100%" stop-color="#0E2A4F"/>
    </linearGradient>
    <linearGradient id="lgold" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#F5D78A"/>
      <stop offset="50%" stop-color="#D4A644"/>
      <stop offset="100%" stop-color="#A87A1F"/>
    </linearGradient>
    <radialGradient id="lglow" cx="50%" cy="50%" r="55%">
      <stop offset="0%" stop-color="#D4A644" stop-opacity="0.30"/>
      <stop offset="100%" stop-color="#D4A644" stop-opacity="0"/>
    </radialGradient>
  </defs>

  <!-- Background -->
  <rect width="100" height="100" rx="22" fill="url(#lbg)"/>
  <circle cx="50" cy="50" r="42" fill="url(#lglow)"/>

  <!-- Subtle gold frame -->
  <rect x="6" y="6" width="88" height="88" fill="none"
        stroke="#D4A644" stroke-width="0.5" opacity="0.30" rx="4"/>

  <!-- Sun disk -->
  <circle cx="50" cy="22" r="6" fill="url(#lgold)"/>
  <circle cx="50" cy="22" r="4" fill="#0E2A4F"/>
  <circle cx="50" cy="22" r="2.5" fill="url(#lgold)"/>

  <!-- Sun rays -->
  <g stroke="url(#lgold)" stroke-width="0.6" opacity="0.55" stroke-linecap="round">
    <line x1="50" y1="29" x2="50" y2="33"/>
    <line x1="45" y1="29" x2="43" y2="33"/>
    <line x1="55" y1="29" x2="57" y2="33"/>
  </g>

  <!-- Eye of Horus -->
  <g>
    <!-- Eyebrow -->
    <path d="M 25 38 Q 50 31 75 38 Q 74 42 71 42.5 Q 50 36 29 42.5 Q 26 42 25 38 Z"
          fill="url(#lgold)"/>

    <!-- Eye almond -->
    <path d="M 23 50 Q 50 41 77 50 Q 50 59 23 50 Z" fill="url(#lgold)"/>
    <path d="M 26 50 Q 50 43.5 74 50 Q 50 56.5 26 50 Z" fill="#0E2A4F"/>

    <!-- Pupil -->
    <circle cx="50" cy="50" r="7" fill="url(#lgold)"/>
    <circle cx="50" cy="50" r="5" fill="#0E2A4F"/>
    <circle cx="50" cy="50" r="3" fill="url(#lgold)"/>

    <!-- Highlight -->
    <circle cx="48" cy="48" r="0.9" fill="#F5D78A" opacity="0.95"/>

    <!-- Teardrop -->
    <path d="M 50 57 L 50 76 Q 50 80 46 80.5 Q 41 80.5 41 76 Q 41 72.5 45 72.5 L 47 72.5 L 47 57 Z"
          fill="url(#lgold)"/>

    <!-- Side curl -->
    <path d="M 77 50 Q 82 53 82.5 58 Q 83 63 78 65 Q 74 66 71 64 Q 75 62.5 76.5 60 Q 78 56 76.5 53 Q 75 51 73 50.5 Z"
          fill="url(#lgold)"/>

    <!-- Corner dots -->
    <circle cx="26" cy="50" r="0.7" fill="#F5D78A"/>
    <circle cx="74" cy="50" r="0.7" fill="#F5D78A"/>
  </g>

  <!-- Bottom water accent -->
  <path d="M 25 86 Q 35 84 42 86 Q 50 87 58 86 Q 65 84 75 86"
        stroke="#D4A644" stroke-width="0.5" opacity="0.45"
        stroke-linecap="round" fill="none"/>

  <style type="text/css">
    .z-breathe { animation: breathe 2.5s ease-in-out infinite; }
    @keyframes breathe { 0%,100% { opacity: 0.9; } 50% { opacity: 1; } }
  </style>
</svg>
"""


def render_svg_to_png(svg_str: str, size: int) -> bytes:
    return cairosvg.svg2png(
        bytestring=svg_str.encode("utf-8"),
        output_width=size,
        output_height=size,
    )


def write_icons():
    fmt = dict(
        lapis_deep=LAPIS_DEEP, lapis_mid=LAPIS_MID, lapis_light=LAPIS_LIGHT,
        gold_light=GOLD_LIGHT, gold_primary=GOLD_PRIMARY, gold_dark=GOLD_DARK,
        terracotta=TERRACOTTA, cream=CREAM,
    )

    # PWA icon sizes
    for s in (192, 256, 384, 512):
        svg = ICON_SVG.format(size=s, **fmt)
        out = ICONS_DIR / f"icon-{s}.png"
        out.write_bytes(render_svg_to_png(svg, s))
        print(f"  wrote {out}")

    # Favicon 32px (special tight design)
    (ICONS_DIR / "favicon-32.png").write_bytes(render_svg_to_png(FAVICON_SVG, 32))

    # Apple touch icon 180px
    (ICONS_DIR / "apple-touch-icon.png").write_bytes(render_svg_to_png(ICON_SVG.format(size=180, **fmt), 180))
    print(f"  wrote apple-touch-icon.png")

    # Maskable icon (same as 512, full-bleed background already)
    (ICONS_DIR / "icon-maskable-512.png").write_bytes(render_svg_to_png(ICON_SVG.format(size=512, **fmt), 512))
    print(f"  wrote icon-maskable-512.png")

    # logo.svg (main brand SVG, used as favicon.svg too)
    (PUBLIC_DIR / "logo.svg").write_text(LOGO_SVG, encoding="utf-8")
    (PUBLIC_DIR / "favicon.svg").write_text(FAVICON_SVG, encoding="utf-8")
    print(f"  wrote logo.svg + favicon.svg")

    # favicon.ico (multi-size)
    ico_sizes = [(16, 16), (32, 32), (48, 48)]
    imgs = []
    for sz in ico_sizes:
        png_at_64 = render_svg_to_png(FAVICON_SVG, 64)
        im = Image.open(io.BytesIO(png_at_64)).convert("RGBA").resize(sz, Image.LANCZOS)
        imgs.append(im)
    imgs[0].save(
        PUBLIC_DIR / "favicon.ico",
        format="ICO",
        sizes=ico_sizes,
        append_images=imgs[1:],
    )
    print(f"  wrote favicon.ico")


if __name__ == "__main__":
    print("Generating KemetNet icons (Eye of Horus + Aten)...")
    write_icons()
    print("Done.")
