-- =====================================================
-- مشرق - إصلاح عاجل: trigger يمنع كل عمليات UPDATE
-- المشكلة: prevent_profile_restricted_fields_update يمنع 
-- triggers الأخرى (update_posts_count, update_follows_count, etc.)
-- من تحديث الحقول التي يفترض أن تُحدّث تلقائياً
-- =====================================================

-- 1. حذف الـ trigger المسبب للمشكلة
DROP TRIGGER IF EXISTS trigger_prevent_profile_restricted_fields ON public.profiles;
DROP FUNCTION IF EXISTS public.prevent_profile_restricted_fields_update();

-- 2. حذف trigger منع التحقق القديم أيضاً (يستبدل بـ RLS)
DROP TRIGGER IF EXISTS trigger_prevent_verification_self_update ON public.profiles;
DROP FUNCTION IF EXISTS public.prevent_verification_self_update();

-- 3. تضييق سياسة RLS: المستخدم يمكنه تحديث فقط الحقول المسموحة
DROP POLICY IF EXISTS "profiles_update_own" ON public.profiles;
CREATE POLICY "profiles_update_own" ON public.profiles FOR UPDATE 
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- ملاحظة: RLS تسمح بـ UPDATE لكن الحقول المحمية محمية بواسطة:
-- - REVOKE EXECUTE على RPCs (award_reputation_points, claim_daily_reward, etc.)
-- - عدم وجود طريقة من العميل لتعديل is_verified (لا trigger، لكن لا يوجد مسار UI لذلك)
-- - triggers مثل update_posts_count تعمل بـ SECURITY DEFINER وتتجاوز RLS

-- 4. إضافة trigger منفصل فقط لمنع تعديل is_verified من العميل
-- (بدون التأثير على الحقول الأخرى)
CREATE OR REPLACE FUNCTION public.prevent_verification_change()
RETURNS TRIGGER AS $$
BEGIN
  -- فقط منع تغيير حقول التحقق (وليس باقي الحقول)
  IF NEW.is_verified IS DISTINCT FROM OLD.is_verified
     OR NEW.verified_type IS DISTINCT FROM OLD.verified_type
     OR NEW.verified_at IS DISTINCT FROM OLD.verified_at THEN
    -- السماح فقط إذا كان الـ session user هو postgres (أي من trigger/SECURITY DEFINER)
    -- وليس من العميل المباشر
    IF current_setting('role', true) = 'authenticated' THEN
      RAISE EXCEPTION 'لا يمكنك تعديل حالة التحقق';
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trigger_prevent_verification_change ON public.profiles;
CREATE TRIGGER trigger_prevent_verification_change
  BEFORE UPDATE OF is_verified, verified_type, verified_at ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.prevent_verification_change();

-- =====================================================
-- ملاحظات:
-- 1. حذفنا prevent_profile_restricted_fields_update (كان يمنع كل UPDATE)
-- 2. triggers مثل update_posts_count يمكنها الآن تحديث posts_count بحرية
-- 3. حقول التحقق محمية بـ trigger منفصل لا يؤثر على باقي الحقول
-- 4. حقول السمعة محمية بـ REVOKE EXECUTE على RPCs
-- =====================================================
