-- =====================================================
-- مشرق - نظام التحقق (Verification Badges)
-- آمن للتشغيل المتكرر
-- =====================================================

-- =====================================================
-- 1. إضافة حقول التحقق لجدول profiles
-- =====================================================
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS is_verified BOOLEAN DEFAULT FALSE;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS verified_type TEXT CHECK (verified_type IS NULL OR verified_type IN ('official', 'business', 'creator', 'early_adopter'));
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS verified_at TIMESTAMPTZ;

-- =====================================================
-- 2. منح صلاحية تحديث is_verified (للمستخدم نفسه فقط، كتجربة)
-- ملاحظة: في الإنتاج، يجب أن يتم التحقق من قبل الإدارة
-- =====================================================
-- بما أن RLS الموجودة تسمح للمستخدم بتحديث ملفه فقط،
-- يمكن للمستخدم تفعيل التحقق لنفسه (early_adopter) كنوع من المكافأة
-- يمكن إضافة منطق تحقق أقوى لاحقاً

-- =====================================================
-- ملاحظات:
-- 1. is_verified: شارة التحقق الزرقاء
-- 2. verified_type: نوع التحقق (official, business, creator, early_adopter)
-- 3. verified_at: تاريخ التحقق
-- 4. النوع "early_adopter" متاح تلقائياً لأول 1000 مستخدم (يمكن تفعيله يدوياً)
-- =====================================================
