-- ============================================================
-- KemetNet — Roles & Staff Management System
-- ============================================================
-- يضيف:
--   1) عمود role في profiles (owner | admin | moderator | custom | user)
--   2) جدول staff_members لإدارة الموظفين وصلاحياتهم
--   3) RPC functions لإدارة الفريق (إضافة/حذف/تعديل صلاحيات)
--   4) RLS policies: فقط المالك يمكنه إدارة الموظفين
-- ============================================================
-- يُشغّل في Supabase Dashboard → SQL Editor → New query
-- آمن للتشغيل المتكرر (idempotent)
-- ============================================================

BEGIN;

-- ============================================================
-- 1) إضافة عمود role في profiles
-- ============================================================
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS role text DEFAULT 'user';

-- تعيين المالك: حساب kemetnet
UPDATE public.profiles SET role = 'owner', is_admin = true
WHERE username = 'kemetnet';

-- تعيين المالكين الإضافيين (لو موجودين)
UPDATE public.profiles SET role = 'owner', is_admin = true
WHERE username IN ('kemetnet_admin') AND role = 'user';

-- ============================================================
-- 2) جدول staff_members — كل موظف وصلاحياته
-- ============================================================
CREATE TABLE IF NOT EXISTS public.staff_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL UNIQUE REFERENCES public.profiles(id) ON DELETE CASCADE,
  role text NOT NULL DEFAULT 'moderator',  -- admin | moderator | custom
  permissions jsonb NOT NULL DEFAULT '[]'::jsonb,
  added_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  added_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  active boolean NOT NULL DEFAULT true,
  notes text
);

CREATE INDEX IF NOT EXISTS idx_staff_members_user_id ON public.staff_members(user_id);
CREATE INDEX IF NOT EXISTS idx_staff_members_active ON public.staff_members(active);

ALTER TABLE public.staff_members ENABLE ROW LEVEL SECURITY;

-- ============================================================
-- 3) تحديث is_admin() لتشمل roles
-- ============================================================
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.id = auth.uid()
      AND (
        p.is_admin = true
        OR p.role IN ('owner', 'admin')
        OR p.username IN ('admin', 'kemetnet', 'kemetnet_admin', 'kemet_admin', 'mohamed')
      )
  );
$$;

-- ============================================================
-- 4) دالة is_owner() — فقط المالك
-- ============================================================
CREATE OR REPLACE FUNCTION public.is_owner()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.id = auth.uid()
      AND (
        p.role = 'owner'
        OR p.username = 'kemetnet'
      )
  );
$$;

-- ============================================================
-- 5) دالة has_permission(perm) — فحص صلاحية معينة
-- ============================================================
CREATE OR REPLACE FUNCTION public.has_permission(perm text)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.id = auth.uid()
    AND (
      -- المالك يملك كل الصلاحيات
      p.role = 'owner'
      OR p.username = 'kemetnet'
      -- الأدمن العام يملك كل الصلاحيات
      OR p.role = 'admin'
      -- أو الموظف لديه الصلاحية المحددة في staff_members
      OR EXISTS (
        SELECT 1 FROM public.staff_members sm
        WHERE sm.user_id = p.id
          AND sm.active = true
          AND (
            sm.permissions @> jsonb_build_array(perm)
            OR sm.permissions @> jsonb_build_array('*')  -- * تعني كل الصلاحيات
          )
      )
    )
  );
$$;

-- ============================================================
-- 6) RLS على staff_members — فقط المالك يدير
-- ============================================================
DROP POLICY IF EXISTS "staff_select_admin_or_owner" ON public.staff_members;
DROP POLICY IF EXISTS "staff_insert_owner_only" ON public.staff_members;
DROP POLICY IF EXISTS "staff_update_owner_only" ON public.staff_members;
DROP POLICY IF EXISTS "staff_delete_owner_only" ON public.staff_members;

-- المدراء يقرؤون staff_members (لرؤية من هم الموظفون)
CREATE POLICY "staff_select_admin_or_owner" ON public.staff_members
  FOR SELECT USING (public.is_admin());

-- فقط المالك يضيف/يعدّل/يحذف موظفين
CREATE POLICY "staff_insert_owner_only" ON public.staff_members
  FOR INSERT WITH CHECK (public.is_owner());

CREATE POLICY "staff_update_owner_only" ON public.staff_members
  FOR UPDATE USING (public.is_owner());

CREATE POLICY "staff_delete_owner_only" ON public.staff_members
  FOR DELETE USING (public.is_owner());

-- ============================================================
-- 7) RPC: إضافة موظف جديد
-- ============================================================
CREATE OR REPLACE FUNCTION public.add_staff_member(
  target_user_id uuid,
  staff_role text DEFAULT 'moderator',
  perms jsonb DEFAULT '[]'::jsonb,
  staff_notes text DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  new_id uuid;
BEGIN
  IF NOT public.is_owner() THEN
    RAISE EXCEPTION 'Unauthorized: owner access required';
  END IF;

  IF target_user_id = auth.uid() THEN
    RAISE EXCEPTION 'Cannot add yourself as staff';
  END IF;

  -- التحقق من عدم وجوده مسبقًا
  IF EXISTS (SELECT 1 FROM public.staff_members WHERE user_id = target_user_id) THEN
    RAISE EXCEPTION 'User is already a staff member';
  END IF;

  INSERT INTO public.staff_members (user_id, role, permissions, added_by, notes)
  VALUES (target_user_id, staff_role, perms, auth.uid(), staff_notes)
  RETURNING id INTO new_id;

  -- تحديث role في profiles
  UPDATE public.profiles
  SET role = staff_role, is_admin = true
  WHERE id = target_user_id;

  RETURN new_id;
END;
$$;

-- ============================================================
-- 8) RPC: تحديث صلاحيات موظف
-- ============================================================
CREATE OR REPLACE FUNCTION public.update_staff_permissions(
  target_user_id uuid,
  new_permissions jsonb,
  new_role text DEFAULT NULL,
  new_active boolean DEFAULT NULL,
  new_notes text DEFAULT NULL
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_owner() THEN
    RAISE EXCEPTION 'Unauthorized: owner access required';
  END IF;

  UPDATE public.staff_members
  SET
    permissions = COALESCE(new_permissions, permissions),
    role = COALESCE(new_role, role),
    active = COALESCE(new_active, active),
    notes = COALESCE(new_notes, notes),
    updated_at = now()
  WHERE user_id = target_user_id;

  -- تحديث role في profiles إن تم تحديده
  IF new_role IS NOT NULL THEN
    UPDATE public.profiles
    SET role = new_role
    WHERE id = target_user_id;
  END IF;

  -- إذا تم تعطيل الموظف، أعد role إلى user
  IF new_active = false THEN
    UPDATE public.profiles
    SET role = 'user', is_admin = false
    WHERE id = target_user_id
      AND role != 'owner';
  END IF;

  RETURN true;
END;
$$;

-- ============================================================
-- 9) RPC: إزالة موظف (حذف نهائي)
-- ============================================================
CREATE OR REPLACE FUNCTION public.remove_staff_member(target_user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_owner() THEN
    RAISE EXCEPTION 'Unauthorized: owner access required';
  END IF;

  -- لا يمكن إزالة المالك
  IF target_user_id = auth.uid() THEN
    RAISE EXCEPTION 'Cannot remove yourself';
  END IF;

  DELETE FROM public.staff_members WHERE user_id = target_user_id;

  UPDATE public.profiles
  SET role = 'user', is_admin = false
  WHERE id = target_user_id
    AND role != 'owner';

  RETURN true;
END;
$$;

-- ============================================================
-- 10) سياسات RLS الجديدة للأدوار (role-based)
-- ============================================================
-- posts: تحديث/حذف للموظفين بصلاحية manage_posts
DROP POLICY IF EXISTS "Admins can update all posts" ON public.posts;
DROP POLICY IF EXISTS "Admins can delete all posts" ON public.posts;
CREATE POLICY "Staff can update all posts" ON public.posts
  FOR UPDATE USING (public.has_permission('manage_posts'));
CREATE POLICY "Staff can delete all posts" ON public.posts
  FOR DELETE USING (public.has_permission('manage_posts'));

-- reports: معالجة البلاغات
DROP POLICY IF EXISTS "Admins can update all reports" ON public.reports;
CREATE POLICY "Staff can update all reports" ON public.reports
  FOR UPDATE USING (public.has_permission('manage_reports'));

-- verification_requests: معالجة طلبات التوثيق
DROP POLICY IF EXISTS "Admins can update verification_requests" ON public.verification_requests;
CREATE POLICY "Staff can update verification_requests" ON public.verification_requests
  FOR UPDATE USING (public.has_permission('manage_verifications'));

-- comments: حذف التعليقات
DROP POLICY IF EXISTS "Admins can delete all comments" ON public.comments;
CREATE POLICY "Staff can delete all comments" ON public.comments
  FOR DELETE USING (public.has_permission('manage_comments'));

-- profiles: تقييد/حذف المستخدمين
DROP POLICY IF EXISTS "Staff can restrict users" ON public.profiles;
CREATE POLICY "Staff can restrict users" ON public.profiles
  FOR UPDATE USING (
    id = auth.uid()
    OR public.has_permission('manage_users')
  );

-- ============================================================
-- 11) Trigger: تحديث role تلقائيًا لحساب kemetnet
-- ============================================================
CREATE OR REPLACE FUNCTION public.ensure_owner_role()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.username = 'kemetnet' THEN
    NEW.role := 'owner';
    NEW.is_admin := true;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS ensure_owner_role_trigger ON public.profiles;
CREATE TRIGGER ensure_owner_role_trigger
  BEFORE INSERT OR UPDATE OF username ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.ensure_owner_role();

COMMIT;

-- ============================================================
-- التحقق النهائي
-- ============================================================
SELECT '✅ Roles & staff system installed' AS status;

-- عرض المالك
SELECT username, role, is_admin FROM public.profiles
WHERE role = 'owner' OR username = 'kemetnet';

-- عرض الموظفين (إن وجدوا)
SELECT user_id, role, permissions, active, added_at
FROM public.staff_members
ORDER BY added_at DESC;
