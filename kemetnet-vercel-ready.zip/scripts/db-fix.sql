-- ============================================================
-- KemetNet — Database Fix & Complete Setup
-- ============================================================
-- يصلح:
--   1) RLS infinite recursion على profiles
--   2) إنشاء الجداول المفقودة: reposts, featured_posts_votes, pinned_posts
--   3) إنشاء RPC functions المفقودة
--   4) تحديث سياسات RLS لتسمح للمدراء
-- ============================================================
-- يُشغّل في Supabase Dashboard → SQL Editor → New query
-- ثم Run (Ctrl+Enter)
-- ============================================================

BEGIN;

-- ============================================================
-- 1) إصلاح RLS recursion على profiles
-- ============================================================
-- المشكلة: سياسة SELECT على profiles كانت تختبر SELECT من profiles نفسها
-- الحل: استخدام دالة SECURITY DEFINER تتجاوز RLS
-- ============================================================

-- 1.1) دالة is_admin() تتجاوز RLS (SECURITY DEFINER)
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.id = auth.uid()
      AND (p.is_admin = true
           OR p.username IN ('admin', 'kemetnet', 'kemetnet_admin', 'kemet_admin', 'mohamed')
           OR (p.is_verified = true AND p.verified_type = 'official'))
  );
$$;

-- 1.2) حذف كل السياسات القديمة على profiles ثم إعادة إنشائها نظيفة
DROP POLICY IF EXISTS "Admins can read all profiles" ON public.profiles;
DROP POLICY IF EXISTS "profiles_select_policy" ON public.profiles;
DROP POLICY IF EXISTS "Users can read all profiles" ON public.profiles;
DROP POLICY IF EXISTS "Users can view profiles" ON public.profiles;
DROP POLICY IF EXISTS "profile_select_self_or_public" ON public.profiles;
DROP POLICY IF EXISTS "Public profiles are viewable" ON public.profiles;
DROP POLICY IF EXISTS "Anyone can view profiles" ON public.profiles;
DROP POLICY IF EXISTS "Profile select" ON public.profiles;
DROP POLICY IF EXISTS "User can read own profile" ON public.profiles;
DROP POLICY IF EXISTS "User can update own profile" ON public.profiles;
DROP POLICY IF EXISTS "User can insert own profile" ON public.profiles;
DROP POLICY IF EXISTS "User can delete own profile" ON public.profiles;
DROP POLICY IF EXISTS "Admins can update all profiles" ON public.profiles;
DROP POLICY IF EXISTS "Admins can delete profiles" ON public.profiles;

-- 1.3) إعادة إنشاء سياسات نظيفة (باستخدام is_admin() بدل SELECT الفرعي)
CREATE POLICY "profiles_select_all" ON public.profiles
  FOR SELECT USING (true);  -- كل البروفايلات قابلة للقراءة (للبحث والاستكشاف)

CREATE POLICY "profiles_update_self_or_admin" ON public.profiles
  FOR UPDATE USING (
    id = auth.uid() OR public.is_admin()
  );

CREATE POLICY "profiles_insert_self" ON public.profiles
  FOR INSERT WITH CHECK (id = auth.uid());

CREATE POLICY "profiles_delete_self_or_admin" ON public.profiles
  FOR DELETE USING (
    id = auth.uid() OR public.is_admin()
  );

-- ============================================================
-- 2) إضافة عمود is_admin إن لم يكن موجودًا
-- ============================================================
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS is_admin boolean DEFAULT false;

-- تفعيل المدراء المعروفين
UPDATE public.profiles SET is_admin = true
WHERE username IN ('admin', 'kemetnet', 'kemetnet_admin', 'kemet_admin', 'mohamed');

-- ============================================================
-- 3) إنشاء الجداول المفقودة
-- ============================================================

-- 3.1) reposts table
CREATE TABLE IF NOT EXISTS public.reposts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  post_id uuid NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, post_id)
);

-- 3.2) featured_posts_votes table (مصوتات تمييز المنشورات)
CREATE TABLE IF NOT EXISTS public.featured_posts_votes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(post_id, user_id)
);

-- 3.3) pinned_posts table (إذا لم تكن موجودة كجدول منفصل، نستخدم عمود is_pinned في posts)
-- ملاحظة: في الكود الحالي، نستخدم posts.is_pinned بدل جدول مستقل،
-- لذا هذا الجدول اختياري للتوافق المستقبلي
CREATE TABLE IF NOT EXISTS public.pinned_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  post_id uuid NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
  pinned_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, post_id)
);

-- 3.4) RLS على الجداول الجديدة
ALTER TABLE public.reposts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.featured_posts_votes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pinned_posts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "reposts_select" ON public.reposts;
DROP POLICY IF EXISTS "reposts_insert" ON public.reposts;
DROP POLICY IF EXISTS "reposts_delete" ON public.reposts;
CREATE POLICY "reposts_select" ON public.reposts FOR SELECT USING (true);
CREATE POLICY "reposts_insert" ON public.reposts
  FOR INSERT WITH CHECK (user_id = auth.uid());
CREATE POLICY "reposts_delete" ON public.reposts
  FOR DELETE USING (user_id = auth.uid() OR public.is_admin());

DROP POLICY IF EXISTS "featured_posts_votes_select" ON public.featured_posts_votes;
DROP POLICY IF EXISTS "featured_posts_votes_insert" ON public.featured_posts_votes;
DROP POLICY IF EXISTS "featured_posts_votes_delete" ON public.featured_posts_votes;
CREATE POLICY "featured_posts_votes_select" ON public.featured_posts_votes FOR SELECT USING (true);
CREATE POLICY "featured_posts_votes_insert" ON public.featured_posts_votes
  FOR INSERT WITH CHECK (user_id = auth.uid());
CREATE POLICY "featured_posts_votes_delete" ON public.featured_posts_votes
  FOR DELETE USING (user_id = auth.uid() OR public.is_admin());

DROP POLICY IF EXISTS "pinned_posts_select" ON public.pinned_posts;
DROP POLICY IF EXISTS "pinned_posts_insert" ON public.pinned_posts;
DROP POLICY IF EXISTS "pinned_posts_delete" ON public.pinned_posts;
CREATE POLICY "pinned_posts_select" ON public.pinned_posts FOR SELECT USING (true);
CREATE POLICY "pinned_posts_insert" ON public.pinned_posts
  FOR INSERT WITH CHECK (user_id = auth.uid());
CREATE POLICY "pinned_posts_delete" ON public.pinned_posts
  FOR DELETE USING (user_id = auth.uid() OR public.is_admin());

-- ============================================================
-- 4) تحديث سياسات RLS على باقي الجداول لتمكين المدراء
-- ============================================================

-- posts: UPDATE + DELETE للمدراء
DROP POLICY IF EXISTS "Admins can update all posts" ON public.posts;
DROP POLICY IF EXISTS "Admins can delete all posts" ON public.posts;
CREATE POLICY "Admins can update all posts" ON public.posts
  FOR UPDATE USING (public.is_admin());
CREATE POLICY "Admins can delete all posts" ON public.posts
  FOR DELETE USING (public.is_admin());

-- reports: UPDATE للمدراء
DROP POLICY IF EXISTS "Admins can update all reports" ON public.reports;
CREATE POLICY "Admins can update all reports" ON public.reports
  FOR UPDATE USING (public.is_admin());

-- verification_requests: UPDATE للمدراء
DROP POLICY IF EXISTS "Admins can update verification_requests" ON public.verification_requests;
CREATE POLICY "Admins can update verification_requests" ON public.verification_requests
  FOR UPDATE USING (public.is_admin());

-- ============================================================
-- 5) إنشاء RPC functions المفقودة
-- ============================================================

-- 5.1) update_last_seen
CREATE OR REPLACE FUNCTION public.update_last_seen(target_user_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- المستخدم يحدّث آخر ظهور لنفسه فقط، أو المدير لأي مستخدم
  IF target_user_id = auth.uid() OR public.is_admin() THEN
    UPDATE public.profiles
    SET last_seen = now()
    WHERE id = target_user_id AND show_last_seen = true;
  END IF;
END;
$$;

-- 5.2) search_users
CREATE OR REPLACE FUNCTION public.search_users(query text, limit_count int DEFAULT 20)
RETURNS TABLE (
  id uuid,
  username text,
  display_name text,
  avatar_url text,
  avatar_color text,
  is_verified boolean,
  followers_count int
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT id, username, display_name, avatar_url, avatar_color, is_verified, followers_count
  FROM public.profiles
  WHERE username ILIKE '%' || query || '%'
     OR display_name ILIKE '%' || query || '%'
  ORDER BY
    CASE
      WHEN username ILIKE query || '%' THEN 1
      WHEN display_name ILIKE query || '%' THEN 2
      ELSE 3
    END,
    followers_count DESC
  LIMIT COALESCE(limit_count, 20);
$$;

-- 5.3) get_feed (للخلاصة المخصصة - For You / Following / Trending)
CREATE OR REPLACE FUNCTION public.get_feed(
  feed_type text DEFAULT 'for-you',
  p_limit int DEFAULT 20,
  p_offset int DEFAULT 0
)
RETURNS SETOF public.posts
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF feed_type = 'following' THEN
    RETURN QUERY
      SELECT p.* FROM public.posts p
      WHERE p.user_id IN (
        SELECT followed_id FROM public.follows WHERE follower_id = auth.uid()
      )
      AND p.repost_of IS NULL
      ORDER BY p.created_at DESC
      LIMIT p_limit OFFSET p_offset;
  ELSIF feed_type = 'trending' THEN
    RETURN QUERY
      SELECT p.* FROM public.posts p
      WHERE p.repost_of IS NULL
        AND p.created_at > now() - INTERVAL '7 days'
      ORDER BY (p.likes_count + p.comments_count * 2 + p.reposts_count * 3) DESC
      LIMIT p_limit OFFSET p_offset;
  ELSE  -- for-you
    RETURN QUERY
      SELECT p.* FROM public.posts p
      WHERE p.repost_of IS NULL
      ORDER BY p.is_pinned DESC, p.is_featured DESC, p.created_at DESC
      LIMIT p_limit OFFSET p_offset;
  END IF;
END;
$$;

-- 5.4) delete_account (حذف الحساب الذاتي)
CREATE OR REPLACE FUNCTION public.delete_account(password_check text DEFAULT NULL)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  current_user_id uuid := auth.uid();
BEGIN
  IF current_user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  -- حذف البروفايل (سي cascade حذف منشوراته + تعليقاته + إعجاباته)
  DELETE FROM public.profiles WHERE id = current_user_id;

  -- حذف من auth.users (يتطلب service_role من العميل، لكن SECURITY DEFINER يقدر)
  -- ملاحظة: هذه تحتاج لأن يكون function owner = postgres
  DELETE FROM auth.users WHERE id = current_user_id;

  RETURN true;
END;
$$;

-- 5.5) admin_delete_user_complete (للمدراء - حذف أي مستخدم)
CREATE OR REPLACE FUNCTION public.admin_delete_user_complete(target_user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_admin() THEN
    RAISE EXCEPTION 'Unauthorized: admin access required';
  END IF;

  IF target_user_id = auth.uid() THEN
    RAISE EXCEPTION 'Cannot delete yourself';
  END IF;

  -- حذف من auth.users (cascade سيحذف البروفايل)
  DELETE FROM auth.users WHERE id = target_user_id;

  RETURN true;
END;
$$;

-- 5.6) admin_restrict_user (للمدراء - تقييد مؤقت)
CREATE OR REPLACE FUNCTION public.admin_restrict_user(target_user_id uuid, reason text, days int DEFAULT 7)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_admin() THEN
    RAISE EXCEPTION 'Unauthorized: admin access required';
  END IF;

  UPDATE public.profiles
  SET restricted_until = NOW() + (days || ' days')::interval,
      restriction_reason = reason
  WHERE id = target_user_id;

  RETURN true;
END;
$$;

-- ============================================================
-- 6) Trigger: منع المقيدين من النشر
-- ============================================================
CREATE OR REPLACE FUNCTION public.prevent_restricted_user_post()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = NEW.user_id
      AND restricted_until IS NOT NULL
      AND restricted_until > NOW()
  ) THEN
    RAISE EXCEPTION 'حسابك مقيّد حتى %',
      (SELECT restricted_until FROM public.profiles WHERE id = NEW.user_id);
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS prevent_restricted_post ON public.posts;
CREATE TRIGGER prevent_restricted_post
  BEFORE INSERT ON public.posts
  FOR EACH ROW
  EXECUTE FUNCTION public.prevent_restricted_user_post();

-- ============================================================
-- 7) Trigger: تفعيل is_admin تلقائيًا لليوزرنيمات المعروفة
-- ============================================================
CREATE OR REPLACE FUNCTION public.sync_admin_flag()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.username IN ('admin', 'kemetnet', 'kemetnet_admin', 'kemet_admin', 'mohamed') THEN
    NEW.is_admin := true;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS sync_admin_flag_trigger ON public.profiles;
CREATE TRIGGER sync_admin_flag_trigger
  BEFORE INSERT OR UPDATE OF username ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.sync_admin_flag();

-- ============================================================
-- 8) ضمان وجود أعمدة is_pinned / is_featured في posts
-- ============================================================
ALTER TABLE public.posts ADD COLUMN IF NOT EXISTS is_pinned boolean DEFAULT false;
ALTER TABLE public.posts ADD COLUMN IF NOT EXISTS pinned_at timestamptz;
ALTER TABLE public.posts ADD COLUMN IF NOT EXISTS is_featured boolean DEFAULT false;
ALTER TABLE public.posts ADD COLUMN IF NOT EXISTS featured_at timestamptz;

-- ============================================================
-- 9) إضافة أعمدة restriction إلى profiles (للمدراء)
-- ============================================================
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS restricted_until timestamptz;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS restriction_reason text;

COMMIT;

-- ============================================================
-- التحقق النهائي
-- ============================================================
SELECT '✅ Database fix complete' AS status;

-- عدّ الجداول
SELECT 'profiles' AS tbl, COUNT(*) FROM public.profiles
UNION ALL SELECT 'posts', COUNT(*) FROM public.posts
UNION ALL SELECT 'reposts', COUNT(*) FROM public.reposts
UNION ALL SELECT 'featured_posts_votes', COUNT(*) FROM public.featured_posts_votes
UNION ALL SELECT 'pinned_posts', COUNT(*) FROM public.pinned_posts
UNION ALL SELECT 'admins', COUNT(*) FROM public.profiles WHERE is_admin = true
ORDER BY 1;
