-- =====================================================
-- مشرق - ترقية الإشارات (mentions) + حذف الحساب + تغيير اليوزرنيم
-- آمن للتشغيل المتكرر - يستخدم IF NOT EXISTS و DROP ... IF EXISTS
-- =====================================================

-- =====================================================
-- 1. توسيع نوع notifications لدعم الإشارات
-- =====================================================
-- إضافة نوع جديد 'mention' للإشعارات
-- نحتاج لإسقاط الـ CHECK constraint القديم وإضافة واحد جديد
DO $$
BEGIN
  -- التحقق من وجود الـ constraint القديم
  IF EXISTS (
    SELECT 1 FROM information_schema.check_constraints
    WHERE constraint_name = 'notifications_type_check'
  ) THEN
    ALTER TABLE public.notifications DROP CONSTRAINT notifications_type_check;
  END IF;
END $$;

ALTER TABLE public.notifications ADD CONSTRAINT notifications_type_check
  CHECK (type IN ('like', 'comment', 'follow', 'mention', 'comment_mention', 'comment_like', 'reply', 'system'));

-- =====================================================
-- 2. دالة لاستخراج الإشارات (@username) من النص
-- =====================================================
CREATE OR REPLACE FUNCTION public.extract_mentions(text_content TEXT)
RETURNS TEXT[] AS $$
DECLARE
  mentions TEXT[];
BEGIN
  IF text_content IS NULL THEN
    RETURN ARRAY[]::TEXT[];
  END IF;
  -- استخراج كل @username (3-20 حرف: أحرف، أرقام، شرطة سفلية)
  SELECT COALESCE(array_agg(DISTINCT lower(matches[1])), ARRAY[]::TEXT[])
  INTO mentions
  FROM regexp_matches(text_content, '@([a-zA-Z0-9_]{3,20})', 'g') AS matches;
  RETURN mentions;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- =====================================================
-- 3. Trigger لإنشاء إشعارات عند الإشارة في منشور
-- =====================================================
CREATE OR REPLACE FUNCTION public.notify_on_post_mention()
RETURNS TRIGGER AS $$
DECLARE
  mentions TEXT[];
  author_name TEXT;
BEGIN
  mentions := public.extract_mentions(NEW.content);
  
  IF array_length(mentions, 1) IS NULL THEN
    RETURN NEW;
  END IF;
  
  SELECT display_name INTO author_name FROM public.profiles WHERE id = NEW.user_id;
  
  -- إدخال إشعار لكل مستخدم تمت الإشارة إليه (باستخدام INSERT...SELECT)
  INSERT INTO public.notifications (user_id, actor_id, type, title, body, post_id)
  SELECT p.id, NEW.user_id, 'mention',
         COALESCE(author_name, 'مستخدم') || ' أشار إليك في منشور',
         LEFT(NEW.content, 80), NEW.id
  FROM public.profiles p
  WHERE lower(p.username) = ANY(mentions)
    AND p.id != NEW.user_id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trigger_notify_on_post_mention ON public.posts;
CREATE TRIGGER trigger_notify_on_post_mention
  AFTER INSERT OR UPDATE OF content ON public.posts
  FOR EACH ROW EXECUTE FUNCTION public.notify_on_post_mention();

-- =====================================================
-- 4. Trigger لإنشاء إشعارات عند الإشارة في تعليق
-- =====================================================
CREATE OR REPLACE FUNCTION public.notify_on_comment_mention()
RETURNS TRIGGER AS $$
DECLARE
  mentions TEXT[];
  commenter_name TEXT;
  post_owner UUID;
BEGIN
  mentions := public.extract_mentions(NEW.content);
  
  IF array_length(mentions, 1) IS NULL THEN
    RETURN NEW;
  END IF;
  
  SELECT display_name INTO commenter_name FROM public.profiles WHERE id = NEW.user_id;
  SELECT user_id INTO post_owner FROM public.posts WHERE id = NEW.post_id;
  
  -- إدخال إشعار لكل مستخدم تمت الإشارة إليه (تجنب صاحب المنشور — لديه إشعار التعليق)
  INSERT INTO public.notifications (user_id, actor_id, type, title, body, post_id)
  SELECT p.id, NEW.user_id, 'comment_mention',
         COALESCE(commenter_name, 'مستخدم') || ' أشار إليك في تعليق',
         LEFT(NEW.content, 80), NEW.post_id
  FROM public.profiles p
  WHERE lower(p.username) = ANY(mentions)
    AND p.id != NEW.user_id
    AND p.id != COALESCE(post_owner, '00000000-0000-0000-0000-000000000000'::UUID);
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trigger_notify_on_comment_mention ON public.comments;
CREATE TRIGGER trigger_notify_on_comment_mention
  AFTER INSERT OR UPDATE OF content ON public.comments
  FOR EACH ROW EXECUTE FUNCTION public.notify_on_comment_mention();

-- =====================================================
-- 5. دالة لحذف الحساب وكل بياناته المرتبطة
-- =====================================================
CREATE OR REPLACE FUNCTION public.delete_user_account(target_user_id UUID)
RETURNS VOID AS $$
DECLARE
  user_email TEXT;
BEGIN
  -- الحصول على بريد المستخدم الإلكتروني من auth.users
  SELECT email INTO user_email FROM auth.users WHERE id = target_user_id;
  
  IF user_email IS NULL THEN
    RAISE EXCEPTION 'User not found';
  END IF;
  
  -- حذف كل البيانات المرتبطة (CASCADE يتولى الباقي)
  DELETE FROM public.notifications WHERE user_id = target_user_id OR actor_id = target_user_id;
  DELETE FROM public.comment_likes WHERE user_id = target_user_id;
  DELETE FROM public.likes WHERE user_id = target_user_id;
  DELETE FROM public.comments WHERE user_id = target_user_id;
  DELETE FROM public.follows WHERE follower_id = target_user_id OR following_id = target_user_id;
  DELETE FROM public.message_requests WHERE sender_id = target_user_id OR receiver_id = target_user_id;
  DELETE FROM public.messages WHERE sender_id = target_user_id;
  DELETE FROM public.conversations WHERE participant_1 = target_user_id OR participant_2 = target_user_id;
  DELETE FROM public.posts WHERE user_id = target_user_id;
  DELETE FROM public.profiles WHERE id = target_user_id;
  
  -- حذف المستخدم من auth.users (يتطلب service_role key من الخادم)
  -- هنا نكتفي بحذف الـ profile وكل البيانات
  -- المستخدم نفسه يحذف عبر استدعاء admin API من العميل
  
  RAISE NOTICE 'Account data deleted for user %', target_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- منح صلاحية تنفيذ الدالة للمستخدم الحالي
GRANT EXECUTE ON FUNCTION public.delete_user_account(UUID) TO authenticated;

-- =====================================================
-- ملاحظات:
-- 1. هذا السكربت آمن للتشغيل المتكرر
-- 2. لا يحذف أي بيانات موجودة
-- 3. يضيف triggers لدعم الإشارات @username
-- 4. يضيف دالة delete_user_account لحذف بيانات الحساب
-- 5. لتغيير اليوزرنيم: نستخدم updateProfile في profiles + updateUser في auth
-- =====================================================
