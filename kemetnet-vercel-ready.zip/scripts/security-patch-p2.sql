-- =====================================================
-- مشرق - إصلاح أمني (جولة 3) — Security Patch P2
-- يصلح: image_url CHECK, avatar_url CHECK, counters >= 0, achievement progress
-- =====================================================

-- =====================================================
-- 1. H-01: التأكد من وجود عمود image_url ثم إضافة CHECK constraint
-- =====================================================
ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS image_url TEXT;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.check_constraints
    WHERE constraint_name = 'messages_image_url_check'
  ) THEN
    ALTER TABLE public.messages ADD CONSTRAINT messages_image_url_check
      CHECK (image_url IS NULL OR image_url ~ '^https://.+\.supabase\.(co|in)/storage/');
  END IF;
END $$;

-- =====================================================
-- 2. M-04: CHECK constraint على profiles.avatar_url
-- =====================================================
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.check_constraints
    WHERE constraint_name = 'profiles_avatar_url_check'
  ) THEN
    ALTER TABLE public.profiles ADD CONSTRAINT profiles_avatar_url_check
      CHECK (avatar_url IS NULL OR avatar_url ~ '^https://.+\.supabase\.(co|in)/storage/');
  END IF;
END $$;

-- =====================================================
-- 3. M-01: CHECK (>= 0) على كل العدادات
-- =====================================================
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.check_constraints WHERE constraint_name = 'profiles_reputation_points_check') THEN
    ALTER TABLE public.profiles ADD CONSTRAINT profiles_reputation_points_check CHECK (reputation_points >= 0);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.check_constraints WHERE constraint_name = 'profiles_reputation_level_check') THEN
    ALTER TABLE public.profiles ADD CONSTRAINT profiles_reputation_level_check CHECK (reputation_level >= 1);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.check_constraints WHERE constraint_name = 'profiles_total_earned_check') THEN
    ALTER TABLE public.profiles ADD CONSTRAINT profiles_total_earned_check CHECK (total_earned_points >= 0);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.check_constraints WHERE constraint_name = 'profiles_login_streak_check') THEN
    ALTER TABLE public.profiles ADD CONSTRAINT profiles_login_streak_check CHECK (login_streak >= 0);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.check_constraints WHERE constraint_name = 'profiles_longest_streak_check') THEN
    ALTER TABLE public.profiles ADD CONSTRAINT profiles_longest_streak_check CHECK (longest_streak >= 0);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.check_constraints WHERE constraint_name = 'profiles_total_logins_check') THEN
    ALTER TABLE public.profiles ADD CONSTRAINT profiles_total_logins_check CHECK (total_logins >= 0);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.check_constraints WHERE constraint_name = 'profiles_followers_count_check') THEN
    ALTER TABLE public.profiles ADD CONSTRAINT profiles_followers_count_check CHECK (followers_count >= 0);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.check_constraints WHERE constraint_name = 'profiles_following_count_check') THEN
    ALTER TABLE public.profiles ADD CONSTRAINT profiles_following_count_check CHECK (following_count >= 0);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.check_constraints WHERE constraint_name = 'profiles_posts_count_check') THEN
    ALTER TABLE public.profiles ADD CONSTRAINT profiles_posts_count_check CHECK (posts_count >= 0);
  END IF;
  
  -- posts table
  IF NOT EXISTS (SELECT 1 FROM information_schema.check_constraints WHERE constraint_name = 'posts_likes_count_check') THEN
    ALTER TABLE public.posts ADD CONSTRAINT posts_likes_count_check CHECK (likes_count >= 0);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.check_constraints WHERE constraint_name = 'posts_comments_count_check') THEN
    ALTER TABLE public.posts ADD CONSTRAINT posts_comments_count_check CHECK (comments_count >= 0);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.check_constraints WHERE constraint_name = 'posts_reposts_count_check') THEN
    ALTER TABLE public.posts ADD CONSTRAINT posts_reposts_count_check CHECK (reposts_count >= 0);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.check_constraints WHERE constraint_name = 'posts_featured_votes_check') THEN
    ALTER TABLE public.posts ADD CONSTRAINT posts_featured_votes_check CHECK (featured_votes_count >= 0);
  END IF;
  
  -- comments table
  IF NOT EXISTS (SELECT 1 FROM information_schema.check_constraints WHERE constraint_name = 'comments_likes_count_check') THEN
    ALTER TABLE public.comments ADD CONSTRAINT comments_likes_count_check CHECK (likes_count >= 0);
  END IF;
END $$;

-- =====================================================
-- 4. M-05: منع update_achievement_progress من تجاوز target_value
-- =====================================================
CREATE OR REPLACE FUNCTION public.update_achievement_progress(
  target_user_id UUID, achievement_slug TEXT, new_progress INTEGER
) RETURNS VOID AS $$
DECLARE
  achievement_record RECORD;
  should_complete BOOLEAN;
  clamped_progress INTEGER;
BEGIN
  IF auth.uid() IS NULL OR auth.uid() != target_user_id THEN
    RETURN;
  END IF;
  
  SELECT * INTO achievement_record FROM public.achievements WHERE slug = achievement_slug;
  IF NOT FOUND THEN RETURN; END IF;
  
  -- ✅ أمني: منع قيم سالبة
  IF new_progress < 0 THEN RETURN; END IF;
  
  -- ✅ أمني: تحديد الحد الأقصى بالـ target_value
  clamped_progress := LEAST(new_progress, COALESCE(achievement_record.target_value, new_progress));
  should_complete := achievement_record.target_value IS NULL OR new_progress >= achievement_record.target_value;
  
  INSERT INTO public.user_achievements (user_id, achievement_slug, progress, completed, completed_at, updated_at)
  VALUES (target_user_id, achievement_slug, clamped_progress, should_complete,
    CASE WHEN should_complete THEN NOW() ELSE NULL END, NOW())
  ON CONFLICT (user_id, achievement_slug) DO UPDATE
  SET progress = GREATEST(user_achievements.progress, clamped_progress),
      completed = user_achievements.completed OR should_complete,
      completed_at = CASE WHEN should_complete AND user_achievements.completed_at IS NULL THEN NOW() ELSE user_achievements.completed_at END,
      updated_at = NOW();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- =====================================================
-- 5. حذف user_achievements_update_own RLS (منع التعديل المباشر)
-- =====================================================
DROP POLICY IF EXISTS "user_achievements_update_own" ON public.user_achievements;

-- =====================================================
-- ملاحظات:
-- 1. messages.image_url الآن مقيد بـ Supabase Storage فقط
-- 2. profiles.avatar_url مقيد بنفس القيد
-- 3. كل العدادات لا يمكن أن تكون سالبة
-- 4. achievement progress محدود بـ target_value
-- 5. user_achievements لا يمكن تعديلها مباشرة (فقط عبر RPC)
-- =====================================================
