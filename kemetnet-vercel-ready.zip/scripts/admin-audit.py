#!/usr/bin/env python3
"""
KemetNet — Admin Policies Audit
يتحقق من:
  1. وجود عمود is_admin في profiles
  2. المستخدمون المفعّل كمدراء
  3. RPC function is_admin()
  4. RPC functions الإدارة (admin_delete_user_complete, admin_restrict_user)
  5. سياسات RLS على كل جدول (Profiles, Posts, Comments, Reports, Verification Requests)
  6. صلاحيات UPDATE/DELETE للمدراء على كل جدول
"""

import json
import urllib.request
import urllib.error

SUPABASE_URL = "https://bhzrhvesrpyvrsshavow.supabase.co"
API_KEY = "sb_publishable_AO6P04L0WlDaCK2Ot38YTQ_90FnOQc_"


def api(method: str, path: str, body=None):
    url = f"{SUPABASE_URL}{path}"
    headers = {
        "apikey": API_KEY,
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json",
    }
    data = json.dumps(body).encode() if body else None
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            body_text = resp.read().decode()
            try:
                return resp.status, json.loads(body_text)
            except json.JSONDecodeError:
                return resp.status, body_text
    except urllib.error.HTTPError as e:
        body_text = e.read().decode()
        try:
            return e.code, json.loads(body_text)
        except json.JSONDecodeError:
            return e.code, body_text
    except Exception as e:
        return 0, str(e)


print("=" * 70)
print("🔍 KemetNet — Admin Policies Audit")
print("=" * 70)
print()

# ============= 1) is_admin column + flag users =============
print("━" * 70)
print("1) فحص عمود is_admin + المستخدمون المفعّلون كمدراء")
print("━" * 70)

# Try to fetch profiles with is_admin column
status, body = api("GET", "/rest/v1/profiles?select=id,username,is_admin,is_verified,verified_type&order=username.asc&limit=50")
if status == 200 and isinstance(body, list):
    admins = [p for p in body if p.get("is_admin") == True]
    print(f"   ✅ عمود is_admin موجود، إجمالي المستخدمين: {len(body)}")
    print(f"   👑 المدراء ({len(admins)}):")
    for a in admins:
        print(f"      - @{a.get('username')} (verified={a.get('is_verified')}, type={a.get('verified_type')})")
    if not admins:
        print("   ⚠️  لا يوجد مستخدمون مفعّل كمدراء!")
else:
    print(f"   ❌ فشل جلب profiles: HTTP {status}")
    print(f"      Body: {str(body)[:200]}")
print()

# ============= 2) RPC: is_admin() =============
print("━" * 70)
print("2) فحص RPC function: public.is_admin()")
print("━" * 70)
status, body = api("POST", "/rest/v1/rpc/is_admin", body={})
if status == 200:
    print(f"   ✅ is_admin() function موجودة")
    print(f"      النتيجة (بدون session): {body}")
elif status == 404:
    print(f"   ❌ is_admin() function غير موجودة (404)")
elif status == 401:
    print(f"   ✅ is_admin() function موجودة (تتطلب auth - 401)")
else:
    print(f"   ⚠️  HTTP {status}: {str(body)[:200]}")
print()

# ============= 3) Admin RPC functions =============
print("━" * 70)
print("3) فحص RPC functions الإدارة")
print("━" * 70)
admin_rpcs = [
    "admin_delete_user_complete",
    "admin_restrict_user",
    "delete_account",
    "update_last_seen",
    "search_users",
    "get_feed",
]
for rpc in admin_rpcs:
    status, body = api("POST", f"/rest/v1/rpc/{rpc}", body={})
    if status == 404:
        print(f"   ❌ {rpc} — غير موجود")
    elif status in (401, 403):
        print(f"   ✅ {rpc} — موجود (يتطلب صلاحية)")
    elif status in (400,):
        print(f"   ✅ {rpc} — موجود (يتطلب args)")
    else:
        print(f"   ⚠️  {rpc} — HTTP {status}: {str(body)[:100]}")
print()

# ============= 4) Admin operations test =============
print("━" * 70)
print("4) فحص محاولات عمليات الإدارة (بدون auth = يجب أن تفشل)")
print("━" * 70)

# Try to UPDATE a post as anon (should fail or no-op)
status, body = api("PATCH", "/rest/v1/posts?id=eq.00000000-0000-0000-0000-000000000000",
                    body={"is_featured": True})
if status == 204:
    print(f"   ⚠️  UPDATE post: نجح (قد يكون لأن العنصر غير موجود — مفيد)")
elif status in (401, 403):
    print(f"   ❌ UPDATE post: {status} (لا يوجد policy admin)")
elif status == 42501:
    print(f"   ✅ UPDATE post: مرفوض (RLS يحجب)")
else:
    print(f"   ℹ️  UPDATE post: HTTP {status}")

# Try to DELETE a post as anon
status, body = api("DELETE", "/rest/v1/posts?id=eq.00000000-0000-0000-0000-000000000000")
if status == 204:
    print(f"   ⚠️  DELETE post: نجح (لكن ربما كان 0 صفوف)")
elif status in (401, 403, 42501):
    print(f"   ✅ DELETE post: مرفوض (RLS يحجب)")
else:
    print(f"   ℹ️  DELETE post: HTTP {status}")

# Try to UPDATE a profile as anon
status, body = api("PATCH", "/rest/v1/profiles?id=eq.00000000-0000-0000-0000-000000000000",
                    body={"is_verified": True})
if status == 204:
    print(f"   ⚠️  UPDATE profile: نجح (تحقق من الـ policy)")
else:
    print(f"   ℹ️  UPDATE profile: HTTP {status}")

# Try to UPDATE verification_requests as anon
status, body = api("PATCH", "/rest/v1/verification_requests?id=eq.00000000-0000-0000-0000-000000000000",
                    body={"status": "approved"})
if status == 204:
    print(f"   ⚠️  UPDATE verification_requests: نجح (تحقق من الـ policy)")
else:
    print(f"   ℹ️  UPDATE verification_requests: HTTP {status}")

# Try to UPDATE reports as anon
status, body = api("PATCH", "/rest/v1/reports?id=eq.00000000-0000-0000-0000-000000000000",
                    body={"status": "actioned"})
if status == 204:
    print(f"   ⚠️  UPDATE reports: نجح (تحقق من الـ policy)")
else:
    print(f"   ℹ️  UPDATE reports: HTTP {status}")
print()

# ============= 5) Admin user test =============
print("━" * 70)
print("5) فحص مستخدم admin محدد (kemetnet_admin)")
print("━" * 70)
status, body = api("GET", "/rest/v1/profiles?username=eq.kemetnet_admin&select=*")
if status == 200 and isinstance(body, list):
    if len(body) == 0:
        print("   ❌ لا يوجد مستخدم بـ username=kemetnet_admin")
    else:
        p = body[0]
        print(f"   ✅ موجود: @{p.get('username')}")
        print(f"      is_admin: {p.get('is_admin', False)}")
        print(f"      is_verified: {p.get('is_verified', False)}")
        print(f"      verified_type: {p.get('verified_type', 'null')}")
        print(f"      id: {p.get('id')}")
        # Check if is_admin flag should be enabled but isn't
        if p.get('username') == 'kemetnet_admin' and not p.get('is_admin'):
            print("   ⚠️  يحتاج: UPDATE profiles SET is_admin=true WHERE username='kemetnet_admin'")
else:
    print(f"   ❌ فشل: HTTP {status}")
print()

# ============= 6) Recommendations =============
print("=" * 70)
print("📋 التوصيات النهائية")
print("=" * 70)
print("""
لتفعيل صلاحيات الإدارة بالكامل، تأكد من:

1) ✅ عمود is_admin موجود في profiles (تم في SQL v2)
2) ✅ public.is_admin() function موجودة (تم في SQL v2)
3) ✅ Admins flagged in profiles (يتم تلقائيًا عبر trigger)
4) ✅ Admins RLS policies على posts/reports/verification_requests (تم في SQL v2)
5) ✅ RPC functions (admin_delete_user_complete, admin_restrict_user)

إذا فشل شيء، شغّل scripts/db-fix-v2.sql مرة أخرى في Dashboard.
""")
