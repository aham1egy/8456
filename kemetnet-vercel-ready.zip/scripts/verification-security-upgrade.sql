-- =====================================================
-- مشرق - تأمين التحقق + حماية الرسائل من لقطات الشاشة
-- آمن للتشغيل المتكرر
-- =====================================================

-- =====================================================
-- 1. تقييد تحديث is_verified (لا يمكن للمستخدم العادي تغييرها)
-- =====================================================
-- إزالة القدرة على تحديث حقول التحقق من الـ profile update العادي
-- المستخدم لا يستطيع تحديث: is_verified, verified_type, verified_at

-- إنشاء سياسة RLS منفصلة لتحديث التحقق:
-- المستخدم يمكنه تحديث كل شيء ما عدا حقول التحقق
CREATE OR REPLACE FUNCTION public.can_update_profile_verification()
RETURNS BOOLEAN AS $$
BEGIN
  -- المستخدم الحالي لا يمكنه تحديث حقول التحقق
  -- (يجب أن تتم عبر service_role من الخادم)
  RETURN FALSE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- =====================================================
-- 2. جدول طلبات التحقق (verification_requests)
-- =====================================================
CREATE TABLE IF NOT EXISTS public.verification_requests (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  -- نوع التحقق المطلوب
  requested_type TEXT NOT NULL CHECK (requested_type IN ('official', 'business', 'creator', 'early_adopter')),
  -- سبب الطلب / وصف
  reason TEXT CHECK (reason IS NULL OR length(reason) <= 500),
  -- معلومات إضافية
  contact_email TEXT,
  social_links TEXT[],
  -- حالة الطلب
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'needs_info')),
  admin_notes TEXT,
  -- التواريخ
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  reviewed_at TIMESTAMPTZ,
  reviewed_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  -- منع تكرار الطلب النشط
  UNIQUE(user_id, status) DEFERRABLE INITIALLY DEFERRED
);

CREATE INDEX IF NOT EXISTS idx_verification_requests_user ON public.verification_requests (user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_verification_requests_status ON public.verification_requests (status, created_at DESC);

-- =====================================================
-- 3. RLS لجدول طلبات التحقق
-- =====================================================
ALTER TABLE public.verification_requests ENABLE ROW LEVEL SECURITY;

-- المستخدم يرى طلباته فقط
DROP POLICY IF EXISTS "verification_requests_select_own" ON public.verification_requests;
CREATE POLICY "verification_requests_select_own" ON public.verification_requests FOR SELECT 
  USING (auth.uid() = user_id);

-- المستخدم يُدرج طلباته فقط
DROP POLICY IF EXISTS "verification_requests_insert_own" ON public.verification_requests;
CREATE POLICY "verification_requests_insert_own" ON public.verification_requests FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

-- المستخدم يحذف طلباته (المعلّقة فقط) 
DROP POLICY IF EXISTS "verification_requests_delete_own" ON public.verification_requests;
CREATE POLICY "verification_requests_delete_own" ON public.verification_requests FOR DELETE 
  USING (auth.uid() = user_id AND status = 'pending');

-- =====================================================
-- 4. حقل منع لقطات الشاشة للرسائل
-- =====================================================
ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS no_screenshot BOOLEAN DEFAULT FALSE;
ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS screenshot_detected BOOLEAN DEFAULT FALSE;

-- =====================================================
-- 5. تحديث RLS على profiles لمنع تحديث حقول التحقق
-- =====================================================
-- ملاحظة: هذه سياسة معقدة لأن PostgreSQL RLS لا يدعم column-level update restrictions
-- بسهولة. الحل البديل هو استخدام trigger قبل التحديث:
CREATE OR REPLACE FUNCTION public.prevent_verification_self_update()
RETURNS TRIGGER AS $$
BEGIN
  -- إذا كان المستخدم يحاول تحديث is_verified أو verified_type أو verified_at
  -- وكان ليس admin، امنع التحديث
  IF (NEW.is_verified IS DISTINCT FROM OLD.is_verified 
      OR NEW.verified_type IS DISTINCT FROM OLD.verified_type
      OR NEW.verified_at IS DISTINCT FROM OLD.verified_at) THEN
    
    -- تحقق إذا كان المستخدم الحالي admin
    -- (يمكن إضافة عمود is_admin في profiles للإدارة)
    IF OLD.id != auth.uid() THEN
      RAISE EXCEPTION 'لا يمكنك تعديل حالة التحقق';
    END IF;
    
    -- حتى لو كان المستخدم يعدّل ملفه، لا يمكنه تغيير حقول التحقق
    -- (إلا إذا كان admin — يُضاف لاحقاً)
    RAISE EXCEPTION 'لا يمكنك تعديل حالة التحقق بنفسك. أرسل طلب تحقق';
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trigger_prevent_verification_self_update ON public.profiles;
CREATE TRIGGER trigger_prevent_verification_self_update
  BEFORE UPDATE OF is_verified, verified_type, verified_at ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.prevent_verification_self_update();

-- =====================================================
-- ملاحظات:
-- 1. طلبات التحقق: المستخدم يطلب، الإدارة تقرر
-- 2. منع تحديث is_verified: trigger يمنع أي تحديث من العميل
-- 3. no_screenshot: علامة للرسائل الحساسة (يُكتشف في الواجهة)
-- 4. screenshot_detected: سجل لمحاولات لقط الشاشة
-- =====================================================
