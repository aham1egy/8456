-- =====================================================
-- مشرق - ردود الأفعال على الرسائل (Message Reactions)
-- آمن للتشغيل المتكرر
-- =====================================================

-- =====================================================
-- 1. جدول ردود الأفعال
-- =====================================================
CREATE TABLE IF NOT EXISTS public.message_reactions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  message_id UUID NOT NULL REFERENCES public.messages(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  -- نوع الـ emoji: heart, like, laugh, wow, sad, angry, fire, thumbsup
  emoji TEXT NOT NULL CHECK (emoji IN (
    'heart', 'like', 'laugh', 'wow', 'sad', 'angry', 'fire', 'thumbsup', 'celebrate', 'thinking'
  )),
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  -- منع تكرار نفس الـ reaction من نفس المستخدم لنفس الرسالة
  UNIQUE(message_id, user_id)
);

CREATE INDEX IF NOT EXISTS idx_msg_reactions_message ON public.message_reactions (message_id);
CREATE INDEX IF NOT EXISTS idx_msg_reactions_user ON public.message_reactions (user_id);

-- =====================================================
-- 2. تفعيل RLS
-- =====================================================
ALTER TABLE public.message_reactions ENABLE ROW LEVEL SECURITY;

-- المستخدم يرى ردود الأفعال على الرسائل في محادثاته فقط
DROP POLICY IF EXISTS "msg_reactions_select_participants" ON public.message_reactions;
CREATE POLICY "msg_reactions_select_participants" ON public.message_reactions FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.conversations c
      JOIN public.messages m ON m.conversation_id = c.id
      WHERE m.id = message_reactions.message_id
      AND (c.participant_1 = auth.uid() OR c.participant_2 = auth.uid())
    )
  );

-- المستخدم يُضيف ردود الأفعال على رسائل محادثاته فقط
DROP POLICY IF EXISTS "msg_reactions_insert_participants" ON public.message_reactions;
CREATE POLICY "msg_reactions_insert_participants" ON public.message_reactions FOR INSERT
  WITH CHECK (
    auth.uid() = user_id
    AND EXISTS (
      SELECT 1 FROM public.conversations c
      JOIN public.messages m ON m.conversation_id = c.id
      WHERE m.id = message_reactions.message_id
      AND (c.participant_1 = auth.uid() OR c.participant_2 = auth.uid())
    )
  );

-- المستخدم يحذف ردود أفعاله فقط
DROP POLICY IF EXISTS "msg_reactions_delete_own" ON public.message_reactions;
CREATE POLICY "msg_reactions_delete_own" ON public.message_reactions FOR DELETE
  USING (auth.uid() = user_id);

-- =====================================================
-- 3. تفعيل Realtime
-- =====================================================
ALTER PUBLICATION supabase_realtime ADD TABLE public.message_reactions;

-- =====================================================
-- ملاحظات:
-- 1. يمكن للمستخدم إضافة رد فعل واحد فقط لكل رسالة
-- 2. رد الفعل يُحذف تلقائياً عند حذف الرسالة (CASCADE)
-- 3. RLS يضمن أن المستخدم يرى ردود الأفعال فقط في محادثاته
-- =====================================================
