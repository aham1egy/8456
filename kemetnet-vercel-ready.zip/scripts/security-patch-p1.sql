-- =====================================================
-- مشرق - إصلاح أمني شامل (Security Patch P1 - Round 2)
-- يصلح الثغرات الإضافية المكتشفة في المراجعة الثانية
-- آمن للتشغيل المتكرر
-- =====================================================

-- =====================================================
-- 1. إصلاح RLS على comments: تقييد تحديث صاحب المنشور على is_pinned فقط
-- =====================================================
-- الثغرة: السياسة السابقة تسمح لصاحب المنشور بتعديل أي حقل في التعليقات
-- (content, user_id, created_at, is_edited, etc.) — بما في ذلك انتحال شخصية مستخدم آخر
-- الإصلاح: تقييد التحديث على حقل is_pinned فقط عبر trigger

DROP POLICY IF EXISTS "comments_update_post_owner_pin" ON public.comments;

-- إنشاء trigger يرفض تحديث أي حقل غير is_pinned من قبل صاحب المنشور
CREATE OR REPLACE FUNCTION public.restrict_comment_pin_update()
RETURNS TRIGGER AS $$
BEGIN
  -- إذا كان المستخدم الحالي هو صاحب المنشور (وليس صاحب التعليق)
  -- يجب أن يُسمح فقط بتغيير is_pinned و pinned_at
  IF NEW.user_id = OLD.user_id
     AND NEW.content IS DISTINCT FROM OLD.content THEN
    -- صاحب المنشور يحاول تعديل المحتوى — ارفض
    RAISE EXCEPTION 'لا يمكنك تعديل محتوى تعليق لست صاحبه';
  END IF;

  IF NEW.user_id IS DISTINCT FROM OLD.user_id THEN
    -- محاولة تغيير صاحب التعليق (انتحال شخصية) — ارفض
    RAISE EXCEPTION 'لا يمكنك تغيير صاحب التعليق';
  END IF;

  IF NEW.created_at IS DISTINCT FROM OLD.created_at THEN
    RAISE EXCEPTION 'لا يمكنك تغيير تاريخ إنشاء التعليق';
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trigger_restrict_comment_pin_update ON public.comments;
CREATE TRIGGER trigger_restrict_comment_pin_update
  BEFORE UPDATE ON public.comments
  FOR EACH ROW EXECUTE FUNCTION public.restrict_comment_pin_update();

-- إعادة إنشاء سياسة صاحب المنشور لكن مع WITH CHECK يقيّد الحقول (لن يصل لها الـ trigger لأنه يرفض أولاً)
CREATE POLICY "comments_update_post_owner_pin" ON public.comments FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.posts p
      WHERE p.id = comments.post_id AND p.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.posts p
      WHERE p.id = comments.post_id AND p.user_id = auth.uid()
    )
  );

-- =====================================================
-- 2. إصلاح RLS على messages: إزالة سياسة "msg_update_recipient_read" الواسعة
-- (تستبدل بـ RPC مخصصة mark_messages_read من security-patch-p0.sql)
-- =====================================================
-- الثغرة: السياسة الموجودة في supabase-schema.sql تسمح لأي مشارك في المحادثة
-- بتعديل أي حقل في أي رسالة (content, sender_id, is_deleted, deleted_by)
-- بما في ذلك تزييف رسائل من مستخدمين آخرين أو حذف رسائل الآخرين
-- الإصلاح: حذف السياسة الواسعة نهائياً (RPC mark_messages_read يتولى المهمة بأمان)

DROP POLICY IF EXISTS "msg_update_recipient_read" ON public.messages;

-- =====================================================
-- 3. إصلاح RLS على message_requests: إضافة WITH CHECK لمنع تغيير sender_id
-- =====================================================
-- الثغرة: السياسة الحالية `mreq_update_receiver` تسمح للمستلم بتعديل أي حقل
-- بما في ذلك sender_id — يمكن للمستلم تغيير sender_id لمستخدم آخر ثم قبول الطلب
-- مما يفتح محادثة بين مستخدم آخر والمستلم
-- الإصلاح: إضافة WITH CHECK يتطلب بقاء sender_id و receiver_id ثابتين

DROP POLICY IF EXISTS "mreq_update_receiver" ON public.message_requests;
CREATE POLICY "mreq_update_receiver" ON public.message_requests FOR UPDATE
  USING (auth.uid() = receiver_id)
  WITH CHECK (
    auth.uid() = receiver_id
    -- منع تغيير sender_id أو receiver_id (يتم التحقق منها عبر trigger إضافي)
  );

-- Trigger يمنع تغيير sender_id من قبل المستلم
CREATE OR REPLACE FUNCTION public.restrict_message_request_fields()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.sender_id IS DISTINCT FROM OLD.sender_id THEN
    RAISE EXCEPTION 'لا يمكنك تغيير المُرسل';
  END IF;
  IF NEW.receiver_id IS DISTINCT FROM OLD.receiver_id THEN
    RAISE EXCEPTION 'لا يمكنك تغيير المُستلم';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trigger_restrict_message_request_fields ON public.message_requests;
CREATE TRIGGER trigger_restrict_message_request_fields
  BEFORE UPDATE ON public.message_requests
  FOR EACH ROW EXECUTE FUNCTION public.restrict_message_request_fields();

-- =====================================================
-- 4. إصلاح RLS على user_achievements: منع المستخدم من تعديل إنجازاته مباشرة
-- =====================================================
-- الثغرة: السياسة الحالية تسمح للمستخدم بتحديث أي حقل في إنجازاته
-- (progress, completed, completed_at) — يمكنه تعليم أي إنجاز كمكتمل
-- الإصلاح: منع التحديث المباشر، يجب أن يتم عبر update_achievement_progress RPC

DROP POLICY IF EXISTS "user_achievements_update_own" ON public.user_achievements;
-- لا نُنشئ سياسة بديلة — التحديث فقط عبر SECURITY DEFINER function

-- Trigger إضافي: التحقق من أن أي محاولة تحديث لـ user_achievements تتم من سياق RPC موثوق
-- (auth.uid() لا يعمل بشكل صحيح في SECURITY DEFINER، لكن السياق الذي يستدعيها يضمن الأمان)
-- الحل البديل: منع المستخدم العادي من التحديث مباشرة، والسماح فقط للـ RPC التي تستخدم SECURITY DEFINER
CREATE OR REPLACE FUNCTION public.prevent_user_achievement_direct_update()
RETURNS TRIGGER AS $$
BEGIN
  -- منع تحديث user_achievements من سياق RLS المباشر
  -- (SECURITY DEFINER يتجاوز RLS، لذا الـ RPC سيمر، لكن التحديث المباشر سيرفض)
  -- ملاحظة: هذه دالة SECURITY DEFINER، لذا session_user يكون مالك الدالة (postgres)
  -- إذا كان session_user = auth.uid()، فهذا تحديث مباشر من المستخدم — ارفضه
  IF session_user = auth.uid()::TEXT THEN
    RAISE EXCEPTION 'لا يمكنك تعديل إنجازاتك مباشرة';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trigger_prevent_user_achievement_direct_update ON public.user_achievements;
CREATE TRIGGER trigger_prevent_user_achievement_direct_update
  BEFORE UPDATE ON public.user_achievements
  FOR EACH ROW EXECUTE FUNCTION public.prevent_user_achievement_direct_update();

-- =====================================================
-- 5. إصلاح RPC get_streak_status: إضافة التحقق من auth.uid()
-- =====================================================
-- الثغرة: الدالة تسمح لأي مستخدم مصادق بقراءة حالة streak لأي مستخدم آخر
-- الإصلاح: التحقق من أن target_user_id = auth.uid()

CREATE OR REPLACE FUNCTION public.get_streak_status(target_user_id UUID)
RETURNS TABLE(
  current_streak INTEGER,
  longest_streak INTEGER,
  last_login_date DATE,
  total_logins INTEGER,
  has_freeze_available BOOLEAN,
  claimed_today BOOLEAN,
  days_until_freeze INTEGER
) AS $$
DECLARE
  user_record RECORD;
  today DATE := CURRENT_DATE;
  claimed BOOLEAN;
BEGIN
  -- V-26: التحقق من auth.uid()
  IF auth.uid() IS NULL OR auth.uid() != target_user_id THEN
    RETURN QUERY SELECT 0, 0, NULL::DATE, 0, FALSE, FALSE, 0;
    RETURN;
  END IF;

  SELECT login_streak, longest_streak, last_login_date, total_logins, streak_freeze_available
  INTO user_record
  FROM public.profiles WHERE id = target_user_id;

  IF NOT FOUND THEN
    RETURN QUERY SELECT 0, 0, NULL::DATE, 0, FALSE, FALSE, 0;
    RETURN;
  END IF;

  SELECT EXISTS(
    SELECT 1 FROM public.daily_rewards_log
    WHERE user_id = target_user_id AND reward_date = today
  ) INTO claimed;

  RETURN QUERY SELECT
    user_record.login_streak,
    user_record.longest_streak,
    user_record.last_login_date,
    user_record.total_logins,
    user_record.streak_freeze_available,
    claimed,
    CASE
      WHEN user_record.login_streak = 0 THEN 7
      ELSE 7 - ((user_record.login_streak - 1) % 7)
    END;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- =====================================================
-- 6. إصلاح RPC update_last_seen: التحقق من auth.uid() (مكرر من security-patch-p0.sql لضمان الأمان)
-- =====================================================
CREATE OR REPLACE FUNCTION public.update_last_seen(target_user_id UUID)
RETURNS VOID AS $$
BEGIN
  IF auth.uid() IS NULL OR auth.uid() != target_user_id THEN
    RETURN;
  END IF;
  UPDATE public.profiles SET last_seen = NOW() WHERE id = target_user_id AND show_last_seen = TRUE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- =====================================================
-- 7. حذف مستخدم من auth.users عند حذف الحساب
-- =====================================================
-- الثغرة: delete_user_account يحذف البيانات لكن يترك auth.users
-- مما يسمح للمستخدم بتسجيل الدخول مجدداً بعد "حذف" حسابه
-- الإصلاح: محاولة حذف المستخدم من auth.users عبر admin.deleteUser()
-- ملاحظة: حذف auth.users يتطلب service_role key ولا يمكن من العميل العادي
-- الحل المتاح: تعطيل المستخدم (ban) عبر RPC إذا كان admin API متاحاً في Supabase

-- دالة تحاول حذف auth.users — يجب تشغيلها من سياق service_role
CREATE OR REPLACE FUNCTION public.delete_auth_user(target_user_id UUID)
RETURNS BOOLEAN AS $$
BEGIN
  IF auth.uid() IS NULL OR auth.uid() != target_user_id THEN
    RETURN FALSE;
  END IF;

  -- محاولة حذف المستخدم من auth.users
  -- (هذا يتطلب صلاحية service_role — ستفشل من العميل العادي)
  BEGIN
    DELETE FROM auth.users WHERE id = target_user_id;
    RETURN TRUE;
  EXCEPTION WHEN OTHERS THEN
    -- إذا فشل الحذف (لأن المستخدم ليس admin)، اعتبر العملية نجحت جزئياً
    -- البيانات العامة محذوفة بالفعل في delete_user_account
    RETURN FALSE;
  END;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- تحديث delete_user_account لتستدعي delete_auth_user أولاً
CREATE OR REPLACE FUNCTION public.delete_user_account(target_user_id UUID)
RETURNS VOID AS $$
DECLARE
  user_email TEXT;
  auth_deleted BOOLEAN;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'غير مصادق';
  END IF;
  IF auth.uid() != target_user_id THEN
    RAISE EXCEPTION 'لا يمكنك حذف حساب مستخدم آخر';
  END IF;

  SELECT email INTO user_email FROM auth.users WHERE id = target_user_id;
  IF user_email IS NULL THEN
    RAISE EXCEPTION 'المستخدم غير موجود';
  END IF;

  -- 1. محاولة حذف المستخدم من auth.users أولاً (قد تفشل بدون service_role)
  SELECT public.delete_auth_user(target_user_id) INTO auth_deleted;

  -- 2. حذف كل البيانات المرتبطة
  DELETE FROM public.notifications WHERE user_id = target_user_id OR actor_id = target_user_id;
  DELETE FROM public.comment_likes WHERE user_id = target_user_id;
  DELETE FROM public.likes WHERE user_id = target_user_id;
  DELETE FROM public.comments WHERE user_id = target_user_id;
  DELETE FROM public.follows WHERE follower_id = target_user_id OR following_id = target_user_id;
  DELETE FROM public.message_requests WHERE sender_id = target_user_id OR receiver_id = target_user_id;
  DELETE FROM public.messages WHERE sender_id = target_user_id;
  DELETE FROM public.conversations WHERE participant_1 = target_user_id OR participant_2 = target_user_id;
  DELETE FROM public.posts WHERE user_id = target_user_id;
  DELETE FROM public.profiles WHERE id = target_user_id;

  RAISE NOTICE 'Account data deleted for user %. Auth user deleted: %', target_user_id, auth_deleted;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

GRANT EXECUTE ON FUNCTION public.delete_user_account(UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION public.delete_auth_user(UUID) TO authenticated;

-- =====================================================
-- ملاحظات:
-- 1. comments: الآن لا يمكن لصاحب المنشور تعديل محتوى التعليقات، فقط is_pinned
-- 2. messages: تم حذف سياسة update الواسعة، استخدم mark_messages_read RPC
-- 3. message_requests: تم منع تغيير sender_id/receiver_id من قبل المستلم
-- 4. user_achievements: منع التحديث المباشر من العميل (عبر RPC فقط)
-- 5. get_streak_status: الآن يتحقق من auth.uid()
-- 6. delete_user_account: يحاول الآن حذف auth.users (قد يفشل بدون service_role)
-- =====================================================
