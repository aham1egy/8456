-- =====================================================
-- مشرق - ترقية رسائل الصور + المسودات التلقائية
-- آمن للتشغيل المتكرر - يستخدم IF NOT EXISTS
-- =====================================================

-- =====================================================
-- 1. إضافة حقل image_url لجدول الرسائل
-- =====================================================
ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS image_url TEXT;

-- السماح بمحتوى فارغ إذا كانت هناك صورة (للرسائل الصورية فقط)
-- نحتاج لإسقاط CHECK constraint القديم وإضافة واحد جديد
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.check_constraints
    WHERE constraint_name = 'messages_content_check'
  ) THEN
    ALTER TABLE public.messages DROP CONSTRAINT messages_content_check;
  END IF;
END $$;

ALTER TABLE public.messages ADD CONSTRAINT messages_content_check
  CHECK (length(content) BETWEEN 1 AND 4000 OR (image_url IS NOT NULL AND length(content) <= 4000));

-- فهرس لتسريع البحث بالصور (اختياري)
CREATE INDEX IF NOT EXISTS idx_messages_image ON public.messages (image_url) WHERE image_url IS NOT NULL;

-- =====================================================
-- 2. إنشاء storage bucket لصور الرسائل
-- =====================================================
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES
  ('message-images', 'message-images', true, 5242880, ARRAY['image/png', 'image/jpeg', 'image/webp', 'image/gif'])
ON CONFLICT (id) DO NOTHING;

-- =====================================================
-- 3. سياسات Storage لصور الرسائل
-- =====================================================
DROP POLICY IF EXISTS "msg_images_public_read" ON storage.objects;
DROP POLICY IF EXISTS "msg_images_user_insert" ON storage.objects;
DROP POLICY IF EXISTS "msg_images_user_delete" ON storage.objects;

CREATE POLICY "msg_images_public_read" ON storage.objects FOR SELECT USING (bucket_id = 'message-images');
CREATE POLICY "msg_images_user_insert" ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'message-images' AND (auth.uid()::text = (storage.foldername(name))[1]));
CREATE POLICY "msg_images_user_delete" ON storage.objects FOR DELETE
  USING (bucket_id = 'message-images' AND (auth.uid()::text = (storage.foldername(name))[1]));

-- =====================================================
-- ملاحظات:
-- 1. هذا السكربت آمن للتشغيل المتكرر
-- 2. يضيف حقل image_url للرسائل (NULL افتراضياً)
-- 3. يسمح بإرسال صورة بدون نص (إذا image_url غير NULL)
-- 4. المسودات التلقائية تُحفظ في localStorage (لا حاجة لقاعدة بيانات)
-- =====================================================
