-- ============================================================
-- KemetNet — Verification System Fix (Instagram-like)
-- ============================================================
-- يحل:
--   1) خطأ duplicate key value violates unique constraint "verification_requests_user_id_status_key"
--      (السبب: UNIQUE(user_id, status) — يمنع المستخدم من طلب توثيق جديد بنفس الحالة)
--   2) علامات التوثيق لا تظهر للمستخدمين
--   3) التوثيق لا يحتسب عند المالك
--
-- يجعل نظام التوثيق نسخة طبق الأصل من Instagram:
--   ✓ شارة موثّق (Blue Badge) للأشخاص
--   ✓ شارة أعمال (Gray Badge) للشركات
--   ✓ شارة صناع المحتوى
--   ✓ إمكانية طلب توثيق جديد بعد الرفض
-- ============================================================
-- يُشغّل في Supabase Dashboard → SQL Editor → New query
-- آمن للتشغيل المتكرر (idempotent)
-- كل عبارة مستقلة (بدون BEGIN/COMMIT)
-- ============================================================

-- ============================================================
-- 1) إزالة القيد UNIQUE(user_id, status) المُسبب للمشكلة
-- ============================================================
-- هذا القيد يمنع المستخدم من طلب توثيق جديد بعد الرفض
-- (لأن status=pending → rejected → pending ثانية = duplicate)
--
-- مهم: يجب DROP CONSTRAINT أولاً، ثم DROP INDEX
-- (لأن الـ index محمي بواسطة الـ constraint)

ALTER TABLE public.verification_requests DROP CONSTRAINT IF EXISTS verification_requests_user_id_status_key;
DROP INDEX IF EXISTS public.verification_requests_user_id_status_key;

-- محاولة إضافية بأسماء بديلة (PostgreSQL قد يولّد أسماء مختلفة)
DO $$
DECLARE
  constr RECORD;
BEGIN
  FOR constr IN
    SELECT conname
    FROM pg_constraint
    WHERE conrelid = 'public.verification_requests'::regclass
      AND contype = 'u'  -- unique constraints
      AND conname LIKE '%verification_requests%'
  LOOP
    EXECUTE format('ALTER TABLE public.verification_requests DROP CONSTRAINT IF EXISTS %I', constr.conname);
  END LOOP;
END $$;

-- ============================================================
-- 2) إضافة قيد بديل: UNIQUE(user_id, status) فقط لـ status='pending'
--    (المستخدم يمكنه طلب واحد pending في كل مرة، لكن تاريخ كل الطلبات محفوظ)
-- ============================================================
CREATE UNIQUE INDEX IF NOT EXISTS idx_verification_requests_unique_pending
  ON public.verification_requests (user_id)
  WHERE status = 'pending';

-- ============================================================
-- 3) إضافة أعمدة لتتبع أفضل (مثل Instagram)
-- ============================================================
ALTER TABLE public.verification_requests ADD COLUMN IF NOT EXISTS reviewed_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL;
ALTER TABLE public.verification_requests ADD COLUMN IF NOT EXISTS reviewed_at timestamptz;
ALTER TABLE public.verification_requests ADD COLUMN IF NOT EXISTS admin_note text;

-- نسخ admin_notes إلى admin_note للتوافق
UPDATE public.verification_requests
SET admin_note = admin_notes
WHERE admin_note IS NULL AND admin_notes IS NOT NULL;

-- ============================================================
-- 4) تحديث RPC: admin_verify_user
--    يجعل المستخدم موثّق + يحفظ من وثّقه ومتى
-- ============================================================
CREATE OR REPLACE FUNCTION public.admin_verify_user(
  target_user_id uuid,
  verified_type text DEFAULT 'official'
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  current_user_id uuid := auth.uid();
BEGIN
  IF NOT public.is_admin() THEN
    RAISE EXCEPTION 'Unauthorized: admin access required';
  END IF;

  -- تحديث profile
  UPDATE public.profiles
  SET is_verified = true,
      verified_type = verified_type,
      verified_at = now()
  WHERE id = target_user_id;

  -- تحديث كل طلبات التوثيق المعلّقة لهذا المستخدم إلى approved
  UPDATE public.verification_requests
  SET status = 'approved',
      reviewed_by = current_user_id,
      reviewed_at = now(),
      admin_note = COALESCE(admin_note, 'تمت الموافقة من قبل الإدارة')
  WHERE user_id = target_user_id
    AND status = 'pending';

  RETURN true;
END;
$$;

-- ============================================================
-- 5) تحديث RPC: admin_unverify_user
--    يزيل التوثيق + يحفظ من أزاله
-- ============================================================
CREATE OR REPLACE FUNCTION public.admin_unverify_user(target_user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_admin() THEN
    RAISE EXCEPTION 'Unauthorized: admin access required';
  END IF;

  UPDATE public.profiles
  SET is_verified = false,
      verified_type = NULL,
      verified_at = NULL
  WHERE id = target_user_id;

  RETURN true;
END;
$$;

-- ============================================================
-- 6) تحديث RPC: admin_approve_verification
--    يقبل طلب توثيق محدد + يوثّق المستخدم
-- ============================================================
CREATE OR REPLACE FUNCTION public.admin_approve_verification(
  request_id uuid,
  p_admin_note text DEFAULT NULL
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user_id uuid;
  v_requested_type text;
  current_user_id uuid := auth.uid();
BEGIN
  IF NOT public.is_admin() THEN
    RAISE EXCEPTION 'Unauthorized: admin access required';
  END IF;

  -- جلب بيانات الطلب
  SELECT user_id, requested_type INTO v_user_id, v_requested_type
  FROM public.verification_requests
  WHERE id = request_id;

  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Verification request not found';
  END IF;

  -- تحديث الطلب
  UPDATE public.verification_requests
  SET status = 'approved',
      reviewed_by = current_user_id,
      reviewed_at = now(),
      admin_note = COALESCE(p_admin_note, 'تمت الموافقة')
  WHERE id = request_id;

  -- توثيق المستخدم
  UPDATE public.profiles
  SET is_verified = true,
      verified_type = v_requested_type,
      verified_at = now()
  WHERE id = v_user_id;

  -- تحديث بقية طلبات المستخدم المعلّقة إلى approved
  UPDATE public.verification_requests
  SET status = 'approved',
      reviewed_by = current_user_id,
      reviewed_at = now(),
      admin_note = COALESCE(admin_note, 'مُعالجة تلقائيًا بعد الموافقة')
  WHERE user_id = v_user_id
    AND status = 'pending'
    AND id != request_id;

  RETURN true;
END;
$$;

-- ============================================================
-- 7) تحديث RPC: admin_reject_verification
--    يرفض طلب توثيق محدد + يحفظ السبب
-- ============================================================
CREATE OR REPLACE FUNCTION public.admin_reject_verification(
  request_id uuid,
  p_admin_note text DEFAULT 'تم الرفض'
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  current_user_id uuid := auth.uid();
BEGIN
  IF NOT public.is_admin() THEN
    RAISE EXCEPTION 'Unauthorized: admin access required';
  END IF;

  UPDATE public.verification_requests
  SET status = 'rejected',
      reviewed_by = current_user_id,
      reviewed_at = now(),
      admin_note = p_admin_note
  WHERE id = request_id;

  RETURN true;
END;
$$;

-- ============================================================
-- 8) تحديث سياسات RLS على verification_requests
--    المالك/الأدمن يقرؤون كل الطلبات، المستخدم يقرأ طلباته فقط
-- ============================================================
DROP POLICY IF EXISTS "verification_requests_select_own" ON public.verification_requests;
DROP POLICY IF EXISTS "verification_requests_insert_own" ON public.verification_requests;
DROP POLICY IF EXISTS "verification_requests_update_admin" ON public.verification_requests;
DROP POLICY IF EXISTS "Staff can update verification_requests" ON public.verification_requests;

-- SELECT: المستخدم يرى طلباته + المدراء يرون كل الطلبات
CREATE POLICY "verification_requests_select" ON public.verification_requests
  FOR SELECT USING (
    user_id = auth.uid() OR public.has_permission('manage_verifications')
  );

-- INSERT: المستخدم ينشئ طلباته فقط
CREATE POLICY "verification_requests_insert_own" ON public.verification_requests
  FOR INSERT WITH CHECK (user_id = auth.uid());

-- UPDATE: فقط من يملك صلاحية manage_verifications
CREATE POLICY "verification_requests_update_admin" ON public.verification_requests
  FOR UPDATE USING (public.has_permission('manage_verifications'));

-- ============================================================
-- 9) ضمان وجود أعمدة التوثيق في profiles
-- ============================================================
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS is_verified boolean DEFAULT false;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS verified_type text;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS verified_at timestamptz;

-- ============================================================
-- 10) توثيق حسابات المالكين تلقائيًا (إذا لم تكن موثّقة)
-- ============================================================
UPDATE public.profiles
SET is_verified = true,
    verified_type = 'official',
    verified_at = COALESCE(verified_at, now())
WHERE username IN ('kemetnet', 'kemetnet_admin')
  AND (is_verified = false OR is_verified IS NULL);

-- ============================================================
-- التحقق
-- ============================================================
SELECT '✅ Verification system fixed (Instagram-like)' AS status;

-- عرض المالكين الموثّقين
SELECT username, is_verified, verified_type, verified_at
FROM public.profiles
WHERE username IN ('kemetnet', 'kemetnet_admin');

-- عرض كل الطلبات المعلّقة
SELECT id, user_id, requested_type, status, created_at
FROM public.verification_requests
ORDER BY created_at DESC LIMIT 5;
