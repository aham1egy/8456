-- ============================================================
-- KemetNet — Final RPC Setup v3 (No Transaction)
-- ============================================================
-- كل عبارة مستقلة (بدون BEGIN/COMMIT)
-- إذا فشلت دالة واحدة، الباقي ينجح
-- يُشغّل في Supabase Dashboard → SQL Editor → New query
-- ============================================================

-- ============= 1) has_permission =============
CREATE OR REPLACE FUNCTION public.has_permission(perm text)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.id = auth.uid()
    AND (
      p.role = 'owner'
      OR p.username = 'kemetnet'
      OR p.role = 'admin'
      OR EXISTS (
        SELECT 1 FROM public.staff_members sm
        WHERE sm.user_id = p.id
          AND sm.active = true
          AND (
            sm.permissions @> jsonb_build_array(perm)
            OR sm.permissions @> jsonb_build_array('*')
          )
      )
    )
  );
$$;

-- ============= 2) add_staff_member =============
CREATE OR REPLACE FUNCTION public.add_staff_member(
  target_user_id uuid,
  staff_role text DEFAULT 'moderator',
  perms jsonb DEFAULT '[]'::jsonb,
  staff_notes text DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  new_id uuid;
BEGIN
  IF NOT public.is_owner() THEN
    RAISE EXCEPTION 'Unauthorized: owner access required';
  END IF;
  IF target_user_id = auth.uid() THEN
    RAISE EXCEPTION 'Cannot add yourself as staff';
  END IF;
  IF EXISTS (SELECT 1 FROM public.staff_members WHERE user_id = target_user_id) THEN
    RAISE EXCEPTION 'User is already a staff member';
  END IF;
  INSERT INTO public.staff_members (user_id, role, permissions, added_by, notes)
  VALUES (target_user_id, staff_role, perms, auth.uid(), staff_notes)
  RETURNING id INTO new_id;
  UPDATE public.profiles
  SET role = staff_role, is_admin = true
  WHERE id = target_user_id;
  RETURN new_id;
END;
$$;

-- ============= 3) update_staff_permissions =============
CREATE OR REPLACE FUNCTION public.update_staff_permissions(
  target_user_id uuid,
  new_permissions jsonb,
  new_role text DEFAULT NULL,
  new_active boolean DEFAULT NULL,
  new_notes text DEFAULT NULL
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_owner() THEN
    RAISE EXCEPTION 'Unauthorized: owner access required';
  END IF;
  UPDATE public.staff_members
  SET
    permissions = COALESCE(new_permissions, permissions),
    role = COALESCE(new_role, role),
    active = COALESCE(new_active, active),
    notes = COALESCE(new_notes, notes),
    updated_at = now()
  WHERE user_id = target_user_id;
  IF new_role IS NOT NULL THEN
    UPDATE public.profiles SET role = new_role WHERE id = target_user_id;
  END IF;
  IF new_active = false THEN
    UPDATE public.profiles
    SET role = 'user', is_admin = false
    WHERE id = target_user_id AND role != 'owner';
  END IF;
  RETURN true;
END;
$$;

-- ============= 4) remove_staff_member =============
CREATE OR REPLACE FUNCTION public.remove_staff_member(target_user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_owner() THEN
    RAISE EXCEPTION 'Unauthorized: owner access required';
  END IF;
  IF target_user_id = auth.uid() THEN
    RAISE EXCEPTION 'Cannot remove yourself';
  END IF;
  DELETE FROM public.staff_members WHERE user_id = target_user_id;
  UPDATE public.profiles
  SET role = 'user', is_admin = false
  WHERE id = target_user_id AND role != 'owner';
  RETURN true;
END;
$$;

-- ============= 5) admin_delete_user_complete =============
CREATE OR REPLACE FUNCTION public.admin_delete_user_complete(target_user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_admin() THEN
    RAISE EXCEPTION 'Unauthorized: admin access required';
  END IF;
  IF target_user_id = auth.uid() THEN
    RAISE EXCEPTION 'Cannot delete yourself';
  END IF;
  DELETE FROM auth.users WHERE id = target_user_id;
  RETURN true;
END;
$$;

-- ============= 6) admin_restrict_user =============
CREATE OR REPLACE FUNCTION public.admin_restrict_user(
  target_user_id uuid,
  reason text,
  days int DEFAULT 7
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_admin() THEN
    RAISE EXCEPTION 'Unauthorized: admin access required';
  END IF;
  UPDATE public.profiles
  SET restricted_until = NOW() + (days || ' days')::interval,
      restriction_reason = reason
  WHERE id = target_user_id;
  RETURN true;
END;
$$;

-- ============= 7) admin_unrestrict_user =============
CREATE OR REPLACE FUNCTION public.admin_unrestrict_user(target_user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_admin() THEN
    RAISE EXCEPTION 'Unauthorized: admin access required';
  END IF;
  UPDATE public.profiles
  SET restricted_until = NULL,
      restriction_reason = NULL
  WHERE id = target_user_id;
  RETURN true;
END;
$$;

-- ============= 8) admin_verify_user =============
CREATE OR REPLACE FUNCTION public.admin_verify_user(
  target_user_id uuid,
  verified_type text DEFAULT 'official'
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_admin() THEN
    RAISE EXCEPTION 'Unauthorized: admin access required';
  END IF;
  UPDATE public.profiles
  SET is_verified = true,
      verified_type = verified_type,
      verified_at = now()
  WHERE id = target_user_id;
  RETURN true;
END;
$$;

-- ============= 9) admin_unverify_user =============
CREATE OR REPLACE FUNCTION public.admin_unverify_user(target_user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_admin() THEN
    RAISE EXCEPTION 'Unauthorized: admin access required';
  END IF;
  UPDATE public.profiles
  SET is_verified = false,
      verified_type = NULL,
      verified_at = NULL
  WHERE id = target_user_id;
  RETURN true;
END;
$$;

-- ============= 10) update_last_seen =============
CREATE OR REPLACE FUNCTION public.update_last_seen(target_user_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF target_user_id = auth.uid() OR public.is_admin() THEN
    UPDATE public.profiles
    SET last_seen = now()
    WHERE id = target_user_id;
  END IF;
END;
$$;

-- ============= 11) search_users =============
CREATE OR REPLACE FUNCTION public.search_users(query text, limit_count int DEFAULT 20)
RETURNS TABLE (
  id uuid,
  username text,
  display_name text,
  avatar_url text,
  avatar_color text,
  is_verified boolean,
  followers_count int
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT id, username, display_name, avatar_url, avatar_color, is_verified, followers_count
  FROM public.profiles
  WHERE username ILIKE '%' || query || '%'
     OR display_name ILIKE '%' || query || '%'
  ORDER BY
    CASE
      WHEN username ILIKE query || '%' THEN 1
      WHEN display_name ILIKE query || '%' THEN 2
      ELSE 3
    END,
    followers_count DESC
  LIMIT COALESCE(limit_count, 20);
$$;

-- ============= التحقق =============
SELECT '✅ RPC functions installed' AS status;

SELECT COUNT(*) AS total_rpcs
FROM information_schema.routines
WHERE routine_schema = 'public'
  AND routine_type = 'FUNCTION'
  AND (routine_name LIKE 'admin_%' OR routine_name = 'is_admin' OR routine_name = 'is_owner'
       OR routine_name = 'has_permission' OR routine_name = 'update_last_seen'
       OR routine_name = 'search_users' OR routine_name = 'get_feed'
       OR routine_name = 'delete_account' OR routine_name LIKE 'add_staff%'
       OR routine_name LIKE 'update_staff%' OR routine_name LIKE 'remove_staff%');
