-- =====================================================
-- مشرق - نظام النقاط والسمعة (Reputation System)
-- آمن للتشغيل المتكرر
-- =====================================================

-- =====================================================
-- 0. التأكد من وجود الأعمدة المعتمد عليها (من ملفات ترقية سابقة)
-- =====================================================
-- repost_of: من reposts-saved-upgrade.sql
ALTER TABLE public.posts ADD COLUMN IF NOT EXISTS repost_of UUID;
ALTER TABLE public.posts ADD COLUMN IF NOT EXISTS reposts_count INTEGER DEFAULT 0;
-- is_pinned: من pinned-posts-upgrade.sql
ALTER TABLE public.posts ADD COLUMN IF NOT EXISTS is_pinned BOOLEAN DEFAULT FALSE;

-- =====================================================
-- 1. إضافة حقول النقاط لجدول profiles
-- =====================================================
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS reputation_points INTEGER DEFAULT 0;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS reputation_level INTEGER DEFAULT 1;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS total_earned_points INTEGER DEFAULT 0;

-- =====================================================
-- 2. جدول سجل النقاط (reputation_log)
-- =====================================================
CREATE TABLE IF NOT EXISTS public.reputation_log (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  -- نوع النشاط الذي أكسب النقاط
  activity_type TEXT NOT NULL CHECK (activity_type IN (
    'post_created',      -- منشور جديد
    'post_liked',        -- منشورك حصل على إعجاب
    'post_commented',    -- منشورك حصل على تعليق
    'post_reposted',     -- منشورك أُعيد نشره
    'post_saved',        -- منشورك حُفظ
    'comment_liked',     -- تعليقك حصل على إعجاب
    'comment_replied',   -- تعليقك حصل على رد
    'follow_received',   -- حصلت على متابع جديد
    'mention_received',  -- تمت الإشارة إليك
    'message_received',  -- استلمت رسالة
    'daily_login',       -- تسجيل دخول يومي
    'first_post',        -- أول منشور
    'verification',      -- الحصول على شارة التحقق
    'early_adopter',     -- مكافأة المستخدم المبكر
    'profile_completed'  -- إكمال الملف الشخصي
  )),
  -- عدد النقاط المكتسبة
  points_earned INTEGER NOT NULL,
  -- معرف المحتوى المرتبط (اختياري)
  related_id UUID,
  related_type TEXT,
  -- التاريخ
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_reputation_log_user ON public.reputation_log (user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_reputation_log_activity ON public.reputation_log (activity_type);

-- =====================================================
-- 3. RLS لجدول سجل النقاط
-- =====================================================
ALTER TABLE public.reputation_log ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "reputation_log_select_own" ON public.reputation_log;
CREATE POLICY "reputation_log_select_own" ON public.reputation_log FOR SELECT 
  USING (auth.uid() = user_id);

-- الإدراج يكون فقط عبر SECURITY DEFINER functions
-- المستخدم العادي لا يمكنه إدراج نقاط بنفسه

-- =====================================================
-- 4. تعريف نقاط كل نشاط
-- =====================================================
CREATE OR REPLACE FUNCTION public.get_activity_points(activity_type TEXT)
RETURNS INTEGER AS $$
BEGIN
  RETURN CASE activity_type
    WHEN 'post_created' THEN 5
    WHEN 'post_liked' THEN 2
    WHEN 'post_commented' THEN 3
    WHEN 'post_reposted' THEN 4
    WHEN 'post_saved' THEN 2
    WHEN 'comment_liked' THEN 1
    WHEN 'comment_replied' THEN 2
    WHEN 'follow_received' THEN 3
    WHEN 'mention_received' THEN 2
    WHEN 'message_received' THEN 1
    WHEN 'daily_login' THEN 10
    WHEN 'first_post' THEN 50
    WHEN 'verification' THEN 100
    WHEN 'early_adopter' THEN 25
    WHEN 'profile_completed' THEN 15
    ELSE 0
  END;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- =====================================================
-- 5. دالة لإضافة نقاط لمستخدم
-- =====================================================
CREATE OR REPLACE FUNCTION public.award_reputation_points(
  target_user_id UUID,
  activity_type TEXT,
  related_id UUID DEFAULT NULL,
  related_type TEXT DEFAULT NULL
)
RETURNS VOID AS $$
DECLARE
  points INTEGER;
BEGIN
  points := public.get_activity_points(activity_type);
  IF points = 0 THEN
    RETURN;
  END IF;
  
  -- إدراج في سجل النقاط
  INSERT INTO public.reputation_log (user_id, activity_type, points_earned, related_id, related_type)
  VALUES (target_user_id, activity_type, points, related_id, related_type);
  
  -- تحديث نقاط المستخدم
  UPDATE public.profiles 
  SET reputation_points = reputation_points + points,
      total_earned_points = total_earned_points + points,
      reputation_level = GREATEST(1, FLOOR(SQRT((reputation_points + points) / 100.0))::INTEGER + 1)
  WHERE id = target_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

GRANT EXECUTE ON FUNCTION public.award_reputation_points(UUID, TEXT, UUID, TEXT) TO authenticated;

-- =====================================================
-- 6. دالة لجلب مستوى السمعة
-- =====================================================
CREATE OR REPLACE FUNCTION public.get_reputation_level(points INTEGER)
RETURNS INTEGER AS $$
BEGIN
  RETURN GREATEST(1, FLOOR(SQRT(points / 100.0))::INTEGER + 1);
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- =====================================================
-- 7. Triggers لمنح النقاط تلقائياً
-- =====================================================

-- منشور جديد
CREATE OR REPLACE FUNCTION public.award_points_on_post()
RETURNS TRIGGER AS $$
BEGIN
  -- إذا كان أول منشور، امنح 50 نقطة، وإلا 5
  IF NEW.repost_of IS NULL THEN
    PERFORM public.award_reputation_points(NEW.user_id, 'post_created', NEW.id, 'post');
    
    -- تحقق من أول منشور
    IF NOT EXISTS (SELECT 1 FROM public.posts WHERE user_id = NEW.user_id AND id != NEW.id) THEN
      PERFORM public.award_reputation_points(NEW.user_id, 'first_post', NEW.id, 'post');
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trigger_award_points_on_post ON public.posts;
CREATE TRIGGER trigger_award_points_on_post
  AFTER INSERT ON public.posts
  FOR EACH ROW EXECUTE FUNCTION public.award_points_on_post();

-- إعجاب بمنشور
CREATE OR REPLACE FUNCTION public.award_points_on_like()
RETURNS TRIGGER AS $$
DECLARE
  post_owner UUID;
BEGIN
  SELECT user_id INTO post_owner FROM public.posts WHERE id = NEW.post_id;
  IF post_owner IS NOT NULL AND post_owner != NEW.user_id THEN
    PERFORM public.award_reputation_points(post_owner, 'post_liked', NEW.post_id, 'post');
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trigger_award_points_on_like ON public.likes;
CREATE TRIGGER trigger_award_points_on_like
  AFTER INSERT ON public.likes
  FOR EACH ROW EXECUTE FUNCTION public.award_points_on_like();

-- تعليق على منشور
CREATE OR REPLACE FUNCTION public.award_points_on_comment()
RETURNS TRIGGER AS $$
DECLARE
  post_owner UUID;
BEGIN
  SELECT user_id INTO post_owner FROM public.posts WHERE id = NEW.post_id;
  IF post_owner IS NOT NULL AND post_owner != NEW.user_id THEN
    PERFORM public.award_reputation_points(post_owner, 'post_commented', NEW.post_id, 'post');
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trigger_award_points_on_comment ON public.comments;
CREATE TRIGGER trigger_award_points_on_comment
  AFTER INSERT ON public.comments
  FOR EACH ROW EXECUTE FUNCTION public.award_points_on_comment();

-- متابعة جديدة
CREATE OR REPLACE FUNCTION public.award_points_on_follow()
RETURNS TRIGGER AS $$
BEGIN
  PERFORM public.award_reputation_points(NEW.following_id, 'follow_received', NEW.id, 'follow');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trigger_award_points_on_follow ON public.follows;
CREATE TRIGGER trigger_award_points_on_follow
  AFTER INSERT ON public.follows
  FOR EACH ROW EXECUTE FUNCTION public.award_points_on_follow();

-- إعادة نشر
CREATE OR REPLACE FUNCTION public.award_points_on_repost()
RETURNS TRIGGER AS $$
DECLARE
  original_owner UUID;
BEGIN
  IF NEW.repost_of IS NOT NULL THEN
    SELECT user_id INTO original_owner FROM public.posts WHERE id = NEW.repost_of;
    IF original_owner IS NOT NULL AND original_owner != NEW.user_id THEN
      PERFORM public.award_reputation_points(original_owner, 'post_reposted', NEW.repost_of, 'post');
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trigger_award_points_on_repost ON public.posts;
CREATE TRIGGER trigger_award_points_on_repost
  AFTER INSERT ON public.posts
  FOR EACH ROW
  WHEN (NEW.repost_of IS NOT NULL)
  EXECUTE FUNCTION public.award_points_on_repost();

-- =====================================================
-- ملاحظات:
-- 1. النقاط تُمنح تلقائياً عبر triggers
-- 2. المستخدم لا يمكنه التلاعب بالنقاط (RLS + SECURITY DEFINER)
-- 3. المستوى = floor(sqrt(points/100)) + 1
-- 4. total_earned_points لا ينقص (حتى لو حُذفت المنشورات)
-- =====================================================
