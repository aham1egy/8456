-- =====================================================
-- مشرق - مكافآت تسجيل الدخول اليومي (Daily Streak)
-- آمن للتشغيل المتكرر
-- =====================================================

-- =====================================================
-- 1. إضافة حقول الـ streak لجدول profiles
-- =====================================================
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS login_streak INTEGER DEFAULT 0;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS longest_streak INTEGER DEFAULT 0;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS last_login_date DATE;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS total_logins INTEGER DEFAULT 0;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS streak_freeze_available BOOLEAN DEFAULT FALSE;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS streak_freeze_used INTEGER DEFAULT 0;

-- =====================================================
-- 2. جدول سجل المكافآت اليومية (daily_rewards_log)
-- =====================================================
CREATE TABLE IF NOT EXISTS public.daily_rewards_log (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  -- تاريخ المكافأة
  reward_date DATE NOT NULL,
  -- اليوم في الـ streak (1-7 ثم يتكرر)
  streak_day INTEGER NOT NULL CHECK (streak_day BETWEEN 1 AND 7),
  -- النقاط الممنوحة
  points_awarded INTEGER NOT NULL,
  -- نوع المكافأة
  reward_type TEXT NOT NULL DEFAULT 'points' CHECK (reward_type IN ('points', 'streak_freeze', 'bonus')),
  -- التاريخ
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  -- منع التكرار في نفس اليوم
  UNIQUE(user_id, reward_date)
);

CREATE INDEX IF NOT EXISTS idx_daily_rewards_user ON public.daily_rewards_log (user_id, reward_date DESC);

-- =====================================================
-- 3. RLS
-- =====================================================
ALTER TABLE public.daily_rewards_log ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "daily_rewards_select_own" ON public.daily_rewards_log;
CREATE POLICY "daily_rewards_select_own" ON public.daily_rewards_log FOR SELECT 
  USING (auth.uid() = user_id);

-- =====================================================
-- 4. دالة لتسجيل الدخول اليومي + منح المكافأة
-- =====================================================
CREATE OR REPLACE FUNCTION public.claim_daily_reward(target_user_id UUID)
RETURNS TABLE(
  success BOOLEAN,
  streak INTEGER,
  day_in_cycle INTEGER,
  points_awarded INTEGER,
  reward_type TEXT,
  is_new_streak BOOLEAN,
  streak_broken BOOLEAN
) AS $$
DECLARE
  user_record RECORD;
  today DATE := CURRENT_DATE;
  yesterday DATE := CURRENT_DATE - 1;
  new_streak INTEGER;
  day_in_cycle INTEGER;
  points_to_award INTEGER;
  reward_type_val TEXT := 'points';
  is_new_streak_val BOOLEAN := FALSE;
  streak_broken_val BOOLEAN := FALSE;
  already_claimed BOOLEAN;
  has_freeze BOOLEAN;
BEGIN
  -- جلب بيانات المستخدم
  SELECT * INTO user_record FROM public.profiles WHERE id = target_user_id;
  IF NOT FOUND THEN
    RETURN QUERY SELECT FALSE, 0, 0, 0, NULL::TEXT, FALSE, FALSE;
    RETURN;
  END IF;
  
  -- التحقق من عدم المطالبة في نفس اليوم
  SELECT EXISTS(
    SELECT 1 FROM public.daily_rewards_log 
    WHERE user_id = target_user_id AND reward_date = today
  ) INTO already_claimed;
  
  IF already_claimed THEN
    -- سبق المطالبة اليوم
    day_in_cycle := ((user_record.login_streak - 1) % 7) + 1;
    RETURN QUERY SELECT FALSE, user_record.login_streak, day_in_cycle, 0, NULL::TEXT, FALSE, FALSE;
    RETURN;
  END IF;
  
  -- حساب الـ streak الجديد
  IF user_record.last_login_date IS NULL THEN
    -- أول تسجيل دخول
    new_streak := 1;
    is_new_streak_val := TRUE;
  ELSIF user_record.last_login_date = yesterday THEN
    -- استمرار الـ streak
    new_streak := user_record.login_streak + 1;
    is_new_streak_val := (new_streak = 2); -- streak جديد إذا كان اليوم الثاني
  ELSIF user_record.last_login_date = today THEN
    -- سبق تسجيل الدخول اليوم (يجب ألا يصل هنا بسبب التحقق السابق)
    new_streak := user_record.login_streak;
  ELSE
    -- انقطع الـ streak
    -- تحقق من توفر streak freeze
    IF user_record.streak_freeze_available THEN
      -- استخدام freeze للحفاظ على الـ streak
      new_streak := user_record.login_streak + 1;
      has_freeze := TRUE;
      -- استهلاك الـ freeze
      UPDATE public.profiles 
      SET streak_freeze_available = FALSE, 
          streak_freeze_used = streak_freeze_used + 1
      WHERE id = target_user_id;
      reward_type_val := 'streak_freeze';
    ELSE
      -- إعادة بدء الـ streak
      new_streak := 1;
      streak_broken_val := TRUE;
      is_new_streak_val := TRUE;
    END IF;
  END IF;
  
  -- حساب اليوم في الدورة (1-7)
  day_in_cycle := ((new_streak - 1) % 7) + 1;
  
  -- حساب النقاط حسب اليوم
  points_to_award := CASE day_in_cycle
    WHEN 1 THEN 10   -- اليوم 1: 10 نقاط
    WHEN 2 THEN 15   -- اليوم 2: 15 نقطة
    WHEN 3 THEN 20   -- اليوم 3: 20 نقطة
    WHEN 4 THEN 25   -- اليوم 4: 25 نقطة
    WHEN 5 THEN 30   -- اليوم 5: 30 نقطة
    WHEN 6 THEN 40   -- اليوم 6: 40 نقطة
    WHEN 7 THEN 50   -- اليوم 7 (إكمال الأسبوع): 50 نقطة + streak freeze
    ELSE 10
  END;
  
  -- في اليوم 7، امنح streak freeze
  IF day_in_cycle = 7 THEN
    UPDATE public.profiles SET streak_freeze_available = TRUE WHERE id = target_user_id;
    reward_type_val := 'bonus';
  END IF;
  
  -- إدراج في سجل المكافآت
  INSERT INTO public.daily_rewards_log (user_id, reward_date, streak_day, points_awarded, reward_type)
  VALUES (target_user_id, today, day_in_cycle, points_to_award, reward_type_val);
  
  -- تحديث الـ profile
  UPDATE public.profiles 
  SET 
    login_streak = new_streak,
    longest_streak = GREATEST(longest_streak, new_streak),
    last_login_date = today,
    total_logins = total_logins + 1,
    reputation_points = reputation_points + points_to_award,
    total_earned_points = total_earned_points + points_to_award,
    reputation_level = GREATEST(1, FLOOR(SQRT((reputation_points + points_to_award) / 100.0))::INTEGER + 1)
  WHERE id = target_user_id;
  
  -- منح إنجاز إذا لزم
  IF new_streak = 7 THEN
    -- إكمال أسبوع كامل
    -- يمكن إضافة إنجاز "أسبوع كامل" هنا
    NULL;
  END IF;
  
  RETURN QUERY SELECT 
    TRUE, 
    new_streak, 
    day_in_cycle, 
    points_to_award, 
    reward_type_val, 
    is_new_streak_val, 
    streak_broken_val;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

GRANT EXECUTE ON FUNCTION public.claim_daily_reward(UUID) TO authenticated;

-- =====================================================
-- 5. دالة لجلب حالة الـ streak الحالية
-- =====================================================
CREATE OR REPLACE FUNCTION public.get_streak_status(target_user_id UUID)
RETURNS TABLE(
  current_streak INTEGER,
  longest_streak INTEGER,
  last_login_date DATE,
  total_logins INTEGER,
  has_freeze_available BOOLEAN,
  claimed_today BOOLEAN,
  days_until_freeze INTEGER
) AS $$
DECLARE
  user_record RECORD;
  today DATE := CURRENT_DATE;
  claimed BOOLEAN;
BEGIN
  SELECT login_streak, longest_streak, last_login_date, total_logins, streak_freeze_available
  INTO user_record
  FROM public.profiles WHERE id = target_user_id;
  
  IF NOT FOUND THEN
    RETURN QUERY SELECT 0, 0, NULL::DATE, 0, FALSE, FALSE, 0;
    RETURN;
  END IF;
  
  SELECT EXISTS(
    SELECT 1 FROM public.daily_rewards_log 
    WHERE user_id = target_user_id AND reward_date = today
  ) INTO claimed;
  
  RETURN QUERY SELECT 
    user_record.login_streak,
    user_record.longest_streak,
    user_record.last_login_date,
    user_record.total_logins,
    user_record.streak_freeze_available,
    claimed,
    CASE 
      WHEN user_record.login_streak = 0 THEN 7
      ELSE 7 - ((user_record.login_streak - 1) % 7)
    END;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

GRANT EXECUTE ON FUNCTION public.get_streak_status(UUID) TO authenticated;

-- =====================================================
-- ملاحظات:
-- 1. streak يزداد يومياً عند تسجيل الدخول
-- 2. اليوم 7 يمنح: 50 نقطة + streak freeze (يحمي من انقطاع يوم واحد)
-- 3. عند انقطاع الـ streak: إعادة من 1 (إلا إذا كان هناك freeze)
-- 4. المكافآت: 10 → 15 → 20 → 25 → 30 → 40 → 50 (تتكرر أسبوعياً)
-- 5. longest_streak: أطول streak في تاريخ المستخدم
-- =====================================================
