-- =====================================================
-- مشروع مشرق - مخطط قاعدة بيانات Supabase (شامل)
-- Mishri App Database Schema - Full Setup
-- 
-- ينشئ كل الجداول والسياسات والـ triggers والبيانات التجريبية
-- آمن للاستخدام: يحذف الجداول الموجودة بـ CASCADE أولاً
-- =====================================================

-- تفعيل الامتدادات
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- =====================================================
-- حذف الجداول الموجودة (إن وُجدت) - آمن للتكرار
-- =====================================================
DROP TRIGGER IF EXISTS trigger_notify_on_like ON public.likes;
DROP TRIGGER IF EXISTS trigger_notify_on_comment ON public.comments;
DROP TRIGGER IF EXISTS trigger_notify_on_follow ON public.follows;
DROP FUNCTION IF EXISTS public.notify_on_like() CASCADE;
DROP FUNCTION IF EXISTS public.notify_on_comment() CASCADE;
DROP FUNCTION IF EXISTS public.notify_on_follow() CASCADE;
DROP TABLE IF EXISTS public.notifications CASCADE;
DROP TABLE IF EXISTS public.follows CASCADE;
DROP TABLE IF EXISTS public.comments CASCADE;
DROP TABLE IF EXISTS public.likes CASCADE;
DROP TABLE IF EXISTS public.posts CASCADE;
DROP TABLE IF EXISTS public.profiles CASCADE;

-- حذف الـ triggers والـ functions القديمة
DROP TRIGGER IF EXISTS trigger_handle_new_user ON auth.users;
DROP FUNCTION IF EXISTS public.handle_new_user() CASCADE;
DROP FUNCTION IF EXISTS public.update_posts_count() CASCADE;
DROP FUNCTION IF EXISTS public.update_likes_count() CASCADE;
DROP FUNCTION IF EXISTS public.update_comments_count() CASCADE;
DROP FUNCTION IF EXISTS public.update_follows_count() CASCADE;
DROP FUNCTION IF EXISTS public.current_user_id() CASCADE;

-- =====================================================
-- 1. جدول الملفات الشخصية (profiles)
-- =====================================================
-- ملاحظة: لا نربط id بـ auth.users(id) حتى نتمكن من إدراج
-- ملفات شخصية تجريبية بدون الحاجة لمستخدمين حقيقيين.
-- سيتم ربط المنشورات والإعجابات بـ profiles فقط.
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  username TEXT UNIQUE NOT NULL CHECK (username ~ '^[a-zA-Z0-9_]{3,20}$'),
  display_name TEXT CHECK (display_name IS NULL OR length(display_name) <= 30),
  bio TEXT CHECK (bio IS NULL OR length(bio) <= 500),
  avatar_url TEXT,
  avatar_color TEXT DEFAULT '#FBBF24' CHECK (avatar_color ~ '^#[0-9A-Fa-f]{6}$'),
  followers_count INTEGER DEFAULT 0,
  following_count INTEGER DEFAULT 0,
  posts_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

CREATE INDEX idx_profiles_username ON public.profiles (lower(username));
CREATE INDEX idx_profiles_created_at ON public.profiles (created_at DESC);

-- دالة لجلب معرف المستخدم الحالي (تحل محل auth.uid())
-- تعيد id المستخدم من JWT، أو null إذا لم يسجل الدخول
CREATE OR REPLACE FUNCTION public.current_user_id()
RETURNS UUID AS $$
DECLARE
  user_id UUID;
BEGIN
  -- محاولة جلب id من auth.uid() (تعمل تلقائيًا في سياق RLS)
  BEGIN
    user_id := auth.uid();
  EXCEPTION WHEN OTHERS THEN
    user_id := NULL;
  END;
  RETURN user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- =====================================================
-- 2. جدول المنشورات (posts)
-- =====================================================
CREATE TABLE public.posts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  content TEXT NOT NULL CHECK (length(content) BETWEEN 1 AND 2000 OR repost_of IS NOT NULL),
  category TEXT NOT NULL DEFAULT 'thoughts' CHECK (category IN ('inspire','tech','art','travel','food','music','thoughts')),
  tags TEXT[] DEFAULT '{}' CHECK (array_length(tags, 1) IS NULL OR array_length(tags, 1) <= 5),
  image_url TEXT CHECK (image_url IS NULL OR image_url ~ '^https://.+\.supabase\.(co|in)/storage/'),
  mood TEXT CHECK (mood IS NULL OR mood IN ('happy','calm','energetic','reflective','grateful')),
  repost_of UUID REFERENCES public.posts(id) ON DELETE SET NULL,
  likes_count INTEGER DEFAULT 0,
  comments_count INTEGER DEFAULT 0,
  reposts_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

CREATE INDEX idx_posts_user_id ON public.posts (user_id);
CREATE INDEX idx_posts_category ON public.posts (category);
CREATE INDEX idx_posts_created_at ON public.posts (created_at DESC);
CREATE INDEX idx_posts_tags ON public.posts USING GIN (tags);
CREATE INDEX idx_posts_repost_of ON public.posts (repost_of) WHERE repost_of IS NOT NULL;
CREATE INDEX idx_posts_reposts_count ON public.posts (reposts_count DESC);

-- =====================================================
-- 3. جدول الإعجابات (likes)
-- =====================================================
CREATE TABLE public.likes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  post_id UUID NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  UNIQUE(post_id, user_id)
);

CREATE INDEX idx_likes_post_id ON public.likes (post_id);
CREATE INDEX idx_likes_user_id ON public.likes (user_id);

-- =====================================================
-- 3b. جدول المنشورات المحفوظة (saved_posts)
-- =====================================================
CREATE TABLE public.saved_posts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  post_id UUID NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  UNIQUE(user_id, post_id)
);

CREATE INDEX idx_saved_posts_user ON public.saved_posts (user_id, created_at DESC);
CREATE INDEX idx_saved_posts_post ON public.saved_posts (post_id);

-- =====================================================
-- 4. جدول التعليقات (comments)
-- =====================================================
CREATE TABLE public.comments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  post_id UUID NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  content TEXT NOT NULL CHECK (length(content) BETWEEN 1 AND 500),
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

CREATE INDEX idx_comments_post_id ON public.comments (post_id);

-- =====================================================
-- 5. جدول المتابعة (follows)
-- =====================================================
CREATE TABLE public.follows (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  follower_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  following_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  UNIQUE(follower_id, following_id),
  CHECK (follower_id != following_id)
);

CREATE INDEX idx_follows_follower ON public.follows (follower_id);
CREATE INDEX idx_follows_following ON public.follows (following_id);

-- =====================================================
-- 6. جدول الإشعارات (notifications) - جديد
-- =====================================================
CREATE TABLE public.notifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  actor_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  type TEXT NOT NULL CHECK (type IN ('like', 'comment', 'follow', 'mention', 'comment_mention', 'comment_like', 'reply', 'system')),
  title TEXT NOT NULL,
  body TEXT,
  post_id UUID REFERENCES public.posts(id) ON DELETE CASCADE,
  read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

CREATE INDEX idx_notifications_user_id ON public.notifications (user_id);
CREATE INDEX idx_notifications_read ON public.notifications (read);
CREATE INDEX idx_notifications_created_at ON public.notifications (created_at DESC);

-- =====================================================
-- 7. Storage Buckets - للصور
-- =====================================================
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES
  ('avatars', 'avatars', true, 2097152, ARRAY['image/png', 'image/jpeg', 'image/webp', 'image/gif']),
  ('post-images', 'post-images', true, 5242880, ARRAY['image/png', 'image/jpeg', 'image/webp', 'image/gif']),
  ('message-images', 'message-images', true, 5242880, ARRAY['image/png', 'image/jpeg', 'image/webp', 'image/gif'])
ON CONFLICT (id) DO NOTHING;

-- سياسات Storage: عام للقراءة، المستخدم يكتب في مجلده فقط
-- استخدام DROP POLICY IF EXISTS لتجنب أخطاء التكرار
DROP POLICY IF EXISTS "avatars_public_read" ON storage.objects;
DROP POLICY IF EXISTS "avatars_user_insert" ON storage.objects;
DROP POLICY IF EXISTS "avatars_user_update" ON storage.objects;
DROP POLICY IF EXISTS "avatars_user_delete" ON storage.objects;
DROP POLICY IF EXISTS "post_images_public_read" ON storage.objects;
DROP POLICY IF EXISTS "post_images_user_insert" ON storage.objects;
DROP POLICY IF EXISTS "post_images_user_delete" ON storage.objects;
DROP POLICY IF EXISTS "msg_images_public_read" ON storage.objects;
DROP POLICY IF EXISTS "msg_images_user_insert" ON storage.objects;
DROP POLICY IF EXISTS "msg_images_user_delete" ON storage.objects;

CREATE POLICY "avatars_public_read" ON storage.objects FOR SELECT USING (bucket_id = 'avatars');
CREATE POLICY "avatars_user_insert" ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'avatars' AND (auth.uid()::text = (storage.foldername(name))[1]));
CREATE POLICY "avatars_user_update" ON storage.objects FOR UPDATE
  USING (bucket_id = 'avatars' AND (auth.uid()::text = (storage.foldername(name))[1]));
CREATE POLICY "avatars_user_delete" ON storage.objects FOR DELETE
  USING (bucket_id = 'avatars' AND (auth.uid()::text = (storage.foldername(name))[1]));

CREATE POLICY "post_images_public_read" ON storage.objects FOR SELECT USING (bucket_id = 'post-images');
CREATE POLICY "post_images_user_insert" ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'post-images' AND (auth.uid()::text = (storage.foldername(name))[1]));
CREATE POLICY "post_images_user_delete" ON storage.objects FOR DELETE
  USING (bucket_id = 'post-images' AND (auth.uid()::text = (storage.foldername(name))[1]));

CREATE POLICY "msg_images_public_read" ON storage.objects FOR SELECT USING (bucket_id = 'message-images');
CREATE POLICY "msg_images_user_insert" ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'message-images' AND (auth.uid()::text = (storage.foldername(name))[1]));
CREATE POLICY "msg_images_user_delete" ON storage.objects FOR DELETE
  USING (bucket_id = 'message-images' AND (auth.uid()::text = (storage.foldername(name))[1]));

-- =====================================================
-- تفعيل RLS (Row Level Security)
-- =====================================================
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.saved_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.follows ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- =====================================================
-- سياسات RLS
-- =====================================================
-- نستخدم auth.uid() الذي يعيد id المستخدم من JWT تلقائيًا.
-- ملاحظة: id الـ profiles يطابق id الـ auth.users (نفس UUID) عند تسجيل الدخول.

-- profiles
-- الجميع يمكنه القراءة
CREATE POLICY "profiles_select_all" ON public.profiles FOR SELECT USING (true);
-- الإدراج: المستخدم يدرج ملفه الخاص (auth.uid() = id)
CREATE POLICY "profiles_insert_own" ON public.profiles FOR INSERT 
  WITH CHECK (auth.uid() = id);
-- تحديث: المستخدم يحدّث ملفه الخاص فقط
CREATE POLICY "profiles_update_own" ON public.profiles FOR UPDATE 
  USING (auth.uid() = id);

-- posts
CREATE POLICY "posts_select_all" ON public.posts FOR SELECT USING (true);
CREATE POLICY "posts_insert_own" ON public.posts FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "posts_update_own" ON public.posts FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "posts_delete_own" ON public.posts FOR DELETE USING (auth.uid() = user_id);

-- likes
-- V-15: تقييد قراءة الإعجابات — المستخدم يرى إعجاباته فقط
CREATE POLICY "likes_select_own" ON public.likes FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "likes_insert_own" ON public.likes FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "likes_delete_own" ON public.likes FOR DELETE USING (auth.uid() = user_id);

-- saved_posts: المستخدم يرى محفوظاته فقط
CREATE POLICY "saved_posts_select_own" ON public.saved_posts FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "saved_posts_insert_own" ON public.saved_posts FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "saved_posts_delete_own" ON public.saved_posts FOR DELETE USING (auth.uid() = user_id);

-- comments
CREATE POLICY "comments_select_all" ON public.comments FOR SELECT USING (true);
CREATE POLICY "comments_insert_own" ON public.comments FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "comments_delete_own" ON public.comments FOR DELETE USING (auth.uid() = user_id);

-- follows
CREATE POLICY "follows_select_all" ON public.follows FOR SELECT USING (true);
CREATE POLICY "follows_insert_own" ON public.follows FOR INSERT WITH CHECK (auth.uid() = follower_id);
CREATE POLICY "follows_delete_own" ON public.follows FOR DELETE USING (auth.uid() = follower_id);

-- notifications: المستخدم يرى إشعاراته فقط، ويمكن للنظام إدراج إشعارات (عبر SECURITY DEFINER)
CREATE POLICY "notifications_select_own" ON public.notifications FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "notifications_insert_own" ON public.notifications FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "notifications_update_own" ON public.notifications FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "notifications_delete_own" ON public.notifications FOR DELETE USING (auth.uid() = user_id);

-- =====================================================
-- Triggers لتحديث العدادات
-- =====================================================

CREATE OR REPLACE FUNCTION public.update_posts_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE public.profiles SET posts_count = posts_count + 1 WHERE id = NEW.user_id;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE public.profiles SET posts_count = GREATEST(posts_count - 1, 0) WHERE id = OLD.user_id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER trigger_update_posts_count
  AFTER INSERT OR DELETE ON public.posts
  FOR EACH ROW EXECUTE FUNCTION public.update_posts_count();

CREATE OR REPLACE FUNCTION public.update_likes_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE public.posts SET likes_count = likes_count + 1 WHERE id = NEW.post_id;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE public.posts SET likes_count = GREATEST(likes_count - 1, 0) WHERE id = OLD.post_id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER trigger_update_likes_count
  AFTER INSERT OR DELETE ON public.likes
  FOR EACH ROW EXECUTE FUNCTION public.update_likes_count();

CREATE OR REPLACE FUNCTION public.update_comments_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE public.posts SET comments_count = comments_count + 1 WHERE id = NEW.post_id;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE public.posts SET comments_count = GREATEST(comments_count - 1, 0) WHERE id = OLD.post_id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER trigger_update_comments_count
  AFTER INSERT OR DELETE ON public.comments
  FOR EACH ROW EXECUTE FUNCTION public.update_comments_count();

-- Trigger لتحديث reposts_count
CREATE OR REPLACE FUNCTION public.update_reposts_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NEW.repost_of IS NOT NULL THEN
      UPDATE public.posts SET reposts_count = reposts_count + 1 WHERE id = NEW.repost_of;
    END IF;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    IF OLD.repost_of IS NOT NULL THEN
      UPDATE public.posts SET reposts_count = GREATEST(reposts_count - 1, 0) WHERE id = OLD.repost_of;
    END IF;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trigger_update_reposts_count ON public.posts;
CREATE TRIGGER trigger_update_reposts_count
  AFTER INSERT OR DELETE ON public.posts
  FOR EACH ROW EXECUTE FUNCTION public.update_reposts_count();

-- إشعار عند إعادة النشر
CREATE OR REPLACE FUNCTION public.notify_on_repost()
RETURNS TRIGGER AS $$
DECLARE
  original_owner UUID;
  reposter_name TEXT;
BEGIN
  IF NEW.repost_of IS NULL THEN
    RETURN NEW;
  END IF;

  SELECT user_id INTO original_owner FROM public.posts WHERE id = NEW.repost_of;
  IF original_owner IS NULL OR original_owner = NEW.user_id THEN
    RETURN NEW;
  END IF;

  SELECT display_name INTO reposter_name FROM public.profiles WHERE id = NEW.user_id;

  INSERT INTO public.notifications (user_id, actor_id, type, title, body, post_id)
  VALUES (
    original_owner,
    NEW.user_id,
    'system',
    COALESCE(reposter_name, 'مستخدم') || ' أعاد نشر منشورك',
    NULL,
    NEW.repost_of
  );

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trigger_notify_on_repost ON public.posts;
CREATE TRIGGER trigger_notify_on_repost
  AFTER INSERT ON public.posts
  FOR EACH ROW
  WHEN (NEW.repost_of IS NOT NULL)
  EXECUTE FUNCTION public.notify_on_repost();

CREATE OR REPLACE FUNCTION public.update_follows_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE public.profiles SET following_count = following_count + 1 WHERE id = NEW.follower_id;
    UPDATE public.profiles SET followers_count = followers_count + 1 WHERE id = NEW.following_id;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE public.profiles SET following_count = GREATEST(following_count - 1, 0) WHERE id = OLD.follower_id;
    UPDATE public.profiles SET followers_count = GREATEST(followers_count - 1, 0) WHERE id = OLD.following_id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER trigger_update_follows_count
  AFTER INSERT OR DELETE ON public.follows
  FOR EACH ROW EXECUTE FUNCTION public.update_follows_count();

-- =====================================================
-- Triggers لإنشاء إشعارات تلقائية
-- =====================================================

-- إشعار عند الإعجاب بمنشور
CREATE OR REPLACE FUNCTION public.notify_on_like()
RETURNS TRIGGER AS $$
DECLARE
  post_owner UUID;
  liker_name TEXT;
  post_content TEXT;
BEGIN
  SELECT user_id, content INTO post_owner, post_content FROM public.posts WHERE id = NEW.post_id;
  IF post_owner IS NULL OR post_owner = NEW.user_id THEN
    RETURN NEW; -- لا إشعار لنفسك
  END IF;
  SELECT display_name INTO liker_name FROM public.profiles WHERE id = NEW.user_id;
  INSERT INTO public.notifications (user_id, actor_id, type, title, body, post_id)
  VALUES (
    post_owner,
    NEW.user_id,
    'like',
    COALESCE(liker_name, 'مستخدم') || ' أعجب بمنشورك',
    LEFT(post_content, 80),
    NEW.post_id
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trigger_notify_on_like ON public.likes;
CREATE TRIGGER trigger_notify_on_like
  AFTER INSERT ON public.likes
  FOR EACH ROW EXECUTE FUNCTION public.notify_on_like();

-- إشعار عند التعليق
CREATE OR REPLACE FUNCTION public.notify_on_comment()
RETURNS TRIGGER AS $$
DECLARE
  post_owner UUID;
  commenter_name TEXT;
BEGIN
  SELECT user_id INTO post_owner FROM public.posts WHERE id = NEW.post_id;
  IF post_owner IS NULL OR post_owner = NEW.user_id THEN
    RETURN NEW;
  END IF;
  SELECT display_name INTO commenter_name FROM public.profiles WHERE id = NEW.user_id;
  INSERT INTO public.notifications (user_id, actor_id, type, title, body, post_id)
  VALUES (
    post_owner,
    NEW.user_id,
    'comment',
    COALESCE(commenter_name, 'مستخدم') || ' علّق على منشورك',
    LEFT(NEW.content, 80),
    NEW.post_id
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trigger_notify_on_comment ON public.comments;
CREATE TRIGGER trigger_notify_on_comment
  AFTER INSERT ON public.comments
  FOR EACH ROW EXECUTE FUNCTION public.notify_on_comment();

-- إشعار عند المتابعة
CREATE OR REPLACE FUNCTION public.notify_on_follow()
RETURNS TRIGGER AS $$
DECLARE
  follower_name TEXT;
BEGIN
  SELECT display_name INTO follower_name FROM public.profiles WHERE id = NEW.follower_id;
  INSERT INTO public.notifications (user_id, actor_id, type, title, body)
  VALUES (
    NEW.following_id,
    NEW.follower_id,
    'follow',
    COALESCE(follower_name, 'مستخدم') || ' بدأ بمتابعتك',
    NULL
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trigger_notify_on_follow ON public.follows;
CREATE TRIGGER trigger_notify_on_follow
  AFTER INSERT ON public.follows
  FOR EACH ROW EXECUTE FUNCTION public.notify_on_follow();

-- =====================================================
-- نظام الإشارات (Mentions) - @username
-- =====================================================

-- دالة لاستخراج الإشارات من النص
CREATE OR REPLACE FUNCTION public.extract_mentions(text_content TEXT)
RETURNS TEXT[] AS $$
DECLARE
  mentions TEXT[];
BEGIN
  IF text_content IS NULL THEN
    RETURN ARRAY[]::TEXT[];
  END IF;
  SELECT COALESCE(array_agg(DISTINCT lower(matches[1])), ARRAY[]::TEXT[])
  INTO mentions
  FROM regexp_matches(text_content, '@([a-zA-Z0-9_]{3,20})', 'g') AS matches;
  RETURN mentions;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- إشعار عند الإشارة في منشور
CREATE OR REPLACE FUNCTION public.notify_on_post_mention()
RETURNS TRIGGER AS $$
DECLARE
  mentions TEXT[];
  author_name TEXT;
BEGIN
  mentions := public.extract_mentions(NEW.content);
  IF array_length(mentions, 1) IS NULL THEN
    RETURN NEW;
  END IF;
  SELECT display_name INTO author_name FROM public.profiles WHERE id = NEW.user_id;
  -- إدخال إشعار لكل مستخدم تمت الإشارة إليه (INSERT...SELECT)
  INSERT INTO public.notifications (user_id, actor_id, type, title, body, post_id)
  SELECT p.id, NEW.user_id, 'mention',
         COALESCE(author_name, 'مستخدم') || ' أشار إليك في منشور',
         LEFT(NEW.content, 80), NEW.id
  FROM public.profiles p
  WHERE lower(p.username) = ANY(mentions)
    AND p.id != NEW.user_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trigger_notify_on_post_mention ON public.posts;
CREATE TRIGGER trigger_notify_on_post_mention
  AFTER INSERT OR UPDATE OF content ON public.posts
  FOR EACH ROW EXECUTE FUNCTION public.notify_on_post_mention();

-- إشعار عند الإشارة في تعليق
CREATE OR REPLACE FUNCTION public.notify_on_comment_mention()
RETURNS TRIGGER AS $$
DECLARE
  mentions TEXT[];
  commenter_name TEXT;
  post_owner UUID;
BEGIN
  mentions := public.extract_mentions(NEW.content);
  IF array_length(mentions, 1) IS NULL THEN
    RETURN NEW;
  END IF;
  SELECT display_name INTO commenter_name FROM public.profiles WHERE id = NEW.user_id;
  SELECT user_id INTO post_owner FROM public.posts WHERE id = NEW.post_id;
  -- تجنب إشعار مزدوج لصاحب المنشور (لديه إشعار التعليق)
  INSERT INTO public.notifications (user_id, actor_id, type, title, body, post_id)
  SELECT p.id, NEW.user_id, 'comment_mention',
         COALESCE(commenter_name, 'مستخدم') || ' أشار إليك في تعليق',
         LEFT(NEW.content, 80), NEW.post_id
  FROM public.profiles p
  WHERE lower(p.username) = ANY(mentions)
    AND p.id != NEW.user_id
    AND p.id != COALESCE(post_owner, '00000000-0000-0000-0000-000000000000'::UUID);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trigger_notify_on_comment_mention ON public.comments;
CREATE TRIGGER trigger_notify_on_comment_mention
  AFTER INSERT OR UPDATE OF content ON public.comments
  FOR EACH ROW EXECUTE FUNCTION public.notify_on_comment_mention();

-- دالة لحذف بيانات الحساب (للحذف الكامل يحتاج admin API)
CREATE OR REPLACE FUNCTION public.delete_user_account(target_user_id UUID)
RETURNS VOID AS $$
DECLARE
  user_email TEXT;
BEGIN
  SELECT email INTO user_email FROM auth.users WHERE id = target_user_id;
  IF user_email IS NULL THEN
    RAISE EXCEPTION 'User not found';
  END IF;
  -- CASCADE في الـ foreign keys سيتولى حذف الباقي
  DELETE FROM public.notifications WHERE user_id = target_user_id OR actor_id = target_user_id;
  DELETE FROM public.comment_likes WHERE user_id = target_user_id;
  DELETE FROM public.likes WHERE user_id = target_user_id;
  DELETE FROM public.comments WHERE user_id = target_user_id;
  DELETE FROM public.follows WHERE follower_id = target_user_id OR following_id = target_user_id;
  DELETE FROM public.message_requests WHERE sender_id = target_user_id OR receiver_id = target_user_id;
  DELETE FROM public.messages WHERE sender_id = target_user_id;
  DELETE FROM public.conversations WHERE participant_1 = target_user_id OR participant_2 = target_user_id;
  DELETE FROM public.posts WHERE user_id = target_user_id;
  DELETE FROM public.profiles WHERE id = target_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

GRANT EXECUTE ON FUNCTION public.delete_user_account(UUID) TO authenticated;

-- =====================================================
-- إنشاء ملف شخصي تلقائيًا عند تسجيل مستخدم جديد
-- =====================================================
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, username, display_name)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'username', 'user_' || substring(NEW.id::text, 1, 8)),
    COALESCE(NEW.raw_user_meta_data->>'display_name', NEW.raw_user_meta_data->>'username')
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER trigger_handle_new_user
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- =====================================================
-- نظام المراسلة الكامل - Messaging System
-- =====================================================

-- 1. جدول المحادثات (conversations)
DROP TABLE IF EXISTS public.conversations CASCADE;
CREATE TABLE public.conversations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  participant_1 UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  participant_2 UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  last_message_id UUID,
  last_message_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  UNIQUE(participant_1, participant_2),
  CHECK (participant_1 != participant_2)
);
CREATE INDEX idx_conversations_p1 ON public.conversations (participant_1);
CREATE INDEX idx_conversations_p2 ON public.conversations (participant_2);
CREATE INDEX idx_conversations_last_msg ON public.conversations (last_message_at DESC);

-- 2. جدول الرسائل (messages)
DROP TABLE IF EXISTS public.messages CASCADE;
CREATE TABLE public.messages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  conversation_id UUID NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  sender_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  content TEXT NOT NULL CHECK (length(content) BETWEEN 1 AND 4000 OR (image_url IS NOT NULL AND length(content) <= 4000)),
  image_url TEXT,
  is_edited BOOLEAN DEFAULT FALSE,
  edited_at TIMESTAMPTZ,
  is_deleted BOOLEAN DEFAULT FALSE,
  deleted_at TIMESTAMPTZ,
  deleted_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  read_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);
CREATE INDEX idx_messages_conversation ON public.messages (conversation_id, created_at DESC);
CREATE INDEX idx_messages_sender ON public.messages (sender_id);
CREATE INDEX idx_messages_unread ON public.messages (conversation_id, read_at) WHERE read_at IS NULL;
CREATE INDEX idx_messages_image ON public.messages (image_url) WHERE image_url IS NOT NULL;

-- 3. جدول طلبات المراسلة (message_requests)
DROP TABLE IF EXISTS public.message_requests CASCADE;
CREATE TABLE public.message_requests (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  sender_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  receiver_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'rejected')),
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  responded_at TIMESTAMPTZ,
  UNIQUE(sender_id, receiver_id),
  CHECK (sender_id != receiver_id)
);
CREATE INDEX idx_msg_requests_receiver ON public.message_requests (receiver_id, status);
CREATE INDEX idx_msg_requests_sender ON public.message_requests (sender_id, status);

-- تفعيل RLS
ALTER TABLE public.conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.message_requests ENABLE ROW LEVEL SECURITY;

-- سياسات conversations: المشارك يرى ويعدّل محادثاته
CREATE POLICY "conv_select_participants" ON public.conversations FOR SELECT
  USING (auth.uid() = participant_1 OR auth.uid() = participant_2);
CREATE POLICY "conv_insert_participants" ON public.conversations FOR INSERT
  WITH CHECK (auth.uid() = participant_1 OR auth.uid() = participant_2);
CREATE POLICY "conv_update_participants" ON public.conversations FOR UPDATE
  USING (auth.uid() = participant_1 OR auth.uid() = participant_2);

-- سياسات messages: المرسل والمستلم فقط
CREATE POLICY "msg_select_participants" ON public.messages FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.conversations c
      WHERE c.id = messages.conversation_id
      AND (c.participant_1 = auth.uid() OR c.participant_2 = auth.uid())
    )
  );
CREATE POLICY "msg_insert_sender" ON public.messages FOR INSERT
  WITH CHECK (
    sender_id = auth.uid()
    AND EXISTS (
      SELECT 1 FROM public.conversations c
      WHERE c.id = messages.conversation_id
      AND (c.participant_1 = auth.uid() OR c.participant_2 = auth.uid())
    )
  );
CREATE POLICY "msg_update_sender" ON public.messages FOR UPDATE
  USING (sender_id = auth.uid());

-- V-09: السماح للمستلم بتعليم الرسائل كمقروءة
CREATE POLICY "msg_update_recipient_read" ON public.messages FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.conversations c
      WHERE c.id = messages.conversation_id
      AND (c.participant_1 = auth.uid() OR c.participant_2 = auth.uid())
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.conversations c
      WHERE c.id = messages.conversation_id
      AND (c.participant_1 = auth.uid() OR c.participant_2 = auth.uid())
    )
  );
CREATE POLICY "msg_delete_sender" ON public.messages FOR DELETE
  USING (sender_id = auth.uid());

-- سياسات message_requests
CREATE POLICY "mreq_select_involved" ON public.message_requests FOR SELECT
  USING (auth.uid() = sender_id OR auth.uid() = receiver_id);
CREATE POLICY "mreq_insert_sender" ON public.message_requests FOR INSERT
  WITH CHECK (auth.uid() = sender_id);
-- V-02: إصلاح — المستلم فقط يمكنه الرد على طلب المراسلة (ليس المرسل)
CREATE POLICY "mreq_update_receiver" ON public.message_requests FOR UPDATE
  USING (auth.uid() = receiver_id);

-- Trigger: تحديث last_message عند إدراج رسالة جديدة
CREATE OR REPLACE FUNCTION public.update_conversation_last_message()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE public.conversations
  SET last_message_id = NEW.id,
      last_message_at = NEW.created_at,
      updated_at = NOW()
  WHERE id = NEW.conversation_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trigger_update_conv_last_msg ON public.messages;
CREATE TRIGGER trigger_update_conv_last_msg
  AFTER INSERT ON public.messages
  FOR EACH ROW EXECUTE FUNCTION public.update_conversation_last_message();

-- =====================================================
-- نظام الإبلاغ + حجب المستخدمين
-- =====================================================

-- جدول البلاغات
CREATE TABLE public.reports (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  reporter_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  target_type TEXT NOT NULL CHECK (target_type IN ('post', 'comment', 'message', 'profile')),
  target_id UUID NOT NULL,
  reported_user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  reason TEXT NOT NULL CHECK (reason IN (
    'spam', 'harassment', 'hate', 'violence', 'adult',
    'illegal', 'impersonation', 'misinformation', 'other'
  )),
  description TEXT CHECK (description IS NULL OR length(description) <= 500),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'reviewing', 'resolved', 'dismissed')),
  admin_notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  resolved_at TIMESTAMPTZ,
  resolved_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  UNIQUE(reporter_id, target_type, target_id)
);

CREATE INDEX idx_reports_reporter ON public.reports (reporter_id);
CREATE INDEX idx_reports_reported_user ON public.reports (reported_user_id);
CREATE INDEX idx_reports_status ON public.reports (status, created_at DESC);
CREATE INDEX idx_reports_target ON public.reports (target_type, target_id);

-- جدول الحجب
CREATE TABLE public.blocks (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  blocker_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  blocked_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  UNIQUE(blocker_id, blocked_id),
  CHECK (blocker_id != blocked_id)
);

CREATE INDEX idx_blocks_blocker ON public.blocks (blocker_id);
CREATE INDEX idx_blocks_blocked ON public.blocks (blocked_id);

ALTER TABLE public.reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.blocks ENABLE ROW LEVEL SECURITY;

-- سياسات reports
CREATE POLICY "reports_select_own" ON public.reports FOR SELECT
  USING (auth.uid() = reporter_id OR auth.uid() = reported_user_id);
CREATE POLICY "reports_insert_own" ON public.reports FOR INSERT
  WITH CHECK (auth.uid() = reporter_id);
CREATE POLICY "reports_delete_own" ON public.reports FOR DELETE
  USING (auth.uid() = reporter_id);

-- سياسات blocks
CREATE POLICY "blocks_select_own" ON public.blocks FOR SELECT
  USING (auth.uid() = blocker_id OR auth.uid() = blocked_id);
CREATE POLICY "blocks_insert_own" ON public.blocks FOR INSERT
  WITH CHECK (auth.uid() = blocker_id);
CREATE POLICY "blocks_delete_own" ON public.blocks FOR DELETE
  USING (auth.uid() = blocker_id);

-- Trigger: عند الحجب، احذف المتابعة + طلبات المراسلة
CREATE OR REPLACE FUNCTION public.handle_block_unfollow()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM public.follows
  WHERE follower_id = NEW.blocker_id AND following_id = NEW.blocked_id;
  DELETE FROM public.follows
  WHERE follower_id = NEW.blocked_id AND following_id = NEW.blocker_id;
  DELETE FROM public.message_requests
  WHERE (sender_id = NEW.blocker_id AND receiver_id = NEW.blocked_id)
     OR (sender_id = NEW.blocked_id AND receiver_id = NEW.blocker_id);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER trigger_handle_block_unfollow
  AFTER INSERT ON public.blocks
  FOR EACH ROW EXECUTE FUNCTION public.handle_block_unfollow();

-- =====================================================
-- تفعيل Realtime على الجداول للبث المباشر
-- =====================================================
ALTER PUBLICATION supabase_realtime ADD TABLE public.profiles;
ALTER PUBLICATION supabase_realtime ADD TABLE public.posts;
ALTER PUBLICATION supabase_realtime ADD TABLE public.likes;
ALTER PUBLICATION supabase_realtime ADD TABLE public.saved_posts;
ALTER PUBLICATION supabase_realtime ADD TABLE public.comments;
ALTER PUBLICATION supabase_realtime ADD TABLE public.follows;
ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications;
ALTER PUBLICATION supabase_realtime ADD TABLE public.conversations;
ALTER PUBLICATION supabase_realtime ADD TABLE public.messages;
ALTER PUBLICATION supabase_realtime ADD TABLE public.message_requests;
ALTER PUBLICATION supabase_realtime ADD TABLE public.reports;
ALTER PUBLICATION supabase_realtime ADD TABLE public.blocks;

-- =====================================================
-- ملاحظات للمستخدم:
-- 1. هذا السكربت آمن للتشغيل المتكرر - يحذف ويعيد إنشاء الجداول
-- 2. يجب تشغيله في SQL Editor في لوحة تحكم Supabase
-- 3. الرابط: https://supabase.com/dashboard/project/bhzrhvesrpyvrsshavow/sql/new
-- 4. يجب أيضًا تفعيل "Email/Password" في Authentication > Providers
-- 5. لتفعيل تسجيل المستخدمين بدون تأكيد البريد: Authentication > Settings
--    ثم تعطيل "Confirm email"
-- 6. Realtime مُفعّل تلقائيًا على كل الجداول للبث المباشر
-- 7. لتفعيل Realtime في لوحة التحكم: Database → Replication → supabase_realtime
-- 8. لا توجد بيانات تجريبية - التطبيق يعمل ببيانات حقيقية فقط من المستخدمين
-- =====================================================
