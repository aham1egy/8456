-- =====================================================
-- مشرق - إصلاح عاجل: إنشاء جدول saved_posts + إصلاح triggers
-- يجب تشغيل هذا فوراً!
-- =====================================================

-- =====================================================
-- 1. إنشاء جدول saved_posts (غير موجود!)
-- =====================================================
CREATE TABLE IF NOT EXISTS public.saved_posts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  post_id UUID NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  UNIQUE(user_id, post_id)
);

CREATE INDEX IF NOT EXISTS idx_saved_posts_user ON public.saved_posts (user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_saved_posts_post ON public.saved_posts (post_id);

ALTER TABLE public.saved_posts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "saved_posts_select_own" ON public.saved_posts;
CREATE POLICY "saved_posts_select_own" ON public.saved_posts FOR SELECT 
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "saved_posts_insert_own" ON public.saved_posts;
CREATE POLICY "saved_posts_insert_own" ON public.saved_posts FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "saved_posts_delete_own" ON public.saved_posts;
CREATE POLICY "saved_posts_delete_own" ON public.saved_posts FOR DELETE 
  USING (auth.uid() = user_id);

-- =====================================================
-- 2. حذف trigger يمنع كل UPDATE (المشكلة الرئيسية)
-- =====================================================
DROP TRIGGER IF EXISTS trigger_prevent_profile_restricted_fields ON public.profiles;
DROP FUNCTION IF EXISTS public.prevent_profile_restricted_fields_update();

DROP TRIGGER IF EXISTS trigger_prevent_verification_self_update ON public.profiles;
DROP FUNCTION IF EXISTS public.prevent_verification_self_update();

-- =====================================================
-- 3. إنشاء trigger آمن فقط لمنع تعديل حقول التحقق
-- =====================================================
CREATE OR REPLACE FUNCTION public.prevent_verification_change()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.is_verified IS DISTINCT FROM OLD.is_verified
     OR NEW.verified_type IS DISTINCT FROM OLD.verified_type
     OR NEW.verified_at IS DISTINCT FROM OLD.verified_at THEN
    IF current_setting('role', true) = 'authenticated' THEN
      RAISE EXCEPTION 'لا يمكنك تعديل حالة التحقق';
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trigger_prevent_verification_change ON public.profiles;
CREATE TRIGGER trigger_prevent_verification_change
  BEFORE UPDATE OF is_verified, verified_type, verified_at ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.prevent_verification_change();

-- =====================================================
-- 4. تفعيل Realtime على saved_posts
-- =====================================================
ALTER PUBLICATION supabase_realtime ADD TABLE public.saved_posts;

-- =====================================================
-- ملاحظات:
-- 1. saved_posts لم يكن موجوداً — الآن تم إنشاؤه
-- 2. trigger المسبب للمشكلة تم حذفه
-- 3. trigger جديد آمن فقط لحقول التحقق
-- 4. كل triggers أخرى (update_posts_count, etc.) تعمل بحرية الآن
-- =====================================================
