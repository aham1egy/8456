-- =====================================================
-- مشرق - المنشورات المميزة (Featured Posts) + تصويت المجتمع
-- آمن للتشغيل المتكرر
-- =====================================================

-- =====================================================
-- 1. إضافة حقول التميز لجدول posts
-- =====================================================
ALTER TABLE public.posts ADD COLUMN IF NOT EXISTS is_featured BOOLEAN DEFAULT FALSE;
ALTER TABLE public.posts ADD COLUMN IF NOT EXISTS featured_at TIMESTAMPTZ;
ALTER TABLE public.posts ADD COLUMN IF NOT EXISTS featured_votes_count INTEGER DEFAULT 0;

-- فهرس للمنشورات المميزة
CREATE INDEX IF NOT EXISTS idx_posts_featured ON public.posts (featured_at DESC) WHERE is_featured = TRUE;
CREATE INDEX IF NOT EXISTS idx_posts_votes ON public.posts (featured_votes_count DESC) WHERE is_featured = FALSE AND repost_of IS NULL;

-- =====================================================
-- 2. جدول تصويتات التميز (feature_votes)
-- =====================================================
CREATE TABLE IF NOT EXISTS public.feature_votes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  post_id UUID NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  UNIQUE(post_id, user_id)
);

CREATE INDEX IF NOT EXISTS idx_feature_votes_post ON public.feature_votes (post_id);
CREATE INDEX IF NOT EXISTS idx_feature_votes_user ON public.feature_votes (user_id);

-- =====================================================
-- 3. RLS
-- =====================================================
ALTER TABLE public.feature_votes ENABLE ROW LEVEL SECURITY;

-- الجميع يرى التصويتات (لعرض العدد)
DROP POLICY IF EXISTS "feature_votes_select_all" ON public.feature_votes;
CREATE POLICY "feature_votes_select_all" ON public.feature_votes FOR SELECT USING (true);

-- المستخدم يُدخل تصويته فقط
DROP POLICY IF EXISTS "feature_votes_insert_own" ON public.feature_votes;
CREATE POLICY "feature_votes_insert_own" ON public.feature_votes FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

-- المستخدم يحذف تصويته فقط
DROP POLICY IF EXISTS "feature_votes_delete_own" ON public.feature_votes;
CREATE POLICY "feature_votes_delete_own" ON public.feature_votes FOR DELETE 
  USING (auth.uid() = user_id);

-- =====================================================
-- 4. Trigger لتحديث عداد التصويتات
-- =====================================================
CREATE OR REPLACE FUNCTION public.update_featured_votes_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE public.posts SET featured_votes_count = featured_votes_count + 1 WHERE id = NEW.post_id;
    
    -- إذا تجاوز 10 أصوات، أصبح مميزاً تلقائياً
    UPDATE public.posts 
    SET is_featured = TRUE, 
        featured_at = NOW() 
    WHERE id = NEW.post_id 
      AND is_featured = FALSE 
      AND featured_votes_count >= 10;
    
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE public.posts SET featured_votes_count = GREATEST(featured_votes_count - 1, 0) WHERE id = OLD.post_id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trigger_update_featured_votes ON public.feature_votes;
CREATE TRIGGER trigger_update_featured_votes
  AFTER INSERT OR DELETE ON public.feature_votes
  FOR EACH ROW EXECUTE FUNCTION public.update_featured_votes_count();

-- =====================================================
-- 5. منح نقاط سمعة عند التصويت
-- =====================================================
CREATE OR REPLACE FUNCTION public.award_points_on_feature_vote()
RETURNS TRIGGER AS $$
DECLARE
  post_owner UUID;
BEGIN
  SELECT user_id INTO post_owner FROM public.posts WHERE id = NEW.post_id;
  IF post_owner IS NOT NULL AND post_owner != NEW.user_id THEN
    -- منح نقطة واحدة لصاحب المنشور عند كل تصويت
    PERFORM public.award_reputation_points(post_owner, 'post_saved', NEW.post_id, 'post');
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trigger_award_points_on_feature_vote ON public.feature_votes;
CREATE TRIGGER trigger_award_points_on_feature_vote
  AFTER INSERT ON public.feature_votes
  FOR EACH ROW EXECUTE FUNCTION public.award_points_on_feature_vote();

-- =====================================================
-- 6. إشعار عند تمييز منشور
-- =====================================================
CREATE OR REPLACE FUNCTION public.notify_on_featured()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.is_featured = TRUE AND (OLD.is_featured = FALSE OR OLD.is_featured IS NULL) THEN
    INSERT INTO public.notifications (user_id, actor_id, type, title, body, post_id)
    VALUES (
      NEW.user_id,
      NULL,
      'system',
      'منشورك أصبح مميزاً! 🌟',
      'حصل منشورك على ما يكفي من التصويتات ليصبح مميزاً',
      NEW.id
    );
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trigger_notify_on_featured ON public.posts;
CREATE TRIGGER trigger_notify_on_featured
  AFTER UPDATE OF is_featured ON public.posts
  FOR EACH ROW
  WHEN (NEW.is_featured = TRUE AND (OLD.is_featured = FALSE OR OLD.is_featured IS NULL))
  EXECUTE FUNCTION public.notify_on_featured();

-- =====================================================
-- ملاحظات:
-- 1. المنشور يصبح مميزاً تلقائياً عند 10 أصوات
-- 2. تصويت واحد لكل مستخدم (UNIQUE constraint)
-- 3. منح نقطة سمعة لصاحب المنشور عند كل تصويت
-- 4. إشعار تلقائي عند التمييز
-- 5. يمكن للمستخدم إلغاء تصويته
-- =====================================================
