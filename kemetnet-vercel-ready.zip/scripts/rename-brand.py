#!/usr/bin/env python3
"""
Bulk rename "مشرق" -> "KemetNet" across all source files.
Strategy: targeted, careful replacements — do NOT touch CSS class names
like "mishri-*" (those are styling tokens, kept for compatibility).
"""

import re
from pathlib import Path

ROOT = Path("/home/z/my-project/src")

# Directories to scan
SCAN_DIRS = [ROOT / "app", ROOT / "components", ROOT / "lib", ROOT / "hooks", ROOT / "store"]

# File extensions to process
EXTS = (".ts", ".tsx", ".css", ".js", ".jsx", ".json")

# Only the Arabic brand text "مشرق" -> "KemetNet"
# (CSS classes like "mishri-gradient-text" remain unchanged — see below)
ARABIC_REPLACEMENTS = [
    # Brand name appearing alone or with following word
    ("مشرق", "KemetNet"),
]

# Latin brand-text replacements (NOT class names, NOT file paths)
# These are guaranteed strings used as user-visible text or comments.
LATIN_TEXT_REPLACEMENTS = [
    # Brand name in comments/strings (lowercase, not as identifier)
    # Be conservative: only replace "Mishri" when surrounded by whitespace/punctuation
    (re.compile(r"(?<![A-Za-z0-9_\-/.])Mishri(?![A-Za-z0-9_\-/])"), "KemetNet"),
    # Mishri Team / Mishri App / Mishri.app / support@mishri.app etc.
    (re.compile(r"Mishri\s+Team"), "KemetNet Team"),
    (re.compile(r"Mishri\s+App"), "KemetNet App"),
    # Email domain (lowercase)
    (re.compile(r"mishri\.app\.local"), "kemetnet.app.local"),
    # Site URL
    (re.compile(r"https?://mishri\.app"), "https://kemetnet.app"),
    (re.compile(r"support@mishri\.app"), "support@kemetnet.app"),
]

# Counters
stats = {"files": 0, "ar_changes": 0, "latin_changes": 0}

for d in SCAN_DIRS:
    if not d.exists():
        continue
    for f in d.rglob("*"):
        if not f.is_file() or f.suffix not in EXTS:
            continue
        try:
            text = f.read_text(encoding="utf-8")
        except Exception:
            continue
        original = text
        ar_changes = 0
        latin_changes = 0

        # 1) Arabic replacements
        for old, new in ARABIC_REPLACEMENTS:
            cnt = text.count(old)
            if cnt:
                text = text.replace(old, new)
                ar_changes += cnt

        # 2) Latin text replacements (regex, carefully avoiding class names)
        for pat, repl in LATIN_TEXT_REPLACEMENTS:
            text, n = pat.subn(repl, text)
            latin_changes += n

        if text != original:
            f.write_text(text, encoding="utf-8")
            stats["files"] += 1
            stats["ar_changes"] += ar_changes
            stats["latin_changes"] += latin_changes
            print(f"  {f.relative_to(ROOT)}: +{ar_changes} ar, +{latin_changes} latin")

print("\nSummary:")
print(f"  Files modified: {stats['files']}")
print(f"  Arabic replacements: {stats['ar_changes']}")
print(f"  Latin text replacements: {stats['latin_changes']}")
