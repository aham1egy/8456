#!/usr/bin/env bash
# ============================================================
# KemetNet — Build & Deploy Script
# ============================================================
# يقوم ببناء التطبيق ونسخ الأصول الثابتة إلى standalone output
# ضروري لأن Next.js standalone لا ينسخ public/ و .next/static تلقائيًا
# ============================================================

set -e  # exit on any error

PROJECT_DIR="/home/z/my-project"
STANDALONE_DIR="${PROJECT_DIR}/.next/standalone"

echo "============================================================"
echo "🚀 KemetNet — Build & Deploy"
echo "============================================================"

# 1) قتل أي خادم قديم
echo "→ إيقاف أي خوادم قديمة..."
pkill -9 -f "next-server" 2>/dev/null || true
pkill -9 -f "next dev" 2>/dev/null || true
sleep 1

# 2) تنظيف cache القديم
echo "→ تنظيف .next/cache..."
rm -rf "${PROJECT_DIR}/.next" 2>/dev/null
rm -f "${PROJECT_DIR}/.next/dev/lock" 2>/dev/null

# 2.5) فحص env vars قبل البناء (حرج!)
echo "→ فحص متغيرات Supabase..."
if ! grep -q "NEXT_PUBLIC_SUPABASE_URL" "${PROJECT_DIR}/.env" 2>/dev/null; then
  echo "  ❌ NEXT_PUBLIC_SUPABASE_URL غير موجود في .env!"
  echo "  → أضِف السطر التالي إلى ${PROJECT_DIR}/.env:"
  echo "    NEXT_PUBLIC_SUPABASE_URL=https://bhzrhvesrpyvrsshavow.supabase.co"
  echo "    NEXT_PUBLIC_SUPABASE_ANON_KEY=sb_publishable_AO6P04L0WlDaCK2Ot38YTQ_90FnOQc_"
  exit 1
fi
echo "  ✓ متغيرات Supabase موجودة في .env"

# 2.6) إعادة كتابة .env إذا كان فارغًا من المفاتيح (استعادة تلقائية)
if ! grep -q "sb_publishable_" "${PROJECT_DIR}/.env" 2>/dev/null; then
  echo "  ⚠️  مفتاح Supabase غير موجود — إعادة كتابة .env..."
  cat > "${PROJECT_DIR}/.env" << 'EOF'
DATABASE_URL=file:/home/z/my-project/db/custom.db

# Supabase - KemetNet
NEXT_PUBLIC_SUPABASE_URL=https://bhzrhvesrpyvrsshavow.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=sb_publishable_AO6P04L0WlDaCK2Ot38YTQ_90FnOQc_
EOF
  echo "  ✓ تمت إعادة كتابة .env"
fi

# 3) البناء (production)
echo "→ بناء التطبيق (production)..."
cd "${PROJECT_DIR}"
npx next build

# 4) نسخ public/ إلى standalone (مطلوب لـ output: "standalone")
echo "→ نسخ public/ إلى standalone..."
if [ -d "${STANDALONE_DIR}/public" ]; then
  rm -rf "${STANDALONE_DIR}/public"
fi
cp -r "${PROJECT_DIR}/public" "${STANDALONE_DIR}/public"

# 5) نسخ .next/static إلى standalone/.next/static
echo "→ نسخ .next/static إلى standalone..."
mkdir -p "${STANDALONE_DIR}/.next"
if [ -d "${STANDALONE_DIR}/.next/static" ]; then
  rm -rf "${STANDALONE_DIR}/.next/static"
fi
cp -r "${PROJECT_DIR}/.next/static" "${STANDALONE_DIR}/.next/static"

# 6) التحقق من وجود الأصول الحرجة
echo "→ التحقق من الأصول الحرجة..."
CRITICAL_ASSETS=(
  "manifest.json"
  "icons/icon-192.png"
  "icons/icon-512.png"
  "icons/favicon-32.png"
  "icons/apple-touch-icon.png"
  "icons/icon-maskable-512.png"
  "logo.svg"
  "favicon.svg"
  "favicon.ico"
  "sw.js"
  "robots.txt"
  "sitemap.xml"
)

MISSING=0
for asset in "${CRITICAL_ASSETS[@]}"; do
  if [ ! -f "${STANDALONE_DIR}/public/${asset}" ]; then
    echo "  ✗ MISSING: public/${asset}"
    MISSING=$((MISSING+1))
  else
    echo "  ✓ public/${asset}"
  fi
done

if [ ${MISSING} -gt 0 ]; then
  echo ""
  echo "❌ خطأ: ينقص ${MISSING} أصل من public/"
  exit 1
fi

# 7) تشغيل الخادم (production standalone)
PORT="${PORT:-3000}"
echo ""
echo "→ تشغيل الخادم على المنفذ ${PORT}..."
cd "${STANDALONE_DIR}"
PORT=${PORT} node server.js &
SERVER_PID=$!
echo "  PID: ${SERVER_PID}"

# انتظار جاهزية الخادم
echo "→ انتظار جاهزية الخادم..."
for i in {1..15}; do
  sleep 1
  if curl -s -o /dev/null -w "%{http_code}" "http://localhost:${PORT}/" 2>/dev/null | grep -q "200"; then
    echo "  ✓ الخادم جاهز على http://localhost:${PORT}"
    break
  fi
done

# اختبار النقاط الحرجة
echo ""
echo "→ اختبار النقاط الحرجة..."
TEST_PATHS=("/" "/manifest.json" "/icons/icon-192.png" "/icons/icon-512.png" "/sw.js" "/robots.txt")
ALL_OK=1
for path in "${TEST_PATHS[@]}"; do
  code=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost:${PORT}${path}")
  if [ "${code}" = "200" ]; then
    echo "  ✓ ${path}: 200"
  else
    echo "  ✗ ${path}: ${code}"
    ALL_OK=0
  fi
done

echo ""
if [ ${ALL_OK} -eq 1 ]; then
  echo "============================================================"
  echo "✅ النشر نجح! التطبيق يعمل على http://localhost:${PORT}"
  echo "============================================================"
  echo ""
  echo "Preview URL: https://preview-$(hostname | grep -oE '[a-z0-9-]+' || echo 'local').space-z.ai/"
else
  echo "============================================================"
  echo "⚠️  التطبيق يعمل لكن بعض الأصول لم تستجب بـ 200"
  echo "============================================================"
fi
