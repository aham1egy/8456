#!/usr/bin/env python3
"""
تهيئة قاعدة بيانات Supabase لمشروع مشرق
يقوم بإنشاء الجداول والسياسات والبيانات التجريبية
"""
import json
import urllib.request
import urllib.parse
import sys
from pathlib import Path

# إعدادات Supabase
SUPABASE_URL = "https://bhzrhvesrpyvrsshavow.supabase.co"
SUPABASE_ANON_KEY = "sb_publishable_AO6P04L0WlDaCK2Ot38YTQ_90FnOQc_"
PROJECT_REF = "bhzrhvesrpyvrsshavow"

REST_URL = f"{SUPABASE_URL}/rest/v1"

def make_request(url: str, method: str = "GET", data: dict = None, headers: dict = None) -> dict:
    """إجراء طلب HTTP"""
    default_headers = {
        "apikey": SUPABASE_ANON_KEY,
        "Authorization": f"Bearer {SUPABASE_ANON_KEY}",
        "Content-Type": "application/json",
    }
    if headers:
        default_headers.update(headers)

    req_data = json.dumps(data).encode() if data else None
    req = urllib.request.Request(url, data=req_data, method=method, headers=default_headers)
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            body = resp.read().decode()
            return {"status": resp.status, "data": json.loads(body) if body else None}
    except urllib.error.HTTPError as e:
        body = e.read().decode()
        return {"status": e.code, "error": body}
    except Exception as e:
        return {"status": 0, "error": str(e)}


def check_table_exists(table: str) -> bool:
    """فحص ما إذا كان الجدول موجودًا"""
    result = make_request(f"{REST_URL}/{table}?limit=1")
    return result.get("status") == 200


def main():
    print("=" * 60)
    print("تهيئة قاعدة بيانات Supabase لمشروع مشرق")
    print("=" * 60)
    print(f"URL: {SUPABASE_URL}")
    print()

    # 1. التحقق من الاتصال
    print("📡 اختبار الاتصال...")
    result = make_request(f"{REST_URL}/")
    if result.get("status") == 200:
        print("✅ الاتصال ناجح!")
    elif result.get("status") == 404:
        print("✅ الاتصال ناجح (REST API يعمل)")
    else:
        print(f"⚠️  استجابة غير متوقعة: {result}")
    print()

    # 2. فحص الجداول
    print("🔍 فحص الجداول الموجودة...")
    tables = ["profiles", "posts", "likes", "comments", "follows"]
    existing_tables = []
    missing_tables = []

    for table in tables:
        exists = check_table_exists(table)
        status = "✅ موجود" if exists else "❌ غير موجود"
        print(f"  - {table}: {status}")
        if exists:
            existing_tables.append(table)
        else:
            missing_tables.append(table)

    print()
    print(f"الإحصائيات: {len(existing_tables)}/{len(tables)} جداول موجودة")
    print()

    if missing_tables:
        print("⚠️  جداول مفقودة تحتاج إلى إنشائها!")
        print()
        print("لإكمال الإعداد، يرجى نسخ SQL التالي ولصقه في محرر SQL:")
        print("في لوحة تحكم Supabase: SQL Editor → New Query")
        print()
        print(f"  الرابط: https://supabase.com/dashboard/project/{PROJECT_REF}/sql/new")
        print()
        sql_file = Path("/home/z/my-project/scripts/supabase-schema.sql")
        if sql_file.exists():
            print(f"📄 ملف SQL متاح في: {sql_file}")
        return

    print("✅ جميع الجداول موجودة! قاعدة البيانات جاهزة.")
    print()

    # 3. إحصائيات سريعة
    print("📊 إحصائيات سريعة:")
    for table in existing_tables:
        result = make_request(f"{REST_URL}/{table}?select=*")
        if result.get("status") == 200:
            count = len(result.get("data", []))
            print(f"  - {table}: {count} صف")
        else:
            print(f"  - {table}: تعذّر العد ({result.get('status')})")


if __name__ == "__main__":
    main()
