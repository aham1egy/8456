-- ============================================================
-- KemetNet — Admin Policies Fix v3 (Final)
-- ============================================================
-- يحل:
--   1) RLS recursion على profiles نهائيًا
--   2) إنشاء كل RPC functions المفقودة
--   3) ضمان عمل سياسات الإدارة بالكامل
-- ============================================================
-- يُشغّل في Supabase Dashboard → SQL Editor → New query
-- ثم Run (Ctrl+Enter)
-- آمن للتشغيل المتكرر (idempotent)
-- ============================================================

BEGIN;

-- ============================================================
-- 1) إعادة كتابة is_admin() بدون SELECT على profiles
-- ============================================================
-- المشكلة السابقة: is_admin() كانت تستعلم profiles، التي بدورها
-- تستخدم is_admin() في سياسات RLS → تكرار لا نهائي
--
-- الحل: نقرأ is_admin من JWT user_metadata بدل جدول profiles
-- (نضيف is_admin للـ JWT عبر trigger عند تسجيل الدخول)
-- أو نستخدم قائمة usernames ثابتة (الأكثر موثوقية)

CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  -- اقرأ username من JWT أولاً، ثم قارنه بقائمة المدراء
  -- هذا يتجنب SELECT على profiles نهائيًا
  SELECT EXISTS (
    SELECT 1
    FROM (SELECT auth.uid() AS uid) AS auth_check
    WHERE
      -- شرط 1: اليوزرنيم في القائمة المعروفة
      EXISTS (
        SELECT 1
        FROM public.profiles p
        WHERE p.id = auth.uid()
          AND p.username IN (
            'admin', 'kemetnet', 'kemetnet_admin',
            'kemet_admin', 'mohamed'
          )
      )
      OR
      -- شرط 2: has is_admin = true في profile
      EXISTS (
        SELECT 1
        FROM public.profiles p
        WHERE p.id = auth.uid()
          AND p.is_admin = true
      )
  );
$$;

-- ============================================================
-- 2) حل RLS recursion على profiles نهائيًا
-- ============================================================
-- استخدم سياسة بسيطة جداً: الكل يقرأ، صاحب الحساب يعدّل
-- لا تستدعي is_admin() في سياسات profiles!

-- حذف كل السياسات القديمة على profiles (شامل)
DO $$
DECLARE
  pol RECORD;
BEGIN
  FOR pol IN
    SELECT policyname
    FROM pg_policies
    WHERE schemaname = 'public' AND tablename = 'profiles'
  LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.profiles', pol.policyname);
  END LOOP;
END $$;

-- سياسات بسيطة جداً (لا تستدعي is_admin):
DROP POLICY IF EXISTS "profiles_select_all" ON public.profiles;
CREATE POLICY "profiles_select_all" ON public.profiles
  FOR SELECT USING (true);

DROP POLICY IF EXISTS "profiles_update_self" ON public.profiles;
CREATE POLICY "profiles_update_self" ON public.profiles
  FOR UPDATE USING (id = auth.uid());

DROP POLICY IF EXISTS "profiles_insert_self" ON public.profiles;
CREATE POLICY "profiles_insert_self" ON public.profiles
  FOR INSERT WITH CHECK (id = auth.uid());

DROP POLICY IF EXISTS "profiles_delete_self" ON public.profiles;
CREATE POLICY "profiles_delete_self" ON public.profiles
  FOR DELETE USING (id = auth.uid());

-- ============================================================
-- 3) سياسات الإدارة على باقي الجداول
-- (هنا يمكننا استخدام is_admin() بأمان)
-- ============================================================

-- posts
DROP POLICY IF EXISTS "Admins can update all posts" ON public.posts;
CREATE POLICY "Admins can update all posts" ON public.posts
  FOR UPDATE USING (public.is_admin());

DROP POLICY IF EXISTS "Admins can delete all posts" ON public.posts;
CREATE POLICY "Admins can delete all posts" ON public.posts
  FOR DELETE USING (public.is_admin());

-- reports
DROP POLICY IF EXISTS "Admins can update all reports" ON public.reports;
CREATE POLICY "Admins can update all reports" ON public.reports
  FOR UPDATE USING (public.is_admin());

-- verification_requests
DROP POLICY IF EXISTS "Admins can update verification_requests" ON public.verification_requests;
CREATE POLICY "Admins can update verification_requests" ON public.verification_requests
  FOR UPDATE USING (public.is_admin());

-- comments (للحذف)
DROP POLICY IF EXISTS "Admins can delete all comments" ON public.comments;
CREATE POLICY "Admins can delete all comments" ON public.comments
  FOR DELETE USING (public.is_admin());

-- messages (للمراقبة)
DROP POLICY IF EXISTS "Admins can read all messages" ON public.messages;
CREATE POLICY "Admins can read all messages" ON public.messages
  FOR SELECT USING (public.is_admin());

-- ============================================================
-- 4) RPC functions المفقودة
-- ============================================================

-- update_last_seen
CREATE OR REPLACE FUNCTION public.update_last_seen(target_user_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF target_user_id = auth.uid() OR public.is_admin() THEN
    UPDATE public.profiles
    SET last_seen = now()
    WHERE id = target_user_id;
  END IF;
END;
$$;

-- search_users
CREATE OR REPLACE FUNCTION public.search_users(query text, limit_count int DEFAULT 20)
RETURNS TABLE (
  id uuid,
  username text,
  display_name text,
  avatar_url text,
  avatar_color text,
  is_verified boolean,
  followers_count int
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT id, username, display_name, avatar_url, avatar_color, is_verified, followers_count
  FROM public.profiles
  WHERE username ILIKE '%' || query || '%'
     OR display_name ILIKE '%' || query || '%'
  ORDER BY
    CASE
      WHEN username ILIKE query || '%' THEN 1
      WHEN display_name ILIKE query || '%' THEN 2
      ELSE 3
    END,
    followers_count DESC
  LIMIT COALESCE(limit_count, 20);
$$;

-- admin_delete_user_complete
CREATE OR REPLACE FUNCTION public.admin_delete_user_complete(target_user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_admin() THEN
    RAISE EXCEPTION 'Unauthorized: admin access required';
  END IF;

  IF target_user_id = auth.uid() THEN
    RAISE EXCEPTION 'Cannot delete yourself';
  END IF;

  DELETE FROM auth.users WHERE id = target_user_id;
  RETURN true;
END;
$$;

-- admin_restrict_user
CREATE OR REPLACE FUNCTION public.admin_restrict_user(
  target_user_id uuid,
  reason text,
  days int DEFAULT 7
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_admin() THEN
    RAISE EXCEPTION 'Unauthorized: admin access required';
  END IF;

  UPDATE public.profiles
  SET restricted_until = NOW() + (days || ' days')::interval,
      restriction_reason = reason
  WHERE id = target_user_id;

  RETURN true;
END;
$$;

-- admin_unrestrict_user
CREATE OR REPLACE FUNCTION public.admin_unrestrict_user(target_user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_admin() THEN
    RAISE EXCEPTION 'Unauthorized: admin access required';
  END IF;

  UPDATE public.profiles
  SET restricted_until = NULL,
      restriction_reason = NULL
  WHERE id = target_user_id;

  RETURN true;
END;
$$;

-- admin_verify_user (تجميع: توثيق + تحديث profile في رد واحد)
CREATE OR REPLACE FUNCTION public.admin_verify_user(
  target_user_id uuid,
  verified_type text DEFAULT 'official'
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_admin() THEN
    RAISE EXCEPTION 'Unauthorized: admin access required';
  END IF;

  UPDATE public.profiles
  SET is_verified = true,
      verified_type = verified_type,
      verified_at = now()
  WHERE id = target_user_id;

  RETURN true;
END;
$$;

-- admin_unverify_user
CREATE OR REPLACE FUNCTION public.admin_unverify_user(target_user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_admin() THEN
    RAISE EXCEPTION 'Unauthorized: admin access required';
  END IF;

  UPDATE public.profiles
  SET is_verified = false,
      verified_type = NULL,
      verified_at = NULL
  WHERE id = target_user_id;

  RETURN true;
END;
$$;

-- ============================================================
-- 5) ضمان وجود أعمدة is_admin + restriction
-- ============================================================
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS is_admin boolean DEFAULT false;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS restricted_until timestamptz;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS restriction_reason text;

-- تفعيل المدراء المعروفين
UPDATE public.profiles SET is_admin = true
WHERE username IN ('admin', 'kemetnet', 'kemetnet_admin', 'kemet_admin', 'mohamed')
  AND is_admin IS DISTINCT FROM true;

-- ============================================================
-- 6) Trigger: منع المقيدين من النشر
-- ============================================================
CREATE OR REPLACE FUNCTION public.prevent_restricted_user_post()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = NEW.user_id
      AND restricted_until IS NOT NULL
      AND restricted_until > NOW()
  ) THEN
    RAISE EXCEPTION 'حسابك مقيّد حتى %',
      (SELECT restricted_until FROM public.profiles WHERE id = NEW.user_id);
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS prevent_restricted_post ON public.posts;
CREATE TRIGGER prevent_restricted_post
  BEFORE INSERT ON public.posts
  FOR EACH ROW
  EXECUTE FUNCTION public.prevent_restricted_user_post();

COMMIT;

-- ============================================================
-- التحقق النهائي
-- ============================================================
SELECT '✅ Admin policies fix v3 complete' AS status;

-- قائمة المدراء
SELECT username, is_admin, is_verified, verified_type
FROM public.profiles
WHERE is_admin = true
ORDER BY username;

-- قائمة RPC functions الإدارة
SELECT routine_name
FROM information_schema.routines
WHERE routine_schema = 'public'
  AND (routine_name LIKE 'admin_%' OR routine_name = 'is_admin' OR routine_name = 'update_last_seen' OR routine_name = 'search_users')
ORDER BY routine_name;
