#!/usr/bin/env python3
"""
KemetNet — Comprehensive Owner & Permissions Audit
يفحص بشكل شامل:
  1) عمود role في profiles
  2) حسابات المالكين (owner)
  3) RPC functions (is_admin, is_owner, has_permission, staff management)
  4) جدول staff_members
  5) سياسات RLS على كل الجداول
  6) التحقق من صحة عمليات admin (DELETE/UPDATE)
"""

import json
import urllib.request
import urllib.error

SUPABASE_URL = "https://bhzrhvesrpyvrsshavow.supabase.co"
API_KEY = "sb_publishable_AO6P04L0WlDaCK2Ot38YTQ_90FnOQc_"


def api(method: str, path: str, body=None):
    url = f"{SUPABASE_URL}{path}"
    headers = {
        "apikey": API_KEY,
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json",
    }
    data = json.dumps(body).encode() if body else None
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            body_text = resp.read().decode()
            try:
                return resp.status, json.loads(body_text)
            except json.JSONDecodeError:
                return resp.status, body_text
    except urllib.error.HTTPError as e:
        body_text = e.read().decode()
        try:
            return e.code, json.loads(body_text)
        except json.JSONDecodeError:
            return e.code, body_text
    except Exception as e:
        return 0, str(e)


print("=" * 70)
print("🔍 KemetNet — Owner & Permissions Comprehensive Audit")
print("=" * 70)
print()

# ============= 1) Profiles + role column =============
print("━" * 70)
print("1) فحص عمود role في profiles + حسابات المالكين")
print("━" * 70)

status, body = api("GET", "/rest/v1/profiles?select=id,username,role,is_admin,is_verified,verified_type&order=username.asc&limit=50")
if status != 200 or not isinstance(body, list):
    print(f"   ❌ فشل جلب profiles: HTTP {status}")
    print(f"      Body: {str(body)[:300]}")
    print("   ⚠️  قد يكون سبب: عمود role غير موجود (شغّل admin-roles.sql)")
else:
    owners = [p for p in body if p.get("role") == "owner" or p.get("username") == "kemetnet"]
    admins = [p for p in body if p.get("role") == "admin"]
    staff  = [p for p in body if p.get("is_admin") == True]
    
    print(f"   ✅ عمود role موجود، إجمالي المستخدمين: {len(body)}")
    print()
    print(f"   👑 المالكين ({len(owners)}):")
    for o in owners:
        print(f"      - @{o.get('username')} (role={o.get('role', 'null')}, is_admin={o.get('is_admin', False)})")
    if not owners:
        print("      ⚠️  لا يوجد مستخدمون بـ role=owner!")
    print()
    if admins:
        print(f"   🛡️  المدراء ({len(admins)}):")
        for a in admins:
            print(f"      - @{a.get('username')}")
    print()
    print(f"   👥 is_admin=true ({len(staff)}):")
    for s in staff:
        print(f"      - @{s.get('username')} (role={s.get('role', 'null')})")
print()

# ============= 2) RPC functions =============
print("━" * 70)
print("2) فحص RPC functions الإدارة")
print("━" * 70)

rpcs = [
    ("is_admin", {}),
    ("is_owner", {}),
    ("has_permission", {"perm": "manage_posts"}),
    ("add_staff_member", {}),
    ("update_staff_permissions", {}),
    ("remove_staff_member", {}),
    ("admin_delete_user_complete", {}),
    ("admin_restrict_user", {}),
    ("admin_unrestrict_user", {}),
    ("admin_verify_user", {}),
    ("admin_unverify_user", {}),
    ("update_last_seen", {}),
    ("search_users", {"query": "test"}),
    ("delete_account", {}),
    ("get_feed", {"feed_type": "for-you"}),
]

for rpc, args in rpcs:
    status, body = api("POST", f"/rest/v1/rpc/{rpc}", body=args)
    if status == 404:
        print(f"   ❌ {rpc:<35} غير موجود")
    elif status in (401, 403):
        print(f"   ✅ {rpc:<35} موجود (يتطلب صلاحية)")
    elif status == 400:
        print(f"   ✅ {rpc:<35} موجود (يتطلب args مختلفة)")
    elif status == 200:
        print(f"   ✅ {rpc:<35} موجود (عمل) — نتيجة: {str(body)[:50]}")
    else:
        print(f"   ⚠️  {rpc:<35} HTTP {status}: {str(body)[:80]}")
print()

# ============= 3) Staff members table =============
print("━" * 70)
print("3) فحص جدول staff_members")
print("━" * 70)

status, body = api("GET", "/rest/v1/staff_members?select=*&limit=10")
if status == 200:
    if isinstance(body, list):
        print(f"   ✅ الجدول موجود ويتاح SELECT")
        print(f"   📊 عدد الموظفين: {len(body)}")
        for s in body:
            print(f"      - user_id={s.get('user_id')[:8]}..., role={s.get('role')}, active={s.get('active')}")
    else:
        print(f"   ⚠️  استجابة غير متوقعة: {str(body)[:100]}")
elif status == 404:
    print(f"   ❌ الجدول غير موجود (شغّل admin-roles.sql)")
elif status in (401, 403):
    print(f"   ✅ الجدول موجود (يحتاج صلاحية للقراءة)")
else:
    print(f"   ⚠️  HTTP {status}: {str(body)[:100]}")
print()

# ============= 4) RLS policies على الجداول الحرجة =============
print("━" * 70)
print("4) فحص عمليات الإدارة (بدون auth)")
print("━" * 70)

# محاولة UPDATE على posts (بدون auth = يجب أن تفشل أو تكون no-op)
status, body = api("PATCH", "/rest/v1/posts?id=eq.00000000-0000-0000-0000-000000000000",
                    body={"is_featured": True})
if status in (401, 403, 42501):
    print(f"   ✅ UPDATE posts بدون auth: مرفوض ({status})")
elif status == 204:
    print(f"   ℹ️  UPDATE posts بدون auth: نجح (لكن ربما 0 صفوف = آمن)")
else:
    print(f"   ⚠️  UPDATE posts: HTTP {status} — {str(body)[:100]}")

status, body = api("DELETE", "/rest/v1/posts?id=eq.00000000-0000-0000-0000-000000000000")
if status in (401, 403, 42501):
    print(f"   ✅ DELETE posts بدون auth: مرفوض")
elif status == 204:
    print(f"   ℹ️  DELETE posts بدون auth: نجح (لكن ربما 0 صفوف = آمن)")
else:
    print(f"   ⚠️  DELETE posts: HTTP {status}")

# محاولة UPDATE على profiles
status, body = api("PATCH", "/rest/v1/profiles?id=eq.00000000-0000-0000-0000-000000000000",
                    body={"is_verified": True})
if status in (401, 403, 42501):
    print(f"   ✅ UPDATE profiles بدون auth: مرفوض")
elif status == 204:
    print(f"   ℹ️  UPDATE profiles بدون auth: نجح (لكن ربما 0 صفوف = آمن)")
else:
    print(f"   ⚠️  UPDATE profiles: HTTP {status}")

# محاولة UPDATE على verification_requests
status, body = api("PATCH", "/rest/v1/verification_requests?id=eq.00000000-0000-0000-0000-000000000000",
                    body={"status": "approved"})
if status in (401, 403, 42501):
    print(f"   ✅ UPDATE verification_requests بدون auth: مرفوض")
elif status == 204:
    print(f"   ℹ️  UPDATE verification_requests بدون auth: نجح (لكن ربما 0 صفوف = آمن)")
else:
    print(f"   ⚠️  UPDATE verification_requests: HTTP {status}")

# محاولة UPDATE على reports
status, body = api("PATCH", "/rest/v1/reports?id=eq.00000000-0000-0000-0000-000000000000",
                    body={"status": "actioned"})
if status in (401, 403, 42501):
    print(f"   ✅ UPDATE reports بدون auth: مرفوض")
elif status == 204:
    print(f"   ℹ️  UPDATE reports بدون auth: نجح (لكن ربما 0 صفوف = آمن)")
else:
    print(f"   ⚠️  UPDATE reports: HTTP {status}")
print()

# ============= 5) Storage buckets =============
print("━" * 70)
print("5) فحص Storage Buckets")
print("━" * 70)

buckets = ["avatars", "post-images", "message-images"]
for bucket in buckets:
    status, body = api("GET", f"/storage/v1/bucket/{bucket}")
    if status == 200:
        print(f"   ✅ {bucket}")
    elif status == 400:
        # قد يكون 400 بسبب RLS لكن البucket موجود
        body_str = str(body)[:100]
        if "not found" in body_str.lower():
            print(f"   ❌ {bucket} — غير موجود")
        else:
            print(f"   ⚠️  {bucket} — HTTP 400: {body_str}")
    else:
        print(f"   ⚠️  {bucket} — HTTP {status}")
print()

# ============= 6) Verification requests table =============
print("━" * 70)
print("6) فحص أعمدة reports + verification_requests")
print("━" * 70)

# Check reports columns
status, body = api("GET", "/rest/v1/reports?select=id,status,reason,action_taken,admin_id,admin_note,resolved_at,updated_at&limit=1")
if status == 200:
    print(f"   ✅ reports: كل الأعمدة موجودة (action_taken, admin_id, admin_note, resolved_at, updated_at)")
elif status == 400:
    err = str(body)
    if "action_taken" in err:
        print(f"   ❌ reports: عمود action_taken غير موجود — شغّل reports-management-upgrade.sql")
    elif "admin_note" in err:
        print(f"   ❌ reports: عمود admin_note غير موجود")
    else:
        print(f"   ⚠️  reports: {err[:150]}")
elif status == 404:
    print(f"   ❌ reports: الجدول غير موجود")
else:
    print(f"   ⚠️  reports: HTTP {status}")

# Check verification_requests columns
status, body = api("GET", "/rest/v1/verification_requests?select=id,status,admin_notes,user_id,requested_type&limit=1")
if status == 200:
    print(f"   ✅ verification_requests: كل الأعمدة موجودة (admin_notes, status, user_id, requested_type)")
elif status == 400:
    err = str(body)
    if "admin_notes" in err:
        print(f"   ❌ verification_requests: عمود admin_notes غير موجود (الكود يستخدم admin_notes الجمع)")
    else:
        print(f"   ⚠️  verification_requests: {err[:150]}")
elif status == 404:
    print(f"   ❌ verification_requests: الجدول غير موجود")
else:
    print(f"   ⚠️  verification_requests: HTTP {status}")
print()

# ============= 7) Summary =============
print("=" * 70)
print("📋 الملخص النهائي")
print("=" * 70)
print("""
النتائج أعلاه توضح حالة كل من:
  - حسابات المالكين والمدراء
  - RPC functions (15 function)
  - جدول staff_members
  - سياسات RLS على الجداول الحرجة
  - Storage buckets (3)
  - أعمدة reports + verification_requests

لتفعيل كل الصلاحيات، تأكد من تشغيل:
  1. scripts/admin-roles.sql (للأدوار + staff_members)
  2. scripts/reports-management-upgrade.sql (لأعمدة reports المتقدمة)

في Supabase Dashboard → SQL Editor
""")
