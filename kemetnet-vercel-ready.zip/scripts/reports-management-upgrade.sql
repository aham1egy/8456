-- ============================================================
-- KemetNet — Reports Management Upgrade
-- ============================================================
-- يضيف أعمدة إدارة البلاغات المتقدمة:
--   - action_taken: ما الإجراء الذي تم اتخاذه
--   - admin_id: من الإداري الذي عالج البلاغ
--   - admin_note: ملاحظات الإداري
--   - resolved_at: متى تم حل البلاغ
--   - updated_at: تاريخ آخر تحديث
-- ============================================================
-- آمن للتشغيل المتكرر (idempotent)
-- يُشغّل في Supabase Dashboard → SQL Editor → New query
-- ============================================================

BEGIN;

-- 1) إضافة الأعمدة الجديدة لجدول reports
ALTER TABLE public.reports ADD COLUMN IF NOT EXISTS action_taken text;
ALTER TABLE public.reports ADD COLUMN IF NOT EXISTS admin_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL;
ALTER TABLE public.reports ADD COLUMN IF NOT EXISTS admin_note text;
ALTER TABLE public.reports ADD COLUMN IF NOT EXISTS resolved_at timestamptz;
ALTER TABLE public.reports ADD COLUMN IF NOT EXISTS updated_at timestamptz DEFAULT now();

-- 2) Index على status + admin_id للاستعلامات السريعة
CREATE INDEX IF NOT EXISTS idx_reports_status ON public.reports(status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_reports_admin ON public.reports(admin_id) WHERE admin_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_reports_pending ON public.reports(created_at DESC) WHERE status = 'pending';

-- 3) Trigger: تحديث updated_at تلقائيًا عند تعديل البلاغ
CREATE OR REPLACE FUNCTION public.update_reports_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS reports_updated_at ON public.reports;
CREATE TRIGGER reports_updated_at
  BEFORE UPDATE ON public.reports
  FOR EACH ROW
  EXECUTE FUNCTION public.update_reports_updated_at();

-- 4) تحديث سياسة RLS — الموظفون بصلاحية manage_reports يمكنهم UPDATE
-- (السياسة الحالية تستخدم has_permission، نحن فقط نتأكد)
DROP POLICY IF EXISTS "Staff can update all reports" ON public.reports;
CREATE POLICY "Staff can update all reports" ON public.reports
  FOR UPDATE USING (public.has_permission('manage_reports'));

-- 5) سياسة SELECT — المدراء يقرؤون كل البلاغات
-- المُبلِّغ يقرأ بلاغاته فقط
DROP POLICY IF EXISTS "reports_select_admin_or_owner" ON public.reports;
DROP POLICY IF EXISTS "Users can read own reports" ON public.reports;
CREATE POLICY "reports_select" ON public.reports
  FOR SELECT USING (
    reporter_id = auth.uid()
    OR public.has_permission('manage_reports')
  );

-- 6) index على reporter_id + reported_user_id
CREATE INDEX IF NOT EXISTS idx_reports_reporter ON public.reports(reporter_id);
CREATE INDEX IF NOT EXISTS idx_reports_reported_user ON public.reports(reported_user_id) WHERE reported_user_id IS NOT NULL;

COMMIT;

-- ============================================================
-- التحقق
-- ============================================================
SELECT '✅ Reports management upgrade complete' AS status;

-- عرض بنية جدول reports
SELECT column_name, data_type, is_nullable
FROM information_schema.columns
WHERE table_schema = 'public' AND table_name = 'reports'
ORDER BY ordinal_position;
