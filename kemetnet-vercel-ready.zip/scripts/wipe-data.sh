#!/usr/bin/env bash
# ============================================================
# KemetNet — Wipe All Data from Supabase
# ============================================================
# يحذف كل الصفوف من جداول البيانات (لا يلمس auth.users افتراضيًا)
# الترتيب مهم: الجداول التابعة أولاً ثم الرئيسية
# ============================================================

set -e

SUPABASE_URL="https://bhzrhvesrpyvrsshavow.supabase.co"
API_KEY="sb_publishable_AO6P04L0WlDaCK2Ot38YTQ_90FnOQc_"

# Header for REST API (with Prefer: return=representation to get count, but we just want deletion)
AUTH_HEADERS=(
  -H "apikey: ${API_KEY}"
  -H "Authorization: Bearer ${API_KEY}"
  -H "Content-Type: application/json"
  -H "Prefer: return=minimal"
)

echo "============================================================"
echo "🗑️  KemetNet — Wipe All Data from Supabase"
echo "============================================================"
echo "Target: ${SUPABASE_URL}"
echo ""

# ترتيب الحذف (من الجداول التابعة إلى الرئيسية)
# — الجداول التي تشير لجداول أخرى عبر FK تُحذف أولاً —
TABLES=(
  # Level 1: تعتمد على كل شيء
  "message_reactions"
  "comment_likes"
  "saved_posts"
  "feature_votes"
  "reputation_log"
  "daily_rewards_log"
  "user_achievements"
  "verification_requests"
  "notifications"
  "reports"
  "blocks"
  "follows"
  "likes"

  # Level 2: تعتمد على posts / messages
  "comments"
  "messages"
  "message_requests"

  # Level 3: تعتمد على conversations / profiles
  "conversations"
  "posts"
  "achievements"   # تعريفات الإنجازات (يمكن إعادة ملئها لاحقًا)

  # Level 4: profiles أخيرًا (لأن كل الجداول تشير إليها)
  "profiles"
)

SUCCESS=0
FAILED=0
SKIPPED=0

for table in "${TABLES[@]}"; do
  url="${SUPABASE_URL}/rest/v1/${table}"
  # DELETE with filter that matches all rows (id neq 'never-match' OR just empty filter)
  response=$(curl -s -o /tmp/wipe-resp.json -w "%{http_code}" \
    -X DELETE "${url}?id=neq.00000000-0000-0000-0000-000000000000" \
    "${AUTH_HEADERS[@]}")
  body=$(cat /tmp/wipe-resp.json 2>/dev/null | head -c 200)

  if [ "${response}" = "204" ]; then
    echo "  ✓ ${table}: حذف بنجاح (204)"
    SUCCESS=$((SUCCESS+1))
  elif [ "${response}" = "404" ]; then
    echo "  ⊘ ${table}: الجدول غير موجود (404) — تخطّي"
    SKIPPED=$((SKIPPED+1))
  elif [ "${response}" = "403" ] || [ "${response}" = "401" ]; then
    echo "  ✗ ${table}: ${response} — ربما RLS يمنع الحذف"
    echo "    body: ${body}"
    FAILED=$((FAILED+1))
  else
    echo "  ✗ ${table}: ${response}"
    echo "    body: ${body}"
    FAILED=$((FAILED+1))
  fi
done

echo ""
echo "============================================================"
echo "📊 ملخص الحذف"
echo "============================================================"
echo "✓ نجح:     ${SUCCESS}"
echo "⊘ تخطّي:   ${SKIPPED} (جداول غير موجودة)"
echo "✗ فشل:     ${FAILED}"
echo "============================================================"

# التحقق: عدّ الصفوف في الجداول الحرجة
echo ""
echo "🔍 التحقق من نظافة الجداول الحرجة..."
VERIFY_TABLES=("posts" "comments" "profiles" "messages" "notifications")
for tbl in "${VERIFY_TABLES[@]}"; do
  count=$(curl -s "${SUPABASE_URL}/rest/v1/${tbl}?select=*" \
    -H "apikey: ${API_KEY}" \
    -H "Authorization: Bearer ${API_KEY}" \
    -H "Prefer: count=exact" \
    -H "Range: 0-0" \
    -D /tmp/headers.txt -o /dev/null -w "%{http_code}")
  total=$(grep -i "content-range" /tmp/headers.txt 2>/dev/null | sed 's/.*\///' | tr -d '\r' || echo "?")
  echo "  ${tbl}: ${count} (صفوف: ${total})"
done
echo ""
echo "✅ تم الانتهاء."
echo ""
echo "ملاحظة: auth.users في Supabase لم يُمَسَّ. إذا أردت حذف المستخدمين أيضًا:"
echo "  1. اذهب إلى Dashboard → Authentication → Users"
echo "  2. احذف المستخدمين يدويًا (أو استخدم service_role key للحذف عبر API)"
