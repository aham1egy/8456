-- =====================================================
-- مشرق - نظام الإنجازات (Achievements System)
-- آمن للتشغيل المتكرر
-- =====================================================

-- =====================================================
-- 1. جدول الإنجازات (achievements)
-- تعريف كل الإنجازات المتاحة
-- =====================================================
CREATE TABLE IF NOT EXISTS public.achievements (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  -- معرف فريد للإنجاز (slug)
  slug TEXT UNIQUE NOT NULL,
  -- اسم الإنجاز
  name TEXT NOT NULL,
  -- الوصف
  description TEXT NOT NULL,
  -- الفئة
  category TEXT NOT NULL CHECK (category IN ('posts', 'social', 'engagement', 'milestone', 'special')),
  -- الأيقونة (emoji)
  icon TEXT NOT NULL,
  -- اللون
  color TEXT NOT NULL DEFAULT '#FBBF24',
  -- النقاط الممنوحة عند الإنجاز
  points_reward INTEGER NOT NULL DEFAULT 0,
  -- الهدف المطلوب (عدد)
  target_value INTEGER,
  -- نوع النشاط المرتبط
  activity_type TEXT,
  -- مستوى الصعوبة
  tier TEXT NOT NULL DEFAULT 'bronze' CHECK (tier IN ('bronze', 'silver', 'gold', 'platinum', 'diamond')),
  -- التاريخ
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- =====================================================
-- 2. جدول إنجازات المستخدمين (user_achievements)
-- يسجل كل إنجاز حصل عليه مستخدم
-- =====================================================
CREATE TABLE IF NOT EXISTS public.user_achievements (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  achievement_slug TEXT NOT NULL REFERENCES public.achievements(slug) ON DELETE CASCADE,
  -- تقدم المستخدم نحو الإنجاز
  progress INTEGER DEFAULT 0,
  -- هل اكتمل الإنجاز؟
  completed BOOLEAN DEFAULT FALSE,
  completed_at TIMESTAMPTZ,
  -- التاريخ
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  -- منع التكرار
  UNIQUE(user_id, achievement_slug)
);

CREATE INDEX IF NOT EXISTS idx_user_achievements_user ON public.user_achievements (user_id, completed);
CREATE INDEX IF NOT EXISTS idx_user_achievements_completed ON public.user_achievements (completed_at DESC) WHERE completed = TRUE;

-- =====================================================
-- 3. RLS
-- =====================================================
ALTER TABLE public.achievements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_achievements ENABLE ROW LEVEL SECURITY;

-- achievements: الجميع يرى التعريفات
DROP POLICY IF EXISTS "achievements_select_all" ON public.achievements;
CREATE POLICY "achievements_select_all" ON public.achievements FOR SELECT USING (true);

-- user_achievements: المستخدم يرى إنجازاته فقط
DROP POLICY IF EXISTS "user_achievements_select_own" ON public.user_achievements;
CREATE POLICY "user_achievements_select_own" ON public.user_achievements FOR SELECT 
  USING (auth.uid() = user_id);

-- الإدراج يكون فقط عبر SECURITY DEFINER functions
DROP POLICY IF EXISTS "user_achievements_insert_own" ON public.user_achievements;
CREATE POLICY "user_achievements_insert_own" ON public.user_achievements FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

-- المستخدم يحدّث تقدم إنجازاته
DROP POLICY IF EXISTS "user_achievements_update_own" ON public.user_achievements;
CREATE POLICY "user_achievements_update_own" ON public.user_achievements FOR UPDATE 
  USING (auth.uid() = user_id);

-- =====================================================
-- 4. دالة لتحديث تقدم إنجاز
-- =====================================================
CREATE OR REPLACE FUNCTION public.update_achievement_progress(
  target_user_id UUID,
  achievement_slug TEXT,
  new_progress INTEGER
)
RETURNS VOID AS $$
DECLARE
  achievement_record RECORD;
  existing_record RECORD;
  should_complete BOOLEAN;
BEGIN
  -- جلب تعريف الإنجاز
  SELECT * INTO achievement_record FROM public.achievements WHERE slug = achievement_slug;
  IF NOT FOUND THEN RETURN; END IF;
  
  -- تحديد ما إذا كان يجب الإكمال
  should_complete := achievement_record.target_value IS NULL OR new_progress >= achievement_record.target_value;
  
  -- upsert
  INSERT INTO public.user_achievements (user_id, achievement_slug, progress, completed, completed_at, updated_at)
  VALUES (
    target_user_id,
    achievement_slug,
    LEAST(new_progress, COALESCE(achievement_record.target_value, new_progress)),
    should_complete,
    CASE WHEN should_complete THEN NOW() ELSE NULL END,
    NOW()
  )
  ON CONFLICT (user_id, achievement_slug) DO UPDATE
  SET 
    progress = GREATEST(user_achievements.progress, LEAST(new_progress, COALESCE(achievement_record.target_value, new_progress))),
    completed = user_achievements.completed OR should_complete,
    completed_at = CASE 
      WHEN should_complete AND user_achievements.completed_at IS NULL THEN NOW()
      ELSE user_achievements.completed_at
    END,
    updated_at = NOW()
  WHERE user_achievements.user_id = target_user_id AND user_achievements.achievement_slug = achievement_slug;
  
  -- منح النقاط عند الإكمال الأول
  IF should_complete THEN
    -- تحقق إذا كان قد اكتمل سابقاً (لا نمنح النقاط مرتين)
    SELECT * INTO existing_record FROM public.user_achievements 
    WHERE user_id = target_user_id AND achievement_slug = achievement_slug;
    
    IF existing_record.completed_at IS NOT NULL AND existing_record.points_awarded IS NULL THEN
      -- منح نقاط السمعة
      PERFORM public.award_reputation_points(
        target_user_id,
        'achievement_completed',
        existing_record.id,
        'achievement'
      );
    END IF;
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- =====================================================
-- 5. إدراج الإنجازات الافتراضية
-- =====================================================
INSERT INTO public.achievements (slug, name, description, category, icon, color, points_reward, target_value, tier) VALUES
-- منشورات
('first_post', 'أول منشور', 'انشر أول منشور لك', 'posts', '✍️', '#10B981', 50, 1, 'bronze'),
('post_10', 'كاتب نشط', 'انشر 10 منشورات', 'posts', '📝', '#3B82F6', 100, 10, 'silver'),
('post_50', 'كاتب غزير', 'انشر 50 منشوراً', 'posts', '📚', '#A855F7', 300, 50, 'gold'),
('post_100', 'كاتب محترف', 'انشر 100 منشور', 'posts', '🏆', '#FBBF24', 500, 100, 'platinum'),
-- اجتماعي
('first_follower', 'أول متابع', 'احصل على أول متابع', 'social', '👥', '#10B981', 25, 1, 'bronze'),
('followers_10', 'شخصية اجتماعية', 'احصل على 10 متابعين', 'social', '🤝', '#3B82F6', 75, 10, 'silver'),
('followers_50', 'مؤثر ناشئ', 'احصل على 50 متابعاً', 'social', '⭐', '#A855F7', 200, 50, 'gold'),
('followers_100', 'مؤثر', 'احصل على 100 متابع', 'social', '🌟', '#FBBF24', 400, 100, 'platinum'),
('followers_1000', 'نجم', 'احصل على 1000 متابع', 'social', '💫', '#EC4899', 1000, 1000, 'diamond'),
-- تفاعل
('first_like', 'أول إعجاب', 'احصل على أول إعجاب', 'engagement', '❤️', '#10B981', 10, 1, 'bronze'),
('likes_100', 'محبوب', 'احصل على 100 إعجاب', 'engagement', '💖', '#3B82F6', 150, 100, 'silver'),
('likes_1000', 'مشتهر', 'احصل على 1000 إعجاب', 'engagement', '💘', '#A855F7', 400, 1000, 'gold'),
-- إنجازات
('verified', 'موثّق', 'احصل على شارة التحقق', 'special', '✓', '#3B82F6', 100, 1, 'gold'),
('early_adopter', 'مستخدم مبكر', 'انضم في الأشهر الأولى', 'special', '⚡', '#FBBF24', 25, 1, 'silver'),
-- معالم
('level_5', 'متطور', 'صل للمستوى 5', 'milestone', '🎖️', '#3B82F6', 100, 5, 'silver'),
('level_10', 'خبير', 'صل للمستوى 10', 'milestone', '🏅', '#A855F7', 250, 10, 'gold'),
('level_25', 'أسطورة', 'صل للمستوى 25', 'milestone', '👑', '#FBBF24', 1000, 25, 'diamond')
ON CONFLICT (slug) DO NOTHING;

-- =====================================================
-- ملاحظات:
-- 1. 17 إنجاز افتراضي في 5 فئات
-- 2. 5 مستويات صعوبة: bronze, silver, gold, platinum, diamond
-- 3. تحديث تلقائي للإنجازات عبر triggers (يُضاف لاحقاً)
-- 4. منح نقاط السمعة عند إكمال إنجاز
-- =====================================================
