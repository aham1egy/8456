-- ============================================================
-- KemetNet — Admin Setup SQL
-- ============================================================
-- شغّل هذا الملف في Supabase Dashboard → SQL Editor
-- لإضافة:
--   1) عمود is_admin في profiles
--   2) RPC functions لتجاوز RLS في عمليات الإدارة
-- ============================================================

-- ============= 1) إضافة عمود is_admin =============
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS is_admin boolean DEFAULT false;

-- ============= 2) تعيين المدراء =============
-- بدّل اليوزرنيمات بقائمتك الحقيقية
UPDATE public.profiles SET is_admin = true
WHERE username IN ('admin', 'kemetnet', 'kemetnet_admin')
  AND is_admin IS DISTINCT FROM true;

-- ============= 3) RLS policy: المدراء يرون كل البيانات =============
-- (سياسات SELECT الحالية قد تكفي، لكن نضيف policy صريحة للمدراء)
DROP POLICY IF EXISTS "Admins can read all profiles" ON public.profiles;
CREATE POLICY "Admins can read all profiles"
  ON public.profiles FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles p
      WHERE p.id = auth.uid() AND p.is_admin = true
    )
  );

-- ============= 4) RLS policy: المدراء يمكنهم تعديل أي شيء =============
DROP POLICY IF EXISTS "Admins can update all posts" ON public.posts;
CREATE POLICY "Admins can update all posts"
  ON public.posts FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles p
      WHERE p.id = auth.uid() AND p.is_admin = true
    )
  );

DROP POLICY IF EXISTS "Admins can delete all posts" ON public.posts;
CREATE POLICY "Admins can delete all posts"
  ON public.posts FOR DELETE
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles p
      WHERE p.id = auth.uid() AND p.is_admin = true
    )
  );

DROP POLICY IF EXISTS "Admins can update all profiles" ON public.profiles;
CREATE POLICY "Admins can update all profiles"
  ON public.profiles FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles p
      WHERE p.id = auth.uid() AND p.is_admin = true
    )
  );

DROP POLICY IF EXISTS "Admins can delete profiles" ON public.profiles;
CREATE POLICY "Admins can delete profiles"
  ON public.profiles FOR DELETE
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles p
      WHERE p.id = auth.uid() AND p.is_admin = true
    )
  );

DROP POLICY IF EXISTS "Admins can update all reports" ON public.reports;
CREATE POLICY "Admins can update all reports"
  ON public.reports FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles p
      WHERE p.id = auth.uid() AND p.is_admin = true
    )
  );

DROP POLICY IF EXISTS "Admins can update verification_requests" ON public.verification_requests;
CREATE POLICY "Admins can update verification_requests"
  ON public.verification_requests FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles p
      WHERE p.id = auth.uid() AND p.is_admin = true
    )
  );

-- ============= 5) RPC: حذف مستخدم بالكامل (مع auth.users) =============
-- يحذف من profiles + auth.users (يتطلب service_role أو being postgres)
CREATE OR REPLACE FUNCTION public.admin_delete_user_complete(target_user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- فحص أن المستدعي مدير
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.id = auth.uid() AND p.is_admin = true
  ) THEN
    RAISE EXCEPTION 'Unauthorized: admin access required';
  END IF;

  -- منع حذف نفسك
  IF target_user_id = auth.uid() THEN
    RAISE EXCEPTION 'Cannot delete yourself';
  END IF;

  -- حذف من auth.users (سيحذف تلقائيًا cascade في profiles)
  DELETE FROM auth.users WHERE id = target_user_id;
  RETURN true;
END;
$$;

-- ============= 6) RPC: تقييد مستخدم =============
CREATE OR REPLACE FUNCTION public.admin_restrict_user(target_user_id uuid, reason text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.id = auth.uid() AND p.is_admin = true
  ) THEN
    RAISE EXCEPTION 'Unauthorized: admin access required';
  END IF;

  UPDATE public.profiles
  SET restricted_until = NOW() + INTERVAL '7 days',
      restriction_reason = reason
  WHERE id = target_user_id;

  RETURN true;
END;
$$;

-- ============= 7) منع المستخدمين المقيدين من إنشاء محتوى =============
CREATE OR REPLACE FUNCTION public.prevent_restricted_user_post()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = NEW.user_id
      AND restricted_until IS NOT NULL
      AND restricted_until > NOW()
  ) THEN
    RAISE EXCEPTION 'Your account is restricted until %',
      (SELECT restricted_until FROM public.profiles WHERE id = NEW.user_id);
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS prevent_restricted_post ON public.posts;
CREATE TRIGGER prevent_restricted_post
  BEFORE INSERT ON public.posts
  FOR EACH ROW
  EXECUTE FUNCTION public.prevent_restricted_user_post();

-- ============= 8) تحديث is_admin تلقائيًا للأسماء المعروفة =============
-- (اختياري - لضمان أن المدراء دائمًا في القائمة)
CREATE OR REPLACE FUNCTION public.sync_admin_flag()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- إذا اليوزرنيم في القائمة، فعّل is_admin
  IF NEW.username IN ('admin', 'kemetnet', 'kemetnet_admin') THEN
    NEW.is_admin := true;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS sync_admin_flag_trigger ON public.profiles;
CREATE TRIGGER sync_admin_flag_trigger
  BEFORE INSERT OR UPDATE OF username ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.sync_admin_flag();

-- ============= 9) التحقق =============
SELECT 'Admin setup complete' AS status;

SELECT username, is_admin, is_verified, verified_type
FROM public.profiles
WHERE is_admin = true
ORDER BY username;
