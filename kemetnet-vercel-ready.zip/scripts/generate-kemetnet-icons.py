#!/usr/bin/env python3
"""
Generate KemetNet app icon (PNG, multiple sizes) + favicon + SVG.
Theme: simple white & brown coffee shop logo.

Brand: KemetNet — a warm, social platform inspired by the heritage of
Kemet (ancient Egypt) and a coffee-house vibe.
"""

from pathlib import Path
import cairosvg
from PIL import Image, ImageDraw, ImageFilter, ImageFont
import io
import math

PUBLIC_DIR = Path("/home/z/my-project/public")
ICONS_DIR = PUBLIC_DIR / "icons"
ICONS_DIR.mkdir(parents=True, exist_ok=True)

# -----------------------------
# Brand palette (white & brown)
# -----------------------------
CREAM_BG       = "#FFF8EB"   # cream / warm white
BROWN_DARK     = "#3B2417"   # very dark coffee brown (text / outline)
BROWN_PRIMARY  = "#6F4E37"   # classic coffee brown (cup body)
BROWN_LIGHT    = "#A0785A"   # milk coffee (highlights)
GOLD_ACCENT    = "#C8A165"   # subtle warm gold accent (steam / glow)

# -----------------------------
# SVG source for the icon mark
# -----------------------------
# Design language: rounded square background (cream), centered coffee cup
# (brown) with saucer + 3 wavy steam lines (gold/brown) + small spark dot.
# Designed to read clearly at 32px and scale up to 512px.
ICON_SVG_TEMPLATE = """<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="{size}" height="{size}">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="{cream}"/>
      <stop offset="100%" stop-color="#F4E4C9"/>
    </linearGradient>
    <linearGradient id="cup" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="{brown_primary}"/>
      <stop offset="100%" stop-color="{brown_dark}"/>
    </linearGradient>
    <linearGradient id="saucer" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="{brown_light}"/>
      <stop offset="100%" stop-color="{brown_primary}"/>
    </linearGradient>
    <radialGradient id="glow" cx="50%" cy="55%" r="60%">
      <stop offset="0%" stop-color="{gold}" stop-opacity="0.25"/>
      <stop offset="100%" stop-color="{gold}" stop-opacity="0"/>
    </radialGradient>
  </defs>

  <!-- Background (full-bleed; system handles rounding) -->
  <rect width="512" height="512" fill="url(#bg)"/>

  <!-- Soft warm glow -->
  <circle cx="256" cy="260" r="200" fill="url(#glow)"/>

  <!-- Steam -->
  <g stroke="{brown_dark}" stroke-width="14" stroke-linecap="round" fill="none" opacity="0.75">
    <path d="M210 170 C 195 145, 225 130, 210 100"/>
    <path d="M256 165 C 241 140, 271 125, 256 95"/>
    <path d="M302 170 C 287 145, 317 130, 302 100"/>
  </g>

  <!-- Cup body (trapezoid) -->
  <path d="
    M 175 215
    L 337 215
    L 322 320
    Q 320 345, 295 345
    L 217 345
    Q 192 345, 190 320
    Z" fill="url(#cup)"/>

  <!-- Cup rim (cream ellipse highlight) -->
  <ellipse cx="256" cy="215" rx="81" ry="14" fill="#F4E4C9"/>
  <ellipse cx="256" cy="212" rx="72" ry="9" fill="#2A1A10"/>

  <!-- Handle -->
  <path d="
    M 337 232
    C 380 232, 392 275, 348 290
    L 340 280
    C 372 268, 363 248, 337 248
    Z" fill="url(#cup)"/>

  <!-- Saucer -->
  <ellipse cx="256" cy="372" rx="125" ry="22" fill="url(#saucer)"/>
  <ellipse cx="256" cy="368" rx="115" ry="16" fill="{brown_primary}" opacity="0.85"/>

  <!-- Small spark on rim (gold highlight dot) -->
  <circle cx="220" cy="208" r="4" fill="#FFF8EB" opacity="0.9"/>

  <!-- Subtle gold accent ring (Kemet heritage nod) -->
  <circle cx="256" cy="260" r="190" fill="none" stroke="{gold}" stroke-width="2" opacity="0.35"/>
</svg>
"""

# Favicon uses a tighter, smaller-rim design for clarity at 32px.
FAVICON_SVG = """<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="32" height="32">
  <rect width="64" height="64" fill="#FFF8EB"/>
  <g>
    <path d="M22 25 H42 L39 42 Q38 46 34 46 H30 Q26 46 25 42 Z" fill="#6F4E37"/>
    <ellipse cx="32" cy="25" rx="10" ry="2.2" fill="#3B2417"/>
    <path d="M42 28 C50 28 52 36 44 38" stroke="#6F4E37" stroke-width="3.5" fill="none" stroke-linecap="round"/>
    <ellipse cx="32" cy="50" rx="14" ry="2.5" fill="#A0785A"/>
    <path d="M28 17 C26 13 30 11 28 7" stroke="#3B2417" stroke-width="2.4" fill="none" stroke-linecap="round" opacity="0.7"/>
    <path d="M32 16 C30 12 34 10 32 6" stroke="#3B2417" stroke-width="2.4" fill="none" stroke-linecap="round" opacity="0.7"/>
    <path d="M36 17 C34 13 38 11 36 7" stroke="#3B2417" stroke-width="2.4" fill="none" stroke-linecap="round" opacity="0.7"/>
  </g>
</svg>
"""

# Full lockup logo (used in splash, auth page) — cup mark + wordmark
LOGO_SVG = """<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30" width="30" height="30">
  <defs>
    <linearGradient id="kbg" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#FFF8EB"/>
      <stop offset="100%" stop-color="#F4E4C9"/>
    </linearGradient>
    <linearGradient id="kcup" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#6F4E37"/>
      <stop offset="100%" stop-color="#3B2417"/>
    </linearGradient>
  </defs>
  <path d="M24.51,28.51H5.49c-2.21,0-4-1.79-4-4V5.49c0-2.21,1.79-4,4-4h19.03c2.21,0,4,1.79,4,4v19.03
    C28.51,26.72,26.72,28.51,24.51,28.51z" fill="url(#kbg)" stroke="#C8A165" stroke-width="0.4"/>
  <g class="z-breathe">
    <!-- Steam -->
    <path d="M10,8 Q11,6 10,4 Q9,2.5 10,1.5" stroke="#3B2417" stroke-width="0.7" fill="none" stroke-linecap="round" opacity="0.7"/>
    <path d="M15,7.5 Q16,5.5 15,3.5 Q14,2 15,1" stroke="#3B2417" stroke-width="0.7" fill="none" stroke-linecap="round" opacity="0.7"/>
    <path d="M20,8 Q21,6 20,4 Q19,2.5 20,1.5" stroke="#3B2417" stroke-width="0.7" fill="none" stroke-linecap="round" opacity="0.7"/>
    <!-- Cup body -->
    <path d="M9,11 H21 L19.7,18.5 Q19.4,20.5 17.5,20.5 H12.5 Q10.6,20.5 10.3,18.5 Z" fill="url(#kcup)"/>
    <!-- Rim -->
    <ellipse cx="15" cy="11" rx="6" ry="1.1" fill="#F4E4C9"/>
    <ellipse cx="15" cy="10.7" rx="5.2" ry="0.7" fill="#2A1A10"/>
    <!-- Handle -->
    <path d="M21,12.5 C24,12.5 24.5,15.5 22,16.5 L21.5,15.8 C23,15 22.5,13.5 21,13.5 Z" fill="url(#kcup)"/>
    <!-- Saucer -->
    <ellipse cx="15" cy="22" rx="8.5" ry="1.4" fill="#A0785A"/>
    <!-- Spark -->
    <circle cx="12.5" cy="10.4" r="0.3" fill="#FFF8EB"/>
  </g>
  <style type="text/css">
    .z-breathe { animation: breathe 2.5s ease-in-out infinite; }
    @keyframes breathe { 0%,100% { opacity: 0.85; } 50% { opacity: 1; } }
  </style>
</svg>
"""


def render_svg_to_png(svg_str: str, size: int) -> bytes:
    """Render an SVG string to PNG bytes at the given size."""
    png_bytes = cairosvg.svg2png(
        bytestring=svg_str.encode("utf-8"),
        output_width=size,
        output_height=size,
    )
    return png_bytes


def write_icons():
    sizes = [192, 256, 384, 512]
    for s in sizes:
        svg = ICON_SVG_TEMPLATE.format(
            size=s,
            cream=CREAM_BG,
            brown_primary=BROWN_PRIMARY,
            brown_dark=BROWN_DARK,
            brown_light=BROWN_LIGHT,
            gold=GOLD_ACCENT,
        )
        out = ICONS_DIR / f"icon-{s}.png"
        out.write_bytes(render_svg_to_png(svg, s))
        print(f"  wrote {out} ({s}x{s})")

    # Favicon 32px (special tight design)
    fav_png = render_svg_to_png(FAVICON_SVG, 32)
    (ICONS_DIR / "favicon-32.png").write_bytes(fav_png)
    print(f"  wrote {ICONS_DIR}/favicon-32.png")

    # Apple touch icon (use 192 maskable padding)
    apple_svg = ICON_SVG_TEMPLATE.format(
        size=180,
        cream=CREAM_BG,
        brown_primary=BROWN_PRIMARY,
        brown_dark=BROWN_DARK,
        brown_light=BROWN_LIGHT,
        gold=GOLD_ACCENT,
    )
    (ICONS_DIR / "apple-touch-icon.png").write_bytes(render_svg_to_png(apple_svg, 180))
    print(f"  wrote {ICONS_DIR}/apple-touch-icon.png")

    # Maskable version — same as the main icon (full-bleed background already)
    maskable_svg = ICON_SVG_TEMPLATE.format(
        size=512,
        cream=CREAM_BG,
        brown_primary=BROWN_PRIMARY,
        brown_dark=BROWN_DARK,
        brown_light=BROWN_LIGHT,
        gold=GOLD_ACCENT,
    )
    (ICONS_DIR / "icon-maskable-512.png").write_bytes(render_svg_to_png(maskable_svg, 512))
    print(f"  wrote {ICONS_DIR}/icon-maskable-512.png")

    # Save the main full logo (square lockup, no text)
    (PUBLIC_DIR / "logo.svg").write_text(LOGO_SVG, encoding="utf-8")
    print(f"  wrote {PUBLIC_DIR}/logo.svg")

    # Save favicon.svg too (modern browsers)
    (PUBLIC_DIR / "favicon.svg").write_text(FAVICON_SVG, encoding="utf-8")
    print(f"  wrote {PUBLIC_DIR}/favicon.svg")

    # ICO (Windows) — small favicon.ico
    ico_sizes = [(16, 16), (32, 32), (48, 48)]
    imgs = []
    for sz in ico_sizes:
        png_at_48 = render_svg_to_png(FAVICON_SVG, 48)
        im = Image.open(io.BytesIO(png_at_48)).convert("RGBA").resize(sz, Image.LANCZOS)
        imgs.append(im)
    imgs[0].save(
        PUBLIC_DIR / "favicon.ico",
        format="ICO",
        sizes=ico_sizes,
        append_images=imgs[1:],
    )
    print(f"  wrote {PUBLIC_DIR}/favicon.ico")


if __name__ == "__main__":
    print("Generating KemetNet icons...")
    write_icons()
    print("Done.")
