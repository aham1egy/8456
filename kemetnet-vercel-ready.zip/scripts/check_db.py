#!/usr/bin/env python3
"""فحص شامل لقاعدة بيانات Supabase"""
import json
import urllib.request

SUPABASE_URL = "https://bhzrhvesrpyvrsshavow.supabase.co"
SUPABASE_ANON_KEY = "sb_publishable_AO6P04L0WlDaCK2Ot38YTQ_90FnOQc_"
REST_URL = f"{SUPABASE_URL}/rest/v1"

def get(path: str):
    url = f"{REST_URL}/{path}"
    req = urllib.request.Request(url, headers={
        "apikey": SUPABASE_ANON_KEY,
        "Authorization": f"Bearer {SUPABASE_ANON_KEY}",
    })
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            body = resp.read().decode()
            return {"ok": True, "status": resp.status, "data": json.loads(body) if body else None}
    except urllib.error.HTTPError as e:
        return {"ok": False, "status": e.code, "error": e.read().decode()}
    except Exception as e:
        return {"ok": False, "error": str(e)}

print("📊 فحص شامل للجداول والبيانات\n")

tables = ["profiles", "posts", "likes", "comments", "follows"]
for t in tables:
    res = get(f"{t}?select=*&limit=5")
    if res["ok"]:
        data = res["data"]
        count = len(data) if isinstance(data, list) else "?"
        print(f"✅ {t}: {count} صف (أول 5)")
        if data and isinstance(data, list):
            for i, row in enumerate(data[:2]):
                print(f"   [{i}] {json.dumps(row, ensure_ascii=False)[:200]}")
    else:
        print(f"❌ {t}: {res['status']} - {res.get('error', '')[:100]}")
    print()

# محاولة RPC: التحقق من الدوال
print("🔧 فحص دالة RPC...")
res = get("rpc/handle_new_user")
print(f"  status: {res['status'] if 'status' in res else 'n/a'}, error: {res.get('error', '')[:100]}")
