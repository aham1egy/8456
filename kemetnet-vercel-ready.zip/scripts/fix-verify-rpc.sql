-- ============================================================
-- KemetNet — Fix admin_verify_user ambiguous column
-- ============================================================
-- المشكلة: column reference "verified_type" is ambiguous
--   (يتعارض اسم parameter مع اسم عمود في table)
-- الحل: استخدام table.column في كل المراجع
-- ============================================================
-- يُشغّل في Supabase Dashboard → SQL Editor
-- ============================================================

CREATE OR REPLACE FUNCTION public.admin_verify_user(
  target_user_id uuid,
  p_verified_type text DEFAULT 'official'
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  current_user_id uuid := auth.uid();
BEGIN
  IF NOT public.is_admin() THEN
    RAISE EXCEPTION 'Unauthorized: admin access required';
  END IF;

  UPDATE public.profiles
  SET is_verified = true,
      verified_type = p_verified_type,
      verified_at = now()
  WHERE id = target_user_id;

  UPDATE public.verification_requests
  SET status = 'approved',
      reviewed_by = current_user_id,
      reviewed_at = now(),
      admin_note = COALESCE(admin_note, 'تمت الموافقة من قبل الإدارة')
  WHERE user_id = target_user_id
    AND status = 'pending';

  RETURN true;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_unverify_user(target_user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.is_admin() THEN
    RAISE EXCEPTION 'Unauthorized: admin access required';
  END IF;

  UPDATE public.profiles
  SET is_verified = false,
      verified_type = NULL,
      verified_at = NULL
  WHERE id = target_user_id;

  RETURN true;
END;
$$;

-- التحقق
SELECT '✅ admin_verify_user fixed' AS status;

-- توثيق المالكين مباشرة (بصلاحية postgres owner)
UPDATE public.profiles
SET is_verified = true,
    verified_type = 'official',
    verified_at = COALESCE(verified_at, now())
WHERE username IN ('kemetnet', 'kemetnet_admin')
  AND (is_verified = false OR is_verified IS NULL);

-- عرض المالكين
SELECT username, role, is_admin, is_verified, verified_type
FROM public.profiles
WHERE role = 'owner' OR username IN ('kemetnet', 'kemetnet_admin');
