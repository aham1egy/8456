#!/usr/bin/env python3
"""اكتشاف أعمدة الجداول الموجودة عبر محاولات إدراج"""
import json
import urllib.request
import urllib.error

SUPABASE_URL = "https://bhzrhvesrpyvrsshavow.supabase.co"
SUPABASE_ANON_KEY = "sb_publishable_AO6P04L0WlDaCK2Ot38YTQ_90FnOQc_"
REST_URL = f"{SUPABASE_URL}/rest/v1"

def try_insert(table: str, data: dict):
    url = f"{REST_URL}/{table}"
    body = json.dumps(data).encode()
    req = urllib.request.Request(url, data=body, method="POST", headers={
        "apikey": SUPABASE_ANON_KEY,
        "Authorization": f"Bearer {SUPABASE_ANON_KEY}",
        "Content-Type": "application/json",
        "Prefer": "return=representation",
    })
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            rbody = resp.read().decode()
            return {"status": resp.status, "data": json.loads(rbody) if rbody else None}
    except urllib.error.HTTPError as e:
        return {"status": e.code, "error": e.read().decode()}
    except Exception as e:
        return {"status": 0, "error": str(e)}


# محاولة إدراج صف فارغ في profiles لاكتشاف الأعمدة المطلوبة
print("🔍 محاولة إدراج صف فارغ في profiles...")
r = try_insert("profiles", {})
print(f"  النتيجة: {r}")
print()

# محاولة إدراج صف بحد أدنى من البيانات
print("🔍 محاولة إدراج صف بـ id و username...")
r = try_insert("profiles", {
    "id": "a0000000-0000-0000-0000-000000000099",
    "username": "test_probe_user",
})
print(f"  النتيجة: {r}")
if r.get("data"):
    print(f"  الأعمدة المتاحة: {list(r['data'][0].keys()) if isinstance(r['data'], list) else list(r['data'].keys())}")
print()

# نفس الشيء لـ posts
print("🔍 محاولة إدراج صف فارغ في posts...")
r = try_insert("posts", {})
print(f"  النتيجة: {r}")
print()

print("🔍 محاولة إدراج صف بـ user_id و content...")
r = try_insert("posts", {
    "user_id": "a0000000-0000-0000-0000-000000000099",
    "content": "اختبار",
})
print(f"  النتيجة: {r}")
if r.get("data"):
    print(f"  الأعمدة المتاحة: {list(r['data'][0].keys()) if isinstance(r['data'], list) else list(r['data'].keys())}")
