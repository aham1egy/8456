// src/hooks/use-haptic.ts
// اهتزازات haptic للتفاعل (Vibration API)

type HapticPattern =
  | 'light'      // نقرة خفيفة (10ms)
  | 'medium'     // نقرة متوسطة (20ms)
  | 'heavy'      // نقرة قوية (40ms)
  | 'success'    // نجاح (10-50-10)
  | 'warning'    // تحذير (30-50-30)
  | 'error'      // خطأ (50-100-50-100-50)
  | 'like'       // إعجاب (10-30-10)
  | 'select'     // اختيار (5ms)
  | 'tick'       // نقرة سريعة (1ms)

const PATTERNS: Record<HapticPattern, number | number[]> = {
  light: 10,
  medium: 20,
  heavy: 40,
  success: [10, 50, 10],
  warning: [30, 50, 30],
  error: [50, 100, 50, 100, 50],
  like: [10, 30, 10],
  select: 5,
  tick: 1,
}

/**
 * خطاف للاهتزازات haptic على الأجهزة المدعومة
 * آمن: لا يفعل شيئاً على الأجهزة غير المدعومة أو على iOS (الذي لا يدعم Vibration API)
 */
export function useHaptic() {
  const vibrate = (pattern: HapticPattern = 'light') => {
    if (typeof window === 'undefined') return
    if (typeof navigator.vibrate !== 'function') return

    try {
      navigator.vibrate(PATTERNS[pattern])
    } catch {
      // ignore errors
    }
  }

  return { vibrate }
}

/**
 * نسخة مبسطة: اهتزاز خفيف عند النقر
 */
export function useLightHaptic() {
  return () => {
    if (typeof window === 'undefined') return
    if (typeof navigator.vibrate !== 'function') return
    try {
      navigator.vibrate(8)
    } catch {
      // ignore
    }
  }
}
