'use client'

import { useCallback, useEffect, useRef } from 'react'
import { useAppStore } from '@/store/app-store'

// أصوات مولّدة برمجيًا عبر Web Audio API (بدون ملفات صوت)
type SoundType =
  | 'like'
  | 'unlike'
  | 'comment'
  | 'follow'
  | 'notification'
  | 'message'
  | 'success'
  | 'error'
  | 'send'

interface SoundConfig {
  frequency: number
  duration: number
  type: OscillatorType
  volume: number
  sweep?: { to: number; time: number } // تدرج التردد
  chord?: number[] // ترددات إضافية للأوتار
}

const SOUND_PRESETS: Record<SoundType, SoundConfig> = {
  like: {
    frequency: 880, // A5
    duration: 0.18,
    type: 'sine',
    volume: 0.3,
    sweep: { to: 1320, time: 0.12 }, // sweep up
  },
  unlike: {
    frequency: 660,
    duration: 0.12,
    type: 'sine',
    volume: 0.2,
    sweep: { to: 440, time: 0.08 },
  },
  comment: {
    frequency: 720,
    duration: 0.16,
    type: 'triangle',
    volume: 0.25,
    chord: [960, 1200],
  },
  follow: {
    frequency: 523, // C5
    duration: 0.22,
    type: 'sine',
    volume: 0.28,
    chord: [659, 784], // E5, G5
  },
  notification: {
    frequency: 1046, // C6
    duration: 0.28,
    type: 'sine',
    volume: 0.32,
    chord: [1318, 1568], // E6, G6
  },
  message: {
    frequency: 880,
    duration: 0.2,
    type: 'triangle',
    volume: 0.25,
    sweep: { to: 1100, time: 0.1 },
  },
  success: {
    frequency: 523,
    duration: 0.32,
    type: 'sine',
    volume: 0.3,
    chord: [659, 784, 1046], // major chord
  },
  error: {
    frequency: 220,
    duration: 0.3,
    type: 'sawtooth',
    volume: 0.2,
    sweep: { to: 180, time: 0.2 },
  },
  send: {
    frequency: 660,
    duration: 0.18,
    type: 'triangle',
    volume: 0.25,
    sweep: { to: 990, time: 0.1 },
  },
}

// AudioContext موحّد (singleton) — يمنع إنشاء عدة contexts
let globalAudioContext: AudioContext | null = null

function getGlobalAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null
  if (!globalAudioContext) {
    const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext
    if (!Ctx) return null
    globalAudioContext = new Ctx()
  }
  if (globalAudioContext.state === 'suspended') {
    void globalAudioContext.resume()
  }
  return globalAudioContext
}

export function useNotificationSound() {
  const soundEnabled = useAppStore((s) => s.soundEnabled)
  const volume = useAppStore((s) => s.notificationVolume)
  const notifPrefs = useAppStore((s) => s.notifPreferences)

  const playSound = useCallback(
    (type: SoundType) => {
      if (!soundEnabled) return
      // احترام تفضيلات الصوت والاهتزاز
      if (!notifPrefs.sound) return
      const ctx = getGlobalAudioContext()
      if (!ctx) return

      const config = SOUND_PRESETS[type]
      const targetVolume = (config.volume * volume) / 100

      // اهتزاز haptic متناسق مع الصوت (إن كان مدعوماً + مفعّلاً)
      if (notifPrefs.vibration && typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function') {
        const hapticPatterns: Partial<Record<SoundType, number | number[]>> = {
          like: [10, 30, 10],
          unlike: 20,
          comment: [15, 40, 15],
          follow: 30,
          notification: 25,
          message: 15,
          success: [10, 50, 10],
          error: [50, 100, 50],
          send: 12,
        }
        const pattern = hapticPatterns[type]
        if (pattern) {
          try {
            navigator.vibrate(pattern)
          } catch {
            // ignore
          }
        }
      }

      const now = ctx.currentTime
      const masterGain = ctx.createGain()
      masterGain.gain.setValueAtTime(0, now)
      masterGain.gain.linearRampToValueAtTime(targetVolume, now + 0.01)
      masterGain.gain.exponentialRampToValueAtTime(0.001, now + config.duration)
      masterGain.connect(ctx.destination)

      // الموجة الرئيسية
      const osc = ctx.createOscillator()
      osc.type = config.type
      osc.frequency.setValueAtTime(config.frequency, now)
      if (config.sweep) {
        osc.frequency.exponentialRampToValueAtTime(
          config.sweep.to,
          now + config.sweep.time
        )
      }
      osc.connect(masterGain)
      osc.start(now)
      osc.stop(now + config.duration + 0.05)

      // أوتار إضافية
      if (config.chord) {
        config.chord.forEach((freq, i) => {
          const chordGain = ctx.createGain()
          const chordVol = targetVolume * 0.5
          chordGain.gain.setValueAtTime(0, now + i * 0.04)
          chordGain.gain.linearRampToValueAtTime(chordVol, now + i * 0.04 + 0.01)
          chordGain.gain.exponentialRampToValueAtTime(0.001, now + config.duration)

          const chordOsc = ctx.createOscillator()
          chordOsc.type = config.type
          chordOsc.frequency.setValueAtTime(freq, now + i * 0.04)
          chordOsc.connect(chordGain)
          chordOsc.start(now + i * 0.04)
          chordOsc.stop(now + config.duration + 0.05)
        })
      }
    },
    [soundEnabled, volume, notifPrefs]
  )

  // إشعار مرئي
  const notify = useCallback(
    (options: {
      title: string
      body?: string
      sound?: SoundType
      icon?: string
    }) => {
      const { title, body, sound = 'notification' } = options
      // صوت
      playSound(sound)
      // إشعار المتصفح (إذا كان مسموحًا)
      if (typeof window !== 'undefined' && 'Notification' in window) {
        if (Notification.permission === 'granted') {
          try {
            new Notification(title, { body, silent: true })
          } catch {
            // تجاهل الأخطاء
          }
        }
      }
    },
    [playSound]
  )

  // طلب إذن الإشعارات
  const requestPermission = useCallback(async () => {
    if (typeof window === 'undefined' || !('Notification' in window)) return false
    if (Notification.permission === 'granted') return true
    const result = await Notification.requestPermission()
    return result === 'granted'
  }, [])

  // تهيئة السياق الصوتي عند أول تفاعل
  useEffect(() => {
    const unlock = () => {
      getGlobalAudioContext()
      window.removeEventListener('click', unlock)
      window.removeEventListener('touchstart', unlock)
    }
    window.addEventListener('click', unlock, { once: true })
    window.addEventListener('touchstart', unlock, { once: true })
    return () => {
      window.removeEventListener('click', unlock)
      window.removeEventListener('touchstart', unlock)
    }
  }, [])

  return { playSound, notify, requestPermission }
}
