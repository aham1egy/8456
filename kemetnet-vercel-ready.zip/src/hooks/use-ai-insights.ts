'use client'

import { useState, useEffect, useCallback } from 'react'
import { generateWeeklyInsights, generateQuickInsights, type WeeklyInsight } from '@/lib/ai/auto-insights'

interface UseAIInsightsResult {
  insights: WeeklyInsight[]
  loading: boolean
  error: string | null
  refresh: () => Promise<void>
}

/**
 * Hook لجلب رؤى الـ AI للمستخدم
 */
export function useAIInsights(userId: string | null | undefined, quick = false): UseAIInsightsResult {
  const [insights, setInsights] = useState<WeeklyInsight[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const refresh = useCallback(async () => {
    if (!userId) return
    setLoading(true)
    setError(null)
    try {
      const result = quick
        ? await generateQuickInsights(userId)
        : await generateWeeklyInsights(userId)
      setInsights(result)
    } catch (e: any) {
      setError(e.message || 'فشل تحميل الرؤى')
    } finally {
      setLoading(false)
    }
  }, [userId, quick])

  useEffect(() => {
    if (userId) void refresh()
  }, [refresh, userId])

  return { insights, loading, error, refresh }
}

// ============= Smart Feed Hook =============

import { buildUserProfile, rankPosts, applyDiversityBoost, type ScoredPost, type UserProfile } from '@/lib/ai/smart-feed'
import type { Post } from '@/lib/supabase/client'

interface UseSmartFeedResult {
  rankedPosts: ScoredPost[]
  profile: UserProfile | null
  loading: boolean
}

export function useSmartFeed(userId: string | null | undefined, posts: Post[]): UseSmartFeedResult {
  const [rankedPosts, setRankedPosts] = useState<ScoredPost[]>([])
  const [profile, setProfile] = useState<UserProfile | null>(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (!userId || posts.length === 0) {
      setRankedPosts(posts.map((p) => ({ post: p, score: 0, reasons: [], signals: {
        relevance: 0, recency: 0, engagement: 0, quality: 0, diversity: 0, authorship: 0,
      }})))
      return
    }

    void (async () => {
      setLoading(true)
      try {
        const userProfile = await buildUserProfile(userId)
        setProfile(userProfile)
        const scored = rankPosts(posts, userProfile)
        const diversified = applyDiversityBoost(scored, 3)
        setRankedPosts(diversified)
      } catch {
        // fallback: ترتيب بدون ذكاء
        setRankedPosts(posts.map((p) => ({ post: p, score: 0, reasons: [], signals: {
          relevance: 0, recency: 0, engagement: 0, quality: 0, diversity: 0, authorship: 0,
        }})))
      } finally {
        setLoading(false)
      }
    })()
  }, [userId, posts])

  return { rankedPosts, profile, loading }
}

// ============= Trends Hook =============

import { detectTrends, type TrendingTopic } from '@/lib/ai/smart-feed'

interface UseTrendsResult {
  trends: TrendingTopic[]
  loading: boolean
  refresh: () => Promise<void>
}

export function useTrends(): UseTrendsResult {
  const [trends, setTrends] = useState<TrendingTopic[]>([])
  const [loading, setLoading] = useState(false)

  const refresh = useCallback(async () => {
    setLoading(true)
    try {
      const t = await detectTrends()
      setTrends(t)
    } catch {
      setTrends([])
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    void refresh()
    // تحديث كل 5 دقائق
    const interval = setInterval(refresh, 5 * 60 * 1000)
    return () => clearInterval(interval)
  }, [refresh])

  return { trends, loading, refresh }
}
