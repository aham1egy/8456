// src/hooks/use-screenshot-detection.ts
// اكتشاف محاولات لقطة الشاشة للرسائل الخاصة

import { useEffect, useRef, useState, useCallback } from 'react'

interface ScreenshotDetectionOptions {
  enabled: boolean
  onScreenshot?: () => void
}

/**
 * hook لاكتشاف محاولات لقطة الشاشة
 * ملاحظة: لا يمكن منع لقطة الشاشة فعلياً في الويب، لكن يمكن اكتشافها
 * - بعض المتصفحات تطلق حدث 'copy' عند لقطة الشاشة
 * - يمكن اكتشاف الضغط على PrintScreen
 * - يمكن إخفاء المحتوى عند فقدان التركيز أو تغيير التبويب
 */
export function useScreenshotDetection({
  enabled,
  onScreenshot,
}: ScreenshotDetectionOptions) {
  const [isHidden, setIsHidden] = useState(false)
  const onScreenshotRef = useRef(onScreenshot)

  useEffect(() => {
    onScreenshotRef.current = onScreenshot
  }, [onScreenshot])

  // كشف PrintScreen
  useEffect(() => {
    if (!enabled) return

    const handleKeyDown = (e: KeyboardEvent) => {
      // PrintScreen key
      if (e.key === 'PrintScreen') {
        try {
          navigator.clipboard?.writeText('تم تسجيل محاولة لقطة شاشة')
        } catch {
          // ignore
        }
        onScreenshotRef.current?.()
      }
      // Ctrl/Cmd + PrintScreen (Windows Snipping Tool)
      if ((e.ctrlKey || e.metaKey) && e.key === 'PrintScreen') {
        onScreenshotRef.current?.()
      }
      // Ctrl/Cmd + Shift + S (بعض المتصفحات)
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'S') {
        onScreenshotRef.current?.()
      }
    }

    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [enabled])

  // إخفاء المحتوى عند فقدان التركيز أو تغيير التبويب
  useEffect(() => {
    if (!enabled) return

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden') {
        setIsHidden(true)
        onScreenshotRef.current?.()
      } else {
        setIsHidden(false)
      }
    }

    const handleBlur = () => {
      setIsHidden(true)
    }

    const handleFocus = () => {
      setIsHidden(false)
    }

    document.addEventListener('visibilitychange', handleVisibilityChange)
    window.addEventListener('blur', handleBlur)
    window.addEventListener('focus', handleFocus)

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange)
      window.removeEventListener('blur', handleBlur)
      window.removeEventListener('focus', handleFocus)
    }
  }, [enabled])

  // كشف copy (بعض المتصفحات تطلقه عند لقطة الشاشة)
  useEffect(() => {
    if (!enabled) return

    const handleCopy = (e: ClipboardEvent) => {
      // إذا كان الـ copy من غير تحديد نص (قد يكون لقطة شاشة)
      const selection = window.getSelection()
      if (!selection || selection.toString().length === 0) {
        onScreenshotRef.current?.()
      }
    }

    document.addEventListener('copy', handleCopy)
    return () => document.removeEventListener('copy', handleCopy)
  }, [enabled])

  // إعادة المحتوى للظهور
  const showContent = useCallback(() => {
    setIsHidden(false)
  }, [])

  return {
    isHidden,
    showContent,
  }
}

/**
 * CSS لإخفاء المحتوى عند لقطة الشاشة
 * يستخدم مع className="screenshot-protected"
 */
export const SCREENSHOT_PROTECTION_CSS = `
.screenshot-protected {
  position: relative;
}
.screenshot-protected::before {
  content: '';
  position: absolute;
  inset: 0;
  background: #000;
  opacity: 0;
  transition: opacity 0.1s;
  z-index: 9999;
  pointer-events: none;
}
.screenshot-hidden.screenshot-protected::before {
  opacity: 1;
}
`
