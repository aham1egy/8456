// src/hooks/use-swipe-back.ts
// دعم السحب من الجانب للرجوع (swipe back) مثل iOS

import { useEffect, useRef } from 'react'
import { useRouter, usePathname } from 'next/navigation'

const SWIPE_THRESHOLD = 80 // الحد الأدنى للسحب
const EDGE_WIDTH = 30 // عرض منطقة الحافة التي تبدأ منها الإيماءة

export function useSwipeBack() {
  const router = useRouter()
  const pathname = usePathname()
  const startX = useRef(0)
  const startY = useRef(0)
  const isTracking = useRef(false)
  const isHorizontal = useRef(false)

  useEffect(() => {
    // لا تفعّل السحب في الصفحات الرئيسية (التي لا تحتاج رجوع)
    const rootPages = ['/home', '/explore', '/notifications', '/messages', '/profile', '/create']
    const isRootPage = rootPages.some((p) => pathname === p || pathname === p + '/')
    
    if (isRootPage) return

    const handleTouchStart = (e: TouchEvent) => {
      const touch = e.touches[0]
      // فقط إذا بدأ اللمس من الحافة اليمنى (لأن RTL)
      if (touch.clientX > window.innerWidth - EDGE_WIDTH) {
        startX.current = touch.clientX
        startY.current = touch.clientY
        isTracking.current = true
        isHorizontal.current = false
      }
    }

    const handleTouchMove = (e: TouchEvent) => {
      if (!isTracking.current) return
      const touch = e.touches[0]
      const diffX = touch.clientX - startX.current
      const diffY = touch.clientY - startY.current

      // تحديد ما إذا كان السحب أفقيًا أم رأسيًا (بعد أول 10px)
      if (Math.abs(diffX) > 10 || Math.abs(diffY) > 10) {
        if (Math.abs(diffX) > Math.abs(diffY)) {
          isHorizontal.current = true
        }
      }

      // منع التمرير الرأسي إذا كان السحب أفقيًا
      if (isHorizontal.current && diffX < 0) {
        e.preventDefault()
      }
    }

    const handleTouchEnd = (e: TouchEvent) => {
      if (!isTracking.current) return
      const touch = e.changedTouches[0]
      const diffX = touch.clientX - startX.current

      // إذا كان السحب أفقيًا للأسفل (في RTL يعني لليسار = رجوع) وتجاوز الحد
      if (isHorizontal.current && diffX < -SWIPE_THRESHOLD) {
        router.back()
      }

      isTracking.current = false
      isHorizontal.current = false
    }

    // passive: false لتمكين preventDefault
    document.addEventListener('touchstart', handleTouchStart, { passive: true })
    document.addEventListener('touchmove', handleTouchMove, { passive: false })
    document.addEventListener('touchend', handleTouchEnd, { passive: true })

    return () => {
      document.removeEventListener('touchstart', handleTouchStart)
      document.removeEventListener('touchmove', handleTouchMove)
      document.removeEventListener('touchend', handleTouchEnd)
    }
  }, [router, pathname])
}
