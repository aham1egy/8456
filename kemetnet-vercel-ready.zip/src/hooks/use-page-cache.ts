// src/hooks/use-page-cache.ts
// حفظ + استعادة موضع التمرير + مزامنة خلفية

import { useEffect, useRef, useCallback } from 'react'
import { useAppStore } from '@/store/app-store'

/**
 * حفظ موضع التمرير عند مغادرة الصفحة + استعادته عند العودة
 * + مزامنة خلفية بدون إظهار loading
 */
export function usePageCache(
  pageKey: string,
  options?: {
    onBackgroundSync?: () => Promise<void>
    backgroundSyncInterval?: number // milliseconds (0 = معطل)
  }
) {
  const setPageScroll = useAppStore((s) => s.setPageScroll)
  const getPageScroll = useAppStore((s) => s.getPageScroll)
  const scrollAreaRef = useRef<HTMLElement | null>(null)
  const syncTimerRef = useRef<ReturnType<typeof setInterval> | null>(null)

  // العثور على scroll area
  useEffect(() => {
    const findScrollArea = () => {
      const area = document.querySelector('[data-scroll-area]') as HTMLElement | null
      scrollAreaRef.current = area
      return area
    }

    const area = findScrollArea()
    if (!area) {
      // إعادة المحاولة بعد تأخير قصير
      const timer = setTimeout(() => {
        const retryArea = findScrollArea()
        if (retryArea) {
          const savedY = getPageScroll(pageKey)
          if (savedY > 0) {
            retryArea.scrollTop = savedY
          }
        }
      }, 100)
      return () => clearTimeout(timer)
    }

    // استعادة موضع التمرير
    const savedY = getPageScroll(pageKey)
    if (savedY > 0) {
      // تأخير قصير للسماح للـ DOM بالرسم
      requestAnimationFrame(() => {
        area.scrollTop = savedY
      })
    }

    // حفظ موضع التمرير عند التمرير (throttled)
    let saveTimer: ReturnType<typeof setTimeout> | null = null
    const handleScroll = () => {
      if (saveTimer) clearTimeout(saveTimer)
      saveTimer = setTimeout(() => {
        if (scrollAreaRef.current) {
          setPageScroll(pageKey, scrollAreaRef.current.scrollTop)
        }
      }, 200)
    }

    area.addEventListener('scroll', handleScroll, { passive: true })

    // أيضاً حفظ عند مغادرة الصفحة
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden' && scrollAreaRef.current) {
        setPageScroll(pageKey, scrollAreaRef.current.scrollTop)
      }
    }
    document.addEventListener('visibilitychange', handleVisibilityChange)

    return () => {
      // حفظ نهائي عند الإزالة
      if (scrollAreaRef.current) {
        setPageScroll(pageKey, scrollAreaRef.current.scrollTop)
      }
      area.removeEventListener('scroll', handleScroll)
      document.removeEventListener('visibilitychange', handleVisibilityChange)
      if (saveTimer) clearTimeout(saveTimer)
    }
  }, [pageKey, setPageScroll, getPageScroll])

  // مزامنة خلفية دورية
  useEffect(() => {
    if (!options?.onBackgroundSync || !options?.backgroundSyncInterval) return

    // مزامنة أولى بعد 2 ثانية (في الخلفية)
    const initialTimer = setTimeout(() => {
      void options.onBackgroundSync?.()
    }, 2000)

    // مزامنة دورية
    if (options.backgroundSyncInterval > 0) {
      syncTimerRef.current = setInterval(() => {
        void options.onBackgroundSync?.()
      }, options.backgroundSyncInterval)
    }

    return () => {
      clearTimeout(initialTimer)
      if (syncTimerRef.current) {
        clearInterval(syncTimerRef.current)
        syncTimerRef.current = null
      }
    }
  }, [options?.onBackgroundSync, options?.backgroundSyncInterval])

  // تحديث عند العودة للصفحة (focus)
  const refreshOnFocus = useCallback(async () => {
    if (options?.onBackgroundSync) {
      await options.onBackgroundSync()
    }
  }, [options?.onBackgroundSync])

  useEffect(() => {
    // تحديث عند العودة للتبويب
    const handleVisibility = () => {
      if (document.visibilityState === 'visible') {
        void refreshOnFocus()
      }
    }
    document.addEventListener('visibilitychange', handleVisibility)
    return () => document.removeEventListener('visibilitychange', handleVisibility)
  }, [refreshOnFocus])

  return { scrollAreaRef }
}
