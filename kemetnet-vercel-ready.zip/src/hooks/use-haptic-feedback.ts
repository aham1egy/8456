// src/hooks/use-haptic-feedback.ts
// اهتزاز فوري على كل تفاعل — تجربة كتطبيق أصلي

type HapticType = 'light' | 'medium' | 'heavy' | 'success' | 'warning' | 'error' | 'select'

const PATTERNS: Record<HapticType, number | number[]> = {
  light: 8,
  medium: 15,
  heavy: 30,
  success: [10, 30, 10],
  warning: [20, 40, 20],
  error: [30, 60, 30, 60, 30],
  select: 5,
}

// cache: هل الجهاز يدعم الاهتزاز؟
let vibrationSupported: boolean | null = null

function isSupported(): boolean {
  if (vibrationSupported !== null) return vibrationSupported
  if (typeof navigator === 'undefined') {
    vibrationSupported = false
  } else {
    vibrationSupported = typeof navigator.vibrate === 'function'
  }
  return vibrationSupported
}

/**
 * اهتزاز فوري — يُستدعى مباشرة (ليس hook)
 * آمن: لا يفعل شيئاً على الأجهزة غير المدعومة
 */
export function haptic(type: HapticType = 'light'): void {
  if (!isSupported()) return
  try {
    navigator.vibrate(PATTERNS[type])
  } catch {
    // ignore
  }
}

/**
 * hook لإستخدام haptic مع useCallback
 */
export function useHapticFeedback() {
  return {
    light: () => haptic('light'),
    medium: () => haptic('medium'),
    heavy: () => haptic('heavy'),
    success: () => haptic('success'),
    warning: () => haptic('warning'),
    error: () => haptic('error'),
    select: () => haptic('select'),
  }
}
