// src/hooks/use-pwa-install.ts
// كشف وإدارة تثبيت PWA

import { useState, useEffect, useCallback } from 'react'

interface BeforeInstallPromptEvent extends Event {
  readonly platforms: string[]
  readonly userChoice: Promise<{
    outcome: 'accepted' | 'dismissed'
    platform: string
  }>
  prompt(): Promise<void>
}

const DISMISS_KEY = 'mishri-pwa-install-dismissed'
const DISMISS_TTL = 7 * 24 * 60 * 60 * 1000 // 7 أيام

export function usePwaInstall() {
  const [installPromptEvent, setInstallPromptEvent] = useState<BeforeInstallPromptEvent | null>(null)
  const [isInstalled, setIsInstalled] = useState(false)
  const [isDismissed, setIsDismissed] = useState(false)

  // التحقق من حالة التثبيت الحالية
  useEffect(() => {
    if (typeof window === 'undefined') return

    // iOS لا يدعم beforeinstallprompt، لكن يمكن كشف standalone mode
    const isStandalone =
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as unknown as { standalone?: boolean }).standalone === true

    setIsInstalled(isStandalone)

    // التحقق من حالة الرفض
    try {
      const dismissedAt = Number(localStorage.getItem(DISMISS_KEY) || 0)
      if (dismissedAt && Date.now() - dismissedAt < DISMISS_TTL) {
        setIsDismissed(true)
      }
    } catch {
      // localStorage قد لا يكون متاحاً
    }
  }, [])

  // الاستماع لحدث beforeinstallprompt
  useEffect(() => {
    if (typeof window === 'undefined') return

    const handler = (e: Event) => {
      e.preventDefault()
      setInstallPromptEvent(e as BeforeInstallPromptEvent)
    }

    const installedHandler = () => {
      setIsInstalled(true)
      setInstallPromptEvent(null)
    }

    window.addEventListener('beforeinstallprompt', handler)
    window.addEventListener('appinstalled', installedHandler)

    return () => {
      window.removeEventListener('beforeinstallprompt', handler)
      window.removeEventListener('appinstalled', installedHandler)
    }
  }, [])

  const promptInstall = useCallback(async (): Promise<boolean> => {
    if (!installPromptEvent) return false

    try {
      await installPromptEvent.prompt()
      const choice = await installPromptEvent.userChoice
      if (choice.outcome === 'accepted') {
        setIsInstalled(true)
        setInstallPromptEvent(null)
        return true
      }
      return false
    } catch (e) {
      // [removed in production] '[usePwaInstall] prompt error:', e
      return false
    }
  }, [installPromptEvent])

  const dismiss = useCallback(() => {
    try {
      localStorage.setItem(DISMISS_KEY, Date.now().toString())
    } catch {
      // ignore
    }
    setIsDismissed(true)
    setInstallPromptEvent(null)
  }, [])

  // هل يجب عرض موجه التثبيت؟
  const shouldShowPrompt = !!installPromptEvent && !isInstalled && !isDismissed

  return {
    canInstall: !!installPromptEvent,
    isInstalled,
    isDismissed,
    shouldShowPrompt,
    promptInstall,
    dismiss,
  }
}
