'use client'

import { useEffect, useRef, useState } from 'react'

interface ScrollDirection {
  direction: 'up' | 'down' | 'idle'
  isVisible: boolean
  scrollTop: number
}

interface UseScrollDirectionOptions {
  threshold?: number // المسافة التي يجب تجاوزها قبل بدء الإخفاء
  showOnUpScroll?: boolean // إظهار عند التمرير للأعلى
  selector?: string // CSS selector للحاوية القابلة للتمرير (افتراضيًا window)
}

export function useScrollDirection({
  threshold = 80,
  showOnUpScroll = true,
  selector,
}: UseScrollDirectionOptions = {}): ScrollDirection {
  const [direction, setDirection] = useState<'up' | 'down' | 'idle'>('idle')
  const [isVisible, setIsVisible] = useState(true)
  const [scrollTop, setScrollTop] = useState(0)
  const lastScrollY = useRef(0)
  const ticking = useRef(false)

  // نربط المستمع على window ونستخدم event.target للحصول على عنصر التمرير
  // هذا يعمل سواء كان التمرير على window أو داخل عنصر داخلي
  useEffect(() => {
    const updateScrollDirection = (scrollY: number) => {
      setScrollTop(scrollY)

      // في أعلى الصفحة، أظهر دائمًا
      if (scrollY < 20) {
        setIsVisible(true)
        setDirection('idle')
        lastScrollY.current = scrollY
        ticking.current = false
        return
      }

      const diff = scrollY - lastScrollY.current
      // تحت threshold، لا تغيّر
      if (Math.abs(diff) < 10) {
        ticking.current = false
        return
      }

      // سكرول للأسفل
      if (diff > 0 && scrollY > threshold) {
        setDirection('down')
        if (showOnUpScroll) setIsVisible(false)
      }
      // سكرول للأعلى
      else if (diff < 0) {
        setDirection('up')
        if (showOnUpScroll) setIsVisible(true)
      }

      lastScrollY.current = scrollY
      ticking.current = false
    }

    const onScroll = () => {
      if (!ticking.current) {
        window.requestAnimationFrame(() => {
          // إذا كان هناك selector، اقرأ منه، وإلا اقرأ من window
          const target = selector ? document.querySelector(selector) as HTMLElement | null : null
          const scrollY = target ? target.scrollTop : window.scrollY
          updateScrollDirection(scrollY)
        })
        ticking.current = true
      }
    }

    // اربط على window مع capture: true ليلتقط أحداث التمرير من أي عنصر داخلي
    window.addEventListener('scroll', onScroll, { passive: true, capture: true })
    return () => window.removeEventListener('scroll', onScroll, { capture: true } as EventListenerOptions)
  }, [threshold, showOnUpScroll, selector])

  return { direction, isVisible, scrollTop }
}

// hook لـ pull-to-refresh (محسّن: لا يُعيد الربط عند كل تغيير pullDistance)
interface PullToRefreshState {
  pulling: boolean
  pullDistance: number
  refreshing: boolean
}

export function usePullToRefresh(onRefresh: () => Promise<void>, threshold = 80) {
  const [state, setState] = useState<PullToRefreshState>({
    pulling: false,
    pullDistance: 0,
    refreshing: false,
  })
  const startY = useRef(0)
  const pulling = useRef(false)
  const pullDistanceRef = useRef(0)
  const onRefreshRef = useRef(onRefresh)

  // تحديث الـ ref بدلاً من إعادة الربط
  useEffect(() => {
    onRefreshRef.current = onRefresh
  }, [onRefresh])

  useEffect(() => {
    const onTouchStart = (e: TouchEvent) => {
      if (window.scrollY <= 0) {
        startY.current = e.touches[0].clientY
        pulling.current = true
      } else {
        pulling.current = false
      }
    }

    const onTouchMove = (e: TouchEvent) => {
      if (!pulling.current) return
      const currentY = e.touches[0].clientY
      const diff = currentY - startY.current
      if (diff > 0 && diff < 150) {
        // مقاومة مطاطية (rubber band effect)
        const dampened = diff * 0.4
        pullDistanceRef.current = dampened
        setState((s) => ({ ...s, pulling: true, pullDistance: dampened }))
      }
    }

    const onTouchEnd = async () => {
      if (!pulling.current) {
        return
      }
      pulling.current = false
      const shouldRefresh = pullDistanceRef.current >= threshold

      if (shouldRefresh) {
        setState((s) => ({ ...s, pulling: false, refreshing: true, pullDistance: 0 }))
        try {
          await onRefreshRef.current()
        } finally {
          setState({ pulling: false, pullDistance: 0, refreshing: false })
          pullDistanceRef.current = 0
        }
      } else {
        setState({ pulling: false, pullDistance: 0, refreshing: false })
        pullDistanceRef.current = 0
      }
    }

    window.addEventListener('touchstart', onTouchStart, { passive: true })
    window.addEventListener('touchmove', onTouchMove, { passive: true })
    window.addEventListener('touchend', onTouchEnd, { passive: true })
    return () => {
      window.removeEventListener('touchstart', onTouchStart)
      window.removeEventListener('touchmove', onTouchMove)
      window.removeEventListener('touchend', onTouchEnd)
    }
  }, [threshold])

  return state
}

// hook لاكتشاف إذا كان المستخدم في الأسفل (للتحديث التلقائي اللانهائي)
export function useInfiniteScroll(callback: () => void, options: { threshold?: number } = {}) {
  const { threshold = 200 } = options
  const targetRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          callback()
        }
      },
      { rootMargin: `${threshold}px` }
    )

    if (targetRef.current) {
      observer.observe(targetRef.current)
    }

    return () => observer.disconnect()
  }, [callback, threshold])

  return targetRef
}
