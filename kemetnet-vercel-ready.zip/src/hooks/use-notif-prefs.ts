// src/hooks/use-notif-prefs.ts
// hook للتحقق من إعدادات الإشعارات قبل عرض/تشغيل أي إشعار

import { useAppStore, type NotificationPreferences } from '@/store/app-store'

export type NotifType =
  | 'like'
  | 'comment'
  | 'mention'
  | 'follow'
  | 'message'
  | 'repost'
  | 'system'

// خريطة: نوع الإشعار -> حقل الـ preference المناسب
const TYPE_TO_PREF: Record<NotifType, keyof NotificationPreferences | null> = {
  like: 'likes',
  comment: 'comments',
  mention: 'mentions',
  follow: 'follows',
  message: 'messages',
  repost: 'reposts',
  system: null, // الإشعارات العامة دائماً تظهر
}

export function useNotifPrefs() {
  const prefs = useAppStore((s) => s.notifPreferences)
  const soundEnabled = useAppStore((s) => s.soundEnabled)
  const volume = useAppStore((s) => s.notificationVolume)

  /**
   * هل يجب عرض إشعار من هذا النوع؟
   */
  const shouldShowNotification = (type: NotifType): boolean => {
    const prefKey = TYPE_TO_PREF[type]
    if (!prefKey) return true // system دائماً
    return prefs[prefKey]
  }

  /**
   * هل يجب تشغيل صوت للإشعار؟
   */
  const shouldPlaySound = (type: NotifType): boolean => {
    if (!soundEnabled) return false
    if (!prefs.sound) return false
    return shouldShowNotification(type)
  }

  /**
   * هل يجب اهتزاز الجهاز؟
   */
  const shouldVibrate = (type: NotifType): boolean => {
    if (!prefs.vibration) return false
    return shouldShowNotification(type)
  }

  /**
   * هل إشعار من نوع معين مفعّل؟
   */
  const isTypeEnabled = (type: keyof NotificationPreferences): boolean => {
    return prefs[type]
  }

  return {
    prefs,
    shouldShowNotification,
    shouldPlaySound,
    shouldVibrate,
    isTypeEnabled,
    volume,
  }
}
