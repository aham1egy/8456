// src/hooks/use-realtime.ts
// البث المباشر للإشعارات والمنشورات - مشروع KemetNet

import { useEffect, useRef, useCallback } from 'react'
import { supabase } from '@/lib/supabase/client'
import { useAppStore } from '@/store/app-store'
import { useNotificationSound } from '@/hooks/use-sound'
import { toast } from 'sonner'
import type { Post } from '@/lib/supabase/client'

export interface RealtimeNotification {
  id: string
  user_id: string
  actor_id: string | null
  type: 'like' | 'comment' | 'follow' | 'mention' | 'system'
  title: string
  body: string | null
  post_id: string | null
  read: boolean
  created_at: string
}

// =====================================================
// hook للبث المباشر للإشعارات
// يستمع لتغييرات جدول notifications ويظهر إشعار فوري
// يجب استدعاؤه مرة واحدة فقط في التطبيق (ProtectedLayout)
// =====================================================
let isNotificationsChannelActive = false // منع الاشتراك المزدوج

export function useRealtimeNotifications() {
  const user = useAppStore((s) => s.user)
  const setUnread = useAppStore((s) => s.setUnreadNotifications)
  const userId = user?.id
  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null)
  const { notify } = useNotificationSound()
  const notifyRef = useRef(notify)

  // تحديث المرجع
  useEffect(() => {
    notifyRef.current = notify
  }, [notify])

  const refreshUnreadCount = useCallback(async (uid: string) => {
    if (!uid) return
    try {
      const { count, error } = await supabase
        .from('notifications')
        .select('id', { count: 'exact', head: true })
        .eq('user_id', uid)
        .eq('read', false)

      if (!error && count !== null) {
        setUnread(count)
      }
    } catch (e) {
      // [removed in production] 'Refresh unread count error:', e
    }
  }, [setUnread])

  useEffect(() => {
    if (!userId || isNotificationsChannelActive) return

    isNotificationsChannelActive = true
    let cancelled = false

    const channel = supabase
      .channel(`notifications-realtime-${userId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'notifications',
          filter: `user_id=eq.${userId}`,
        },
        (payload) => {
          if (cancelled) return
          const newNotif = payload.new as RealtimeNotification
          void refreshUnreadCount(userId)

          const soundMap: Record<string, 'like' | 'comment' | 'follow' | 'notification'> = {
            like: 'like',
            comment: 'comment',
            follow: 'follow',
            mention: 'notification',
            system: 'notification',
          }

          try {
            notifyRef.current({
              title: newNotif.title,
              body: newNotif.body || undefined,
              sound: soundMap[newNotif.type] || 'notification',
            })
            toast(newNotif.title, {
              description: newNotif.body || undefined,
              duration: 5000,
            })
          } catch (e) {
            // [removed in production] 'Notification display error:', e
          }
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'notifications',
          filter: `user_id=eq.${userId}`,
        },
        () => {
          if (cancelled) return
          void refreshUnreadCount(userId)
        }
      )
      .subscribe()

    channelRef.current = channel
    void refreshUnreadCount(userId)

    return () => {
      cancelled = true
      isNotificationsChannelActive = false
      if (channelRef.current) {
        try {
          void supabase.removeChannel(channelRef.current)
        } catch (e) {
          // [removed in production] 'Channel cleanup error:', e
        }
        channelRef.current = null
      }
    }
  }, [userId, refreshUnreadCount])

  return { refreshUnreadCount }
}

// =====================================================
// hook للبث المباشر لتحديث الإعجابات والتعليقات على المنشورات
// فقط UPDATE و DELETE (لا INSERT عام لتجنب الإزعاج)
// =====================================================
interface RealtimePostUpdate {
  likes_count?: number
  comments_count?: number
  content?: string
  _deleted?: boolean
}

export function useRealtimePosts(onUpdate?: (postId: string, changes: RealtimePostUpdate) => void) {
  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null)
  const onUpdateRef = useRef(onUpdate)

  useEffect(() => {
    onUpdateRef.current = onUpdate
  }, [onUpdate])

  useEffect(() => {
    const channel = supabase
      .channel('posts-realtime-updates')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'posts',
        },
        (payload) => {
          const updated = payload.new as Post
          onUpdateRef.current?.(updated.id, {
            likes_count: updated.likes_count,
            comments_count: updated.comments_count,
            content: updated.content,
          })
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'DELETE',
          schema: 'public',
          table: 'posts',
        },
        (payload) => {
          const deleted = payload.old as { id: string }
          onUpdateRef.current?.(deleted.id, { _deleted: true })
        }
      )
      .subscribe()

    channelRef.current = channel

    return () => {
      if (channelRef.current) {
        void supabase.removeChannel(channelRef.current)
        channelRef.current = null
      }
    }
  }, [])
}
