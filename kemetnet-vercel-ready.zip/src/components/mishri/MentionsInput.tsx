'use client'

import { useState, useRef, useEffect, useCallback } from 'react'
import { searchUsersForMention, detectActiveMention, insertMention, type ActiveMention, type MentionSuggestion } from '@/lib/mentions'
import { useAppStore } from '@/store/app-store'

interface MentionsInputProps {
 value: string
 onChange: (value: string) => void
 onSend?: () => void
 placeholder?: string
 maxLength?: number
 disabled?: boolean
 /** عدد الاقتراحات الأقصى */
 maxSuggestions?: number
 className?: string
 multiline?: boolean
 rows?: number
 autoFocus?: boolean
 id?: string
}

export function MentionsInput({
 value,
 onChange,
 onSend,
 placeholder = 'اكتب...',
 maxLength = 2000,
 disabled = false,
 maxSuggestions = 5,
 className = '',
 multiline = false,
 rows = 1,
 autoFocus = false,
 id,
}: MentionsInputProps) {
 const user = useAppStore((s) => s.user)
 const inputRef = useRef<HTMLInputElement | HTMLTextAreaElement>(null)
 const [suggestions, setSuggestions] = useState<MentionSuggestion[]>([])
 const [activeMention, setActiveMention] = useState<ActiveMention | null>(null)
 const [selectedIndex, setSelectedIndex] = useState(0)
 const [showSuggestions, setShowSuggestions] = useState(false)

 // البحث عن المستخدمين عند تغير الاستعلام
 useEffect(() => {
 if (!activeMention || activeMention.query.length === 0) {
 setSuggestions([])
 setShowSuggestions(false)
 return
 }

 let cancelled = false
 const timer = setTimeout(async () => {
 const results = await searchUsersForMention(
 activeMention.query,
 user?.id,
 maxSuggestions
 )
 if (!cancelled) {
 setSuggestions(results)
 setShowSuggestions(results.length > 0)
 setSelectedIndex(0)
 }
 }, 200) // debounce 200ms

 return () => {
 cancelled = true
 clearTimeout(timer)
 }
 }, [activeMention, user?.id, maxSuggestions])

 // معالجة تغيير النص واكتشاف الإشارات
 const handleChange = useCallback(
 (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
 const newValue = e.target.value
 const cursorPos = e.target.selectionStart || newValue.length

 onChange(newValue)

 // اكتشاف mention نشط
 const mention = detectActiveMention(newValue, cursorPos)
 setActiveMention(mention)

 if (!mention) {
 setShowSuggestions(false)
 }
 },
 [onChange]
 )

 // اختيار اقتراح
 const handleSelectSuggestion = (suggestion: MentionSuggestion) => {
 if (!activeMention) return

 const { newText, newCursorPos } = insertMention(
 value,
 activeMention,
 suggestion.username
 )

 onChange(newText)
 setShowSuggestions(false)
 setActiveMention(null)
 setSuggestions([])

 // إعادة التركيز ووضع المؤشر في الموضع الصحيح
 setTimeout(() => {
 if (inputRef.current) {
 inputRef.current.focus()
 if (inputRef.current.setSelectionRange) {
 inputRef.current.setSelectionRange(newCursorPos, newCursorPos)
 }
 }
 }, 0)
 }

 // التنقل بين الاقتراحات بالكيبورد
 const handleKeyDown = (e: React.KeyboardEvent) => {
 if (showSuggestions && suggestions.length > 0) {
 if (e.key === 'ArrowDown') {
 e.preventDefault()
 setSelectedIndex((i) => (i + 1) % suggestions.length)
 return
 }
 if (e.key === 'ArrowUp') {
 e.preventDefault()
 setSelectedIndex((i) => (i - 1 + suggestions.length) % suggestions.length)
 return
 }
 if (e.key === 'Enter' || e.key === 'Tab') {
 e.preventDefault()
 handleSelectSuggestion(suggestions[selectedIndex])
 return
 }
 if (e.key === 'Escape') {
 e.preventDefault()
 setShowSuggestions(false)
 return
 }
 }

 // Enter للإرسال (في وضع سطر واحد أو بدون shift)
 if (onSend && e.key === 'Enter' && !e.shiftKey && !multiline) {
 e.preventDefault()
 onSend()
 }
 }

 // إغلاق الاقتراحات عند النقر خارجها
 const handleBlur = () => {
 // تأخير قصير للسماح بالنقر على الاقتراح
 setTimeout(() => setShowSuggestions(false), 150)
 }

 const handleFocus = () => {
 if (activeMention && suggestions.length > 0) {
 setShowSuggestions(true)
 }
 }

 const commonProps = {
 ref: inputRef as never,
 value,
 onChange: handleChange,
 onKeyDown: handleKeyDown,
 onBlur: handleBlur,
 onFocus: handleFocus,
 placeholder,
 maxLength,
 disabled,
 autoFocus,
 id,
 className: `mishri-input w-full rounded-xl py-2.5 px-3 text-sm font-medium outline-none resize-none ${className}`,
 dir: 'auto' as const,
 }

 return (
 <div className="relative">
 {multiline ? (
 <textarea {...commonProps} rows={rows} />
 ) : (
 <input type="text" {...commonProps} />
 )}

 {/* قائمة الاقتراحات */}
 {showSuggestions && suggestions.length > 0 && (
 <div
 className="absolute bottom-full mb-2 left-0 right-0 z-50 rounded-2xl bg-foreground/5 shadow-2xl overflow-hidden max-h-64 overflow-y-auto transition-colors duration-200"
 >
 <div className="px-3 py-2 text-[10px] font-bold text-muted-foreground border-b border-foreground/5">
 المستخدمون
 </div>
 {suggestions.map((s, i) => (
 <button
 key={s.id}
 onClick={() => handleSelectSuggestion(s)}
 onMouseEnter={() => setSelectedIndex(i)}
 className={`w-full flex items-center gap-2.5 p-2.5 text-right transition-colors ${
 i === selectedIndex ? 'bg-amber-500/15' : 'hover:bg-foreground/5'
 }`}
 >
 {s.avatar_url ? (
 <img
 src={s.avatar_url}
 alt=""
 className="w-8 h-8 rounded-xl object-cover flex-shrink-0"
 />
 ) : (
 <div
 className="w-8 h-8 rounded-xl flex items-center justify-center text-white text-xs font-bold flex-shrink-0"
 style={{
 background: `linear-gradient(135deg, ${s.avatar_color || '#FBBF24'} 0%, ${s.avatar_color || '#FBBF24'}aa 100%)`,
 }}
 >
 {(s.display_name || s.username || '؟').charAt(0).toUpperCase()}
 </div>
 )}
 <div className="flex-1 min-w-0">
 <div className="text-xs font-bold truncate">
 {s.display_name || s.username}
 </div>
 <div className="text-[10px] text-muted-foreground" dir="ltr">
 @{s.username}
 </div>
 </div>
 <span className="text-[10px] text-amber-500 font-bold opacity-70">
 @{s.username}
 </span>
 </button>
 ))}
 </div>
 )}
 </div>
 )
}
