'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Home, ArrowLeft } from 'lucide-react'
import { useAppStore } from '@/store/app-store'

export function NotFoundClient() {
 const router = useRouter()
 const user = useAppStore((s) => s.user)

 // استعادة حالة Zustand
 useEffect(() => {
 void useAppStore.persist.rehydrate()
 }, [])

 const goHome = () => {
 router.push(user ? '/home' : '/')
 }

 return (
 <div className="min-h-screen mishri-aurora-bg flex flex-col items-center justify-center px-6">
 <div
 className="text-center transition-colors duration-200"
 >
 <div className="w-20 h-20 mx-auto mb-6 rounded-3xl rounded-xl bg-foreground/5 flex items-center justify-center mishri-glow-soft">
 <span className="font-display text-3xl font-bold mishri-gradient-text">404</span>
 </div>
 <h1 className="font-display text-3xl font-bold mb-2 mishri-gradient-text">
 الصفحة غير موجودة
 </h1>
 <p className="text-sm text-muted-foreground mb-8 max-w-xs mx-auto leading-relaxed">
 عذرًا، الصفحة التي تبحث عنها غير موجودة أو تم نقلها.
 </p>

 <div className="flex gap-3 justify-center">
 <button
 onClick={goHome}
 className="px-5 py-2.5 rounded-xl mishri-gradient-primary text-white text-sm font-bold shadow-md mishri-glow-soft mishri-press flex items-center gap-2"
 >
 <Home className="w-4 h-4" />
 العودة للرئيسية
 </button>
 <button
 onClick={() => router.back()}
 className="px-5 py-2.5 rounded-xl rounded-xl bg-foreground/5 text-sm font-bold text-foreground mishri-press flex items-center gap-2"
 >
 <ArrowLeft className="w-4 h-4" />
 رجوع
 </button>
 </div>
 </div>
 </div>
 )
}
