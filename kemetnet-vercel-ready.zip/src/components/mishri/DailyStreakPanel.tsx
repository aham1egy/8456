'use client'

import { useState, useEffect } from 'react'
import { Flame, Gift, Snowflake, ChevronDown, ChevronUp, Loader2, Check, Calendar } from 'lucide-react'
import {
 fetchStreakStatus,
 claimDailyReward,
 DAILY_REWARDS,
 getRewardForDay,
 type StreakStatus,
 type ClaimResult,
} from '@/lib/daily-streak'
import { useAppStore } from '@/store/app-store'
import { useNotificationSound } from '@/hooks/use-sound'
import { toast } from 'sonner'

interface DailyStreakPanelProps {
 userId: string
}

export function DailyStreakPanel({ userId }: DailyStreakPanelProps) {
 const [status, setStatus] = useState<StreakStatus | null>(null)
 const [loading, setLoading] = useState(true)
 const [claiming, setClaiming] = useState(false)
 const [expanded, setExpanded] = useState(false)
 const [lastClaim, setLastClaim] = useState<ClaimResult | null>(null)
 const user = useAppStore((s) => s.user)
 const setUser = useAppStore((s) => s.setUser)
 const { playSound } = useNotificationSound()

 useEffect(() => {
 let cancelled = false
 void (async () => {
 setLoading(true)
 const result = await fetchStreakStatus(userId)
 if (!cancelled) {
 setStatus(result)
 setLoading(false)
 }
 })()
 return () => {
 cancelled = true
 }
 }, [userId])

 const handleClaim = async () => {
 if (!user || claiming) return
 setClaiming(true)
 const result = await claimDailyReward(user.id)
 if (result.success) {
 playSound('success')
 setLastClaim(result)
 // تحديث الحالة
 const fresh = await fetchStreakStatus(user.id)
 setStatus(fresh)
 // تحديث user state في store (نقاط السمعة)
 if (fresh && user) {
 setUser({
 ...user,
 reputation_points: user.reputation_points + result.points_awarded,
 login_streak: result.streak,
 })
 }
 if (result.reward_type === 'bonus') {
 toast.success(`🎉 إكمال الأسبوع! +${result.points_awarded} نقطة + حماية انقطاع!`)
 } else if (result.streak_broken) {
 toast.success(`+${result.points_awarded} نقطة — بدأت سلسلة جديدة!`)
 } else {
 toast.success(`+${result.points_awarded} نقطة — اليوم ${result.day_in_cycle}!`)
 }
 } else {
 toast.info('سبق المطالبة بمكافأة اليوم')
 }
 setClaiming(false)
 }

 if (loading || !status) {
 return (
 <div className="rounded-2xl bg-foreground/5 p-4">
 <div className="h-6 w-32 mishri-shimmer rounded-lg mb-3" />
 <div className="h-16 mishri-shimmer rounded-xl" />
 </div>
 )
 }

 const currentDay = ((status.current_streak - 1) % 7) + 1
 const todayReward = getRewardForDay(status.current_streak + (status.claimed_today ? 0 : 1))

 return (
 <div className="rounded-2xl bg-foreground/5 p-4 ">
 {/* الرأس */}
 <div className="flex items-center justify-between mb-3">
 <div className="flex items-center gap-2">
 <div className="w-8 h-8 rounded-xl bg-orange-500/15 flex items-center justify-center">
 <Flame className="w-4 h-4 text-orange-500" fill="#F97316" />
 </div>
 <div>
 <h3 className="font-bold text-sm">المكافأة اليومية</h3>
 <p className="text-[10px] text-muted-foreground">
 {status.current_streak > 0 ? `${status.current_streak} يوم متتالي` : 'ابدأ سلسلتك اليوم!'}
 </p>
 </div>
 </div>
 <button
 onClick={() => setExpanded(!expanded)}
 className="p-1.5 rounded-full hover:bg-foreground/5 transition-colors"
 aria-label={expanded ? 'طي' : 'توسيع'}
 >
 {expanded ? (
 <ChevronUp className="w-4 h-4 text-muted-foreground" />
 ) : (
 <ChevronDown className="w-4 h-4 text-muted-foreground" />
 )}
 </button>
 </div>

 {/* العداد الرئيسي */}
 <div className="flex items-center gap-3 mb-3">
 {/* رقم الـ streak */}
 <div
 className="w-14 h-14 rounded-2xl bg-gradient-to-br from-orange-400 to-red-500 flex flex-col items-center justify-center text-white transition-colors duration-200"
 >
 <Flame className="w-5 h-5" fill="white" />
 <span className="text-lg font-bold leading-none">{status.current_streak}</span>
 </div>

 {/* المعلومات */}
 <div className="flex-1">
 <div className="text-xs font-bold text-orange-600 dark:text-orange-400">
 {status.current_streak === 0
 ? 'سلسلتك تبدأ اليوم!'
 : `يوم ${currentDay} من 7`}
 </div>
 <div className="text-[10px] text-muted-foreground mt-0.5">
 أطول سلسلة: {status.longest_streak} يوم
 </div>
 {status.has_freeze_available && (
 <div className="flex items-center gap-1 mt-1">
 <Snowflake className="w-3 h-3 text-cyan-500" fill="#06B6D4" />
 <span className="text-[10px] font-bold text-cyan-600 dark:text-cyan-400">
 حماية انقطاع متاحة
 </span>
 </div>
 )}
 </div>

 {/* زر المطالبة */}
 <button
 onClick={handleClaim}
 disabled={status.claimed_today || claiming}
 className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all mishri-press ${
 status.claimed_today
 ? 'bg-foreground/5 text-muted-foreground'
 : 'mishri-gradient-primary text-white shadow-md mishri-glow-soft'
 } disabled:opacity-70 flex items-center gap-1.5`}
 >
 {claiming ? (
 <Loader2 className="w-3.5 h-3.5 animate-spin" />
 ) : status.claimed_today ? (
 <>
 <Check className="w-3.5 h-3.5" />
 مُطالب
 </>
 ) : (
 <>
 <Gift className="w-3.5 h-3.5" />
 مطالبة
 </>
 )}
 </button>
 </div>

 {/* عرض مفصّل */}
 {expanded && (
 <div
 className="overflow-hidden transition-all duration-200"
 >
 {/* أيام الأسبوع */}
 <div className="border-t border-foreground/5 pt-3 mb-3">
 <div className="flex items-center gap-1.5 mb-2">
 <Calendar className="w-3.5 h-3.5 text-muted-foreground" />
 <span className="text-[11px] font-bold text-muted-foreground">مكافآت الأسبوع</span>
 </div>
 <div className="grid grid-cols-7 gap-1">
 {DAILY_REWARDS.map((reward, i) => {
 const isCurrentDay = reward.day === currentDay
 const isCompleted = status.current_streak >= reward.day && status.claimed_today
 const isPast = status.current_streak > reward.day
 const isNext = reward.day === currentDay + 1 && !status.claimed_today

 return (
 <div
 key={reward.day}
 className={`rounded-xl p-1.5 text-center relative transition-colors duration-200 ${
 isCompleted
 ? 'bg-emerald-500/15 border border-emerald-500/30'
 : isCurrentDay && !status.claimed_today
 ? 'bg-amber-500/15 border border-amber-500/30'
 : isPast
 ? 'bg-foreground/5 opacity-60'
 : 'bg-foreground/5'
 }`}
 >
 <div className="text-base mb-0.5">{reward.icon}</div>
 <div className="text-[8px] font-bold text-muted-foreground">
 يوم {reward.day}
 </div>
 <div className="text-[9px] font-bold text-amber-500 tabular-nums">
 +{reward.points}
 </div>
 {isCompleted && (
 <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 flex items-center justify-center">
 <Check className="w-2 h-2 text-white" strokeWidth={3} />
 </div>
 )}
 {reward.bonus === 'streak_freeze' && (
 <div className="absolute -top-1 -left-1">
 <Snowflake className="w-3.5 h-3.5 text-cyan-500" fill="#06B6D4" />
 </div>
 )}
 </div>
 )
 })}
 </div>
 </div>

 {/* إحصائيات */}
 <div className="grid grid-cols-3 gap-2 mb-3">
 <div className="rounded-xl bg-foreground/5 p-2 text-center">
 <div className="text-sm font-bold tabular-nums">{status.current_streak}</div>
 <div className="text-[9px] text-muted-foreground">السلسلة الحالية</div>
 </div>
 <div className="rounded-xl bg-foreground/5 p-2 text-center">
 <div className="text-sm font-bold tabular-nums">{status.longest_streak}</div>
 <div className="text-[9px] text-muted-foreground">أطول سلسلة</div>
 </div>
 <div className="rounded-xl bg-foreground/5 p-2 text-center">
 <div className="text-sm font-bold tabular-nums">{status.total_logins}</div>
 <div className="text-[9px] text-muted-foreground">إجمالي الأيام</div>
 </div>
 </div>

 {/* معلومة */}
 <div className="rounded-xl bg-cyan-500/5 border border-cyan-500/15 p-2.5 flex items-start gap-2">
 <Snowflake className="w-3.5 h-3.5 text-cyan-500 flex-shrink-0 mt-0.5" fill="#06B6D4" />
 <div className="text-[10px] text-muted-foreground leading-relaxed">
 <strong className="text-cyan-600 dark:text-cyan-400">حماية الانقطاع:</strong> عند إكمال 7 أيام متتالية، تحصل على حماية تحفظ سلسلتك إذا انقطعت يوماً واحداً. تنتهي الحماية بعد الاستخدام.
 </div>
 </div>
 </div>
 )}
 </div>
 )
}
