'use client'

import { useState, useRef, useEffect } from 'react'
import { Heart, MoreHorizontal, Edit2, Trash2, Pin, Flag, Ban } from 'lucide-react'
import { useRouter } from 'next/navigation'
import type { Comment } from '@/lib/comments'
import { getTimeAgoArabic, getTimeAgoFull } from '@/lib/comments'
import { useAppStore } from '@/store/app-store'
import { useNotificationSound } from '@/hooks/use-sound'
import { MentionText } from './MentionText'
import { ReportModal, BlockConfirmModal } from './ReportModal'
import { toast } from 'sonner'

interface CommentItemProps {
 comment: Comment & { replies?: Comment[]; replies_count?: number }
 postOwnerId: string
 onReply?: (parentId: string, username: string) => void
 onLikeToggle?: (commentId: string, liked: boolean) => void
 onDelete?: (commentId: string) => void
 onEdit?: (commentId: string, newContent: string) => void
 onPinToggle?: (commentId: string, pinned: boolean) => void
 /** هل عرض الردود كاملة أو مختصرة */
 isReply?: boolean
}

export function CommentItem({
 comment,
 postOwnerId,
 onReply,
 onLikeToggle,
 onDelete,
 onEdit,
 onPinToggle,
 isReply = false,
}: CommentItemProps) {
 const user = useAppStore((s) => s.user)
 const router = useRouter()
 const { playSound } = useNotificationSound()
 const [showMenu, setShowMenu] = useState(false)
 const [editing, setEditing] = useState(false)
 const [editContent, setEditContent] = useState(comment.content)
 const [deleteConfirm, setDeleteConfirm] = useState(false)
 const [showReportModal, setShowReportModal] = useState(false)
 const [showBlockModal, setShowBlockModal] = useState(false)
 const [liked, setLiked] = useState(comment.user_liked || false)
 const [likeCount, setLikeCount] = useState(comment.likes_count || 0)
 const [likeInProgress, setLikeInProgress] = useState(false)
 const [showReplies, setShowReplies] = useState(false)
 const [localReplies, setLocalReplies] = useState<Comment[]>(comment.replies || [])
 const editInputRef = useRef<HTMLTextAreaElement>(null)

 const profile = comment.profile
 const isOwnComment = user?.id === comment.user_id
 const isPostOwner = user?.id === postOwnerId
 const canDelete = isOwnComment || isPostOwner
 const canEdit = isOwnComment
 const canPin = isPostOwner && !isReply // فقط صاحب المنشور يثبّت تعليقاً رئيسياً

 // تحديث الحالة عند تغيير التعليق من الخارج
 useEffect(() => {
 setLiked(comment.user_liked || false)
 setLikeCount(comment.likes_count || 0)
 }, [comment.user_liked, comment.likes_count, comment.id])

 useEffect(() => {
 setLocalReplies(comment.replies || [])
 }, [comment.replies, comment.id])

 useEffect(() => {
 if (editing && editInputRef.current) {
 editInputRef.current.focus()
 editInputRef.current.setSelectionRange(editContent.length, editContent.length)
 }
 }, [editing])

 const handleLike = async () => {
 if (!user) {
 toast.error('سجّل الدخول للإعجاب بالتعليقات')
 return
 }
 if (likeInProgress) return
 setLikeInProgress(true)

 const newLiked = !liked
 setLiked(newLiked)
 setLikeCount((c) => Math.max(0, c + (newLiked ? 1 : -1)))
 playSound(newLiked ? 'like' : 'unlike')

 try {
 const { toggleCommentLike } = await import('@/lib/comments')
 const result = await toggleCommentLike(comment.id, user.id, !newLiked)
 if (!result.success) {
 // تراجع
 setLiked(!newLiked)
 setLikeCount((c) => Math.max(0, c + (newLiked ? -1 : 1)))
 } else if (result.liked !== newLiked) {
 // الخادم صحّح الحالة
 setLiked(result.liked || false)
 }
 if (onLikeToggle) onLikeToggle(comment.id, newLiked)
 } catch (e) {
 // [removed in production] 'Comment like error:', e
 setLiked(!newLiked)
 setLikeCount((c) => Math.max(0, c + (newLiked ? -1 : 1)))
 } finally {
 setLikeInProgress(false)
 }
 }

 const handleSaveEdit = async () => {
 if (!user || !editContent.trim()) return
 try {
 const { editComment } = await import('@/lib/comments')
 const result = await editComment(comment.id, user.id, editContent)
 if (result.success) {
 toast.success('تم تعديل التعليق')
 setEditing(false)
 if (onEdit) onEdit(comment.id, editContent.trim())
 } else {
 toast.error(result.error || 'تعذّر تعديل التعليق')
 }
 } catch (e) {
 // [removed in production] 'Edit comment error:', e
 toast.error('حدث خطأ')
 }
 }

 const handleDelete = async () => {
 if (!user) return
 try {
 const { deleteComment } = await import('@/lib/comments')
 const result = await deleteComment(comment.id, user.id, postOwnerId)
 if (result.success) {
 toast.success('تم حذف التعليق')
 setShowMenu(false)
 setDeleteConfirm(false)
 if (onDelete) onDelete(comment.id)
 } else {
 toast.error(result.error || 'تعذّر حذف التعليق')
 }
 } catch (e) {
 // [removed in production] 'Delete comment error:', e
 toast.error('حدث خطأ')
 }
 }

 const handlePin = async () => {
 if (!user || !canPin) return
 try {
 const { togglePinComment } = await import('@/lib/comments')
 const result = await togglePinComment(comment.id, comment.post_id, user.id)
 if (result.success) {
 toast.success(result.pinned ? 'تم تثبيت التعليق' : 'تمت إزالة التثبيت')
 setShowMenu(false)
 if (onPinToggle) onPinToggle(comment.id, result.pinned || false)
 } else {
 toast.error(result.error || 'تعذّر التحديث')
 }
 } catch (e) {
 // [removed in production] 'Pin comment error:', e
 toast.error('حدث خطأ')
 }
 }

 const handleProfileClick = () => {
 if (!profile) return
 router.push(`/profile/${profile.username}`)
 }

 const handleReplyClick = () => {
 if (!profile) return
 if (onReply) onReply(comment.id, profile.username || profile.display_name || 'مستخدم')
 }

 return (
 <div
 className={`relative ${isReply ? 'mr-10' : ''}`}
 >
 {comment.is_pinned && (
 <div className="flex items-center gap-1.5 mb-1.5 mr-1 text-[11px] font-semibold text-amber-500">
 <Pin className="w-3 h-3 fill-amber-500" />
 <span>تعليق مثبّت</span>
 </div>
 )}

 <div className="flex gap-2.5">
 {/* الصورة الرمزية */}
 <button onClick={handleProfileClick} className="flex-shrink-0 mishri-press">
 {profile?.avatar_url ? (
 <img
 src={profile.avatar_url}
 alt={profile.display_name || profile.username || 'مستخدم'}
 className="w-9 h-9 rounded-xl object-cover shadow-sm"
 />
 ) : (
 <div
 className="w-9 h-9 rounded-xl flex items-center justify-center text-white text-sm font-bold shadow-sm"
 style={{
 background: `linear-gradient(135deg, ${profile?.avatar_color || '#FBBF24'} 0%, ${profile?.avatar_color || '#FBBF24'}aa 100%)`,
 }}
 >
 {(profile?.display_name || profile?.username || '؟').charAt(0).toUpperCase()}
 </div>
 )}
 </button>

 {/* محتوى التعليق */}
 <div className="flex-1 min-w-0">
 {/* بطاقة التعليق */}
 <div className="relative">
 {!editing ? (
 <div className="bg-foreground/5 dark:bg-foreground/10 rounded-2xl px-3.5 py-2.5 inline-block max-w-full">
 <button
 onClick={handleProfileClick}
 className="text-[13px] font-bold hover:underline block mb-0.5 text-right"
 >
 {profile?.display_name || profile?.username || 'مستخدم'}
 </button>
 <p className="text-[14px] leading-relaxed text-foreground/90 whitespace-pre-wrap break-words">
 <MentionText text={comment.content} />
 </p>
 </div>
 ) : (
 <div className="bg-foreground/5 dark:bg-foreground/10 rounded-2xl p-2">
 <textarea
 ref={editInputRef}
 value={editContent}
 onChange={(e) => setEditContent(e.target.value)}
 className="w-full bg-transparent text-[14px] leading-relaxed outline-none resize-none px-1 py-0.5"
 rows={Math.min(5, Math.max(2, editContent.split('\n').length))}
 maxLength={500}
 />
 <div className="flex items-center justify-between mt-1.5">
 <span className="text-[10px] text-muted-foreground">{editContent.length}/500</span>
 <div className="flex gap-1.5">
 <button
 onClick={() => {
 setEditing(false)
 setEditContent(comment.content)
 }}
 className="px-3 py-1 rounded-lg bg-foreground/5 text-[11px] font-semibold"
 >
 إلغاء
 </button>
 <button
 onClick={handleSaveEdit}
 disabled={!editContent.trim() || editContent.trim() === comment.content}
 className="px-3 py-1 rounded-lg mishri-gradient-primary text-white text-[11px] font-bold disabled:opacity-50"
 >
 حفظ
 </button>
 </div>
 </div>
 </div>
 )}

 {/* زر القائمة */}
 {(canDelete || canEdit || canPin) && !editing && (
 <div className="absolute top-1 left-1">
 <button
 onClick={() => setShowMenu((v) => !v)}
 className="p-1.5 rounded-full hover:bg-foreground/10 transition-colors"
 aria-label="خيارات"
 >
 <MoreHorizontal className="w-3.5 h-3.5 text-muted-foreground" />
 </button>
 {showMenu && (
 <>
 <div
 className="fixed inset-0 z-40"
 onClick={() => setShowMenu(false)}
 />
 <div
 className="absolute top-7 left-0 z-50 rounded-xl bg-foreground/5 shadow-xl py-1 min-w-[140px] "
 >
 {canPin && (
 <MenuItem
 icon={<Pin className="w-3.5 h-3.5" />}
 label={comment.is_pinned ? 'إزالة التثبيت' : 'تثبيت التعليق'}
 onClick={handlePin}
 />
 )}
 {canEdit && (
 <MenuItem
 icon={<Edit2 className="w-3.5 h-3.5" />}
 label="تعديل"
 onClick={() => {
 setEditing(true)
 setShowMenu(false)
 }}
 />
 )}
 {canDelete && (
 <MenuItem
 icon={<Trash2 className="w-3.5 h-3.5" />}
 label="حذف"
 danger
 onClick={() => {
 setDeleteConfirm(true)
 setShowMenu(false)
 }}
 />
 )}
 {/* خيارات الإبلاغ والحجب للمستخدمين غير المالكين */}
 {!isOwnComment && (
 <>
 <div className="border-t border-foreground/5 my-1" />
 <MenuItem
 icon={<Flag className="w-3.5 h-3.5" />}
 label="إبلاغ عن التعليق"
 danger
 onClick={() => {
 setShowReportModal(true)
 setShowMenu(false)
 }}
 />
 <MenuItem
 icon={<Ban className="w-3.5 h-3.5" />}
 label="حجب المستخدم"
 danger
 onClick={() => {
 setShowBlockModal(true)
 setShowMenu(false)
 }}
 />
 </>
 )}
 </div>
 </>
 )}
 </div>
 )}
 </div>

 {/* أزرار الإجراءات السفلية */}
 {!editing && (
 <div className="flex items-center gap-3 mt-1 px-1">
 <span
 className="text-[10px] text-muted-foreground"
 title={getTimeAgoFull(comment.created_at)}
 >
 {getTimeAgoArabic(comment.created_at)}
 </span>

 <button
 onClick={handleLike}
 disabled={likeInProgress}
 className="text-[10px] font-bold text-muted-foreground hover:text-rose-500 transition-colors mishri-tap"
 >
 إعجاب
 </button>

 {onReply && (
 <button
 onClick={handleReplyClick}
 className="text-[10px] font-bold text-muted-foreground hover:text-sky-500 transition-colors mishri-tap"
 >
 رد
 </button>
 )}

 {comment.is_edited && (
 <span className="text-[9px] text-muted-foreground/70">تم التعديل</span>
 )}

 {/* زر الإعجاب بقلب */}
 {likeCount > 0 && (
 <div className="mr-auto flex items-center gap-1">
 <button
 onClick={handleLike}
 className="flex items-center gap-1"
 aria-label="إعجابات"
 >
 <div
 key={liked ? 'liked' : 'unliked'}
 >
 <Heart
 className={`w-3 h-3 transition-colors duration-200 ${
 liked
 ? 'fill-rose-500 text-rose-500 mishri-heart-pop'
 : 'text-muted-foreground'
 }`}
 strokeWidth={liked ? 0 : 2}
 />
 </div>
 <span
 className={`text-[10px] font-bold tabular-nums ${
 liked ? 'text-rose-500' : 'text-muted-foreground'
 }`}
 >
 {likeCount}
 </span>
 </button>
 </div>
 )}
 </div>
 )}

 {/* زر عرض الردود */}
 {!isReply && (comment.replies_count || 0) > 0 && !showReplies && localReplies.length === 0 && (
 <button
 onClick={() => setShowReplies(true)}
 className="flex items-center gap-2 mt-1.5 mr-2 text-[11px] font-semibold text-muted-foreground hover:text-foreground transition-colors mishri-tap"
 >
 <span className="w-6 h-px bg-muted-foreground/40" />
 عرض الردود ({comment.replies_count})
 </button>
 )}

 {/* الردود */}
 {!isReply && (showReplies || localReplies.length > 0) && (
 <div className="mt-2 space-y-2.5">
 {localReplies.map((reply) => (
 <CommentItem
 key={reply.id}
 comment={reply}
 postOwnerId={postOwnerId}
 onReply={onReply}
 onLikeToggle={onLikeToggle}
 onDelete={(deletedId) => {
 setLocalReplies((prev) => prev.filter((r) => r.id !== deletedId))
 }}
 onEdit={(editId, newContent) => {
 setLocalReplies((prev) =>
 prev.map((r) =>
 r.id === editId
 ? { ...r, content: newContent, is_edited: true }
 : r
 )
 )
 }}
 isReply
 />
 ))}
 {showReplies && (comment.replies_count || 0) > localReplies.length && (
 <button
 onClick={() => setShowReplies(false)}
 className="flex items-center gap-2 mr-2 text-[11px] font-semibold text-muted-foreground hover:text-foreground transition-colors mishri-tap"
 >
 <span className="w-6 h-px bg-muted-foreground/40" />
 إخفاء الردود
 </button>
 )}
 </div>
 )}
 </div>
 </div>

 {/* تأكيد الحذف */}
 {deleteConfirm && (
 <div
 className="fixed inset-0 z-[100] bg-black/50 flex items-center justify-center p-6"
 onClick={() => setDeleteConfirm(false)}
 >
 <div
 className="rounded-2xl p-4 bg-foreground/5 max-w-xs w-full text-center"
 onClick={(e) => e.stopPropagation()}
 >
 <div className="w-12 h-12 mx-auto mb-3 rounded-2xl bg-rose-500/15 flex items-center justify-center">
 <Trash2 className="w-5 h-5 text-rose-500" />
 </div>
 <h3 className="font-bold text-sm mb-1">حذف التعليق؟</h3>
 <p className="text-xs text-muted-foreground mb-4">
 لا يمكن التراجع عن هذا الإجراء.
 </p>
 <div className="flex gap-2">
 <button
 onClick={() => setDeleteConfirm(false)}
 className="flex-1 py-2.5 rounded-xl bg-foreground/5 text-xs font-bold"
 >
 إلغاء
 </button>
 <button
 onClick={handleDelete}
 className="flex-1 py-2.5 rounded-xl bg-rose-500 text-white text-xs font-bold"
 >
 حذف
 </button>
 </div>
 </div>
 </div>
 )}

 {/* مودال الإبلاغ */}
 <ReportModal
 open={showReportModal}
 onClose={() => setShowReportModal(false)}
 targetType="comment"
 targetId={comment.id}
 reportedUserId={comment.user_id}
 reportedUserName={profile?.display_name || profile?.username}
 />

 {/* مودال الحجب */}
 <BlockConfirmModal
 open={showBlockModal}
 onClose={() => setShowBlockModal(false)}
 blockedUserId={comment.user_id}
 blockedUserName={profile?.display_name || profile?.username}
 />
 </div>
 )
}

// ========================================
// عنصر قائمة منسدلة
// ========================================

function MenuItem({
 icon,
 label,
 onClick,
 danger = false,
}: {
 icon: React.ReactNode
 label: string
 onClick: () => void
 danger?: boolean
}) {
 return (
 <button
 onClick={onClick}
 className={`w-full flex items-center gap-2.5 px-3 py-2 text-[12px] font-semibold hover:bg-foreground/5 transition-colors text-right ${
 danger ? 'text-rose-500' : 'text-foreground'
 }`}
 >
 <span className={danger ? 'text-rose-500' : 'text-muted-foreground'}>{icon}</span>
 <span>{label}</span>
 </button>
 )
}
