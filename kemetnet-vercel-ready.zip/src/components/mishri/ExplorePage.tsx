'use client'

import { useState, useEffect, useCallback, useRef } from 'react'
import { useRouter } from 'next/navigation'
import { Search, TrendingUp, Users, Hash, Compass, X, SlidersHorizontal, Flame, Clock, History, Trash2, Trophy } from 'lucide-react'
import { supabase, CATEGORIES, MOODS, type Profile, type Post } from '@/lib/supabase/client'
import { escapeIlikePattern } from '@/lib/postgrest-utils'
import { usePageCache } from '@/hooks/use-page-cache'
import {
 loadSearchHistory,
 addSearchHistory,
 removeSearchHistory,
 clearSearchHistory,
 SUGGESTED_SEARCHES,
 formatSearchTime,
 type SearchHistoryEntry,
} from '@/lib/search-history'
import { PostCard } from './PostCard'
import { toast } from 'sonner'

export function ExplorePage() {
 const [tab, setTab] = useState<'trending' | 'people' | 'tags'>('trending')
 const [search, setSearch] = useState('')
 const [debouncedSearch, setDebouncedSearch] = useState('')
 const [posts, setPosts] = useState<Post[]>([])
 const [suggestedUsers, setSuggestedUsers] = useState<Profile[]>([])

 // قراءة query param للوسم (من النقر على وسم في منشور)
 useEffect(() => {
 if (typeof window !== 'undefined') {
 const params = new URLSearchParams(window.location.search)
 const tagParam = params.get('tag')
 if (tagParam) {
 setSearch('#' + tagParam)
 setTab('tags')
 // مسح الـ param من URL بعد الاستخدام
 window.history.replaceState({}, '', '/explore')
 }
 }
 }, [])

 // scroll restoration + background sync
 usePageCache('explore', {
 backgroundSyncInterval: 120000, // دقيقتان
 })
 const [people, setPeople] = useState<Profile[]>([])
 const [tags, setTags] = useState<{ tag: string; count: number }[]>([])
 const [loading, setLoading] = useState(true)
 const [sortBy, setSortBy] = useState<'recent' | 'popular'>('popular')
 const [selectedCategory, setSelectedCategory] = useState<string>('all')
 const [selectedMood, setSelectedMood] = useState<string | null>(null)
 const [showFilters, setShowFilters] = useState(false)
 const [searchHistory, setSearchHistory] = useState<SearchHistoryEntry[]>([])
 const [showHistory, setShowHistory] = useState(false)
 const searchInputRef = useRef<HTMLInputElement>(null)
 const router = useRouter()

 // تحميل سجل البحث عند التحميل
 useEffect(() => {
 setSearchHistory(loadSearchHistory())
 // تحميل مستخدمين مقترحين (أكثر متابعين)
 void (async () => {
 try {
 const { data } = await supabase
 .from('profiles')
 .select('*')
 .order('followers_count', { ascending: false })
 .limit(10)
 if (data) setSuggestedUsers(data as Profile[])
 } catch {}
 })()
 }, [])

 // حفظ البحث عند الإرسال (Enter)
 const handleSearchSubmit = useCallback(() => {
 if (search.trim().length >= 2) {
 const type = tab === 'people' ? 'people' : tab === 'tags' ? 'tags' : 'all'
 addSearchHistory(search, type)
 setSearchHistory(loadSearchHistory())
 setShowHistory(false)
 }
 }, [search, tab])

 // Debounce على البحث (300ms)
 useEffect(() => {
 const timeout = setTimeout(() => setDebouncedSearch(search), 300)
 return () => clearTimeout(timeout)
 }, [search])

 const loadData = useCallback(async () => {
 setLoading(true)
 try {
 if (tab === 'trending') {
 let query = supabase
 .from('posts')
 .select('*, profile:profiles(*)')
 .limit(30)

 // فلترة بالفئة
 if (selectedCategory !== 'all') {
 query = query.eq('category', selectedCategory)
 }

 // فلترة بالمود
 if (selectedMood) {
 query = query.eq('mood', selectedMood)
 }

 // البحث
 if (debouncedSearch) {
 const safeSearch = escapeIlikePattern(debouncedSearch)
 if (safeSearch) {
 query = query.ilike('content', `%${safeSearch}%`)
 }
 }

 // الترتيب
 if (sortBy === 'recent') {
 query = query.order('created_at', { ascending: false })
 } else {
 query = query.order('likes_count', { ascending: false })
 }

 const { data, error } = await query
 if (error) throw error
 setPosts(data || [])
 } else if (tab === 'people') {
 let query = supabase
 .from('profiles')
 .select('*')
 .order('followers_count', { ascending: false })
 .limit(50)

 // البحث عن المستخدمين
 if (debouncedSearch) {
 const safeSearch = escapeIlikePattern(debouncedSearch)
 if (safeSearch) {
 query = query.or(`username.ilike.%${safeSearch}%,display_name.ilike.%${safeSearch}%`)
 }
 }

 const { data, error } = await query
 if (error) throw error
 setPeople(data || [])
 } else if (tab === 'tags') {
 let query = supabase
 .from('posts')
 .select('tags')
 .limit(200)

 // فلترة بالفئة للوسوم
 if (selectedCategory !== 'all') {
 query = query.eq('category', selectedCategory)
 }

 const { data, error } = await query
 if (error) throw error
 const tagCounts: Record<string, number> = {}
 ;(data || []).forEach((p: { tags: string[] | null }) => {
 if (p.tags) {
 p.tags.forEach((t: string) => {
 if (!debouncedSearch || t.toLowerCase().includes(debouncedSearch.toLowerCase())) {
 tagCounts[t] = (tagCounts[t] || 0) + 1
 }
 })
 }
 })
 const sortedTags = Object.entries(tagCounts)
 .map(([tag, count]) => ({ tag, count }))
 .sort((a, b) => b.count - a.count)
 .slice(0, 50)
 setTags(sortedTags)
 }
 } catch (e) {
 // [removed in production] 'Load explore error:', e
 } finally {
 setLoading(false)
 }
 }, [tab, debouncedSearch, selectedCategory, selectedMood, sortBy])

 useEffect(() => {
 void loadData()
 }, [loadData])

 return (
 <div className="flex flex-col flex-1 min-h-0">
 {/* رأس رفيع نظيف */}
 <header className="flex-shrink-0 border-b border-foreground/8 bg-background/80 backdrop-blur-xl z-40" style={{ paddingTop: 'env(safe-area-inset-top, 0px)' }}>
 <div className="max-w-md mx-auto px-4 py-2">
 <div className="flex items-center justify-between mb-2">
 <h1 className="font-display text-xl font-bold mishri-gradient-text">استكشاف</h1>
 <button
 onClick={() => router.push('/leaderboard')}
 className="w-8 h-8 rounded-full hover:bg-foreground/5 flex items-center justify-center transition-colors"
 aria-label="المتصدرون"
 >
 <Trophy className="[18px] h-[18px] text-foreground" strokeWidth={1.8} />
 </button>
 </div>

 {/* البحث */}
 <div className="relative mb-2">
 <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
 <input
 ref={searchInputRef}
 type="text"
 value={search}
 onChange={(e) => setSearch(e.target.value)}
 onFocus={() => setShowHistory(true)}
 onKeyDown={(e) => {
 if (e.key === 'Enter') {
 handleSearchSubmit()
 }
 }}
 placeholder={tab === 'people' ? 'ابحث عن مستخدمين...' : tab === 'tags' ? 'ابحث عن وسوم...' : 'ابحث...'}
 className="w-full rounded-xl py-2.5 pr-10 pl-10 text-sm bg-foreground/5 outline-none focus:bg-foreground/10 transition-colors"
 />
 {search ? (
 <button
 onClick={() => {
 setSearch('')
 setShowHistory(false)
 }}
 className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
 >
 <X className="w-4 h-4" />
 </button>
 ) : searchHistory.length > 0 ? (
 <button
 onClick={() => setShowHistory(!showHistory)}
 className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
 >
 <History className="w-4 h-4" />
 </button>
 ) : null}

 {/* لوحة السجل والاقتراحات */}
 {showHistory && !search && (
 <>
 {/* overlay لإغلاق السجل عند النقر خارج */}
 <div
 className="fixed inset-0 z-40"
 onClick={() => setShowHistory(false)}
 />
 <div
 className="absolute top-full left-0 right-0 mt-1 z-50 rounded-2xl bg-foreground/5 shadow-xl overflow-hidden max-h-80 overflow-y-auto transition-colors duration-200"
 >
 {/* سجل البحث */}
 {searchHistory.length > 0 && (
 <div className="p-2">
 <div className="flex items-center justify-between px-2 py-1 mb-1">
 <span className="text-[10px] font-bold text-muted-foreground flex items-center gap-1">
 <History className="w-3 h-3" />
 عمليات البحث الأخيرة
 </span>
 <button
 onClick={() => {
 clearSearchHistory()
 setSearchHistory([])
 }}
 className="text-[10px] text-rose-500 hover:underline flex items-center gap-1"
 >
 <Trash2 className="w-3 h-3" />
 مسح
 </button>
 </div>
 {searchHistory.map((entry, i) => (
 <div
 key={`${entry.query}-${entry.timestamp}`}
 className="flex items-center gap-2 group"
 >
 <button
 onClick={() => {
 setSearch(entry.query)
 setShowHistory(false)
 searchInputRef.current?.focus()
 }}
 className="flex-1 flex items-center gap-2 p-2 rounded-lg hover:bg-foreground/5 text-right"
 >
 <Clock className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
 <span className="text-sm flex-1 truncate">{entry.query}</span>
 <span className="text-[10px] text-muted-foreground">
 {formatSearchTime(entry.timestamp)}
 </span>
 </button>
 <button
 onClick={() => {
 removeSearchHistory(entry.query, entry.type)
 setSearchHistory(loadSearchHistory())
 }}
 className="p-1.5 rounded-full opacity-0 group-hover:opacity-100 transition-opacity hover:bg-rose-500/10"
 >
 <X className="w-3 h-3 text-rose-500" />
 </button>
 </div>
 ))}
 </div>
 )}

 {/* اقتراحات سريعة */}
 <div className="p-2 border-t border-foreground/5">
 <div className="px-2 py-1 mb-1">
 <span className="text-[10px] font-bold text-muted-foreground">
 اقتراحات شائعة
 </span>
 </div>
 <div className="flex flex-wrap gap-1.5 px-2">
 {SUGGESTED_SEARCHES.map((suggestion) => (
 <button
 key={suggestion}
 onClick={() => {
 setSearch(suggestion)
 setShowHistory(false)
 searchInputRef.current?.focus()
 }}
 className="px-3 py-1.5 rounded-full bg-amber-500/10 text-amber-700 dark:text-amber-300 text-xs font-semibold hover:bg-amber-500/20 transition-colors"
 >
 {suggestion}
 </button>
 ))}
 </div>
 </div>
 </div>
 </>
 )}
 </div>

 {/* تبويبات */}
 <div className="flex gap-2">
 <button onClick={() => setTab('trending')} className={`px-4 py-1.5 rounded-full text-sm font-bold transition-all ${tab === 'trending' ? 'bg-foreground text-background' : 'text-muted-foreground hover:bg-foreground/5'}`}>منشورات</button>
 <button onClick={() => setTab('people')} className={`px-4 py-1.5 rounded-full text-sm font-bold transition-all ${tab === 'people' ? 'bg-foreground text-background' : 'text-muted-foreground hover:bg-foreground/5'}`}>مستخدمون</button>
 <button onClick={() => setTab('tags')} className={`px-4 py-1.5 rounded-full text-sm font-bold transition-all ${tab === 'tags' ? 'bg-foreground text-background' : 'text-muted-foreground hover:bg-foreground/5'}`}>وسوم</button>
 </div>
 </div>
 </header>

 {/* شريط الفلاتر — يظهر فقط في تبويب المنشورات */}
 {tab === 'trending' && (
 <div className="flex-shrink-0 px-4 py-2 border-b border-foreground/5">
 <div className="max-w-md mx-auto">
 {/* الفئات */}
 <div className="flex gap-2 overflow-x-auto pb-2" style={{ scrollbarWidth: 'none' }}>
 <FilterChip
 active={selectedCategory === 'all'}
 onClick={() => setSelectedCategory('all')}
 label="الكل"
 />
 {CATEGORIES.filter((c) => c.id !== 'all').map((cat) => {
 const Icon = cat.icon
 return (
 <FilterChip
 key={cat.id}
 active={selectedCategory === cat.id}
 onClick={() => setSelectedCategory(cat.id)}
 icon={<Icon className="w-3.5 h-3.5" />}
 label={cat.label}
 />
 )
 })}
 </div>

 {/* الترتيب + زر الفلترة */}
 <div className="flex items-center justify-between gap-2 pt-1">
 <div className="flex bg-foreground/5 rounded-xl p-1 flex-1">
 <SortBtn active={sortBy === 'recent'} onClick={() => setSortBy('recent')} icon={Clock} label="حديث" />
 <SortBtn active={sortBy === 'popular'} onClick={() => setSortBy('popular')} icon={Flame} label="رائج" />
 </div>
 <button
 onClick={() => setShowFilters(!showFilters)}
 className="p-2.5 rounded-xl bg-foreground/5 hover:bg-foreground/10 transition-colors mishri-press relative"
 aria-label="فلترة متقدمة"
 >
 <SlidersHorizontal className="w-4 h-4 text-muted-foreground" />
 {selectedMood && (
 <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-amber-500" />
 )}
 </button>
 </div>

 {/* الفلترة المتقدمة */}
 {showFilters && (
 <div
 className="overflow-hidden mt-2"
 >
 <div className="rounded-2xl bg-foreground/5 p-3">
 <h4 className="text-xs font-bold text-muted-foreground mb-2">المزاج</h4>
 <div className="flex flex-wrap gap-2">
 <MoodChip active={!selectedMood} onClick={() => setSelectedMood(null)} label="الكل" />
 {MOODS.map((m) => {
 const Icon = m.icon
 return (
 <MoodChip
 key={m.id}
 active={selectedMood === m.id}
 onClick={() => setSelectedMood(m.id)}
 icon={<Icon className="w-3 h-3" />}
 label={m.label}
 color={m.color}
 />
 )
 })}
 </div>
 </div>
 </div>
 )}

 {/* عرض الفلاتر النشطة */}
 {(selectedMood || selectedCategory !== 'all') && (
 <div className="flex items-center gap-2 mt-2">
 {selectedCategory !== 'all' && (
 <span className="inline-flex items-center gap-1 text-xs font-semibold px-2 py-1 rounded-full bg-amber-500/10 text-amber-700 dark:text-amber-300">
 {CATEGORIES.find((c) => c.id === selectedCategory)?.label}
 <button onClick={() => setSelectedCategory('all')} className="hover:bg-amber-500/20 rounded-full p-0.5">
 <X className="w-3 h-3" />
 </button>
 </span>
 )}
 {selectedMood && (
 <span className="inline-flex items-center gap-1 text-xs font-semibold px-2 py-1 rounded-full bg-amber-500/10 text-amber-700 dark:text-amber-300">
 {MOODS.find((m) => m.id === selectedMood)?.label}
 <button onClick={() => setSelectedMood(null)} className="hover:bg-amber-500/20 rounded-full p-0.5">
 <X className="w-3 h-3" />
 </button>
 </span>
 )}
 <button
 onClick={() => { setSelectedCategory('all'); setSelectedMood(null) }}
 className="text-[11px] text-rose-500 font-semibold"
 >
 مسح الكل
 </button>
 </div>
 )}
 </div>
 </div>
 )}

 {/* المحتوى */}
 <div data-scroll-area className="flex-1 overflow-y-auto overscroll-y-contain">
 <div className="max-w-md mx-auto px-4 pt-4 pb-4">
 {loading ? (
 <div className="space-y-3">
 {Array.from({ length: 5 }).map((_, i) => (
 <div key={i} className="rounded-2xl bg-foreground/5 p-3 h-16 mishri-shimmer" />
 ))}
 </div>
 ) : tab === 'trending' ? (
 posts.length === 0 ? (
 <EmptyState icon={<Search className="w-7 h-7" />} title="لا توجد نتائج" desc="جرّب تغيير الفلاتر أو البحث بكلمات أخرى" />
 ) : (
 <div className="space-y-4">
 {/* عدد النتائج */}
 {debouncedSearch && (
 <div className="text-xs text-muted-foreground px-1">
 {posts.length} نتيجة لـ "{debouncedSearch}"
 </div>
 )}
 {/* مستخدمون مقترحون — يظهرون فقط بدون بحث */}
 {!debouncedSearch && suggestedUsers.length > 0 && (
 <div className="rounded-2xl bg-foreground/[0.02] border border-foreground/8 p-3">
 <h3 className="text-xs font-bold text-muted-foreground mb-2 px-1">مستخدمون قد تهمّك</h3>
 <div className="flex gap-2 overflow-x-auto pb-1 mishri-scrollbar-hide">
 {suggestedUsers.map((user) => (
 <button
 key={user.id}
 onClick={() => router.push(`/profile/${user.username}`)}
 className="flex-shrink-0 w-20 flex flex-col items-center gap-1.5 p-2 rounded-xl hover:bg-foreground/5 transition-colors"
 >
 <div
 className="w-12 h-12 rounded-full flex items-center justify-center text-white text-sm font-bold"
 style={{
 background: `linear-gradient(135deg, ${user.avatar_color || '#1F4E8C'}, ${user.avatar_color || '#0E2A4F'}aa)`,
 }}
 >
 {(user.display_name || user.username || '؟').charAt(0).toUpperCase()}
 </div>
 <span className="text-[10px] font-bold truncate w-full text-center">
 @{user.username}
 </span>
 <span className="text-[9px] text-muted-foreground">
 {user.followers_count} متابع
 </span>
 </button>
 ))}
 </div>
 </div>
 )}
 {posts.map((post, i) => (
 <div key={post.id}>
 <PostCard post={post} profile={post.profile as Profile} />
 </div>
 ))}
 </div>
 )
 ) : tab === 'people' ? (
 people.length === 0 ? (
 <EmptyState icon={<Users className="w-7 h-7" />} title="لا يوجد مستخدمون" desc={debouncedSearch ? `لا توجد نتائج لـ "${debouncedSearch}"` : 'لا يوجد مستخدمون بعد'} />
 ) : (
 <div className="space-y-2">
 {debouncedSearch && (
 <p className="text-xs text-muted-foreground px-1 pb-2">
 {people.length} نتيجة لـ "{debouncedSearch}"
 </p>
 )}
 {people.map((person, i) => (
 <button
 key={person.id}
 onClick={() => router.push(`/profile/${person.username}`)}
 className="w-full rounded-2xl bg-foreground/5 p-3 flex items-center gap-3 mishri-press mishri-hover-lift transition-colors duration-200"
 >
 {person.avatar_url ? (
 <img src={person.avatar_url} alt={person.display_name || person.username || 'مستخدم'} className="w-12 h-12 rounded-2xl object-cover flex-shrink-0" />
 ) : (
 <div
 className="w-12 h-12 rounded-2xl flex items-center justify-center text-white font-bold text-lg shadow-md flex-shrink-0"
 style={{ background: `linear-gradient(135deg, ${person.avatar_color || '#FBBF24'} 0%, ${person.avatar_color || '#FBBF24'}cc 100%)` }}
 >
 {(person.display_name || person.username || '؟').charAt(0).toUpperCase()}
 </div>
 )}
 <div className="flex-1 text-right min-w-0">
 <div className="text-sm font-bold truncate">{person.display_name || person.username}</div>
 <div className="text-xs text-muted-foreground" dir="ltr">@{person.username}</div>
 {person.bio && <div className="text-[11px] text-muted-foreground truncate mt-0.5">{person.bio}</div>}
 </div>
 <div className="text-left flex-shrink-0">
 <div className="text-xs font-bold tabular-nums">{person.followers_count || 0}</div>
 <div className="text-[10px] text-muted-foreground">متابع</div>
 </div>
 </button>
 ))}
 </div>
 )
 ) : (
 tags.length === 0 ? (
 <EmptyState icon={<Hash className="w-7 h-7" />} title="لا توجد وسوم" desc={debouncedSearch ? `لا توجد وسوم لـ "${debouncedSearch}"` : 'لم يُستخدم أي وسم بعد'} />
 ) : (
 <div className="flex flex-wrap gap-2">
 {tags.map((t, i) => (
 <button
 key={t.tag}
 onClick={() => {
 setSearch(t.tag)
 setTab('trending')
 }}
 className="rounded-xl bg-foreground/5 rounded-full px-4 py-2 flex items-center gap-2 mishri-press mishri-hover-lift transition-colors duration-200"
 >
 <span className="text-xs font-semibold" dir="ltr">#{t.tag}</span>
 <span className="text-[10px] text-muted-foreground tabular-nums">{t.count}</span>
 </button>
 ))}
 </div>
 )
 )}
 </div>
 </div>
 </div>
 )
}

// ========================================
// مكونات مساعدة
// ========================================

function TabButton({ active, onClick, icon: Icon, label }: { active: boolean; onClick: () => void; icon: typeof TrendingUp; label: string }) {
 return (
 <button
 onClick={onClick}
 className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
 active ? 'bg-white dark:bg-white/10 text-amber-500 shadow-sm' : 'text-muted-foreground'
 }`}
 >
 <Icon className="w-3.5 h-3.5" />
 {label}
 </button>
 )
}

function FilterChip({ active, onClick, icon, label }: { active: boolean; onClick: () => void; icon?: React.ReactNode; label: string }) {
 return (
 <button
 onClick={onClick}
 className={`flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-colors ${
 active ? 'mishri-gradient-primary text-white shadow-md' : 'bg-foreground/5 text-muted-foreground hover:bg-foreground/10'
 }`}
 >
 {icon}
 {label}
 </button>
 )
}

function SortBtn({ active, onClick, icon: Icon, label }: { active: boolean; onClick: () => void; icon: typeof Clock; label: string }) {
 return (
 <button
 onClick={onClick}
 className={`flex-1 flex items-center justify-center gap-1 py-1.5 rounded-lg text-xs font-semibold transition-all ${
 active ? 'bg-white dark:bg-white/10 text-amber-500 shadow-sm' : 'text-muted-foreground'
 }`}
 >
 <Icon className="w-3.5 h-3.5" />
 {label}
 </button>
 )
}

function MoodChip({ active, onClick, icon, label, color }: { active: boolean; onClick: () => void; icon?: React.ReactNode; label: string; color?: string }) {
 return (
 <button
 onClick={onClick}
 className={`flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
 active ? 'shadow-md' : 'bg-foreground/5 hover:bg-foreground/10'
 }`}
 style={active && color ? { background: `${color}25`, border: `1.5px solid ${color}` } : { border: '1.5px solid transparent' }}
 >
 {icon}
 <span style={{ color: active && color ? color : undefined }}>{label}</span>
 </button>
 )
}

function EmptyState({ icon, title, desc }: { icon: React.ReactNode; title: string; desc: string }) {
 return (
 <div className="text-center py-16">
 <div className="w-14 h-14 mx-auto mb-3 rounded-2xl rounded-xl bg-foreground/5 flex items-center justify-center text-muted-foreground">
 {icon}
 </div>
 <h3 className="font-bold text-sm mb-1">{title}</h3>
 <p className="text-xs text-muted-foreground max-w-xs mx-auto">{desc}</p>
 </div>
 )
}
