'use client'

import { useState, useEffect, useCallback, useRef } from 'react'
import { Search as SearchIcon, Loader2, ArrowDown } from 'lucide-react'
import { useRouter } from 'next/navigation'
import { supabase, type Post } from '@/lib/supabase/client'
import { useAppStore } from '@/store/app-store'
import { PostCard } from './PostCard'
import { fetchFeed, type FeedType } from '@/lib/feed'
import { useNotificationSound } from '@/hooks/use-sound'
import { usePageCache } from '@/hooks/use-page-cache'
import { fetchBlockedUserIds } from '@/lib/moderation'
import { toast } from 'sonner'

type SortBy = 'recent' | 'popular'

export function HomePage() {
 const user = useAppStore((s) => s.user)
 const router = useRouter()

 const [posts, setPosts] = useState<Post[]>([])
 // لا نعرض loading إذا كان لدينا بيانات — تحديث في الخلفية فقط
 const [loading, setLoading] = useState(true)
 const [refreshing, setRefreshing] = useState(false)
 const [sortBy, setSortBy] = useState<SortBy>('recent')
 const [feedType, setFeedType] = useState<FeedType>('for-you')
 const [likedPosts, setLikedPosts] = useState<Record<string, boolean>>({})
 const likedPostsRef = useRef<Record<string, boolean>>({})
 const lastRefreshRef = useRef<number>(Date.now())
 const blockedIdsRef = useRef<Set<string>>(new Set())
 const hasInitialLoad = useRef(false)
 const { playSound } = useNotificationSound()

 // === scroll tracking للـ header (Facebook-style) ===
 const [headerVisible, setHeaderVisible] = useState(true)
 const [pullDistance, setPullDistance] = useState(0)
 const [isPulling, setIsPulling] = useState(false)
 const scrollRef = useRef<HTMLDivElement>(null)
 const startYRef = useRef<number>(0)
 const lastScrollYRef = useRef<number>(0)

 // scroll restoration + background sync
 usePageCache('home', {
 onBackgroundSync: async () => {
 // مزامنة خلفية صامتة (بدون loading)
 if (!user) return
 try {
 const result = await fetchFeed(feedType, user.id, 30)
 let finalPosts = result.posts
 if (sortBy === 'popular' && feedType !== 'trending') {
 finalPosts = [...result.posts].sort((a, b) => (b.likes_count || 0) - (a.likes_count || 0))
 }
 // تحديث صامت بدون إظهار loading
 setPosts(finalPosts.map((p) => ({ ...p, user_liked: likedPostsRef.current[p.id] ?? false })))
 } catch {
 // تجاهل الأخطاء في المزامنة الخلفية
 }
 },
 backgroundSyncInterval: 60000, // دقيقة
 })

 const handleLikesUpdated = useCallback((postId: string, liked: boolean) => {
 setLikedPosts((prev) => {
 const updated = { ...prev, [postId]: liked }
 likedPostsRef.current = updated
 return updated
 })
 }, [])

 const fetchPosts = useCallback(async (silent = false) => {
 // إذا لدينا بيانات بالفعل، لا نعرض loading — تحديث في الخلفية
 if (!silent && !hasInitialLoad.current) {
 setLoading(true)
 }
 try {
 if (user && blockedIdsRef.current.size === 0) {
 blockedIdsRef.current = await fetchBlockedUserIds(user.id)
 }

 if (user) {
 const result = await fetchFeed(feedType, user.id, 30)
 let finalPosts = result.posts
 if (sortBy === 'popular' && feedType !== 'trending') {
 finalPosts = [...result.posts].sort((a, b) => (b.likes_count || 0) - (a.likes_count || 0))
 }
 // فلترة المنشورات من مستخدمين محجوبين
 if (blockedIdsRef.current.size > 0) {
 finalPosts = finalPosts.filter((p) => !blockedIdsRef.current.has(p.user_id))
 }
 setPosts(finalPosts.map((p) => ({ ...p, user_liked: likedPostsRef.current[p.id] ?? false })))
 } else {
 let query = supabase
 .from('posts')
 .select('*, profile:profiles(*)')
 .is('repost_of', null)

 if (sortBy === 'popular') {
 query = query.order('likes_count', { ascending: false })
 } else {
 query = query.order('created_at', { ascending: false })
 }
 query = query.limit(50)

 const { data, error } = await query
 if (error) {
 if (!silent) toast.error('تعذّر تحميل المنشورات')
 } else if (data) {
 setPosts(data.map((p) => ({
 ...p,
 user_liked: likedPostsRef.current[p.id] ?? false,
 })))
 }
 }
 } catch (err) {
 // [removed in production] err
 } finally {
 hasInitialLoad.current = true
 if (!silent) setLoading(false)
 lastRefreshRef.current = Date.now()
 }
 }, [sortBy, user, feedType])

 useEffect(() => { void fetchPosts() }, [fetchPosts])

 // التحديث التلقائي تم استبداله بـ usePageCache background sync (صامت في الخلفية)

 const handleRefresh = async () => {
 setRefreshing(true)
 await fetchPosts(true)
 setRefreshing(false)
 playSound('success')
 toast.success('تم التحديث')
 }

 // البث المباشر — محذوف للأداء (التطبيق يحدث عند العودة للصفحة)

 // === scroll handler: hide/show header (Facebook-style) ===
 const handleScroll = useCallback(() => {
 const el = scrollRef.current
 if (!el) return

 const scrollTop = el.scrollTop
 const prev = lastScrollYRef.current
 const delta = scrollTop - prev

 if (scrollTop > 80 && delta > 3) {
 setHeaderVisible(false)
 } else if (delta < -3 || scrollTop < 80) {
 setHeaderVisible(true)
 }
 lastScrollYRef.current = scrollTop
 }, [])

 // === pull-to-refresh ===
 const handleTouchStart = useCallback((e: React.TouchEvent) => {
 const el = scrollRef.current
 if (!el || el.scrollTop > 0) return
 startYRef.current = e.touches[0].clientY
 setIsPulling(true)
 }, [])

 const handleTouchMove = useCallback((e: React.TouchEvent) => {
 if (!isPulling) return
 const pull = e.touches[0].clientY - startYRef.current
 if (pull > 0 && pull < 120) {
 setPullDistance(Math.min(pull * 0.5, 60))
 }
 }, [isPulling])

 const handleTouchEnd = useCallback(async () => {
 if (pullDistance > 35) {
 setRefreshing(true)
 setPullDistance(60)
 await fetchPosts(true)
 toast.success('تم التحديث')
 } else {
 setPullDistance(0)
 }
 setIsPulling(false)
 }, [pullDistance, fetchPosts])

 return (
 <div className="flex flex-col flex-1 min-h-0">
 {/* رأس يختبئ مع التمرير للأسفل (Facebook-style) */}
 <header
 className={`flex-shrink-0 border-b border-foreground/8 bg-background/80 backdrop-blur-xl z-40 header-transition ${
 headerVisible ? 'header-visible' : 'header-hidden'
 }`}
 style={{ paddingTop: 'env(safe-area-inset-top, 0px)' }}
 >
 <div className="max-w-md mx-auto px-4 py-2">
 <div className="flex items-center justify-between">
 <h1 className="font-display text-xl font-bold mishri-gradient-text">KemetNet</h1>
 <button onClick={() => router.push('/explore')} className="w-8 h-8 rounded-full hover:bg-foreground/5 flex items-center justify-center transition-colors" aria-label="بحث">
 <SearchIcon className="w-[18px] h-[18px] text-foreground" strokeWidth={1.8} />
 </button>
 </div>

 {/* نوع الخلاصة — أزرار رفيعة */}
 {user && (
 <div className="flex gap-1.5 mt-2">
 <FeedTab active={feedType === 'for-you'} onClick={() => { setFeedType('for-you'); setSortBy('recent') }} label="لك" />
 <FeedTab active={feedType === 'following'} onClick={() => { setFeedType('following'); setSortBy('recent') }} label="متابعوك" />
 <FeedTab active={feedType === 'trending'} onClick={() => { setFeedType('trending'); setSortBy('popular') }} label="رائج" />
 </div>
 )}
 </div>
 </header>

 {/* قائمة المنشورات + pull-to-refresh */}
 <div
 ref={scrollRef}
 data-scroll-area
 className="flex-1 overflow-y-auto overscroll-y-contain"
 onScroll={handleScroll}
 onTouchStart={handleTouchStart}
 onTouchMove={handleTouchMove}
 onTouchEnd={handleTouchEnd}
 style={{ touchAction: 'pan-y' }}
 >
 {/* مؤشر pull-to-refresh */}
 {(refreshing || pullDistance > 0) && (
 <div
 className="flex items-center justify-center overflow-hidden transition-all"
 style={{ height: refreshing ? 60 : pullDistance }}
 >
 {refreshing ? (
 <Loader2 className="w-5 h-5 text-amber-500 animate-spin" />
 ) : pullDistance > 35 ? (
 <ArrowDown className="w-4 h-4 text-amber-500 rotate-180 transition-transform" />
 ) : (
 <ArrowDown className="w-4 h-4 text-muted-foreground" />
 )}
 </div>
 )}

 <main className="max-w-md mx-auto pb-4">
 {loading ? (
 <div className="space-y-4">
 {Array.from({ length: 3 }).map((_, i) => (
 <PostCardSkeleton key={i} />
 ))}
 </div>
 ) : posts.length === 0 ? (
 <EmptyState feedType={feedType} />
 ) : (
 <div>
 {posts.map((post) => (
 <PostCard
 key={post.id}
 post={post}
 profile={post.profile}
 onLikesUpdated={handleLikesUpdated}
 />
 ))}
 </div>
 )}
 </main>
 </div>
 </div>
 )
}

// ========================================

function FeedTab({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
 return (
 <button
 onClick={onClick}
 className={`px-4 py-1.5 rounded-full text-sm font-bold transition-colors ${
 active
 ? 'bg-foreground text-background'
 : 'text-muted-foreground hover:bg-foreground/5'
 }`}
 >
 {label}
 </button>
 )
}

function EmptyState({ feedType }: { feedType?: string }) {
 const isFollowing = feedType === 'following'
 return (
 <div className="text-center py-16 px-6">
 {isFollowing ? (
 <>
 <p className="text-sm font-bold mb-1">لا توجد منشورات من متابعيك</p>
 <p className="text-xs text-muted-foreground leading-relaxed">
 ابدأ بمتابعة مستخدمين آخرين لرؤية منشوراتهم هنا
 </p>
 </>
 ) : (
 <p className="text-sm text-muted-foreground">لا توجد منشورات بعد</p>
 )}
 </div>
 )
}

function PostCardSkeleton() {
 return (
 <div className="bg-background border-b border-foreground/5">
 <div className="flex items-center gap-2.5 px-3 py-2.5">
 <div className="w-9 h-9 rounded-full bg-foreground/10 mishri-shimmer" />
 <div className="flex-1">
 <div className="h-3 w-24 bg-foreground/10 rounded mishri-shimmer mb-1.5" />
 <div className="h-2 w-12 bg-foreground/5 rounded mishri-shimmer" />
 </div>
 </div>
 <div className="px-3 pb-2 space-y-2">
 <div className="h-3 w-full bg-foreground/10 rounded mishri-shimmer" />
 <div className="h-3 w-3/4 bg-foreground/10 rounded mishri-shimmer" />
 </div>
 </div>
 )
}

// زر العودة للأعلى
// (يُستخدم في layout المنطقة الرئيسية)
