'use client'

import { useState, useEffect, useRef, useCallback } from 'react'

interface SmartImageProps {
  src: string
  alt: string
  className?: string
  aspectRatio?: number
  showPlaceholder?: boolean
  onClick?: () => void
  loading?: 'lazy' | 'eager'
}

/**
 * صورة ذكية مع:
 * - lazy loading
 * - blur placeholder أثناء التحميل
 * - fade-in سلس عند الاكتمال
 * - معالجة أخطاء (fallback)
 * - بدون مكتبات خارجية (CSS فقط)
 */
export function SmartImage({
  src,
  alt,
  className = '',
  aspectRatio,
  showPlaceholder = true,
  onClick,
  loading = 'lazy',
}: SmartImageProps) {
  const [loaded, setLoaded] = useState(false)
  const [error, setError] = useState(false)
  const imgRef = useRef<HTMLImageElement>(null)

  // إعادة تعيين الحالة عند تغيير src — بدون استدعاء setState داخل effect مباشرة
  // نستخدم key prop على img بدلاً من إعادة تعيين state
  const imgKey = src

  // فحص إذا كانت الصورة محمّلة بالفعل (من cache)
  const checkCached = useCallback(() => {
    if (imgRef.current?.complete && imgRef.current.naturalWidth > 0) {
      setLoaded(true)
    }
  }, [])

  useEffect(() => {
    // فحص مرة واحدة بعد تركيب المكون
    checkCached()
  }, [checkCached])

  const style: React.CSSProperties = {}
  if (aspectRatio) {
    style.aspectRatio = String(aspectRatio)
  }

  if (error) {
    return (
      <div
        className={`bg-foreground/5 flex items-center justify-center ${className}`}
        style={style}
        onClick={onClick}
      >
        <span className="text-xs text-muted-foreground">تعذّر تحميل الصورة</span>
      </div>
    )
  }

  return (
    <div
      className={`relative overflow-hidden ${className}`}
      style={style}
      onClick={onClick}
    >
      {/* Placeholder */}
      {showPlaceholder && !loaded && (
        <div className="absolute inset-0 mishri-shimmer bg-foreground/5" />
      )}

      {/* الصورة */}
      <img
        key={imgKey}
        ref={imgRef}
        src={src}
        alt={alt}
        loading={loading}
        decoding="async"
        onLoad={() => setLoaded(true)}
        onError={() => setError(true)}
        className={`w-full h-full object-cover transition-opacity duration-200 ${
          loaded ? 'opacity-100' : 'opacity-0'
        }`}
      />
    </div>
  )
}
