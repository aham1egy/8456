'use client'

import { useState, useEffect, useCallback, useRef } from 'react'
import { ArrowLeft, Send, MessageCircle, X, Share2, Link2, Check } from 'lucide-react'
import { useRouter } from 'next/navigation'
import { supabase, type Post, type Profile } from '@/lib/supabase/client'
import { fetchPostComments, addComment, type CommentWithReplies } from '@/lib/comments'
import { useAppStore } from '@/store/app-store'
import { useNotificationSound } from '@/hooks/use-sound'
import { PostCard } from './PostCard'
import { CommentItem } from './CommentItem'
import { MentionsInput } from './MentionsInput'
import { haptic } from '@/hooks/use-haptic-feedback'
import { toast } from 'sonner'

interface PostDetailPageProps {
 postId: string
}

export function PostDetailPage({ postId }: PostDetailPageProps) {
 const user = useAppStore((s) => s.user)
 const router = useRouter()
 const { playSound } = useNotificationSound()

 const [post, setPost] = useState<Post | null>(null)
 const [profile, setProfile] = useState<Profile | null>(null)
 const [comments, setComments] = useState<CommentWithReplies[]>([])
 const [newComment, setNewComment] = useState('')
 const [loading, setLoading] = useState(true)
 const [sending, setSending] = useState(false)
 const [replyTo, setReplyTo] = useState<{ parentId: string; username: string } | null>(null)
 const scrollAreaRef = useRef<HTMLDivElement>(null)

 // ====================
 // جلب المنشور
 // ====================
 const loadPost = useCallback(async () => {
 if (!postId) return
 setLoading(true)
 const { data, error } = await supabase
 .from('posts')
 .select('*, profile:profiles(*)')
 .eq('id', postId)
 .maybeSingle()
 if (error || !data) {
 toast.error('المنشور غير موجود')
 router.replace('/home')
 return
 }
 setPost(data)
 setProfile(data.profile as Profile)
 setLoading(false)
 }, [postId, router])

 // ====================
 // جلب التعليقات
 // ====================
 const loadComments = useCallback(async () => {
 if (!postId) return
 const data = await fetchPostComments(postId, user?.id)
 setComments(data)
 }, [postId, user?.id])

 useEffect(() => {
 if (!postId) {
 router.back()
 return
 }
 let cancelled = false
 void (async () => {
 await loadPost()
 if (!cancelled) await loadComments()
 })()
 return () => {
 cancelled = true
 }
 }, [postId, loadPost, loadComments, router])

 // ====================
 // بث مباشر Realtime للتعليقات
 // ====================
 useEffect(() => {
 if (!postId) return

 const channel = supabase
 .channel(`comments:${postId}`)
 .on(
 'postgres_changes',
 {
 event: '*',
 schema: 'public',
 table: 'comments',
 filter: `post_id=eq.${postId}`,
 },
 async () => {
 await loadComments()
 }
 )
 .on(
 'postgres_changes',
 {
 event: '*',
 schema: 'public',
 table: 'comment_likes',
 },
 async () => {
 await loadComments()
 }
 )
 .subscribe()

 return () => {
 void supabase.removeChannel(channel)
 }
 }, [postId, loadComments])

 // ====================
 // إرسال تعليق أو رد
 // ====================
 const handleComment = async () => {
 if (!newComment.trim() || !user || !postId) return
 setSending(true)

 const contentToSend = newComment.trim()
 const parentId = replyTo?.parentId || null

 // إفراغ الحقل فوراً للإحساس بالسرعة
 setNewComment('')
 if (replyTo) setReplyTo(null)

 try {
 const result = await addComment(postId, user.id, contentToSend, parentId)
 if (result.success) {
 playSound('success')
 // إعادة جلب التعليقات لإظهار التعليق/الرد الجديد
 await loadComments()
 // تمرير للأسفل بعد إرسال تعليق رئيسي (وليس رد)
 if (!parentId && scrollAreaRef.current) {
 setTimeout(() => {
 scrollAreaRef.current?.scrollTo({
 top: scrollAreaRef.current.scrollHeight,
 behavior: 'smooth',
 })
 }, 100)
 }
 } else {
 toast.error(result.error || 'تعذّر إضافة التعليق')
 setNewComment(contentToSend)
 if (parentId) setReplyTo({ parentId, username: replyTo?.username || '' })
 }
 } catch (e) {
 // [removed in production] 'Comment error:', e
 toast.error('حدث خطأ')
 setNewComment(contentToSend)
 } finally {
 setSending(false)
 }
 }

 // ====================
 // بدء الرد على تعليق
 // ====================
 const handleReply = (parentId: string, username: string) => {
 setReplyTo({ parentId, username })
 setTimeout(() => {
 const input = document.getElementById('comment-input') as HTMLInputElement | null
 input?.focus()
 }, 50)
 }

 // ====================
 // إلغاء الرد
 // ====================
 const handleCancelReply = () => {
 setReplyTo(null)
 setNewComment('')
 }

 // ====================
 // حذف تعليق من الواجهة فوراً
 // ====================
 const handleCommentDeleted = (commentId: string) => {
 setComments((prev) => prev.filter((c) => c.id !== commentId))
 setComments((prev) =>
 prev.map((c) => ({
 ...c,
 replies: (c.replies || []).filter((r) => r.id !== commentId),
 }))
 )
 }

 // ====================
 // تعديل تعليق في الواجهة
 // ====================
 const handleCommentEdited = (commentId: string, newContent: string) => {
 setComments((prev) =>
 prev.map((c) => {
 if (c.id === commentId) {
 return { ...c, content: newContent, is_edited: true }
 }
 if (c.replies) {
 return {
 ...c,
 replies: c.replies.map((r) =>
 r.id === commentId
 ? { ...r, content: newContent, is_edited: true }
 : r
 ),
 }
 }
 return c
 })
 )
 }

 // ====================
 // تبديل التثبيت — إعادة ترتيب التعليقات
 // ====================
 const handlePinToggled = (commentId: string, pinned: boolean) => {
 setComments((prev) => {
 const updated = prev.map((c) =>
 c.id === commentId ? { ...c, is_pinned: pinned } : { ...c, is_pinned: false }
 )
 return updated.sort((a, b) => {
 if (a.is_pinned && !b.is_pinned) return -1
 if (!a.is_pinned && b.is_pinned) return 1
 return new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
 })
 })
 }

 if (loading || !post) {
 return (
 <div className="flex items-center justify-center flex-1">
 <div className="mishri-shimmer w-32 h-32 rounded-3xl" />
 </div>
 )
 }

 return (
 <div className="flex flex-col flex-1 min-h-0">
 {/* الرأس — عرض كامل */}
 <header className="flex-shrink-0 bg-background/95 backdrop-blur-xl safe-top z-40 border-b border-foreground/8">
 <div className="w-full px-3 py-2 flex items-center gap-2">
 <button
 onClick={() => router.back()}
 className="p-1.5 rounded-full hover:bg-foreground/5 mishri-press"
 aria-label="رجوع"
 >
 <ArrowLeft className="w-[18px] h-[18px]" />
 </button>
 <h1 className="font-display text-base font-bold flex-1">المنشور</h1>
 <div className="text-xs text-muted-foreground">
 {comments.length} تعليق
 </div>
 {/* أزرار المشاركة */}
 <div className="flex items-center gap-1">
 <button
 onClick={() => {
 const url = window.location.origin + '/post/' + postId
 if (navigator.share) {
 navigator.share({ title: 'KemetNet', text: post.content.slice(0, 100), url })
 } else {
 navigator.clipboard.writeText(url)
 toast.success('تم نسخ الرابط')
 }
 haptic('light')
 }}
 className="p-1.5 rounded-full hover:bg-foreground/5 mishri-press"
 aria-label="مشاركة"
 >
 <Share2 className="w-[18px] h-[18px] text-muted-foreground" />
 </button>
 </div>
 </div>
 </header>

 {/* المحتوى القابل للتمرير */}
 <div
 ref={scrollAreaRef}
 data-scroll-area
 className="flex-1 overflow-y-auto overscroll-y-contain"
 >
 <main className="w-full px-3 pt-3 pb-6">
 {/* المنشور */}
 <div>
 <PostCard post={post} profile={profile} />
 </div>

 {/* قسم التعليقات */}
 <div className="mt-6">
 <h3 className="font-bold text-sm mb-4 flex items-center gap-2">
 <div className="w-1 h-4 rounded-full mishri-gradient-primary" />
 التعليقات
 <span className="text-muted-foreground font-normal">
 ({comments.length})
 </span>
 </h3>

 {comments.length === 0 ? (
 <div className="text-center py-10 rounded-2xl bg-foreground/5">
 <div className="w-14 h-14 mx-auto mb-3 rounded-2xl rounded-xl bg-foreground/5 flex items-center justify-center mishri-float">
 <MessageCircle className="w-7 h-7 text-muted-foreground" />
 </div>
 <p className="text-sm font-semibold mb-1">لا توجد تعليقات بعد</p>
 <p className="text-xs text-muted-foreground">كن أول من يعلّق على هذا المنشور</p>
 </div>
 ) : (
 <div className="space-y-4">
 {comments.map((c, i) => (
 <div
 key={c.id}
 >
 <CommentItem
 comment={c}
 postOwnerId={post.user_id}
 onReply={handleReply}
 onDelete={handleCommentDeleted}
 onEdit={handleCommentEdited}
 onPinToggle={handlePinToggled}
 />
 </div>
 ))}
 </div>
 )}
 </div>
 </main>
 </div>

 {/* صندوق كتابة التعليق — عرض كامل احترافي */}
 <div className="flex-shrink-0 bg-background/95 backdrop-blur-xl border-t border-foreground/8" style={{ paddingBottom: 'env(safe-area-inset-bottom, 0px)' }}>
 <div className="w-full px-3 py-2.5">
 {/* مؤشر الرد */}
 {replyTo && (
 <div
 className="flex items-center justify-between mb-1.5 px-1 text-[11px] text-muted-foreground"
 >
 <span>
 رد على <span className="font-bold text-foreground">@{replyTo.username}</span>
 </span>
 <button
 onClick={handleCancelReply}
 className="p-1 rounded-full hover:bg-foreground/10"
 aria-label="إلغاء الرد"
 >
 <X className="w-3 h-3" />
 </button>
 </div>
 )}

 <div className="flex items-center gap-2">
 {/* صورة المستخدم الحالي */}
 {user && (
 <div className="flex-shrink-0">
 {user.avatar_url ? (
 <img
 src={user.avatar_url}
 alt=""
 className="w-8 h-8 rounded-xl object-cover"
 />
 ) : (
 <div
 className="w-8 h-8 rounded-xl flex items-center justify-center text-white text-xs font-bold"
 style={{
 background: `linear-gradient(135deg, ${user.avatar_color || '#FBBF24'} 0%, ${user.avatar_color || '#FBBF24'}aa 100%)`,
 }}
 >
 {(user.display_name || user.username || '؟').charAt(0).toUpperCase()}
 </div>
 )}
 </div>
 )}

 {/* صندوق الإدخال مع دعم الإشارات */}
 <MentionsInput
 id="comment-input"
 value={newComment}
 onChange={setNewComment}
 onSend={handleComment}
 placeholder={
 replyTo
 ? `الرد على @${replyTo.username}...`
 : 'أضف تعليقاً...'
 }
 maxLength={500}
 disabled={!user || sending}
 className="flex-1 rounded-2xl"
 />

 <button
 onClick={handleComment}
 disabled={!newComment.trim() || !user || sending}
 className="w-9 h-9 rounded-full mishri-gradient-primary text-white flex items-center justify-center disabled:opacity-40 mishri-press mishri-glow-soft flex-shrink-0"
 aria-label="إرسال"
 >
 {sending ? (
 <div
 className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"
 />
 ) : (
 <Send className="w-4 h-4" />
 )}
 </button>
 </div>

 {/* عدّاد الأحرف */}
 {newComment.length > 0 && (
 <div className="text-left mt-1 mr-12">
 <span
 className={`text-[10px] ${
 newComment.length > 450 ? 'text-rose-500' : 'text-muted-foreground'
 }`}
 >
 {newComment.length}/500
 </span>
 </div>
 )}
 </div>
 </div>
 </div>
 )
}
