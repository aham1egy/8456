'use client'

import { useState, useEffect, useCallback } from 'react'
import { Heart, MessageCircle, Share2, MoreHorizontal, Bookmark, Repeat2, Pin, Star } from 'lucide-react'
import { useRouter } from 'next/navigation'
import type { Post, Profile } from '@/lib/supabase/client'
import { supabase, CATEGORIES, MOODS } from '@/lib/supabase/client'
import { useAppStore } from '@/store/app-store'
import { useNotificationSound } from '@/hooks/use-sound'
import { MentionText } from './MentionText'
import { SmartImage } from './SmartImage'
import { ImageLightbox } from './ImageLightbox'
import { ReportModal, BlockConfirmModal } from './ReportModal'
import { VerifiedBadgeMini } from './VerifiedBadge'
import { repostPost, undoRepost, toggleSavePost } from '@/lib/reposts'
import { togglePinPost } from '@/lib/pinned-posts'
import { voteForFeatured, FEATURE_VOTE_THRESHOLD } from '@/lib/featured-posts'
import { haptic } from '@/hooks/use-haptic-feedback'
import { toast } from 'sonner'

interface PostCardProps {
 post: Post
 profile?: Profile | null
 onLikesUpdated?: (postId: string, liked: boolean) => void
}

export function PostCard({ post, profile, onLikesUpdated }: PostCardProps) {
 const [liked, setLiked] = useState(post.user_liked ?? false)
 const [likeCount, setLikeCount] = useState(post.likes_count)
 const [showActions, setShowActions] = useState(false)
 const [showFullText, setShowFullText] = useState(false)
 const [lightboxOpen, setLightboxOpen] = useState(false)
 const [likeInProgress, setLikeInProgress] = useState(false) // M-21: منع double-toggle
 const [showReportModal, setShowReportModal] = useState(false)
 const [showBlockModal, setShowBlockModal] = useState(false)
 const [saved, setSaved] = useState(post.user_saved ?? false)
 const [reposted, setReposted] = useState(false)
 const [repostCount, setRepostCount] = useState(post.reposts_count || 0)
 const [actionInProgress, setActionInProgress] = useState(false)
 const [featuredVoted, setFeaturedVoted] = useState(post.user_voted_featured ?? false)
 const [featureVotes, setFeatureVotes] = useState(post.featured_votes_count || 0)
 const user = useAppStore((s) => s.user)
 const router = useRouter()
 const { playSound } = useNotificationSound()

 const category = CATEGORIES.find((c) => c.id === post.category) || CATEGORIES[0]
 const mood = post.mood ? MOODS.find((m) => m.id === post.mood) : null
 const postProfile = profile || post.profile

 // جلب حالة الإعجاب الحالية من قاعدة البيانات عند تحميل البطاقة
 const fetchLikeStatus = useCallback(async () => {
 if (!user) return
 try {
 const { data, error } = await supabase
 .from('likes')
 .select('id')
 .eq('post_id', post.id)
 .eq('user_id', user.id)
 .maybeSingle()

 if (!error) {
 const isLiked = !!data
 setLiked(isLiked)
 // تحديث المخزن المؤقت
 if (onLikesUpdated) onLikesUpdated(post.id, isLiked)
 }
 } catch (e) {
 // [removed in production] 'Fetch like status error:', e
 }
 }, [user, post.id, onLikesUpdated])

 useEffect(() => {
 if (user && !post.user_liked) {
 void fetchLikeStatus()
 } else {
 setLiked(post.user_liked ?? false)
 }
 }, [user, post.id, post.user_liked, fetchLikeStatus])

 const handleLike = async () => {
 if (!user) {
 toast.error('سجّل الدخول للإعجاب بالمنشورات')
 return
 }
 if (likeInProgress) return
 setLikeInProgress(true)
 haptic('light')

 // تحديث متفائل فوري
 const newLiked = !liked
 setLiked(newLiked)
 setLikeCount((c) => Math.max(0, c + (newLiked ? 1 : -1)))

 try {
 if (newLiked) {
 playSound('like')
 const { error } = await supabase
 .from('likes')
 .insert({ post_id: post.id, user_id: user.id })

 if (error) {
 if (error.message.includes('duplicate') || error.message.includes('unique')) {
 setLiked(true) // موجود بالفعل
 } else if (error.message.includes('Could not find')) {
 toast.error('جدول الإعجابات غير مهيأ', { duration: 3000 })
 } else {
 setLiked(false)
 setLikeCount((c) => Math.max(0, c - 1))
 toast.error('تعذّر تسجيل الإعجاب')
 }
 }
 } else {
 playSound('unlike')
 const { error } = await supabase
 .from('likes')
 .delete()
 .match({ post_id: post.id, user_id: user.id })

 if (error && !error.message.includes('Could not find')) {
 setLiked(true)
 setLikeCount((c) => c + 1)
 }
 }
 if (onLikesUpdated) onLikesUpdated(post.id, newLiked)
 } catch (e) {
 // [removed in production] 'Like error:', e
 setLiked(!newLiked)
 setLikeCount((c) => Math.max(0, c + (newLiked ? -1 : 1)))
 } finally {
 setLikeInProgress(false)
 }
 }

 const handleProfileClick = () => {
 if (!postProfile) return
 router.push(`/profile/${postProfile.username}`)
 }

 // حفظ / إلغاء حفظ المنشور
 const handleSave = async () => {
 if (!user) {
 toast.error('سجّل الدخول لحفظ المنشورات')
 return
 }
 if (actionInProgress) return
 setActionInProgress(true)
 haptic('light')

 // تحديث متفائل
 const newSaved = !saved
 setSaved(newSaved)
 playSound(newSaved ? 'success' : 'unlike')

 try {
 const result = await toggleSavePost(user.id, post.id, !newSaved)
 if (!result.success) {
 setSaved(!newSaved)
 toast.error(result.error || 'تعذّر تحديث الحفظ')
 } else {
 toast.success(newSaved ? 'تم الحفظ' : 'تمت الإزالة من المحفوظات')
 }
 } catch (e) {
 // [removed in production] 'Save error:', e
 setSaved(!newSaved)
 toast.error('حدث خطأ')
 } finally {
 setActionInProgress(false)
 }
 }

 // إعادة نشر / إلغاء إعادة نشر
 const handleRepost = async () => {
 if (!user) {
 toast.error('سجّل الدخول لإعادة النشر')
 return
 }
 if (isOwnPost) {
 toast.error('لا يمكنك إعادة نشر منشورك')
 return
 }
 if (actionInProgress) return
 setActionInProgress(true)
 haptic('medium')

 if (reposted) {
 // إلغاء إعادة النشر
 setReposted(false)
 setRepostCount((c) => Math.max(0, c - 1))
 playSound('unlike')

 try {
 const result = await undoRepost(user.id, post.id)
 if (!result.success) {
 setReposted(true)
 setRepostCount((c) => c + 1)
 toast.error(result.error || 'تعذّر إلغاء إعادة النشر')
 } else {
 toast.success('تم إلغاء إعادة النشر')
 }
 } catch (e) {
 // [removed in production] 'Undo repost error:', e
 setReposted(true)
 setRepostCount((c) => c + 1)
 } finally {
 setActionInProgress(false)
 }
 } else {
 // إعادة النشر
 setReposted(true)
 setRepostCount((c) => c + 1)
 playSound('success')

 try {
 const result = await repostPost(user.id, post.id)
 if (!result.success) {
 setReposted(false)
 setRepostCount((c) => Math.max(0, c - 1))
 toast.error(result.error || 'تعذّر إعادة النشر')
 } else {
 toast.success('تمت إعادة النشر')
 }
 } catch (e) {
 // [removed in production] 'Repost error:', e
 setReposted(false)
 setRepostCount((c) => Math.max(0, c - 1))
 toast.error('حدث خطأ')
 } finally {
 setActionInProgress(false)
 }
 }
 }

 const handlePostClick = () => {
 router.push(`/post/${post.id}`)
 }

 // التصويت على تمييز المنشور
 const handleFeatureVote = async () => {
 if (!user) {
 toast.error('سجّل الدخول للتصويت')
 return
 }
 if (isOwnPost) {
 toast.error('لا يمكنك التصويت على منشورك')
 return
 }
 if (actionInProgress) return
 setActionInProgress(true)
 haptic('light')

 // تحديث متفائل
 const newVoted = !featuredVoted
 setFeaturedVoted(newVoted)
 setFeatureVotes((c) => Math.max(0, c + (newVoted ? 1 : -1)))
 playSound(newVoted ? 'like' : 'unlike')

 try {
 const result = await voteForFeatured(post.id, user.id)
 if (!result.success) {
 setFeaturedVoted(!newVoted)
 setFeatureVotes((c) => Math.max(0, c + (newVoted ? -1 : 1)))
 toast.error(result.error || 'تعذّر التصويت')
 } else if (result.voted !== newVoted) {
 setFeaturedVoted(result.voted || false)
 }
 } catch (e) {
 // [removed in production] 'Feature vote error:', e
 setFeaturedVoted(!newVoted)
 setFeatureVotes((c) => Math.max(0, c + (newVoted ? -1 : 1)))
 } finally {
 setActionInProgress(false)
 }
 }

 const isOwnPost = user?.id === post.user_id
 const timeAgo = getTimeAgo(post.created_at)

 return (
 <article className="bg-background border-b border-foreground/5 relative">
 {/* شارة المنشور المثبت */}
 {post.is_pinned && (
 <div className="absolute top-2 left-2 z-10 px-2 py-0.5 rounded-full bg-amber-500/20 backdrop-blur-md text-amber-600 dark:text-amber-300 text-[10px] font-bold flex items-center gap-1">
 <Pin className="w-2.5 h-2.5 fill-amber-500 text-amber-500" />
 مثبّت
 </div>
 )}
 {/* شارة المنشور المميز */}
 {post.is_featured && (
 <div className="absolute top-2 right-2 z-10 px-2 py-0.5 rounded-full bg-gradient-to-r from-amber-400 to-yellow-500 text-white text-[10px] font-bold flex items-center gap-1 shadow-md">
 <Star className="w-2.5 h-2.5 fill-white" />
 مميّز
 </div>
 )}
 {/* الرأس */}
 <div className="flex items-center justify-between px-3 py-2.5">
 <button onClick={handleProfileClick} className="flex items-center gap-2.5">
 <Avatar profile={postProfile} />
 <div className="text-right">
 <div className="text-sm font-semibold leading-tight flex items-center gap-1">
 <span>{postProfile?.display_name || postProfile?.username || 'مستخدم KemetNet'}</span>
 {postProfile?.is_verified && (
 <VerifiedBadgeMini type={postProfile.verified_type} />
 )}
 </div>
 <div className="text-[11px] text-muted-foreground">
 {timeAgo}
 </div>
 </div>
 </button>
 <button
 onClick={() => setShowActions((v) => !v)}
 className="p-1.5 rounded-full hover:bg-foreground/5 transition-colors"
 >
 <MoreHorizontal className="w-5 h-5 text-muted-foreground" />
 </button>
 </div>

 {/* المحتوى — تصميم Facebook-style */}
 <div onClick={handlePostClick} className="cursor-pointer">
 {/* النص: يظهر سطر واحد فوق الصورة، مع زر "عرض المزيد" */}
 {post.content && (
 <div className="px-3 pb-2">
 <div className={`text-[15px] leading-relaxed text-foreground/90 whitespace-pre-wrap ${
 !showFullText && post.content.length > 100 ? 'line-clamp-2' : ''
 }`}>
 <MentionText text={post.content} />
 </div>
 {post.content.length > 100 && (
 <button
 onClick={(e) => {
 e.stopPropagation()
 setShowFullText((v) => !v)
 }}
 className="text-xs font-semibold text-muted-foreground hover:text-foreground mt-1"
 >
 {showFullText ? 'عرض أقل' : 'عرض المزيد'}
 </button>
 )}
 </div>
 )}

 {/* الصورة — قابلة للنقر لفتح Lightbox */}
 {post.image_url && (
 <div className="overflow-hidden bg-foreground/5 cursor-pointer" onClick={(e) => { e.stopPropagation(); setLightboxOpen(true) }}>
 <SmartImage
 src={post.image_url}
 alt="صورة المنشور"
 />
 </div>
 )}

 {/* الوسوم */}
 {post.tags && post.tags.length > 0 && (
 <div className="flex flex-wrap gap-1.5 px-3 mt-3">
 {post.tags.slice(0, 5).map((tag) => (
 <button
 key={tag}
 onClick={(e) => {
 e.stopPropagation()
 router.push(`/explore?tag=${encodeURIComponent(tag)}`)
 }}
 className="text-[11px] font-medium px-2.5 py-1 rounded-full bg-amber-500/10 text-amber-700 dark:text-amber-300 hover:bg-amber-500/20 transition-colors"
 dir="ltr"
 >
 #{tag}
 </button>
 ))}
 </div>
 )}
 </div>

 {/* الفئة والمود */}
 <div className="flex items-center gap-1.5 px-3 pb-2">
 <span
 className="inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full"
 style={{ background: `${category.color}15`, color: category.color }}
 >
 <category.icon className="w-2.5 h-2.5" />
 {category.label}
 </span>
 {mood && (
 <span
 className="inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full"
 style={{ background: `${mood.color}20`, color: mood.color }}
 >
 <mood.icon className="w-2.5 h-2.5" />
 {mood.label}
 </span>
 )}
 </div>

 {/* الإجراءات */}
 <div className="flex items-center justify-between px-2 py-1.5">
 <div className="flex items-center">
 <button
 onClick={handleLike}
 className="flex items-center gap-1 px-3 py-2 rounded-full hover:bg-rose-500/10 transition-colors"
 aria-label={liked ? 'إزالة الإعجاب' : 'إعجاب'}
 >
 <Heart
 className={`w-[18px] h-[18px] transition-colors duration-200 ${
 liked
 ? 'fill-rose-500 text-rose-500'
 : 'text-muted-foreground hover:text-rose-400'
 }`}
 strokeWidth={liked ? 0 : 2}
 />
 <span className={`text-xs font-bold tabular-nums ${liked ? 'text-rose-500' : 'text-muted-foreground'}`}>
 {likeCount}
 </span>
 </button>

 <button
 onClick={handlePostClick}
 className="flex items-center gap-1 px-3 py-2 rounded-full hover:bg-sky-500/10 transition-colors"
 aria-label="تعليق"
 >
 <MessageCircle className="w-[18px] h-[18px] text-muted-foreground hover:text-sky-400 transition-colors" />
 <span className="text-xs font-bold tabular-nums text-muted-foreground">{post.comments_count}</span>
 </button>

 {!isOwnPost && (
 <button
 onClick={handleRepost}
 disabled={actionInProgress}
 className="flex items-center gap-1 px-3 py-2 rounded-full hover:bg-emerald-500/10 transition-colors disabled:opacity-50"
 aria-label={reposted ? 'إلغاء إعادة النشر' : 'إعادة نشر'}
 >
 <Repeat2
 className={`w-[18px] h-[18px] transition-colors duration-200 ${
 reposted ? 'text-emerald-500' : 'text-muted-foreground hover:text-emerald-400'
 }`}
 strokeWidth={reposted ? 2.5 : 2}
 />
 {repostCount > 0 && (
 <span className={`text-xs font-bold tabular-nums ${reposted ? 'text-emerald-500' : 'text-muted-foreground'}`}>
 {repostCount}
 </span>
 )}
 </button>
 )}

 {!isOwnPost && !post.is_featured && (
 <button
 onClick={handleFeatureVote}
 disabled={actionInProgress}
 className="flex items-center gap-1 px-3 py-2 rounded-full hover:bg-amber-500/10 transition-colors disabled:opacity-50"
 aria-label={featuredVoted ? 'إلغاء التصويت' : 'تصويت للتمييز'}
 >
 <Star
 className={`w-[18px] h-[18px] transition-colors duration-200 ${
 featuredVoted ? 'fill-amber-400 text-amber-400' : 'text-muted-foreground hover:text-amber-400'
 }`}
 strokeWidth={featuredVoted ? 0 : 2}
 />
 {featureVotes > 0 && (
 <span className={`text-xs font-bold tabular-nums ${featuredVoted ? 'text-amber-400' : 'text-muted-foreground'}`}>
 {featureVotes}
 </span>
 )}
 </button>
 )}
 </div>
 <div className="flex items-center">
 <button
 onClick={handleSave}
 disabled={actionInProgress}
 className="p-2 rounded-full hover:bg-foreground/5 transition-colors disabled:opacity-50"
 aria-label={saved ? 'إزالة من المحفوظات' : 'حفظ'}
 >
 <Bookmark
 className={`w-[18px] h-[18px] transition-colors duration-200 ${
 saved ? 'fill-amber-500 text-amber-500' : 'text-muted-foreground hover:text-amber-400'
 }`}
 strokeWidth={saved ? 0 : 2}
 />
 </button>
 <button
 onClick={() => {
 if (navigator.share) {
 navigator.share({ title: 'KemetNet', text: post.content.slice(0, 200), url: window.location.origin + `/post/${post.id}` })
 } else {
 navigator.clipboard?.writeText(post.content.slice(0, 200) + '\n\n' + window.location.origin + `/post/${post.id}`)
 toast.success('تم نسخ الرابط')
 }
 }}
 className="p-2 rounded-full hover:bg-emerald-500/10 transition-colors"
 aria-label="مشاركة"
 >
 <Share2 className="w-[18px] h-[18px] text-muted-foreground hover:text-emerald-400 transition-colors" />
 </button>
 </div>
 </div>

 {showActions && (
 <div className="border-t border-foreground/5 overflow-hidden">
 <div className="p-2 grid grid-cols-3 gap-1">
 {isOwnPost && (
 <ActionMiniButton
 icon="pin"
 label={post.is_pinned ? 'إلغاء التثبيت' : 'تثبيت'}
 onClick={async () => {
 if (!user) return
 const result = await togglePinPost(user.id, post.id, post.is_pinned)
 if (result.success) {
 toast.success(post.is_pinned ? 'تم إلغاء التثبيت' : 'تم تثبيت المنشور')
 playSound('success')
 } else {
 toast.error(result.error || 'تعذّر التحديث')
 }
 }}
 />
 )}
 <ActionMiniButton icon="flag" label="إبلاغ" onClick={() => setShowReportModal(true)} />
 <ActionMiniButton icon="block" label="حجب" onClick={() => setShowBlockModal(true)} />
 <ActionMiniButton icon="copy" label="نسخ" onClick={() => {
 navigator.clipboard?.writeText(post.content)
 toast.success('تم النسخ')
 }} />
 </div>
 </div>
 )}

 {/* مودال الإبلاغ */}
 <ReportModal
 open={showReportModal}
 onClose={() => setShowReportModal(false)}
 targetType="post"
 targetId={post.id}
 reportedUserId={post.user_id}
 reportedUserName={postProfile?.display_name || postProfile?.username}
 />

 {/* مودال الحجب */}
 <BlockConfirmModal
 open={showBlockModal}
 onClose={() => setShowBlockModal(false)}
 blockedUserId={post.user_id}
 blockedUserName={postProfile?.display_name || postProfile?.username}
 onBlocked={() => setShowActions(false)}
 />

 {/* عارض الصور بملء الشاشة */}
 {lightboxOpen && post.image_url && (
 <ImageLightbox
 src={post.image_url}
 alt="صورة المنشور"
 onClose={() => setLightboxOpen(false)}
 />
 )}
 </article>
 )
}

function Avatar({ profile }: { profile?: Profile | null }) {
 if (profile?.avatar_url) {
 return (
 <img
 src={profile.avatar_url}
 alt={profile.display_name || profile.username || 'مستخدم'}
 className="w-9 h-9 rounded-full object-cover"
 />
 )
 }
 return (
 <div
 className="w-9 h-9 rounded-full flex items-center justify-center text-white font-bold text-sm"
 style={{
 background: `linear-gradient(135deg, ${profile?.avatar_color || '#FBBF24'} 0%, ${shiftColor(profile?.avatar_color || '#FBBF24', -40)} 100%)`,
 }}
 >
 {(profile?.display_name || profile?.username || '؟').charAt(0).toUpperCase()}
 </div>
 )
}

function ActionMiniButton({ icon, label, onClick }: { icon: string; label: string; onClick: () => void }) {
 // أيقونات SVG بدل الإيموجي
 const icons: Record<string, React.ReactNode> = {
 flag: <svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" y1="22" x2="4" y2="15"/></svg>,
 block: <svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/></svg>,
 copy: <svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>,
 pin: <Pin className="w-4 h-4" />,
 edit: <svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>,
 trash: <svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>,
 }
 return (
 <button
 onClick={onClick}
 className="flex flex-col items-center gap-1 py-2 rounded-xl hover:bg-foreground/5 transition-colors mishri-press"
 >
 <span className="text-muted-foreground">{icons[icon]}</span>
 <span className="text-[10px] text-muted-foreground font-medium">{label}</span>
 </button>
 )
}

function getTimeAgo(dateStr: string): string {
 const date = new Date(dateStr)
 const now = new Date()
 const diff = (now.getTime() - date.getTime()) / 1000
 if (diff < 60) return 'الآن'
 if (diff < 3600) return `قبل ${Math.floor(diff / 60)} دقيقة`
 if (diff < 86400) return `قبل ${Math.floor(diff / 3600)} ساعة`
 if (diff < 604800) return `قبل ${Math.floor(diff / 86400)} يوم`
 if (diff < 2592000) return `قبل ${Math.floor(diff / 604800)} أسبوع`
 return `قبل ${Math.floor(diff / 2592000)} شهر`
}

function shiftColor(hex: string, amount: number): string {
 const r = parseInt(hex.slice(1, 3), 16)
 const g = parseInt(hex.slice(3, 5), 16)
 const b = parseInt(hex.slice(5, 7), 16)
 const nr = Math.max(0, Math.min(255, r + amount))
 const ng = Math.max(0, Math.min(255, g + amount))
 const nb = Math.max(0, Math.min(255, b + amount))
 return `#${nr.toString(16).padStart(2, '0')}${ng.toString(16).padStart(2, '0')}${nb.toString(16).padStart(2, '0')}`
}
