'use client'

import { useState } from 'react'
import { Download, X, Sparkles } from 'lucide-react'
import { usePwaInstall } from '@/hooks/use-pwa-install'
import { useNotificationSound } from '@/hooks/use-sound'

export function InstallPrompt() {
 const { shouldShowPrompt, promptInstall, dismiss } = usePwaInstall()
 const { playSound } = useNotificationSound()
 const [installing, setInstalling] = useState(false)

 const handleInstall = async () => {
 setInstalling(true)
 const success = await promptInstall()
 if (success) {
 playSound('success')
 }
 setInstalling(false)
 }

 const handleDismiss = () => {
 dismiss()
 playSound('unlike')
 }

 return (
 <>
 {shouldShowPrompt && (
 <div
 className="fixed top-0 left-0 right-0 z-[200] safe-top pointer-events-none transition-colors duration-200"
 >
 <div className="max-w-md mx-auto px-3 pt-2 pointer-events-auto">
 <div className="rounded-xl bg-foreground/5 rounded-2xl p-3 shadow-2xl">
 <div className="flex items-center gap-3">
 {/* الأيقونة */}
 <div className="relative w-12 h-12 rounded-xl mishri-gradient-primary mishri-glow-soft flex items-center justify-center flex-shrink-0">
 <Sparkles className="w-6 h-6 text-white" />
 <div
 className="absolute inset-0 rounded-xl mishri-gradient-primary mishri-pulse"
 />
 </div>

 {/* النص */}
 <div className="flex-1 min-w-0">
 <div className="text-sm font-bold">ثبّت KemetNet على جهازك</div>
 <div className="text-[11px] text-muted-foreground">
 وصول أسرع، تجربة كاملة، يعمل بدون إنترنت
 </div>
 </div>

 {/* أزرار */}
 <div className="flex items-center gap-1.5 flex-shrink-0">
 <button
 onClick={handleDismiss}
 className="w-8 h-8 rounded-full hover:bg-foreground/5 flex items-center justify-center transition-colors"
 aria-label="إغلاق"
 >
 <X className="w-4 h-4 text-muted-foreground" />
 </button>
 <button
 onClick={handleInstall}
 disabled={installing}
 className="px-4 py-2 rounded-xl mishri-gradient-primary text-white text-xs font-bold shadow-md mishri-glow-soft disabled:opacity-50 flex items-center gap-1.5 transition-colors duration-200"
 >
 {installing ? (
 <>
 <div
 className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin"
 />
 جارٍ...
 </>
 ) : (
 <>
 <Download className="w-3.5 h-3.5" />
 تثبيت
 </>
 )}
 </button>
 </div>
 </div>
 </div>
 </div>
 </div>
 )}
 </>
 )
}
