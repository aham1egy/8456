'use client'

import { useState, useRef, useEffect, useCallback } from 'react'
import {
 Crop, RotateCw, ZoomIn, ZoomOut, Check, X, Sun, Contrast,
 Droplets, RotateCcw, FlipHorizontal2, FlipVertical2, Maximize2
} from 'lucide-react'

export interface ImageEditResult {
 blob: Blob
 url: string
 width: number
 height: number
}

interface ImageEditorProps {
 file: File
 aspectRatio?: number // 4/5 افتراضيًا للمنشورات، 1 للبروفيل
 onSave: (result: ImageEditResult) => void
 onCancel: () => void
 title?: string
}

type AdjustKey = 'brightness' | 'contrast' | 'saturation' | 'warmth' | 'sharpness' | 'vignette' | 'blur' | 'rotation' | 'zoom' | 'flipH' | 'flipV'

const ADJUST_DEFAULTS: Record<AdjustKey, number> = {
 brightness: 100,
 contrast: 100,
 saturation: 100,
 warmth: 0, // -100 to 100 (دافئ/بارد)
 sharpness: 0, // 0 to 100
 vignette: 0, // 0 to 100
 blur: 0, // 0 to 20 (px)
 rotation: 0,
 zoom: 1,
 flipH: 1,
 flipV: 1,
}

const FILTERS = [
 { id: 'none', label: 'أصلي', css: 'none' },
 { id: 'warm', label: 'دافئ', css: 'sepia(0.3) saturate(1.4) hue-rotate(-10deg)' },
 { id: 'cool', label: 'بارد', css: 'hue-rotate(180deg) saturate(0.8) brightness(1.05)' },
 { id: 'vivid', label: 'حيوي', css: 'saturate(1.6) contrast(1.1)' },
 { id: 'mono', label: 'أحادي', css: 'grayscale(1) contrast(1.1)' },
 { id: 'vintage', label: 'كلاسيكي', css: 'sepia(0.5) contrast(1.1) brightness(0.95) saturate(1.3)' },
 { id: 'fade', label: 'باهت', css: 'saturate(0.6) brightness(1.1) contrast(0.9)' },
 { id: 'dramatic', label: 'درامي', css: 'contrast(1.4) saturate(1.2) brightness(0.95)' },
 { id: 'noir', label: 'نوار', css: 'grayscale(1) contrast(1.5) brightness(0.85)' },
 { id: 'sunset', label: 'غروب', css: 'sepia(0.4) saturate(1.8) hue-rotate(-20deg) brightness(1.1)' },
 { id: 'forest', label: 'غابة', css: 'hue-rotate(60deg) saturate(1.3) brightness(0.95)' },
 { id: 'ocean', label: 'محيط', css: 'hue-rotate(150deg) saturate(1.4) brightness(1.05) contrast(1.1)' },
 { id: 'rose', label: 'وردي', css: 'sepia(0.2) saturate(1.5) hue-rotate(300deg) brightness(1.05)' },
 { id: 'gold', label: 'ذهبي', css: 'sepia(0.6) saturate(1.8) hue-rotate(-15deg) brightness(1.1) contrast(1.1)' },
 { id: 'retro', label: 'ريترو', css: 'sepia(0.4) saturate(0.8) contrast(1.2) brightness(0.9) hue-rotate(-5deg)' },
 { id: 'cinematic', label: 'سينمائي', css: 'contrast(1.3) saturate(1.1) brightness(0.92) sepia(0.15)' },
]

export function ImageEditor({
 file,
 aspectRatio = 4 / 5,
 onSave,
 onCancel,
 title = 'تحرير الصورة',
}: ImageEditorProps) {
 const canvasRef = useRef<HTMLCanvasElement>(null)
 const imgRef = useRef<HTMLImageElement | null>(null)
 const [imgLoaded, setImgLoaded] = useState(false)
 const [activeTab, setActiveTab] = useState<'adjust' | 'filters' | 'crop'>('crop')
 const [adjust, setAdjust] = useState({ ...ADJUST_DEFAULTS })
 const [activeFilter, setActiveFilter] = useState('none')
 const [cropPos, setCropPos] = useState({ x: 0, y: 0 })
 const [isDragging, setIsDragging] = useState(false)
 const dragStart = useRef({ x: 0, y: 0 })

 // تحميل الصورة
 useEffect(() => {
 const url = URL.createObjectURL(file)
 const img = new Image()
 img.onload = () => {
 imgRef.current = img
 setImgLoaded(true)
 // توسيط المحاصصة
 setCropPos({ x: 0, y: 0 })
 }
 img.src = url
 return () => URL.revokeObjectURL(url)
 }, [file])

 // رسم المعاينة
 const drawPreview = useCallback(() => {
 const canvas = canvasRef.current
 const img = imgRef.current
 if (!canvas || !img || !imgLoaded) return

 const ctx = canvas.getContext('2d')
 if (!ctx) return

 // أبعاد الكانفاس حسب نسبة العرض
 const canvasW = 400
 const canvasH = Math.round(canvasW / aspectRatio)
 canvas.width = canvasW
 canvas.height = canvasH

 ctx.save()
 ctx.clearRect(0, 0, canvasW, canvasH)

 // بناء سلسلة الفلتر CSS
 const filterCss = FILTERS.find((f) => f.id === activeFilter)?.css || 'none'

 // تعديلات يدوية
 const warmthHue = adjust.warmth > 0 ? `hue-rotate(-${adjust.warmth * 0.3}deg)` : adjust.warmth < 0 ? `hue-rotate(${Math.abs(adjust.warmth) * 0.3}deg)` : ''
 const warmthSepia = adjust.warmth > 0 ? `sepia(${adjust.warmth / 200})` : ''
 const warmthSaturate = adjust.warmth < 0 ? `saturate(${1 + adjust.warmth / 200})` : 'saturate(1.05)'

 const blurPx = adjust.blur > 0 ? `blur(${adjust.blur}px)` : ''

 const fullFilter = [
 filterCss !== 'none' ? filterCss : '',
 `brightness(${adjust.brightness}%)`,
 `contrast(${adjust.contrast}%)`,
 `saturate(${adjust.saturation}%)`,
 warmthHue,
 warmthSepia,
 warmthSaturate,
 blurPx,
 ].filter(Boolean).join(' ')

 // تطبيق التحويلات + الفلتر
 ctx.filter = fullFilter
 ctx.translate(canvasW / 2, canvasH / 2)
 ctx.rotate((adjust.rotation * Math.PI) / 180)
 ctx.scale(adjust.flipH, adjust.flipV)
 ctx.scale(adjust.zoom, adjust.zoom)

 // حساب أبعاد الصورة لتناسب النسبة
 const imgRatio = img.width / img.height
 const targetRatio = aspectRatio
 let drawW: number, drawH: number

 if (imgRatio > targetRatio) {
 drawH = canvasH
 drawW = drawH * imgRatio
 } else {
 drawW = canvasW
 drawH = drawW / imgRatio
 }

 // تطبيق الإزاحة (crop)
 const offsetX = -drawW / 2 - cropPos.x
 const offsetY = -drawH / 2 - cropPos.y

 ctx.drawImage(img, offsetX, offsetY, drawW, drawH)
 ctx.restore()

 // تطبيق vignette (تعتيم الحواف)
 if (adjust.vignette > 0) {
 ctx.save()
 const gradient = ctx.createRadialGradient(
 canvasW / 2,
 canvasH / 2,
 Math.min(canvasW, canvasH) * 0.3,
 canvasW / 2,
 canvasH / 2,
 Math.max(canvasW, canvasH) * 0.7
 )
 gradient.addColorStop(0, 'rgba(0, 0, 0, 0)')
 gradient.addColorStop(1, `rgba(0, 0, 0, ${adjust.vignette / 100})`)
 ctx.fillStyle = gradient
 ctx.fillRect(0, 0, canvasW, canvasH)
 ctx.restore()
 }
 }, [imgLoaded, adjust, activeFilter, cropPos, aspectRatio])

 useEffect(() => {
 drawPreview()
 }, [drawPreview])

 // معالجة السحب للقص
 const handlePointerDown = (e: React.PointerEvent) => {
 if (activeTab !== 'crop') return
 setIsDragging(true)
 dragStart.current = { x: e.clientX - cropPos.x, y: e.clientY - cropPos.y }
 e.currentTarget.setPointerCapture(e.pointerId)
 }

 const handlePointerMove = (e: React.PointerEvent) => {
 if (!isDragging) return
 setCropPos({
 x: e.clientX - dragStart.current.x,
 y: e.clientY - dragStart.current.y,
 })
 }

 const handlePointerUp = () => {
 setIsDragging(false)
 }

 // حفظ الصورة
 const handleSave = () => {
 const canvas = canvasRef.current
 const img = imgRef.current
 if (!canvas || !img) return

 // إنشاء canvas عالي الدقة
 const maxW = 1080
 const outW = maxW
 const outH = Math.round(maxW / aspectRatio)
 const outCanvas = document.createElement('canvas')
 outCanvas.width = outW
 outCanvas.height = outH
 const ctx = outCanvas.getContext('2d')
 if (!ctx) return

 // بناء سلسلة الفلتر الكاملة (نفس المعاينة)
 const filterCss = FILTERS.find((f) => f.id === activeFilter)?.css || 'none'
 const warmthHue = adjust.warmth > 0 ? `hue-rotate(-${adjust.warmth * 0.3}deg)` : adjust.warmth < 0 ? `hue-rotate(${Math.abs(adjust.warmth) * 0.3}deg)` : ''
 const warmthSepia = adjust.warmth > 0 ? `sepia(${adjust.warmth / 200})` : ''
 const warmthSaturate = adjust.warmth < 0 ? `saturate(${1 + adjust.warmth / 200})` : 'saturate(1.05)'
 const blurPxScaled = adjust.blur > 0 ? `blur(${adjust.blur * (outW / 400)}px)` : ''

 const fullFilter = [
 filterCss !== 'none' ? filterCss : '',
 `brightness(${adjust.brightness}%)`,
 `contrast(${adjust.contrast}%)`,
 `saturate(${adjust.saturation}%)`,
 warmthHue,
 warmthSepia,
 warmthSaturate,
 blurPxScaled,
 ].filter(Boolean).join(' ')

 ctx.filter = fullFilter

 ctx.save()
 ctx.translate(outW / 2, outH / 2)
 ctx.rotate((adjust.rotation * Math.PI) / 180)
 ctx.scale(adjust.flipH, adjust.flipV)
 ctx.scale(adjust.zoom, adjust.zoom)

 const imgRatio = img.width / img.height
 let drawW: number, drawH: number
 if (imgRatio > aspectRatio) {
 drawH = outH
 drawW = drawH * imgRatio
 } else {
 drawW = outW
 drawH = drawW / imgRatio
 }

 // تكبير cropPos للحجم الكامل
 const scale = outW / 400
 const offsetX = -drawW / 2 - cropPos.x * scale
 const offsetY = -drawH / 2 - cropPos.y * scale

 ctx.drawImage(img, offsetX, offsetY, drawW, drawH)
 ctx.restore()

 // تطبيق vignette على الصورة عالية الدقة
 if (adjust.vignette > 0) {
 ctx.save()
 const gradient = ctx.createRadialGradient(
 outW / 2,
 outH / 2,
 Math.min(outW, outH) * 0.3,
 outW / 2,
 outH / 2,
 Math.max(outW, outH) * 0.7
 )
 gradient.addColorStop(0, 'rgba(0, 0, 0, 0)')
 gradient.addColorStop(1, `rgba(0, 0, 0, ${adjust.vignette / 100})`)
 ctx.fillStyle = gradient
 ctx.fillRect(0, 0, outW, outH)
 ctx.restore()
 }

 outCanvas.toBlob((blob) => {
 if (!blob) return
 const url = URL.createObjectURL(blob)
 onSave({ blob, url, width: outW, height: outH })
 }, 'image/jpeg', 0.92)
 }

 const resetAdjust = () => {
 setAdjust({ ...ADJUST_DEFAULTS })
 setActiveFilter('none')
 setCropPos({ x: 0, y: 0 })
 }

 const setAdjustValue = (key: AdjustKey, value: number) => {
 setAdjust((prev) => ({ ...prev, [key]: value }))
 }

 return (
 <div
 className="fixed inset-0 z-[100] bg-black flex flex-col transition-colors duration-200"
 onClick={(e) => e.stopPropagation()}
 >
 {/* الرأس */}
 <div className="flex items-center justify-between p-4 safe-top bg-black">
 <button
 onClick={onCancel}
 className="w-10 h-10 rounded-full bg-white/10 text-white flex items-center justify-center"
 aria-label="إلغاء"
 >
 <X className="w-5 h-5" />
 </button>
 <h2 className="text-white font-bold text-sm">{title}</h2>
 <button
 onClick={handleSave}
 className="px-4 py-2 rounded-full mishri-gradient-primary text-white text-xs font-bold mishri-glow-soft"
 >
 حفظ
 </button>
 </div>

 {/* منطقة المعاينة */}
 <div className="flex-1 flex items-center justify-center overflow-hidden relative">
 {!imgLoaded ? (
 <div className="text-white/50 text-sm">جارٍ تحميل الصورة...</div>
 ) : (
 <div
 className="relative"
 style={{ width: 'min(90vw, 400px)', aspectRatio: aspectRatio }}
 onPointerDown={handlePointerDown}
 onPointerMove={handlePointerMove}
 onPointerUp={handlePointerUp}
 >
 <canvas
 ref={canvasRef}
 className="w-full h-full rounded-2xl touch-none cursor-grab active:cursor-grabbing"
 style={{ aspectRatio }}
 />
 {activeTab === 'crop' && (
 <div className="absolute inset-0 pointer-events-none rounded-2xl border-2 border-white/30">
 <div className="absolute inset-0 grid grid-cols-3 grid-rows-3">
 {Array.from({ length: 9 }).map((_, i) => (
 <div key={i} className="border border-white/10" />
 ))}
 </div>
 </div>
 )}
 </div>
 )}
 </div>

 {/* أزرار سريعة */}
 <div className="flex items-center justify-center gap-2 pb-2 px-4">
 <QuickBtn icon={RotateCcw} onClick={() => setAdjustValue('rotation', adjust.rotation - 90)} label="يسار" />
 <QuickBtn icon={RotateCw} onClick={() => setAdjustValue('rotation', adjust.rotation + 90)} label="يمين" />
 <QuickBtn icon={FlipHorizontal2} onClick={() => setAdjustValue('flipH', -adjust.flipH)} label="عكس أفقي" />
 <QuickBtn icon={FlipVertical2} onClick={() => setAdjustValue('flipV', -adjust.flipV)} label="عكس رأسي" />
 <QuickBtn icon={Maximize2} onClick={resetAdjust} label="إعادة تعيين" />
 </div>

 {/* التبويبات */}
 <div className="flex bg-white/5 p-1 mx-4 mb-2 rounded-xl">
 <TabBtn active={activeTab === 'crop'} onClick={() => setActiveTab('crop')} icon={Crop} label="قص" />
 <TabBtn active={activeTab === 'filters'} onClick={() => setActiveTab('filters')} icon={Sun} label="فلاتر" />
 <TabBtn active={activeTab === 'adjust'} onClick={() => setActiveTab('adjust')} icon={Contrast} label="تعديل" />
 </div>

 {/* لوحة التحكم */}
 <div className="bg-black px-4 pb-6 safe-bottom min-h-[140px]">
 {activeTab === 'crop' && (
 <div className="space-y-3">
 <SliderControl
 icon={<ZoomIn className="w-4 h-4" />}
 label="تكبير"
 value={adjust.zoom}
 min={1}
 max={3}
 step={0.1}
 onChange={(v) => setAdjustValue('zoom', v)}
 />
 <p className="text-white/40 text-[11px] text-center">
 اسحب الصورة لتحريكها داخل الإطار
 </p>
 </div>
 )}

 {activeTab === 'filters' && (
 <div className="overflow-x-auto">
 <div className="flex gap-3 pb-2" style={{ scrollbarWidth: 'none' }}>
 {FILTERS.map((filter) => (
 <button
 key={filter.id}
 onClick={() => setActiveFilter(filter.id)}
 className={`flex-shrink-0 flex flex-col items-center gap-1 ${activeFilter === filter.id ? '' : 'opacity-60'}`}
 >
 <div
 className={`w-16 h-16 rounded-xl overflow-hidden bg-cover ${activeFilter === filter.id ? 'ring-2 ring-amber-500' : ''}`}
 style={{
 filter: filter.css !== 'none' ? filter.css : undefined,
 }}
 >
 <img
 src={URL.createObjectURL(file)}
 alt={filter.label}
 className="w-full h-full object-cover"
 />
 </div>
 <span className={`text-[10px] ${activeFilter === filter.id ? 'text-amber-500 font-bold' : 'text-white/60'}`}>
 {filter.label}
 </span>
 </button>
 ))}
 </div>
 </div>
 )}

 {activeTab === 'adjust' && (
 <div className="space-y-3 max-h-[40vh] overflow-y-auto pr-1">
 <SliderControl
 icon={<Sun className="w-4 h-4" />}
 label="السطوع"
 value={adjust.brightness}
 min={50}
 max={150}
 step={1}
 onChange={(v) => setAdjustValue('brightness', v)}
 suffix="%"
 />
 <SliderControl
 icon={<Contrast className="w-4 h-4" />}
 label="التباين"
 value={adjust.contrast}
 min={50}
 max={150}
 step={1}
 onChange={(v) => setAdjustValue('contrast', v)}
 suffix="%"
 />
 <SliderControl
 icon={<Droplets className="w-4 h-4" />}
 label="التشبع"
 value={adjust.saturation}
 min={0}
 max={200}
 step={1}
 onChange={(v) => setAdjustValue('saturation', v)}
 suffix="%"
 />
 <SliderControl
 icon={<Sun className="w-4 h-4" />}
 label="الدفء"
 value={adjust.warmth}
 min={-100}
 max={100}
 step={1}
 onChange={(v) => setAdjustValue('warmth', v)}
 suffix=""
 centerValue={0}
 />
 <SliderControl
 icon={<Maximize2 className="w-4 h-4" />}
 label="تعتيم الحواف"
 value={adjust.vignette}
 min={0}
 max={100}
 step={1}
 onChange={(v) => setAdjustValue('vignette', v)}
 suffix="%"
 />
 <SliderControl
 icon={<Droplets className="w-4 h-4" />}
 label="ضبابية"
 value={adjust.blur}
 min={0}
 max={20}
 step={0.5}
 onChange={(v) => setAdjustValue('blur', v)}
 suffix="px"
 />
 </div>
 )}
 </div>
 </div>
 )
}

// ========================================
// مكونات مساعدة
// ========================================

function QuickBtn({ icon: Icon, onClick, label }: { icon: typeof RotateCw; onClick: () => void; label: string }) {
 return (
 <button
 onClick={onClick}
 className="flex flex-col items-center gap-1 px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 transition-colors"
 >
 <Icon className="w-4 h-4 text-white/80" />
 <span className="text-[9px] text-white/60">{label}</span>
 </button>
 )
}

function TabBtn({ active, onClick, icon: Icon, label }: { active: boolean; onClick: () => void; icon: typeof Crop; label: string }) {
 return (
 <button
 onClick={onClick}
 className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold transition-all ${
 active ? 'bg-white/15 text-white' : 'text-white/50'
 }`}
 >
 <Icon className="w-3.5 h-3.5" />
 {label}
 </button>
 )
}

function SliderControl({
 icon,
 label,
 value,
 min,
 max,
 step,
 onChange,
 suffix = '',
 centerValue,
}: {
 icon: React.ReactNode
 label: string
 value: number
 min: number
 max: number
 step: number
 onChange: (v: number) => void
 suffix?: string
 centerValue?: number // إذا وُجد، يكون الـ slider ثنائي الاتجاه منه
}) {
 // حساب النسبة المئوية لتعبئة الـ slider
 const fillPercent = centerValue !== undefined
 ? value >= centerValue
 ? 50 + ((value - centerValue) / (max - centerValue)) * 50
 : ((value - min) / (centerValue - min)) * 50
 : ((value - min) / (max - min)) * 100

 return (
 <div>
 <div className="flex items-center justify-between mb-1">
 <div className="flex items-center gap-1.5 text-white/70">
 {icon}
 <span className="text-xs">{label}</span>
 </div>
 <span className="text-xs text-white/50 tabular-nums">
 {value > 0 && centerValue !== undefined ? '+' : ''}{Math.round(value * 10) / 10}{suffix}
 </span>
 </div>
 <input
 type="range"
 min={min}
 max={max}
 step={step}
 value={value}
 onChange={(e) => onChange(Number(e.target.value))}
 className="w-full h-1.5 bg-white/10 rounded-full appearance-none cursor-pointer accent-amber-500"
 style={{
 background: `linear-gradient(to left, #FBBF24 ${fillPercent}%, rgba(255,255,255,0.1) ${fillPercent}%)`,
 }}
 />
 </div>
 )
}
