'use client'

import { useState, useEffect, useCallback, useRef } from 'react'
import { useRouter } from 'next/navigation'
import { MessageCircle, Send, Check, X, Mail, MailOpen, Clock, XCircle } from 'lucide-react'
import { useAppStore } from '@/store/app-store'
import {
 fetchConversations,
 fetchIncomingRequests,
 fetchOutgoingRequests,
 respondToMessageRequest,
 type Conversation,
 type MessageRequest,
} from '@/lib/messaging'
import { supabase } from '@/lib/supabase/client'
import { initPresence, getUserPresence, type PresenceState } from '@/lib/presence'
import { VerifiedBadgeMini } from './VerifiedBadge'
import { toast } from 'sonner'

export function MessagesPage() {
 const router = useRouter()
 const user = useAppStore((s) => s.user)
 const [conversations, setConversations] = useState<Conversation[]>([])
 const [incomingRequests, setIncomingRequests] = useState<MessageRequest[]>([])
 const [outgoingRequests, setOutgoingRequests] = useState<MessageRequest[]>([])
 const [loading, setLoading] = useState(true)
 const [tab, setTab] = useState<'conversations' | 'requests'>('conversations')
 const [presenceMap, setPresenceMap] = useState<Record<string, PresenceState>>({})
 const presencePollRef = useRef<ReturnType<typeof setInterval> | null>(null)

 const loadData = useCallback(async () => {
 if (!user) return
 setLoading(true)
 try {
 const [convs, incoming, outgoing] = await Promise.all([
 fetchConversations(user.id),
 fetchIncomingRequests(user.id),
 fetchOutgoingRequests(user.id),
 ])
 setConversations(convs)
 setIncomingRequests(incoming)
 setOutgoingRequests(outgoing)
 } catch (e) {
 // [removed in production] 'Load messages error:', e
 } finally {
 setLoading(false)
 }
 }, [user])

 useEffect(() => {
 void loadData()
 }, [loadData])

 // تهيئة الـ presence + جلب حالات الاتصال دورياً
 useEffect(() => {
 if (!user) return

 // تهيئة الـ presence للمستخدم الحالي
 initPresence(user.id)

 // جلب حالات الاتصال لكل المستخدمين الآخرين
 const fetchPresence = async () => {
 const newMap: Record<string, PresenceState> = {}
 for (const conv of conversations) {
 const otherId = conv.participant_1 === user.id ? conv.participant_2 : conv.participant_1
 if (otherId && !newMap[otherId]) {
 const state = await getUserPresence(otherId)
 if (state) {
 newMap[otherId] = state
 }
 }
 }
 setPresenceMap(newMap)
 }

 void fetchPresence()
 // تحديث دوري كل 10 ثوانٍ
 presencePollRef.current = setInterval(() => void fetchPresence(), 10000)

 return () => {
 if (presencePollRef.current) {
 clearInterval(presencePollRef.current)
 presencePollRef.current = null
 }
 }
 }, [user, conversations])

 // البث المباشر لتحديث المحادثات
 useEffect(() => {
 if (!user) return

 const channel = supabase
 .channel('messages-list-realtime')
 .on(
 'postgres_changes',
 { event: 'INSERT', schema: 'public', table: 'messages' },
 () => void loadData()
 )
 .on(
 'postgres_changes',
 { event: 'UPDATE', schema: 'public', table: 'messages' },
 () => void loadData()
 )
 .on(
 'postgres_changes',
 { event: 'INSERT', schema: 'public', table: 'message_requests' },
 () => void loadData()
 )
 .on(
 'postgres_changes',
 { event: 'UPDATE', schema: 'public', table: 'message_requests' },
 () => void loadData()
 )
 .subscribe()

 return () => {
 void supabase.removeChannel(channel)
 }
 }, [user, loadData])

 const handleRespond = async (requestId: string, status: 'accepted' | 'rejected') => {
 const result = await respondToMessageRequest(requestId, status)
 if (result.success) {
 toast.success(status === 'accepted' ? 'تم قبول طلب المراسلة' : 'تم رفض الطلب')
 void loadData()
 } else {
 toast.error(result.error || 'تعذّر الرد على الطلب')
 }
 }

 return (
 <div className="flex flex-col flex-1 min-h-0">
 {/* رأس بسيط */}
 <header className="flex-shrink-0 border-b border-foreground/8 bg-background/80 backdrop-blur-xl z-40" style={{ paddingTop: 'env(safe-area-inset-top, 0px)' }}>
 <div className="max-w-md mx-auto px-4 py-2">
 <div className="flex items-center gap-2 mb-2">
 <h1 className="font-display text-xl font-bold mishri-gradient-text">الرسائل</h1>
 {incomingRequests.length > 0 && (
 <span className="px-2 py-0.5 rounded-full bg-rose-500 text-white text-[10px] font-bold">
 {incomingRequests.length}
 </span>
 )}
 </div>

 {/* تبويبات */}
 <div className="flex gap-2">
 <button
 onClick={() => setTab('conversations')}
 className={`px-3.5 py-1 rounded-full text-xs font-bold transition-all ${
 tab === 'conversations' ? 'bg-foreground text-background' : 'text-muted-foreground hover:bg-foreground/5'
 }`}
 >
 المحادثات ({conversations.length})
 </button>
 <button
 onClick={() => setTab('requests')}
 className={`px-3.5 py-1 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 ${
 tab === 'requests' ? 'bg-foreground text-background' : 'text-muted-foreground hover:bg-foreground/5'
 }`}
 >
 الطلبات
 {incomingRequests.length > 0 && (
 <span className="w-4 h-4 rounded-full bg-rose-500 text-white text-[9px] flex items-center justify-center">
 {incomingRequests.length}
 </span>
 )}
 </button>
 </div>
 </div>
 </header>

 {/* المحتوى */}
 <div data-scroll-area className="flex-1 overflow-y-auto overscroll-y-contain">
 <div className="max-w-md mx-auto px-4 pt-4 pb-4 space-y-3">
 {loading ? (
 <div className="space-y-3">
 {Array.from({ length: 4 }).map((_, i) => (
 <div key={i} className="rounded-2xl bg-foreground/5 p-3 h-16 mishri-shimmer" />
 ))}
 </div>
 ) : tab === 'conversations' ? (
 conversations.length === 0 ? (
 <EmptyState
 icon={<MessageCircle className="w-8 h-8" />}
 title="لا توجد محادثات"
 desc="ابدأ محادثة جديدة من ملف أي مستخدم"
 />
 ) : (
 <>
 {conversations.map((conv, i) => {
 const otherId = conv.participant_1 === (user?.id || '') ? conv.participant_2 : conv.participant_1
 return (
 <ConversationItem
 key={conv.id}
 conversation={conv}
 currentUserId={user?.id || ''}
 index={i}
 presence={presenceMap[otherId]}
 onClick={() => router.push(`/messages/${conv.id}`)}
 />
 )
 })}
 </>
 )
 ) : (
 <>
 {/* الطلبات الواردة */}
 {incomingRequests.length > 0 && (
 <div className="space-y-2">
 <h3 className="text-xs font-bold text-muted-foreground px-1">الطلبات الواردة</h3>
 {incomingRequests.map((req, i) => (
 <RequestItem
 key={req.id}
 request={req}
 type="incoming"
 index={i}
 onRespond={handleRespond}
 />
 ))}
 </div>
 )}

 {/* الطلبات المُرسلة */}
 {outgoingRequests.length > 0 && (
 <div className="space-y-2 mt-4">
 <h3 className="text-xs font-bold text-muted-foreground px-1">الطلبات المُرسلة</h3>
 {outgoingRequests.map((req, i) => (
 <RequestItem
 key={req.id}
 request={req}
 type="outgoing"
 index={i}
 />
 ))}
 </div>
 )}

 {incomingRequests.length === 0 && outgoingRequests.length === 0 && (
 <EmptyState
 icon={<Mail className="w-8 h-8" />}
 title="لا توجد طلبات مراسلة"
 desc="أرسل طلب مراسلة لمستخدم من ملفه الشخصي"
 />
 )}
 </>
 )}
 </div>
 </div>
 </div>
 )
}

// ========================================
// مكون: عنصر محادثة
// ========================================
function ConversationItem({
 conversation,
 currentUserId,
 index,
 presence,
 onClick,
}: {
 conversation: Conversation
 currentUserId: string
 index: number
 presence?: PresenceState
 onClick: () => void
}) {
 const other = conversation.other_participant
 const lastMsg = conversation.last_message

 return (
 <button
 onClick={onClick}
 className="w-full rounded-2xl bg-foreground/5 p-3 flex items-center gap-3 text-right mishri-hover-lift transition-colors duration-200"
 >
 {/* الصورة الرمزية */}
 <div className="relative flex-shrink-0">
 {other?.avatar_url ? (
 <img
 src={other.avatar_url}
 alt={other.display_name || other.username || 'مستخدم'}
 className="w-12 h-12 rounded-2xl object-cover"
 />
 ) : (
 <div
 className="w-12 h-12 rounded-2xl flex items-center justify-center text-white font-bold text-lg flex-shrink-0"
 style={{
 background: `linear-gradient(135deg, ${other?.avatar_color || '#FBBF24'} 0%, ${other?.avatar_color || '#FBBF24'}aa 100%)`,
 }}
 >
 {(other?.display_name || other?.username || '؟').charAt(0).toUpperCase()}
 </div>
 )}
 {/* مؤشر حالة الاتصال */}
 {presence?.status === 'online' && (
 <div className="absolute bottom-0 left-0 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-background" />
 )}
 {presence?.status === 'away' && (
 <div className="absolute bottom-0 left-0 w-3.5 h-3.5 rounded-full bg-amber-500 border-2 border-background" />
 )}
 </div>

 {/* المعلومات */}
 <div className="flex-1 min-w-0">
 <div className="flex items-baseline justify-between gap-2">
 <span className={`text-sm truncate flex items-center gap-1 ${(conversation.unread_count || 0) > 0 ? 'font-bold text-foreground' : 'font-semibold'}`}>
 <span className="truncate">{other?.display_name || other?.username || 'مستخدم'}</span>
 {other?.is_verified && (
 <VerifiedBadgeMini type={other.verified_type} />
 )}
 </span>
 <div className="flex items-center gap-1.5 flex-shrink-0">
 {(conversation.unread_count || 0) > 0 && (
 <span className="min-w-[18px] h-[18px] px-1 rounded-full bg-amber-500 text-white text-[9px] font-bold flex items-center justify-center">
 {conversation.unread_count}
 </span>
 )}
 {conversation.last_message_at && (
 <span className={`text-[10px] whitespace-nowrap ${(conversation.unread_count || 0) > 0 ? 'text-amber-600 dark:text-amber-400 font-bold' : 'text-muted-foreground'}`}>
 {formatTime(conversation.last_message_at)}
 </span>
 )}
 </div>
 </div>
 {lastMsg && (
 <p className={`text-xs truncate mt-0.5 ${(conversation.unread_count || 0) > 0 ? 'text-foreground/90 font-medium' : 'text-muted-foreground'}`}>
 {lastMsg.is_deleted
 ? '[تم حذف الرسالة]'
 : lastMsg.image_url && !lastMsg.content?.trim()
 ? (lastMsg.sender_id === currentUserId ? 'أنت: 📷 صورة' : '📷 صورة')
 : lastMsg.image_url
 ? (lastMsg.sender_id === currentUserId
 ? `أنت: ${lastMsg.content} 📷`
 : `${lastMsg.content} 📷`)
 : lastMsg.sender_id === currentUserId
 ? `أنت: ${lastMsg.content}`
 : lastMsg.content}
 </p>
 )}
 </div>
 </button>
 )
}

// ========================================
// مكون: عنصر طلب مراسلة
// ========================================
function RequestItem({
 request,
 type,
 index,
 onRespond,
}: {
 request: MessageRequest
 type: 'incoming' | 'outgoing'
 index: number
 onRespond?: (id: string, status: 'accepted' | 'rejected') => void
}) {
 const profile = type === 'incoming' ? request.sender : request.receiver

 return (
 <div
 className="rounded-2xl bg-foreground/5 p-3 flex items-center gap-3 transition-colors duration-200"
 >
 {/* الصورة الرمزية */}
 {profile?.avatar_url ? (
 <img
 src={profile.avatar_url}
 alt={profile.display_name || profile.username || 'مستخدم'}
 className="w-12 h-12 rounded-2xl object-cover flex-shrink-0"
 />
 ) : (
 <div
 className="w-12 h-12 rounded-2xl flex items-center justify-center text-white font-bold text-lg flex-shrink-0"
 style={{
 background: `linear-gradient(135deg, ${profile?.avatar_color || '#FBBF24'} 0%, ${profile?.avatar_color || '#FBBF24'}aa 100%)`,
 }}
 >
 {(profile?.display_name || profile?.username || '؟').charAt(0).toUpperCase()}
 </div>
 )}

 <div className="flex-1 min-w-0">
 <div className="text-sm font-bold truncate">
 {profile?.display_name || profile?.username || 'مستخدم'}
 </div>
 <div className="text-[11px] text-muted-foreground flex items-center gap-1">
 {type === 'incoming' ? (
 <>
 <Mail className="w-3 h-3" />
 يريد مراسلتك
 </>
 ) : request.status === 'pending' ? (
 <>
 <Clock className="w-3 h-3" />
 في انتظار الرد
 </>
 ) : request.status === 'accepted' ? (
 <>
 <Check className="w-3 h-3 text-emerald-500" />
 تم القبول
 </>
 ) : (
 <>
 <XCircle className="w-3 h-3 text-rose-500" />
 تم الرفض
 </>
 )}
 </div>
 </div>

 {/* أزرار القبول/الرفض */}
 {type === 'incoming' && onRespond && request.status === 'pending' && (
 <div className="flex gap-1 flex-shrink-0">
 <button
 onClick={() => onRespond(request.id, 'accepted')}
 className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-500 hover:bg-emerald-500/20 flex items-center justify-center transition-colors duration-200"
 aria-label="قبول"
 >
 <Check className="w-4 h-4" />
 </button>
 <button
 onClick={() => onRespond(request.id, 'rejected')}
 className="w-9 h-9 rounded-xl bg-rose-500/10 text-rose-500 hover:bg-rose-500/20 flex items-center justify-center transition-colors duration-200"
 aria-label="رفض"
 >
 <X className="w-4 h-4" />
 </button>
 </div>
 )}
 </div>
 )
}

// ========================================
// مكون: حالة فارغة
// ========================================
function EmptyState({ icon, title, desc }: { icon: React.ReactNode; title: string; desc: string }) {
 return (
 <div className="text-center py-16">
 <div className="w-16 h-16 mx-auto mb-4 rounded-2xl rounded-xl bg-foreground/5 flex items-center justify-center text-muted-foreground">
 {icon}
 </div>
 <h3 className="font-bold text-sm mb-1">{title}</h3>
 <p className="text-xs text-muted-foreground max-w-xs mx-auto">{desc}</p>
 </div>
 )
}

function formatTime(dateStr: string): string {
 const date = new Date(dateStr)
 const now = new Date()
 const diff = (now.getTime() - date.getTime()) / 1000
 if (diff < 60) return 'الآن'
 if (diff < 3600) return `${Math.floor(diff / 60)} د`
 if (diff < 86400) return `${Math.floor(diff / 3600)} س`
 if (diff < 604800) return `${Math.floor(diff / 86400)} ي`
 return date.toLocaleDateString('ar-EG', { day: 'numeric', month: 'short' })
}
