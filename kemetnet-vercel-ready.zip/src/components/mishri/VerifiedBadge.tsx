'use client'

/**
 * شارة التوثيق - نسخة طبق الأصل من Instagram
 *
 * Instagram Verified Badge:
 * - شارة دائرية زرقاء فاتحة (#1D9BF0)
 * - علامة صح بيضاء (✓) في المنتصف
 * - بجانب اسم المستخدم
 *
 * أنواع التوثيق (مثل Instagram):
 * - official: أزرق (Blue Badge) — حسابات رسمية/أشخاص
 * - business: رمادي (Gray Badge) — شركات/منظمات
 * - creator: بنفسجي (Purple Badge) — صناع محتوى
 * - early_adopter: ذهبي — مستخدمون مبكرون (KemetNet خاص)
 */

import { Check } from 'lucide-react'

type VerifiedType = 'official' | 'business' | 'creator' | 'early_adopter' | null

interface VerifiedBadgeProps {
  type: VerifiedType
  size?: 'xs' | 'sm' | 'md' | 'lg'
  showTooltip?: boolean
  className?: string
}

const BADGE_CONFIG: Record<Exclude<VerifiedType, null>, {
  color: string
  label: string
  desc: string
}> = {
  official: {
    color: '#1D9BF0',  // Instagram blue
    label: 'موثّق',
    desc: 'حساب موثّق رسمي',
  },
  business: {
    color: '#71767B',  // Instagram gray (business)
    label: 'عمل تجاري',
    desc: 'حساب تجاري موثّق',
  },
  creator: {
    color: '#A855F7',  // Purple for creators
    label: 'صانع محتوى',
    desc: 'صانع محتوى موثّق',
  },
  early_adopter: {
    color: '#FBBF24',  // Gold
    label: 'مستخدم مبكر',
    desc: 'من أوائل مستخدمي KemetNet',
  },
}

const SIZE_CLASSES = {
  xs: { container: 'w-3 h-3', icon: 'w-2 h-2' },
  sm: { container: 'w-3.5 h-3.5', icon: 'w-2.5 h-2.5' },
  md: { container: 'w-4 h-4', icon: 'w-3 h-3' },
  lg: { container: 'w-5 h-5', icon: 'w-3.5 h-3.5' },
}

/**
 * شارة التوثيق الكاملة (مثل Instagram)
 * دائرة ملوّنة بتصميم badge filled + علامة صح بيضاء
 */
export function VerifiedBadge({ type, size = 'sm', showTooltip = true, className = '' }: VerifiedBadgeProps) {
  if (!type) return null

  const config = BADGE_CONFIG[type]
  if (!config) return null

  const sizes = SIZE_CLASSES[size]

  return (
    <span
      className={`inline-flex items-center flex-shrink-0 ${className}`}
      title={showTooltip ? config.desc : undefined}
      role="img"
      aria-label={config.desc}
    >
      <span
        className={`${sizes.container} rounded-full flex items-center justify-center relative`}
        style={{
          backgroundColor: config.color,
          // حدود بيضاء رفيعة مثل Instagram (للتباين على الخلفيات الملونة)
          boxShadow: '0 0 0 1px rgba(255,255,255,0.3) inset',
        }}
      >
        <Check
          className={sizes.icon}
          strokeWidth={3.5}
          stroke="#FFFFFF"
          fill="none"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </span>
    </span>
  )
}

/**
 * نسخة مبسطة (icon فقط، بدون container)
 */
export function VerifiedBadgeMini({ type, className = '' }: { type: VerifiedType, className?: string }) {
  if (!type) return null
  const config = BADGE_CONFIG[type]
  if (!config) return null

  return (
    <span
      className={`inline-flex items-center justify-center w-3.5 h-3.5 rounded-full ${className}`}
      style={{ backgroundColor: config.color }}
      title={config.desc}
      aria-label={config.desc}
    >
      <Check
        className="w-2.5 h-2.5"
        strokeWidth={3.5}
        stroke="#FFFFFF"
        fill="none"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </span>
  )
}

/**
 * شارة كبيرة (للـ profile header مثل Instagram)
 */
export function VerifiedBadgeLarge({ type, showLabel = false }: { type: VerifiedType, showLabel?: boolean }) {
  if (!type) return null
  const config = BADGE_CONFIG[type]
  if (!config) return null

  return (
    <div className="inline-flex items-center gap-1.5">
      <span
        className="w-5 h-5 rounded-full flex items-center justify-center"
        style={{
          backgroundColor: config.color,
          boxShadow: '0 0 0 1px rgba(255,255,255,0.3) inset',
        }}
        title={config.desc}
      >
        <Check
          className="w-3.5 h-3.5"
          strokeWidth={3.5}
          stroke="#FFFFFF"
          fill="none"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </span>
      {showLabel && (
        <span className="text-xs font-bold" style={{ color: config.color }}>
          {config.label}
        </span>
      )}
    </div>
  )
}

export function getVerificationLabel(type: VerifiedType): string {
  if (!type) return ''
  return BADGE_CONFIG[type]?.label ?? ''
}

export function getVerificationDesc(type: VerifiedType): string {
  if (!type) return ''
  return BADGE_CONFIG[type]?.desc ?? ''
}
