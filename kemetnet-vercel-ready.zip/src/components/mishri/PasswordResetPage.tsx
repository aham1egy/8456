'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { ArrowLeft, Mail, Loader2, CheckCircle2, KeyRound, Eye, EyeOff } from 'lucide-react'
import { requestPasswordReset } from '@/lib/password-reset'
import { validateUsername } from '@/lib/supabase/auth'
import { toast } from 'sonner'

export function PasswordResetPage() {
 const router = useRouter()
 const [stage, setStage] = useState<'request' | 'sent'>('request')
 const [username, setUsername] = useState('')
 const [sending, setSending] = useState(false)

 const handleSubmit = async () => {
 if (!username.trim()) {
 toast.error('أدخل اليوزرنيم')
 return
 }

 const validation = validateUsername(username)
 if (!validation.valid) {
 toast.error(validation.error || 'يوزرنيم غير صالح')
 return
 }

 setSending(true)
 try {
 const result = await requestPasswordReset(username)
 // نعرض شاشة "أُرسل الرابط" دائماً (حتى لو فشل — لأسباب أمنية)
 setStage('sent')
 } catch (e) {
 // [removed in production] 'Reset request error:', e
 setStage('sent')
 } finally {
 setSending(false)
 }
 }

 if (stage === 'sent') {
 return (
 <div className="min-h-screen mishri-aurora-bg flex flex-col items-center justify-center px-6">
 <div
 className="text-center max-w-sm transition-colors duration-200"
 >
 <div
 className="w-20 h-20 mx-auto mb-6 rounded-3xl mishri-gradient-primary mishri-glow-soft flex items-center justify-center mishri-pulse"
 >
 <Mail className="w-10 h-10 text-white" />
 </div>

 <h1 className="font-display text-2xl font-bold mb-2">
 تحقق من بريدك
 </h1>
 <p className="text-sm text-muted-foreground mb-2 leading-relaxed">
 إذا كان حساب <span className="font-bold text-foreground">@{username}</span> موجوداً،
 فقد أرسلنا رابط استعادة كلمة المرور إلى بريده الإلكتروني.
 </p>
 <p className="text-xs text-muted-foreground/70 mb-8 leading-relaxed">
 ملاحظة: في تطبيق KemetNet نستخدم بريداً وهمياً للتسجيل باليوزرنيم فقط،
 لذا قد لا يصلك البريد فعلياً. إذا كنت تتذكر كلمة المرور الحالية،
 يمكنك تغييرها من الإعدادات → كلمة المرور.
 </p>

 <div className="space-y-2">
 <button
 onClick={() => router.push('/')}
 className="w-full py-3 rounded-xl mishri-gradient-primary text-white text-sm font-bold shadow-md mishri-glow-soft mishri-press flex items-center justify-center gap-2"
 >
 العودة لتسجيل الدخول
 </button>
 <button
 onClick={() => setStage('request')}
 className="w-full py-2.5 text-xs text-muted-foreground hover:text-foreground transition-colors"
 >
 إعادة إرسال الطلب
 </button>
 </div>
 </div>
 </div>
 )
 }

 return (
 <div className="min-h-screen mishri-aurora-bg flex flex-col items-center justify-center px-6">
 <div
 className="w-full max-w-sm transition-colors duration-200"
 >
 {/* شعار */}
 <div className="text-center mb-8">
 <div
 className="w-16 h-16 mx-auto mb-4 rounded-3xl mishri-gradient-primary mishri-glow-soft flex items-center justify-center mishri-pulse"
 >
 <KeyRound className="w-8 h-8 text-white" />
 </div>
 <h1 className="font-display text-2xl font-bold mishri-gradient-text mb-1">
 نسيت كلمة المرور؟
 </h1>
 <p className="text-sm text-muted-foreground">
 أدخل يوزرنيمك وسنرسل لك رابط الاستعادة
 </p>
 </div>

 {/* البطاقة */}
 <div className="rounded-2xl p-4 bg-foreground/5 ">
 <div className="mb-4">
 <label className="block text-xs font-bold mb-2 text-muted-foreground">
 اليوزرنيم
 </label>
 <div className="relative">
 <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm font-bold">
 @
 </span>
 <input
 type="text"
 value={username}
 onChange={(e) => setUsername(e.target.value)}
 onKeyDown={(e) => {
 if (e.key === 'Enter' && !sending) handleSubmit()
 }}
 placeholder="username"
 dir="ltr"
 className="mishri-input w-full rounded-xl py-3 px-4 pr-9 text-sm font-medium outline-none"
 disabled={sending}
 autoFocus
 />
 </div>
 </div>

 <button
 onClick={handleSubmit}
 disabled={sending || !username.trim()}
 className="w-full py-3 rounded-xl mishri-gradient-primary text-white text-sm font-bold shadow-md mishri-glow-soft disabled:opacity-50 flex items-center justify-center gap-2 mishri-press"
 >
 {sending ? (
 <>
 <Loader2 className="w-4 h-4 animate-spin" />
 جارٍ الإرسال...
 </>
 ) : (
 <>
 <Mail className="w-4 h-4" />
 إرسال رابط الاستعادة
 </>
 )}
 </button>
 </div>

 {/* رابط العودة */}
 <button
 onClick={() => router.push('/')}
 className="w-full mt-4 py-2.5 flex items-center justify-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors mishri-press"
 >
 <ArrowLeft className="w-3.5 h-3.5" />
 العودة لتسجيل الدخول
 </button>

 {/* معلومة أمنية */}
 <div className="mt-6 text-center">
 <p className="text-[10px] text-muted-foreground/70 leading-relaxed">
 لأسباب أمنية، لا نكشف ما إذا كان الحساب موجوداً بالفعل.
 ستحصل على نفس الرسالة بغض النظر عن وجود الحساب.
 </p>
 </div>
 </div>
 </div>
 )
}

// ========================================
// صفحة إعادة تعيين كلمة المرور (بعد النقر على الرابط)
// ========================================

export function ResetPasswordForm() {
 const router = useRouter()
 const [newPassword, setNewPassword] = useState('')
 const [confirmPassword, setConfirmPassword] = useState('')
 const [showPassword, setShowPassword] = useState(false)
 const [resetting, setResetting] = useState(false)
 const [isValidSession, setIsValidSession] = useState<boolean | null>(null)

 useEffect(() => {
 void (async () => {
 const { resetPasswordFromRecovery, checkPasswordResetSession } = await import('@/lib/password-reset')
 const valid = await checkPasswordResetSession()
 setIsValidSession(valid)
 })()
 }, [])

 const canReset =
 newPassword.length >= 8 &&
 /[a-zA-Z]/.test(newPassword) &&
 /[0-9]/.test(newPassword) &&
 newPassword === confirmPassword &&
 !resetting

 const handleReset = async () => {
 if (!canReset) return
 setResetting(true)
 try {
 const { resetPasswordFromRecovery } = await import('@/lib/password-reset')
 const result = await resetPasswordFromRecovery(newPassword)
 if (result.success) {
 toast.success('تم تحديث كلمة المرور بنجاح')
 setTimeout(() => router.push('/'), 1500)
 } else {
 toast.error(result.error || 'تعذّر تحديث كلمة المرور')
 }
 } catch (e) {
 // [removed in production] 'Reset error:', e
 toast.error('حدث خطأ')
 } finally {
 setResetting(false)
 }
 }

 if (isValidSession === null) {
 return (
 <div className="min-h-screen mishri-aurora-bg flex items-center justify-center">
 <Loader2 className="w-6 h-6 text-amber-500 animate-spin" />
 </div>
 )
 }

 if (isValidSession === false) {
 return (
 <div className="min-h-screen mishri-aurora-bg flex flex-col items-center justify-center px-6">
 <div
 className="text-center max-w-sm transition-colors duration-200"
 >
 <div className="w-16 h-16 mx-auto mb-4 rounded-3xl bg-rose-500/15 flex items-center justify-center">
 <X className="w-8 h-8 text-rose-500" />
 </div>
 <h1 className="font-display text-xl font-bold mb-2">انتهت صلاحية الرابط</h1>
 <p className="text-sm text-muted-foreground mb-6">
 رابط استعادة كلمة المرور غير صالح أو منتهي الصلاحية.
 اطلب رابطاً جديداً.
 </p>
 <button
 onClick={() => router.push('/forgot-password')}
 className="px-5 py-2.5 rounded-xl mishri-gradient-primary text-white text-sm font-bold mishri-press"
 >
 طلب رابط جديد
 </button>
 </div>
 </div>
 )
 }

 return (
 <div className="min-h-screen mishri-aurora-bg flex flex-col items-center justify-center px-6">
 <div
 className="w-full max-w-sm transition-colors duration-200"
 >
 <div className="text-center mb-8">
 <div className="w-16 h-16 mx-auto mb-4 rounded-3xl mishri-gradient-primary mishri-glow-soft flex items-center justify-center">
 <CheckCircle2 className="w-8 h-8 text-white" />
 </div>
 <h1 className="font-display text-2xl font-bold mishri-gradient-text mb-1">
 كلمة مرور جديدة
 </h1>
 <p className="text-sm text-muted-foreground">
 اختر كلمة مرور قوية لحسابك
 </p>
 </div>

 <div className="rounded-2xl p-4 bg-foreground/5 ">
 <div className="mb-4">
 <label className="block text-xs font-bold mb-2 text-muted-foreground">
 كلمة المرور الجديدة
 </label>
 <div className="relative">
 <input
 type={showPassword ? 'text' : 'password'}
 value={newPassword}
 onChange={(e) => setNewPassword(e.target.value)}
 placeholder="••••••••"
 dir="ltr"
 className="mishri-input w-full rounded-xl py-3 px-4 pl-10 text-sm font-medium outline-none"
 disabled={resetting}
 autoFocus
 />
 <button
 onClick={() => setShowPassword(!showPassword)}
 className="absolute top-1/2 -translate-y-1/2 left-3 p-1"
 >
 {showPassword ? (
 <EyeOff className="w-4 h-4 text-muted-foreground" />
 ) : (
 <Eye className="w-4 h-4 text-muted-foreground" />
 )}
 </button>
 </div>
 </div>

 <div className="mb-4">
 <label className="block text-xs font-bold mb-2 text-muted-foreground">
 تأكيد كلمة المرور
 </label>
 <input
 type={showPassword ? 'text' : 'password'}
 value={confirmPassword}
 onChange={(e) => setConfirmPassword(e.target.value)}
 placeholder="••••••••"
 dir="ltr"
 className="mishri-input w-full rounded-xl py-3 px-4 text-sm font-medium outline-none"
 disabled={resetting}
 />
 {confirmPassword && newPassword !== confirmPassword && (
 <p className="text-[11px] text-rose-500 mt-1">كلمتا المرور غير متطابقتين</p>
 )}
 </div>

 <div className="text-[10px] text-muted-foreground mb-4 space-y-1 p-3 rounded-xl bg-foreground/5">
 <div className="font-bold mb-1">متطلبات كلمة المرور:</div>
 <div>• 8 أحرف على الأقل</div>
 <div>• أحرف + أرقام</div>
 </div>

 <button
 onClick={handleReset}
 disabled={!canReset}
 className="w-full py-3 rounded-xl mishri-gradient-primary text-white text-sm font-bold shadow-md mishri-glow-soft disabled:opacity-50 flex items-center justify-center gap-2 mishri-press"
 >
 {resetting ? (
 <>
 <Loader2 className="w-4 h-4 animate-spin" />
 جارٍ التحديث...
 </>
 ) : (
 'تحديث كلمة المرور'
 )}
 </button>
 </div>
 </div>
 </div>
 )
}

// استيراد X هنا لتجنب circular dependency
import { X } from 'lucide-react'
