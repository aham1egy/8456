'use client'

import { useState } from 'react'
import { Flag, X, AlertTriangle, Ban, Loader2 } from 'lucide-react'
import {
 REPORT_REASONS,
 createReport,
 blockUser,
 type ReportTargetType,
 type ReportReason,
} from '@/lib/moderation'
import { useAppStore } from '@/store/app-store'
import { useNotificationSound } from '@/hooks/use-sound'
import { toast } from 'sonner'

interface ReportModalProps {
 open: boolean
 onClose: () => void
 targetType: ReportTargetType
 targetId: string
 reportedUserId: string
 reportedUserName?: string
}

export function ReportModal({
 open,
 onClose,
 targetType,
 targetId,
 reportedUserId,
 reportedUserName,
}: ReportModalProps) {
 const user = useAppStore((s) => s.user)
 const { playSound } = useNotificationSound()
 const [selectedReason, setSelectedReason] = useState<ReportReason | null>(null)
 const [description, setDescription] = useState('')
 const [submitting, setSubmitting] = useState(false)
 const [showBlockPrompt, setShowBlockPrompt] = useState(false)
 const [blocking, setBlocking] = useState(false)

 if (!open) return null

 const handleSubmit = async () => {
 if (!user || !selectedReason) return
 setSubmitting(true)
 try {
 const result = await createReport(
 user.id,
 targetType,
 targetId,
 reportedUserId,
 selectedReason,
 description
 )
 if (result.success) {
 playSound('success')
 toast.success('تم إرسال البلاغ. شكراً لمساهمتك في حماية المجتمع.')
 setShowBlockPrompt(true)
 } else if (result.alreadyReported) {
 toast.info('لقد بلّغت عن هذا المحتوى مسبقاً')
 setShowBlockPrompt(true)
 } else {
 toast.error(result.error || 'تعذّر إرسال البلاغ')
 }
 } catch (e) {
 // [removed in production] 'Report error:', e
 toast.error('حدث خطأ')
 } finally {
 setSubmitting(false)
 }
 }

 const handleBlock = async () => {
 if (!user) return
 setBlocking(true)
 try {
 const result = await blockUser(user.id, reportedUserId)
 if (result.success) {
 playSound('success')
 toast.success(`تم حجب ${reportedUserName || 'المستخدم'}`)
 handleClose()
 } else {
 toast.error(result.error || 'تعذّر الحجب')
 }
 } catch (e) {
 // [removed in production] 'Block error:', e
 toast.error('حدث خطأ')
 } finally {
 setBlocking(false)
 }
 }

 const handleClose = () => {
 setSelectedReason(null)
 setDescription('')
 setShowBlockPrompt(false)
 onClose()
 }

 const targetTypeLabel = {
 post: 'المنشور',
 comment: 'التعليق',
 message: 'الرسالة',
 profile: 'الملف الشخصي',
 }[targetType]

 return (
 <>
 {open && (
 <div
 className="fixed inset-0 z-[100] bg-black/50 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-6 transition-colors duration-200"
 onClick={handleClose}
 >
 <div
 className="relative w-full sm:max-w-md rounded-t-2xl bg-background/95 sm:rounded-3xl max-h-[85vh] overflow-y-auto transition-colors duration-200"
 onClick={(e) => e.stopPropagation()}
 >
 {!showBlockPrompt ? (
 <>
 {/* الرأس */}
 <div className="sticky top-0 rounded-xl bg-foreground/5-strong z-10 px-5 py-4 border-b border-foreground/5 flex items-center justify-between">
 <div className="flex items-center gap-2">
 <div className="w-9 h-9 rounded-xl bg-rose-500/15 flex items-center justify-center">
 <Flag className="w-4 h-4 text-rose-500" />
 </div>
 <div>
 <h3 className="font-display text-base font-bold">إبلاغ عن {targetTypeLabel}</h3>
 <p className="text-[10px] text-muted-foreground">سيتم مراجعة بلاغك</p>
 </div>
 </div>
 <button
 onClick={handleClose}
 className="p-2 rounded-full hover:bg-foreground/5"
 aria-label="إغلاق"
 >
 <X className="w-4 h-4" />
 </button>
 </div>

 {/* الأسباب */}
 <div className="p-4 space-y-2">
 <p className="text-xs font-bold text-muted-foreground mb-2">
 ما السبب؟
 </p>
 {(Object.keys(REPORT_REASONS) as ReportReason[]).map((reason) => {
 const info = REPORT_REASONS[reason]
 const selected = selectedReason === reason
 return (
 <button
 key={reason}
 onClick={() => setSelectedReason(reason)}
 className={`w-full flex items-start gap-3 p-3 rounded-2xl text-right transition-all mishri-press ${
 selected
 ? 'bg-rose-500/10 border-2 border-rose-500/30'
 : 'bg-foreground/5 border-2 border-transparent hover:bg-foreground/10'
 }`}
 >
 <div
 className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 mt-0.5 ${
 selected ? 'border-rose-500 bg-rose-500' : 'border-foreground/30'
 }`}
 >
 {selected && <div className="w-2 h-2 rounded-full bg-white" />}
 </div>
 <div className="flex-1 min-w-0">
 <div className="text-sm font-bold">{info.label}</div>
 <div className="text-[11px] text-muted-foreground">{info.desc}</div>
 </div>
 </button>
 )
 })}
 </div>

 {/* وصف اختياري */}
 {selectedReason && (
 <div
 className="px-4 pb-4"
 >
 <label className="block text-xs font-bold text-muted-foreground mb-2">
 تفاصيل إضافية (اختياري)
 </label>
 <textarea
 value={description}
 onChange={(e) => setDescription(e.target.value)}
 placeholder="أضف تفاصيل تساعد في المراجعة..."
 className="mishri-input w-full rounded-xl py-2.5 px-3 text-sm outline-none resize-none"
 rows={3}
 maxLength={500}
 />
 <div className="text-left text-[10px] text-muted-foreground mt-1">
 {description.length}/500
 </div>
 </div>
 )}

 {/* زر الإرسال */}
 <div className="sticky bottom-0 rounded-xl bg-foreground/5-strong px-4 py-3 border-t border-foreground/5">
 <button
 onClick={handleSubmit}
 disabled={!selectedReason || submitting}
 className="w-full py-3 rounded-xl bg-rose-500 text-white text-sm font-bold disabled:opacity-50 flex items-center justify-center gap-2 mishri-press"
 >
 {submitting ? (
 <>
 <Loader2 className="w-4 h-4 animate-spin" />
 جارٍ الإرسال...
 </>
 ) : (
 <>
 <Flag className="w-4 h-4" />
 إرسال البلاغ
 </>
 )}
 </button>
 </div>
 </>
 ) : (
 // شاشة "هل تريد حجب المستخدم؟"
 <div className="p-6 text-center">
 <div
 className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-emerald-500/15 flex items-center justify-center mishri-pulse"
 >
 <Flag className="w-8 h-8 text-emerald-500" />
 </div>
 <h3 className="font-display text-lg font-bold mb-2">تم إرسال البلاغ</h3>
 <p className="text-xs text-muted-foreground mb-5 leading-relaxed">
 هل تريد أيضاً حجب{' '}
 <span className="font-bold text-foreground">
 {reportedUserName || 'هذا المستخدم'}
 </span>
 ؟<br />
 لن ترى منشوراته ولن يتمكن من مراسلتك.
 </p>

 <div className="space-y-2">
 <button
 onClick={handleBlock}
 disabled={blocking}
 className="w-full py-3 rounded-xl bg-rose-500 text-white text-sm font-bold disabled:opacity-50 flex items-center justify-center gap-2 mishri-press"
 >
 {blocking ? (
 <>
 <Loader2 className="w-4 h-4 animate-spin" />
 جارٍ الحجب...
 </>
 ) : (
 <>
 <Ban className="w-4 h-4" />
 نعم، حجب المستخدم
 </>
 )}
 </button>
 <button
 onClick={handleClose}
 className="w-full py-3 rounded-xl bg-foreground/5 text-sm font-bold mishri-press"
 >
 لا، شكراً
 </button>
 </div>
 </div>
 )}
 </div>
 </div>
 )}
 </>
 )
}

// ========================================
// مكون: تأكيد الحجب (للحجب المباشر بدون بلاغ)
// ========================================

interface BlockConfirmModalProps {
 open: boolean
 onClose: () => void
 blockedUserId: string
 blockedUserName?: string
 onBlocked?: () => void
}

export function BlockConfirmModal({
 open,
 onClose,
 blockedUserId,
 blockedUserName,
 onBlocked,
}: BlockConfirmModalProps) {
 const user = useAppStore((s) => s.user)
 const { playSound } = useNotificationSound()
 const [blocking, setBlocking] = useState(false)

 if (!open) return null

 const handleBlock = async () => {
 if (!user) return
 setBlocking(true)
 try {
 const result = await blockUser(user.id, blockedUserId)
 if (result.success) {
 playSound('success')
 toast.success(`تم حجب ${blockedUserName || 'المستخدم'}`)
 onBlocked?.()
 onClose()
 } else {
 toast.error(result.error || 'تعذّر الحجب')
 }
 } catch (e) {
 // [removed in production] 'Block error:', e
 toast.error('حدث خطأ')
 } finally {
 setBlocking(false)
 }
 }

 return (
 <>
 {open && (
 <div
 className="fixed inset-0 z-[100] bg-black/50 backdrop-blur-sm flex items-center justify-center p-6 transition-colors duration-200"
 onClick={onClose}
 >
 <div
 className="rounded-2xl p-4 bg-foreground/5 max-w-xs w-full text-center transition-colors duration-200"
 onClick={(e) => e.stopPropagation()}
 >
 <div className="w-12 h-12 mx-auto mb-3 rounded-2xl bg-rose-500/15 flex items-center justify-center">
 <AlertTriangle className="w-6 h-6 text-rose-500" />
 </div>
 <h3 className="font-bold text-sm mb-1">حجب المستخدم؟</h3>
 <p className="text-xs text-muted-foreground mb-4 leading-relaxed">
 سيتم حذف متابعة{' '}
 <span className="font-bold text-foreground">{blockedUserName || 'المستخدم'}</span>{' '}
 وطلب إلغاء أي طلبات مراسلة معلّقة.
 </p>
 <div className="flex gap-2">
 <button
 onClick={onClose}
 disabled={blocking}
 className="flex-1 py-2.5 rounded-xl bg-foreground/5 text-xs font-bold disabled:opacity-50"
 >
 إلغاء
 </button>
 <button
 onClick={handleBlock}
 disabled={blocking}
 className="flex-1 py-2.5 rounded-xl bg-rose-500 text-white text-xs font-bold disabled:opacity-50 flex items-center justify-center gap-1.5"
 >
 {blocking ? (
 <Loader2 className="w-3.5 h-3.5 animate-spin" />
 ) : (
 <>
 <Ban className="w-3.5 h-3.5" />
 حجب
 </>
 )}
 </button>
 </div>
 </div>
 </div>
 )}
 </>
 )
}
