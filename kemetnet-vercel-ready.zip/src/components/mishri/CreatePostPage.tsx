'use client'

import { useState, useRef, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { ArrowLeft, X, Image as ImageIcon, Hash, Loader2, Send, Check } from 'lucide-react'
import { supabase, CATEGORIES, MOODS } from '@/lib/supabase/client'
import { uploadPostImage, isValidImageUrl } from '@/lib/supabase/storage'
import { useAppStore } from '@/store/app-store'
import { useNotificationSound } from '@/hooks/use-sound'
import { ImageEditor, type ImageEditResult } from './ImageEditor'
import { MentionsInput } from './MentionsInput'
import { usePostDraft } from '@/lib/drafts'
import { haptic } from '@/hooks/use-haptic-feedback'
import { toast } from 'sonner'
import { detectSpam } from '@/lib/ai/content-analyzer'
import { sanitizeText, sanitizeTags, checkRateLimit, validatePostContent } from '@/lib/security'
import { moderateContent, detectDuplicate } from '@/lib/content-moderation'

export function CreatePostPage() {
 const user = useAppStore((s) => s.user)
 const router = useRouter()
 const { playSound } = useNotificationSound()

 const draft = usePostDraft()
 const content = draft.content
 const setContent = draft.setContent
 const category = draft.category
 const setCategory = draft.setCategory
 const mood = draft.mood
 const setMood = draft.setMood
 const tags = draft.tags
 const setTags = draft.setTags
 const imageUrl = draft.imageUrl || ''
 const setImageUrl = (url: string | null) => draft.setImageUrl(url || null)

 const [tagInput, setTagInput] = useState('')
 const [loading, setLoading] = useState(false)
 const [uploading, setUploading] = useState(false)
 const [pendingFile, setPendingFile] = useState<File | null>(null)
 const fileInputRef = useRef<HTMLInputElement>(null)

 const canPost = content.trim().length > 0 && !loading

 const handleAddTag = () => {
 const trimmed = tagInput.trim().replace(/^#/, '').toLowerCase()
 // ✅ أمني: التحقق من طول ومحتوى الوسم
 if (trimmed.length < 2 || trimmed.length > 30) {
 toast.error('الوسم يجب أن يكون 2-30 حرفًا')
 return
 }
 if (!/^[a-zA-Z0-9_\u0600-\u06FF]+$/.test(trimmed)) {
 toast.error('الوسم يجب أن يحتوي على أحرف وأرقام فقط')
 return
 }
 if (!tags.includes(trimmed) && tags.length < 5) {
 setTags([...tags, trimmed])
 setTagInput('')
 haptic('light')
 }
 }

 const handleRemoveTag = (tag: string) => {
 setTags(tags.filter((t) => t !== tag))
 haptic('light')
 }

 const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
 const file = e.target.files?.[0]
 if (!file || !user) return
 setPendingFile(file)
 if (fileInputRef.current) fileInputRef.current.value = ''
 }

 const handleImageEditSave = async (result: ImageEditResult) => {
 if (!user) return
 setPendingFile(null)
 setUploading(true)
 try {
 const editedFile = new File([result.blob], 'post.jpg', { type: 'image/jpeg' })
 const uploadResult = await uploadPostImage(user.id, editedFile)
 if (uploadResult.url) {
 setImageUrl(uploadResult.url)
 playSound('success')
 }
 } catch {
 toast.error('حدث خطأ أثناء الرفع')
 } finally {
 setUploading(false)
 }
 }

 const handleSubmit = async () => {
 if (!canPost || !user) return

 // 1) Rate limiting — منع النشر المفرط
 const rateLimit = checkRateLimit('create_post', 5, 60_000) // 5 منشورات/دقيقة
 if (!rateLimit.allowed) {
   const waitSec = Math.ceil((rateLimit.resetAt - Date.now()) / 1000)
   toast.error(`Very many posts. Wait ${waitSec}s`)
   haptic('error')
   return
 }

 // 2) تنظيف المحتوى من XSS
 const cleanContent = sanitizeText(content)

 // 3) فحص شامل للمحتوى
 const validation = validatePostContent(cleanContent)
 if (!validation.valid) {
   toast.error(validation.errors[0])
   haptic('error')
   return
 }

 // 4) إشراف على المحتوى (content moderation)
 const moderation = moderateContent(cleanContent)
 if (moderation.suggestedAction === 'block') {
   toast.error(`محتوى مرفوض: ${moderation.flags[0]?.message || 'غير مناسب'}`)
   haptic('error')
   return
 }

 // 5) كشف spam
 const spamCheck = detectSpam(cleanContent)
 if (spamCheck.isSpam) {
   toast.error(`محتوى مرفوض: ${spamCheck.reasons[0] || 'يبدو كرسالة مزعجة'}`)
   haptic('error')
   return
 }

 // 6) كشف التكرار — جلب آخر 10 منشورات للمستخدم
 try {
   const { data: recentPosts } = await supabase
     .from('posts')
     .select('content')
     .eq('user_id', user.id)
     .order('created_at', { ascending: false })
     .limit(10)
   if (recentPosts && detectDuplicate(cleanContent, recentPosts.map((p) => p.content || ''))) {
     toast.error('لا يمكن نشر نفس المحتوى مرتين')
     haptic('error')
     return
   }
 } catch {
   // تجاهل — لا نمنع النشر بسبب فشل الفحص
 }

 // 7) تنظيف الوسوم
 const cleanTags = sanitizeTags(tags)

 // تحذيرات (لا تمنع النشر)
 if (moderation.flags.length > 0 && moderation.suggestedAction === 'review') {
   toast.warning(`تنبيه: ${moderation.flags[0].message}`)
 }

 haptic('success')
 setLoading(true)
 try {
 if (imageUrl && !isValidImageUrl(imageUrl)) {
 toast.error('رابط الصورة غير صالح')
 setLoading(false)
 return
 }
 const { error } = await supabase.from('posts').insert({
 user_id: user.id,
 content: cleanContent,
 category,
 mood,
 tags: cleanTags,
 image_url: imageUrl.trim() || null,
 })
 if (error) {
 toast.error('تعذّر النشر')
 return
 }
 playSound('send')
 toast.success('تم النشر')
 draft.clearDraft()
 router.push('/home')
 } catch {
 toast.error('حدث خطأ')
 } finally {
 setLoading(false)
 }
 }

 return (
 <div className="flex flex-col flex-1 min-h-0">
 <input type="file" ref={fileInputRef} accept="image/png,image/jpeg,image/webp,image/gif" onChange={handleFileSelect} className="hidden" />

 {/* رأس بسيط جداً */}
 <header className="flex-shrink-0 border-b border-foreground/5 bg-background/80 backdrop-blur-xl z-40" style={{ paddingTop: 'env(safe-area-inset-top, 0px)' }}>
 <div className="max-w-md mx-auto px-4 py-3 flex items-center justify-between">
 <button onClick={() => router.push('/home')} className="text-sm font-semibold text-muted-foreground hover:text-foreground transition-colors">
 إلغاء
 </button>
 <span className={`text-[10px] tabular-nums px-2 py-0.5 rounded-full ${content.length > 1800 ? 'bg-rose-500/10 text-rose-500' : 'text-muted-foreground'}`}>
 {content.length}/2000
 </span>
 <button
 onClick={handleSubmit}
 disabled={!canPost}
 className="px-4 py-1.5 rounded-full bg-foreground text-background text-sm font-bold disabled:opacity-30 transition-opacity"
 >
 {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'نشر'}
 </button>
 </div>
 </header>

 {/* المحتوى */}
 <div data-scroll-area className="flex-1 overflow-y-auto overscroll-y-contain">
 <div className="max-w-md mx-auto px-4 py-4 pb-8">

 {/* بطاقة المستخدم + الكتابة */}
 <div className="flex items-start gap-3 mb-4">
 {/* الصورة الرمزية */}
 {user?.avatar_url ? (
 <img src={user.avatar_url} alt="" className="w-10 h-10 rounded-full object-cover flex-shrink-0" />
 ) : (
 <div className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm flex-shrink-0" style={{ background: `linear-gradient(135deg, ${user?.avatar_color || '#FBBF24'} 0%, ${user?.avatar_color || '#FBBF24'}aa 100%)` }}>
 {(user?.display_name || user?.username || '؟').charAt(0).toUpperCase()}
 </div>
 )}

 {/* حقل الكتابة */}
 <div className="flex-1 min-w-0">
 <div className="text-sm font-semibold mb-1">{user?.display_name || user?.username}</div>
 <MentionsInput
 value={content}
 onChange={setContent}
 placeholder="ماذا يدور في ذهنك؟"
 maxLength={2000}
 multiline
 rows={4}
 autoFocus
 className="bg-transparent text-[15px] leading-relaxed min-h-[100px] placeholder:text-muted-foreground/50 border-0"
 />
 </div>
 </div>

 {/* معاينة الصورة */}
 {imageUrl && (
 <div className="relative mb-4 overflow-hidden rounded-2xl bg-foreground/5">
 <img src={imageUrl} alt="معاينة" className="w-full object-cover" style={{ aspectRatio: '4 / 5', maxHeight: '60vh' }} />
 <button
 onClick={() => setImageUrl('')}
 className="absolute top-2 left-2 w-8 h-8 rounded-full bg-black/60 backdrop-blur text-white flex items-center justify-center"
 aria-label="حذف الصورة"
 >
 <X className="w-4 h-4" />
 </button>
 </div>
 )}

 {/* أزرار سريعة */}
 <div className="flex items-center gap-2 mb-6">
 <button
 onClick={() => fileInputRef.current?.click()}
 disabled={uploading || !user}
 className="flex items-center gap-2 px-3 py-2 rounded-xl bg-foreground/5 hover:bg-foreground/10 transition-colors disabled:opacity-50"
 >
 {uploading ? <Loader2 className="w-4 h-4 animate-spin text-amber-500" /> : <ImageIcon className="w-4 h-4 text-foreground" />}
 <span className="text-xs font-semibold">صورة</span>
 </button>
 <button
 onClick={() => {
 const input = document.getElementById('tag-input-field') as HTMLInputElement | null
 input?.focus()
 }}
 className="flex items-center gap-2 px-3 py-2 rounded-xl bg-foreground/5 hover:bg-foreground/10 transition-colors"
 >
 <Hash className="w-4 h-4 text-foreground" />
 <span className="text-xs font-semibold">وسم</span>
 </button>
 </div>

 {/* الفئة */}
 <div className="mb-6">
 <h3 className="text-xs font-bold text-muted-foreground mb-3 px-1">الفئة</h3>
 <div className="grid grid-cols-4 gap-2">
 {CATEGORIES.filter((c) => c.id !== 'all').map((cat) => {
 const Icon = cat.icon
 const isActive = category === cat.id
 return (
 <button
 key={cat.id}
 onClick={() => { setCategory(cat.id); haptic('light') }}
 className={`flex flex-col items-center gap-1.5 py-2.5 rounded-xl transition-colors ${
 isActive ? 'bg-foreground text-background' : 'bg-foreground/5 hover:bg-foreground/10 text-muted-foreground'
 }`}
 >
 <Icon className="w-4 h-4" />
 <span className="text-[10px] font-semibold">{cat.label}</span>
 </button>
 )
 })}
 </div>
 </div>

 {/* المزاج */}
 <div className="mb-6">
 <h3 className="text-xs font-bold text-muted-foreground mb-3 px-1">المزاج (اختياري)</h3>
 <div className="flex gap-2 overflow-x-auto pb-1" style={{ scrollbarWidth: 'none' }}>
 <button
 onClick={() => setMood(null)}
 className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-colors ${
 !mood ? 'bg-foreground text-background' : 'bg-foreground/5 text-muted-foreground'
 }`}
 >
 بدون
 </button>
 {MOODS.map((m) => {
 const Icon = m.icon
 const isActive = mood === m.id
 return (
 <button
 key={m.id}
 onClick={() => { setMood(m.id); haptic('light') }}
 className={`flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-colors ${
 isActive ? 'text-white' : 'bg-foreground/5 text-muted-foreground'
 }`}
 style={isActive ? { background: m.color } : {}}
 >
 <Icon className="w-3 h-3" />
 {m.label}
 </button>
 )
 })}
 </div>
 </div>

 {/* الوسوم */}
 <div className="mb-6">
 <h3 className="text-xs font-bold text-muted-foreground mb-3 px-1 flex items-center justify-between">
 <span>الوسوم</span>
 <span className="text-[10px] tabular-nums">{tags.length}/5</span>
 </h3>

 {tags.length > 0 && (
 <div className="flex flex-wrap gap-1.5 mb-3">
 {tags.map((tag) => (
 <span
 key={tag}
 className="inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full bg-amber-500/10 text-amber-700 dark:text-amber-300"
 dir="ltr"
 >
 #{tag}
 <button onClick={() => handleRemoveTag(tag)} className="hover:bg-amber-500/20 rounded-full p-0.5" aria-label="حذف">
 <X className="w-3 h-3" />
 </button>
 </span>
 ))}
 </div>
 )}

 <div className="relative">
 <Hash className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
 <input
 id="tag-input-field"
 type="text"
 value={tagInput}
 onChange={(e) => setTagInput(e.target.value)}
 onKeyDown={(e) => {
 if (e.key === 'Enter' || e.key === ',') {
 e.preventDefault()
 handleAddTag()
 }
 }}
 placeholder={tags.length >= 5 ? 'وصلت للحد الأقصى' : 'أضف وسمًا...'}
 className="w-full rounded-xl py-2.5 pr-10 pl-3 text-sm bg-foreground/5 outline-none focus:bg-foreground/10 transition-colors disabled:opacity-50"
 dir="ltr"
 disabled={tags.length >= 5}
 />
 </div>
 </div>

 {/* الفئة المختارة + المزاج (عرض مختصر) */}
 <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
 {(() => {
 const cat = CATEGORIES.find((c) => c.id === category)
 const Icon = cat?.icon
 return cat && Icon ? (
 <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full" style={{ background: `${cat.color}15`, color: cat.color }}>
 <Icon className="w-2.5 h-2.5" />
 {cat.label}
 </span>
 ) : null
 })()}
 {mood && (() => {
 const m = MOODS.find((m) => m.id === mood)
 const Icon = m?.icon
 return m && Icon ? (
 <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full" style={{ background: `${m.color}20`, color: m.color }}>
 <Icon className="w-2.5 h-2.5" />
 {m.label}
 </span>
 ) : null
 })()}
 </div>
 </div>
 </div>

 {/* محرر الصور */}
 {pendingFile && (
 <ImageEditor
 file={pendingFile}
 aspectRatio={4 / 5}
 onSave={handleImageEditSave}
 onCancel={() => setPendingFile(null)}
 title="تحرير الصورة"
 />
 )}
 </div>
 )
}
