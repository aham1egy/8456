'use client'

import { useEffect, useState, useCallback, useMemo } from 'react'
import { useRouter } from 'next/navigation'
import {
  LayoutDashboard, FileText, Flag, Users, BadgeCheck, LogOut,
  Trash2, Pin, Star, Check, X, Search, AlertCircle, Loader2,
  ShieldCheck, Ban, UserCheck, ArrowRight, Eye, RefreshCw, ChevronLeft,
  UserCog, Crown, Clock, AlertTriangle, Filter, Ban as BanIcon, Trash,
} from 'lucide-react'
import { useAppStore } from '@/store/app-store'
import { getCurrentProfile } from '@/lib/supabase/auth'
import { supabase } from '@/lib/supabase/client'
import { isAdminProfile, isOwnerProfile } from '@/lib/admin-config'
import { toast } from 'sonner'
import {
  fetchAdminStats, fetchAllPostsAdmin, fetchAllReports, fetchAllUsers,
  fetchVerificationRequests, fetchReportsStats,
  adminDeletePost, adminFeaturePost, adminPinPost,
  adminUpdateReportStatus, adminVerifyUser, adminUnverifyUser,
  adminApproveVerification, adminRejectVerification,
  adminAssignReportToMe, adminTakeReportAction, adminBulkUpdateReports,
  type AdminStats, type AdminReport, type AdminVerificationRequest,
} from '@/lib/admin'
import type { Profile, Post } from '@/lib/supabase/client'
import { MishriLogoMark } from './MishriLogo'
import { StaffManagement } from './StaffManagement'

type Tab = 'overview' | 'posts' | 'reports' | 'users' | 'verifications' | 'staff'

// ============================================================
// AdminPage — لوحة الإدارة الكاملة
// ============================================================
export function AdminPage() {
  const router = useRouter()
  const setUser = useAppStore((s) => s.setUser)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [loading, setLoading] = useState(true)
  const [tab, setTab] = useState<Tab>('overview')

  useEffect(() => {
    void (async () => {
      try {
        const p = await getCurrentProfile()
        if (!p) { router.replace('/'); return }
        if (!isAdminProfile(p)) {
          toast.error('ليس لديك صلاحية الإدارة')
          router.replace('/home')
          return
        }
        setProfile(p)
        setUser(p)
      } catch {
        router.replace('/')
      } finally {
        setLoading(false)
      }
    })()
  }, [router, setUser])

  if (loading) {
    return (
      <div className="min-h-[100dvh] mishri-aurora-bg flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <MishriLogoMark size={64} animated />
          <div className="w-8 h-8 border-2 border-amber-500 border-t-transparent rounded-full animate-spin" />
          <p className="text-sm text-muted-foreground">جارٍ فحص صلاحية الإدارة...</p>
        </div>
      </div>
    )
  }

  if (!profile) return null

  const TABS: { id: Tab; label: string; icon: typeof Users }[] = [
    { id: 'overview', label: 'النظرة العامة', icon: LayoutDashboard },
    { id: 'posts', label: 'المنشورات', icon: FileText },
    { id: 'reports', label: 'البلاغات', icon: Flag },
    { id: 'users', label: 'الحسابات', icon: Users },
    { id: 'verifications', label: 'التوثيقات', icon: BadgeCheck },
    // تبويب الفريق — يظهر فقط للمالك
    ...(isOwnerProfile(profile) ? [
      { id: 'staff' as Tab, label: 'الفريق', icon: UserCog },
    ] : []),
  ]

  return (
    <div className="min-h-[100dvh] bg-background flex flex-col">
      {/* Header */}
      <header
        className="flex-shrink-0 border-b border-foreground/10 bg-background/95 backdrop-blur-xl z-40"
        style={{ paddingTop: 'env(safe-area-inset-top, 0px)' }}
      >
        <div className="w-full px-4 py-2.5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <MishriLogoMark size={32} />
            <div>
              <h1 className="font-display text-base font-bold mishri-gradient-text leading-tight flex items-center gap-1.5">
                لوحة الإدارة
                {isOwnerProfile(profile) && (
                  <Crown className="w-3.5 h-3.5 text-amber-500" />
                )}
              </h1>
              <p className="text-[10px] text-muted-foreground leading-tight">
                @{profile.username}
                {isOwnerProfile(profile) && (
                  <span className="text-amber-600 dark:text-amber-400 font-bold"> • المالك</span>
                )}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={() => router.push('/home')}
              className="px-3 py-1.5 rounded-lg text-xs font-semibold text-muted-foreground hover:bg-foreground/5 flex items-center gap-1.5"
            >
              <ArrowRight className="w-3.5 h-3.5" />
              لل تطبيق
            </button>
            <button
              onClick={async () => {
                await supabase.auth.signOut()
                router.replace('/')
              }}
              className="w-8 h-8 rounded-lg bg-rose-500/10 text-rose-500 hover:bg-rose-500/20 flex items-center justify-center"
              aria-label="خروج"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="w-full px-3 pb-1.5 flex gap-1 overflow-x-auto mishri-scrollbar-hide">
          {TABS.map((t) => {
            const Icon = t.icon
            return (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`flex-shrink-0 px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
                  tab === t.id
                    ? 'mishri-gradient-primary text-white shadow-md'
                    : 'text-muted-foreground hover:bg-foreground/5'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                {t.label}
              </button>
            )
          })}
        </div>
      </header>

      {/* Content */}
      <main className="flex-1 overflow-y-auto">
        {tab === 'overview' && <OverviewTab />}
        {tab === 'posts' && <PostsTab />}
        {tab === 'reports' && <ReportsTab />}
        {tab === 'users' && <UsersTab />}
        {tab === 'verifications' && <VerificationsTab />}
        {tab === 'staff' && isOwnerProfile(profile) && (
          <StaffManagement currentUserId={profile.id} />
        )}
      </main>
    </div>
  )
}

// ============================================================
// Overview Tab
// ============================================================
function OverviewTab() {
  const [stats, setStats] = useState<AdminStats | null>(null)
  const [loading, setLoading] = useState(true)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const s = await fetchAdminStats()
      setStats(s)
    } catch (e) {
      toast.error('فشل تحميل الإحصائيات')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { void load() }, [load])

  if (loading || !stats) {
    return <CenteredLoader label="جارٍ تحميل الإحصائيات..." />
  }

  const cards = [
    { label: 'إجمالي المستخدمين', value: stats.total_users, sub: `+${stats.new_users_today} اليوم`, icon: Users, color: 'text-blue-500' },
    { label: 'إجمالي المنشورات', value: stats.total_posts, sub: `+${stats.new_posts_today} اليوم`, icon: FileText, color: 'text-amber-500' },
    { label: 'إجمالي التعليقات', value: stats.total_comments, sub: '', icon: MessageSquare, color: 'text-emerald-500' },
    { label: 'إجمالي الرسائل', value: stats.total_messages, sub: '', icon: Mail, color: 'text-violet-500' },
    { label: 'بلاغات معلّقة', value: stats.pending_reports, sub: 'تحتاج مراجعة', icon: Flag, color: 'text-rose-500', urgent: stats.pending_reports > 0 },
    { label: 'طلبات توثيق', value: stats.pending_verifications, sub: 'معلّقة', icon: BadgeCheck, color: 'text-yellow-500', urgent: stats.pending_verifications > 0 },
    { label: 'مستخدمون موثّقون', value: stats.verified_users, sub: '', icon: ShieldCheck, color: 'text-emerald-500' },
  ]

  return (
    <div className="w-full px-3 py-4 space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="font-display text-lg font-bold">النظرة العامة</h2>
        <button onClick={load} className="p-1.5 rounded-lg hover:bg-foreground/5">
          <RefreshCw className="w-4 h-4 text-muted-foreground" />
        </button>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 gap-2.5">
        {cards.map((c) => {
          const Icon = c.icon
          return (
            <div
              key={c.label}
              className={`rounded-2xl border p-3 ${
                c.urgent
                  ? 'border-rose-500/30 bg-rose-500/5'
                  : 'border-foreground/8 bg-foreground/[0.02]'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <Icon className={`w-4 h-4 ${c.color}`} />
                {c.urgent && (
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-500 mishri-pulse" />
                )}
              </div>
              <div className="text-2xl font-bold tabular-nums">
                {c.value.toLocaleString('ar-EG')}
              </div>
              <div className="text-[11px] text-muted-foreground mt-0.5">{c.label}</div>
              {c.sub && (
                <div className="text-[10px] text-muted-foreground/70 mt-0.5">{c.sub}</div>
              )}
            </div>
          )
        })}
      </div>

      {/* Quick info */}
      <div className="rounded-2xl border border-amber-500/20 bg-amber-500/5 p-3">
        <div className="flex items-start gap-2.5">
          <AlertCircle className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
          <div className="text-[11px] leading-relaxed">
            <p className="font-bold text-amber-700 dark:text-amber-300 mb-1">
              تنبيه الإدارة
            </p>
            <p className="text-muted-foreground">
              العمليات الحساسة (حذف منشور، توثيق حساب) تتطلب تأكيدًا قبل التنفيذ. تأكد من مراجعة كل إجراء بعناية.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

// Helper imports used in cards (need to import here to avoid duplication)
import { MessageSquare, Mail } from 'lucide-react'

// ============================================================
// Posts Tab
// ============================================================
function PostsTab() {
  const [posts, setPosts] = useState<Post[]>([])
  const [loading, setLoading] = useState(true)
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(0)
  const [confirmDelete, setConfirmDelete] = useState<Post | null>(null)
  const pageSize = 20

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const { posts, total } = await fetchAllPostsAdmin(pageSize, page * pageSize)
      setPosts(posts)
      setTotal(total)
    } catch {
      toast.error('فشل تحميل المنشورات')
    } finally {
      setLoading(false)
    }
  }, [page])

  useEffect(() => { void load() }, [load])

  const handleAction = async (action: 'delete' | 'feature' | 'pin', post: Post) => {
    try {
      if (action === 'delete') {
        await adminDeletePost(post.id)
        toast.success('تم حذف المنشور')
        setConfirmDelete(null)
      } else if (action === 'feature') {
        await adminFeaturePost(post.id, !post.is_featured)
        toast.success(post.is_featured ? 'تم إزالة التمييز' : 'تم تمييز المنشور')
      } else if (action === 'pin') {
        await adminPinPost(post.id, !post.is_pinned)
        toast.success(post.is_pinned ? 'تم إلغاء التثبيت' : 'تم تثبيت المنشور')
      }
      await load()
    } catch (e: any) {
      toast.error(e.message || 'فشلت العملية')
    }
  }

  if (loading && posts.length === 0) return <CenteredLoader label="جارٍ تحميل المنشورات..." />

  return (
    <div className="w-full px-3 py-4 space-y-3">
      <div className="flex items-center justify-between">
        <h2 className="font-display text-lg font-bold">
          المنشورات <span className="text-sm text-muted-foreground font-normal">({total})</span>
        </h2>
        <button onClick={load} className="p-1.5 rounded-lg hover:bg-foreground/5">
          <RefreshCw className="w-4 h-4 text-muted-foreground" />
        </button>
      </div>

      {posts.length === 0 ? (
        <EmptyState icon={FileText} label="لا توجد منشورات" />
      ) : (
        <div className="space-y-2">
          {posts.map((post) => (
            <div
              key={post.id}
              className="rounded-2xl border border-foreground/8 bg-foreground/[0.02] p-3"
            >
              <div className="flex items-start justify-between gap-2 mb-2">
                <div className="flex items-center gap-2 min-w-0 flex-1">
                  <div
                    className="w-7 h-7 rounded-full flex items-center justify-center text-white text-[10px] font-bold flex-shrink-0"
                    style={{
                      background: `linear-gradient(135deg, ${post.profile?.avatar_color || '#1F4E8C'}, ${post.profile?.avatar_color || '#0E2A4F'}aa)`,
                    }}
                  >
                    {(post.profile?.display_name || post.profile?.username || '؟').charAt(0).toUpperCase()}
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs font-bold truncate">
                      @{post.profile?.username || 'محذوف'}
                    </div>
                    <div className="text-[10px] text-muted-foreground">
                      {new Date(post.created_at).toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short' })}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  {post.is_pinned && (
                    <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-blue-500/15 text-blue-500 flex items-center gap-0.5">
                      <Pin className="w-2.5 h-2.5" /> مثبّت
                    </span>
                  )}
                  {post.is_featured && (
                    <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-amber-500/15 text-amber-500 flex items-center gap-0.5">
                      <Star className="w-2.5 h-2.5" /> مميّز
                    </span>
                  )}
                </div>
              </div>

              <p className="text-xs leading-relaxed mb-2 line-clamp-3">
                {post.content}
              </p>

              <div className="flex items-center gap-1 text-[10px] text-muted-foreground mb-2">
                <span>❤️ {post.likes_count}</span>
                <span>·</span>
                <span>💬 {post.comments_count}</span>
                <span>·</span>
                <span>🔁 {post.reposts_count}</span>
                {post.image_url && (
                  <>
                    <span>·</span>
                    <span>📷 صورة</span>
                  </>
                )}
              </div>

              <div className="flex items-center gap-1">
                <button
                  onClick={() => handleAction('pin', post)}
                  className={`flex-1 py-1.5 rounded-lg text-[11px] font-bold flex items-center justify-center gap-1 ${
                    post.is_pinned
                      ? 'bg-blue-500/10 text-blue-500 hover:bg-blue-500/20'
                      : 'bg-foreground/5 hover:bg-foreground/10'
                  }`}
                >
                  <Pin className="w-3 h-3" />
                  {post.is_pinned ? 'إلغاء التثبيت' : 'تثبيت'}
                </button>
                <button
                  onClick={() => handleAction('feature', post)}
                  className={`flex-1 py-1.5 rounded-lg text-[11px] font-bold flex items-center justify-center gap-1 ${
                    post.is_featured
                      ? 'bg-amber-500/10 text-amber-500 hover:bg-amber-500/20'
                      : 'bg-foreground/5 hover:bg-foreground/10'
                  }`}
                >
                  <Star className="w-3 h-3" />
                  {post.is_featured ? 'إزالة التمييز' : 'تمييز'}
                </button>
                <button
                  onClick={() => setConfirmDelete(post)}
                  className="flex-1 py-1.5 rounded-lg text-[11px] font-bold bg-rose-500/10 text-rose-500 hover:bg-rose-500/20 flex items-center justify-center gap-1"
                >
                  <Trash2 className="w-3 h-3" />
                  حذف
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Pagination */}
      {total > pageSize && (
        <div className="flex items-center justify-center gap-2 pt-2">
          <button
            onClick={() => setPage((p) => Math.max(0, p - 1))}
            disabled={page === 0}
            className="px-3 py-1.5 rounded-lg text-xs font-bold bg-foreground/5 hover:bg-foreground/10 disabled:opacity-30 flex items-center gap-1"
          >
            <ChevronLeft className="w-3 h-3" />
            السابق
          </button>
          <span className="text-xs text-muted-foreground">
            صفحة {page + 1} من {Math.ceil(total / pageSize)}
          </span>
          <button
            onClick={() => setPage((p) => p + 1)}
            disabled={(page + 1) * pageSize >= total}
            className="px-3 py-1.5 rounded-lg text-xs font-bold bg-foreground/5 hover:bg-foreground/10 disabled:opacity-30 flex items-center gap-1"
          >
            التالي
            <ChevronLeft className="w-3 h-3 rotate-180" />
          </button>
        </div>
      )}

      {/* Delete confirmation */}
      {confirmDelete && (
        <ConfirmModal
          title="حذف المنشور؟"
          message="سيتم حذف المنشور نهائيًا مع كل تعليقاته وإعجاباته. لا يمكن التراجع."
          confirmLabel="نعم، احذف"
          onConfirm={() => handleAction('delete', confirmDelete)}
          onCancel={() => setConfirmDelete(null)}
        />
      )}
    </div>
  )
}

// ============================================================
// Reports Tab
// ============================================================
function ReportsTab() {
  const [reports, setReports] = useState<AdminReport[]>([])
  const [stats, setStats] = useState<{ total: number; pending: number; reviewing: number; actioned: number; dismissed: number } | null>(null)
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState<'all' | 'pending' | 'reviewing' | 'actioned' | 'dismissed'>('pending')
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set())
  const [actionModal, setActionModal] = useState<AdminReport | null>(null)
  const [actionType, setActionType] = useState<'delete_post' | 'restrict_user' | 'warn_user' | 'no_action' | 'other'>('no_action')
  const [adminNote, setAdminNote] = useState('')
  const [restrictDays, setRestrictDays] = useState(7)
  const [deletePost, setDeletePost] = useState(false)
  const [processing, setProcessing] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const [reportsRes, statsRes] = await Promise.all([
        fetchAllReports(50, 0, filter),
        fetchReportsStats(),
      ])
      setReports(reportsRes.reports)
      setStats(statsRes)
    } catch {
      toast.error('فشل تحميل البلاغات')
    } finally {
      setLoading(false)
    }
  }, [filter])

  useEffect(() => { void load() }, [load])

  const handleAssignToMe = async (id: string) => {
    try {
      await adminAssignReportToMe(id)
      toast.success('تم تعيين البلاغ لك')
      await load()
    } catch (e: any) {
      toast.error(e.message || 'فشل التعيين')
    }
  }

  const openActionModal = (report: AdminReport) => {
    setActionModal(report)
    setActionType('no_action')
    setAdminNote('')
    setRestrictDays(7)
    setDeletePost(false)
  }

  const handleTakeAction = async () => {
    if (!actionModal) return
    setProcessing(true)
    try {
      await adminTakeReportAction(actionModal.id, {
        action: 'actioned',
        actionType,
        adminNote,
        deleteReportedPost: deletePost,
        restrictUserDays: actionType === 'restrict_user' ? restrictDays : 0,
      })
      toast.success('تم اتخاذ الإجراء بنجاح')
      setActionModal(null)
      await load()
    } catch (e: any) {
      toast.error(e.message || 'فشل الإجراء')
    } finally {
      setProcessing(false)
    }
  }

  const handleDismiss = async (id: string) => {
    try {
      await adminUpdateReportStatus(id, 'dismissed', { adminNote: 'تم الرفض بدون إجراء' })
      toast.success('تم رفض البلاغ')
      await load()
    } catch (e: any) {
      toast.error(e.message || 'فشلت العملية')
    }
  }

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  const handleBulkAction = async (status: 'actioned' | 'dismissed') => {
    if (selectedIds.size === 0) return
    try {
      await adminBulkUpdateReports(Array.from(selectedIds), status)
      toast.success(`تم تحديث ${selectedIds.size} بلاغ`)
      setSelectedIds(new Set())
      await load()
    } catch (e: any) {
      toast.error(e.message || 'فشل التحديث')
    }
  }

  if (loading && reports.length === 0 && !stats) return <CenteredLoader label="جارٍ تحميل البلاغات..." />

  return (
    <div className="w-full px-3 py-4 space-y-3">
      <div className="flex items-center justify-between">
        <h2 className="font-display text-lg font-bold">
          البلاغات {stats && <span className="text-sm text-muted-foreground font-normal">({stats.total})</span>}
        </h2>
        <button onClick={load} className="p-1.5 rounded-lg hover:bg-foreground/5">
          <RefreshCw className="w-4 h-4 text-muted-foreground" />
        </button>
      </div>

      {/* إحصائيات سريعة */}
      {stats && (
        <div className="grid grid-cols-4 gap-1.5">
          <StatPill label="معلّقة" value={stats.pending} color="text-rose-500" bg="bg-rose-500/5" urgent={stats.pending > 0} />
          <StatPill label="قيد المراجعة" value={stats.reviewing} color="text-amber-500" bg="bg-amber-500/5" />
          <StatPill label="تم الإجراء" value={stats.actioned} color="text-emerald-500" bg="bg-emerald-500/5" />
          <StatPill label="مرفوضة" value={stats.dismissed} color="text-muted-foreground" bg="bg-foreground/5" />
        </div>
      )}

      {/* Filter chips */}
      <div className="flex gap-1.5 overflow-x-auto mishri-scrollbar-hide">
        {([
          { id: 'pending', label: 'معلّقة' },
          { id: 'reviewing', label: 'قيد المراجعة' },
          { id: 'actioned', label: 'تم الإجراء' },
          { id: 'dismissed', label: 'مرفوضة' },
          { id: 'all', label: 'الكل' },
        ] as const).map((f) => (
          <button
            key={f.id}
            onClick={() => setFilter(f.id)}
            className={`flex-shrink-0 px-3 py-1 rounded-full text-xs font-bold ${
              filter === f.id
                ? 'mishri-gradient-primary text-white'
                : 'bg-foreground/5 text-muted-foreground'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Bulk actions bar */}
      {selectedIds.size > 0 && (
        <div className="sticky top-0 z-10 bg-background/95 backdrop-blur-xl border border-foreground/10 rounded-2xl p-2.5 flex items-center justify-between gap-2">
          <span className="text-xs font-bold">{selectedIds.size} محدد</span>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => handleBulkAction('actioned')}
              className="px-2.5 py-1 rounded-lg bg-emerald-500/10 text-emerald-600 text-[10px] font-bold hover:bg-emerald-500/20"
            >
              اتخاذ إجراء جماعي
            </button>
            <button
              onClick={() => handleBulkAction('dismissed')}
              className="px-2.5 py-1 rounded-lg bg-foreground/5 text-[10px] font-bold hover:bg-foreground/10"
            >
              رفض جماعي
            </button>
            <button
              onClick={() => setSelectedIds(new Set())}
              className="px-2 py-1 rounded-lg text-[10px] text-muted-foreground"
            >
              إلغاء
            </button>
          </div>
        </div>
      )}

      {reports.length === 0 ? (
        <EmptyState icon={Flag} label="لا توجد بلاغات بهذه الحالة" />
      ) : (
        <div className="space-y-2">
          {reports.map((r) => (
            <div
              key={r.id}
              className={`rounded-2xl border p-3 transition-all ${
                r.status === 'pending'
                  ? 'border-rose-500/20 bg-rose-500/[0.02]'
                  : r.status === 'reviewing'
                  ? 'border-amber-500/20 bg-amber-500/[0.02]'
                  : 'border-foreground/8 bg-foreground/[0.02]'
              }`}
            >
              {/* رأس البلاغ */}
              <div className="flex items-start gap-2 mb-2">
                {/* checkbox for bulk select */}
                <input
                  type="checkbox"
                  checked={selectedIds.has(r.id)}
                  onChange={() => toggleSelect(r.id)}
                  className="mt-1 w-3.5 h-3.5 accent-amber-500"
                />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-xs font-bold text-rose-500">
                      {r.reason}
                    </span>
                    <StatusBadge status={r.status} />
                  </div>
                  <div className="text-[10px] text-muted-foreground mt-0.5">
                    من @{r.reporter_profile?.username || 'محذوف'} • {new Date(r.created_at).toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short' })}
                  </div>
                </div>
              </div>

              {/* تفاصيل البلاغ */}
              {r.details && (
                <p className="text-[11px] text-muted-foreground mb-2 bg-foreground/5 rounded-lg p-2">
                  {r.details}
                </p>
              )}

              {/* المنشور المبلّغ عنه */}
              {r.reported_post && (
                <div className="rounded-lg bg-foreground/5 p-2 mb-2">
                  <div className="text-[10px] text-muted-foreground mb-0.5 flex items-center gap-1">
                    <FileText className="w-2.5 h-2.5" />
                    المنشور المبلّغ عنه:
                  </div>
                  <p className="text-[11px] line-clamp-3 leading-relaxed">{r.reported_post.content}</p>
                  {r.reported_post.image_url && (
                    <div className="text-[10px] text-muted-foreground mt-1">📷 يحتوي على صورة</div>
                  )}
                </div>
              )}

              {/* المستخدم المبلّغ عنه */}
              {r.reported_profile && (
                <div className="rounded-lg bg-foreground/5 p-2 mb-2 flex items-center gap-2">
                  <div
                    className="w-6 h-6 rounded-full flex items-center justify-center text-white text-[9px] font-bold"
                    style={{
                      background: `linear-gradient(135deg, ${r.reported_profile.avatar_color || '#1F4E8C'}, ${r.reported_profile.avatar_color || '#0E2A4F'}aa)`,
                    }}
                  >
                    {(r.reported_profile.display_name || r.reported_profile.username || '؟').charAt(0).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-[10px] text-muted-foreground">المستخدم المبلّغ عنه:</div>
                    <div className="text-[11px] font-bold">@{r.reported_profile.username}</div>
                  </div>
                </div>
              )}

              {/* الإجراء المتخذ */}
              {r.action_taken && (
                <div className="rounded-lg bg-emerald-500/5 border border-emerald-500/15 p-2 mb-2">
                  <div className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold mb-0.5 flex items-center gap-1">
                    <Check className="w-2.5 h-2.5" />
                    الإجراء المتخذ:
                  </div>
                  <div className="text-[11px]">{r.action_taken}</div>
                  {r.admin_note && (
                    <div className="text-[10px] text-muted-foreground mt-1 italic">"{r.admin_note}"</div>
                  )}
                  {r.admin_profile && (
                    <div className="text-[9px] text-muted-foreground mt-1">
                      بواسطة @{r.admin_profile.username} • {r.resolved_at ? new Date(r.resolved_at).toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short' }) : ''}
                    </div>
                  )}
                </div>
              )}

              {/* أزرار الإجراءات */}
              {r.status === 'pending' && (
                <div className="grid grid-cols-3 gap-1">
                  <button
                    onClick={() => handleAssignToMe(r.id)}
                    className="py-1.5 rounded-lg text-[10px] font-bold bg-foreground/5 hover:bg-foreground/10 flex items-center justify-center gap-1"
                  >
                    <Eye className="w-3 h-3" />
                    عَيّن لي
                  </button>
                  <button
                    onClick={() => openActionModal(r)}
                    className="py-1.5 rounded-lg text-[10px] font-bold bg-emerald-500/10 text-emerald-600 hover:bg-emerald-500/20 flex items-center justify-center gap-1"
                  >
                    <Check className="w-3 h-3" />
                    إجراء
                  </button>
                  <button
                    onClick={() => handleDismiss(r.id)}
                    className="py-1.5 rounded-lg text-[10px] font-bold bg-foreground/5 hover:bg-foreground/10 flex items-center justify-center gap-1"
                  >
                    <X className="w-3 h-3" />
                    رفض
                  </button>
                </div>
              )}

              {r.status === 'reviewing' && (
                <div className="grid grid-cols-2 gap-1">
                  <button
                    onClick={() => openActionModal(r)}
                    className="py-1.5 rounded-lg text-[10px] font-bold bg-emerald-500/10 text-emerald-600 hover:bg-emerald-500/20 flex items-center justify-center gap-1"
                  >
                    <Check className="w-3 h-3" />
                    إجراء
                  </button>
                  <button
                    onClick={() => handleDismiss(r.id)}
                    className="py-1.5 rounded-lg text-[10px] font-bold bg-foreground/5 hover:bg-foreground/10 flex items-center justify-center gap-1"
                  >
                    <X className="w-3 h-3" />
                    رفض
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Modal اتخاذ الإجراء */}
      {actionModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setActionModal(null)}>
          <div className="bg-background rounded-3xl max-w-md w-full max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="sticky top-0 bg-background/95 backdrop-blur-xl border-b border-foreground/8 p-4 flex items-center justify-between">
              <h3 className="font-display text-base font-bold">اتخاذ إجراء على البلاغ</h3>
              <button onClick={() => setActionModal(null)} className="p-1 rounded-lg hover:bg-foreground/5">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 space-y-3">
              {/* ملخص البلاغ */}
              <div className="rounded-xl bg-foreground/5 p-2.5">
                <div className="text-xs font-bold text-rose-500 mb-1">{actionModal.reason}</div>
                <div className="text-[10px] text-muted-foreground">
                  من @{actionModal.reporter_profile?.username || 'محذوف'}
                </div>
                {actionModal.details && (
                  <p className="text-[11px] text-muted-foreground mt-1">{actionModal.details}</p>
                )}
              </div>

              {/* نوع الإجراء */}
              <div>
                <label className="text-xs font-bold text-muted-foreground mb-2 block">نوع الإجراء</label>
                <div className="space-y-1">
                  {([
                    { id: 'no_action', label: 'لا إجراء مطلوب', desc: 'البلاغ غير مبرر', icon: Check },
                    { id: 'delete_post', label: 'حذف المنشور', desc: 'سيتم حذف المنشور المبلّغ عنه', icon: Trash },
                    { id: 'restrict_user', label: 'تقييد المستخدم', desc: 'تقييد مؤقت للمستخدم المخالف', icon: BanIcon },
                    { id: 'warn_user', label: 'تحذير المستخدم', desc: 'إرسال تنبيه فقط', icon: AlertTriangle },
                    { id: 'other', label: 'إجراء آخر', desc: 'اكتب التفاصيل في الملاحظة', icon: Filter },
                  ] as const).map((opt) => {
                    const Icon = opt.icon
                    return (
                      <button
                        key={opt.id}
                        onClick={() => {
                          setActionType(opt.id)
                          if (opt.id === 'delete_post') setDeletePost(true)
                          else setDeletePost(false)
                        }}
                        className={`w-full flex items-start gap-2.5 p-2.5 rounded-xl text-right transition-all ${
                          actionType === opt.id
                            ? 'bg-amber-500/10 border border-amber-500/30'
                            : 'bg-foreground/5 border border-transparent hover:bg-foreground/10'
                        }`}
                      >
                        <Icon className="w-4 h-4 flex-shrink-0 mt-0.5" />
                        <div className="flex-1">
                          <div className="text-xs font-bold">{opt.label}</div>
                          <div className="text-[10px] text-muted-foreground">{opt.desc}</div>
                        </div>
                        {actionType === opt.id && (
                          <Check className="w-3 h-3 text-amber-500" />
                        )}
                      </button>
                    )
                  })}
                </div>
              </div>

              {/* خيارات إضافية */}
              {actionType === 'restrict_user' && (
                <div>
                  <label className="text-xs font-bold text-muted-foreground mb-1.5 block">
                    مدة التقييد (أيام)
                  </label>
                  <div className="flex gap-1.5">
                    {[1, 3, 7, 14, 30].map((d) => (
                      <button
                        key={d}
                        onClick={() => setRestrictDays(d)}
                        className={`flex-1 py-1.5 rounded-lg text-xs font-bold ${
                          restrictDays === d
                            ? 'mishri-gradient-primary text-white'
                            : 'bg-foreground/5 text-muted-foreground'
                        }`}
                      >
                        {d}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {actionType === 'delete_post' && actionModal.reported_post && (
                <label className="flex items-start gap-2 p-2 rounded-lg bg-rose-500/5 border border-rose-500/20">
                  <input
                    type="checkbox"
                    checked={deletePost}
                    onChange={(e) => setDeletePost(e.target.checked)}
                    className="mt-0.5 w-3.5 h-3.5 accent-rose-500"
                  />
                  <span className="text-[11px] text-rose-600 dark:text-rose-400">
                    تأكيد حذف المنشور نهائيًا. لا يمكن التراجع.
                  </span>
                </label>
              )}

              {/* ملاحظة المدير */}
              <div>
                <label className="text-xs font-bold text-muted-foreground mb-1.5 block">
                  ملاحظة (اختياري)
                </label>
                <textarea
                  value={adminNote}
                  onChange={(e) => setAdminNote(e.target.value)}
                  rows={2}
                  placeholder="سبب الإجراء أو تفاصيل إضافية..."
                  className="mishri-input w-full rounded-xl p-2.5 text-xs outline-none resize-none"
                />
              </div>

              {/* أزرار */}
              <div className="flex gap-2 pt-2">
                <button
                  onClick={() => setActionModal(null)}
                  className="flex-1 py-2.5 rounded-xl bg-foreground/5 text-xs font-bold"
                >
                  إلغاء
                </button>
                <button
                  onClick={handleTakeAction}
                  disabled={processing}
                  className="flex-1 py-2.5 rounded-xl mishri-gradient-primary text-white text-xs font-bold disabled:opacity-50 flex items-center justify-center gap-1"
                >
                  {processing ? (
                    <Loader2 className="w-3 h-3 animate-spin" />
                  ) : (
                    <>
                      <Check className="w-3 h-3" />
                      تأكيد الإجراء
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// Helper: Status badge for reports
function StatusBadge({ status }: { status: string }) {
  const config: Record<string, { label: string; color: string }> = {
    pending: { label: 'معلّق', color: 'bg-rose-500/15 text-rose-500' },
    reviewing: { label: 'قيد المراجعة', color: 'bg-amber-500/15 text-amber-500' },
    actioned: { label: 'تم الإجراء', color: 'bg-emerald-500/15 text-emerald-500' },
    dismissed: { label: 'مرفوض', color: 'bg-foreground/10 text-muted-foreground' },
  }
  const c = config[status] || config.pending
  return (
    <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${c.color}`}>
      {c.label}
    </span>
  )
}

// Helper: Stat pill
function StatPill({ label, value, color, bg, urgent }: { label: string; value: number; color: string; bg: string; urgent?: boolean }) {
  return (
    <div className={`rounded-xl p-2 ${bg} text-center relative`}>
      {urgent && value > 0 && (
        <span className="absolute top-1 right-1 w-1.5 h-1.5 rounded-full bg-rose-500 mishri-pulse" />
      )}
      <div className={`text-lg font-bold tabular-nums ${color}`}>{value.toLocaleString('ar-EG')}</div>
      <div className="text-[9px] text-muted-foreground">{label}</div>
    </div>
  )
}

// ============================================================
// Users Tab
// ============================================================
function UsersTab() {
  const [users, setUsers] = useState<Profile[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(0)
  const [confirmAction, setConfirmAction] = useState<{ user: Profile; action: 'verify' | 'unverify' | 'delete'; type?: any } | null>(null)
  const pageSize = 20

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const { users, total } = await fetchAllUsers(pageSize, page * pageSize, search || undefined)
      setUsers(users)
      setTotal(total)
    } catch {
      toast.error('فشل تحميل المستخدمين')
    } finally {
      setLoading(false)
    }
  }, [page, search])

  useEffect(() => {
    const t = setTimeout(() => void load(), search ? 400 : 0)
    return () => clearTimeout(t)
  }, [load, search])

  const handleAction = async () => {
    if (!confirmAction) return
    const { user, action, type } = confirmAction
    try {
      if (action === 'verify' && type) {
        await adminVerifyUser(user.id, type, true)
        toast.success(`تم توثيق @${user.username}`)
      } else if (action === 'unverify') {
        await adminUnverifyUser(user.id)
        toast.success(`تم إزالة توثيق @${user.username}`)
      } else if (action === 'delete') {
        await supabase.from('profiles').delete().eq('id', user.id)
        toast.success(`تم حذف حساب @${user.username}`)
      }
      setConfirmAction(null)
      await load()
    } catch (e: any) {
      toast.error(e.message || 'فشلت العملية')
    }
  }

  return (
    <div className="w-full px-3 py-4 space-y-3">
      <div className="flex items-center justify-between">
        <h2 className="font-display text-lg font-bold">
          الحسابات <span className="text-sm text-muted-foreground font-normal">({total})</span>
        </h2>
        <button onClick={load} className="p-1.5 rounded-lg hover:bg-foreground/5">
          <RefreshCw className="w-4 h-4 text-muted-foreground" />
        </button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input
          type="text"
          value={search}
          onChange={(e) => { setSearch(e.target.value); setPage(0) }}
          placeholder="ابحث باليوزرنيم أو الاسم..."
          className="mishri-input w-full rounded-xl py-2 pr-9 pl-3 text-sm font-medium outline-none"
        />
      </div>

      {loading && users.length === 0 ? (
        <CenteredLoader label="جارٍ تحميل المستخدمين..." />
      ) : users.length === 0 ? (
        <EmptyState icon={Users} label={search ? 'لا توجد نتائج' : 'لا يوجد مستخدمون'} />
      ) : (
        <div className="space-y-2">
          {users.map((u) => (
            <div key={u.id} className="rounded-2xl border border-foreground/8 bg-foreground/[0.02] p-3">
              <div className="flex items-center gap-2.5 mb-2">
                <div
                  className="w-9 h-9 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0"
                  style={{
                    background: `linear-gradient(135deg, ${u.avatar_color || '#1F4E8C'}, ${u.avatar_color || '#0E2A4F'}aa)`,
                  }}
                >
                  {(u.display_name || u.username || '؟').charAt(0).toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1">
                    <span className="text-xs font-bold truncate">@{u.username}</span>
                    {u.is_verified && (
                      <BadgeCheck className="w-3 h-3 text-amber-500 flex-shrink-0" />
                    )}
                  </div>
                  <div className="text-[10px] text-muted-foreground">
                    {u.posts_count} منشور · {u.followers_count} متابع
                  </div>
                </div>
                {u.verified_type && (
                  <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-amber-500/15 text-amber-600">
                    {u.verified_type}
                  </span>
                )}
              </div>

              <div className="flex items-center gap-1">
                <button
                  onClick={() => setConfirmAction({ user: u, action: 'verify', type: 'official' })}
                  className={`flex-1 py-1.5 rounded-lg text-[10px] font-bold flex items-center justify-center gap-1 ${
                    u.is_verified
                      ? 'bg-foreground/5 text-muted-foreground'
                      : 'bg-amber-500/10 text-amber-600 hover:bg-amber-500/20'
                  }`}
                  disabled={u.is_verified}
                >
                  <BadgeCheck className="w-3 h-3" />
                  توثيق
                </button>
                {u.is_verified && (
                  <button
                    onClick={() => setConfirmAction({ user: u, action: 'unverify' })}
                    className="flex-1 py-1.5 rounded-lg text-[10px] font-bold bg-foreground/5 hover:bg-foreground/10 flex items-center justify-center gap-1"
                  >
                    <X className="w-3 h-3" />
                    إزالة التوثيق
                  </button>
                )}
                <button
                  onClick={() => setConfirmAction({ user: u, action: 'delete' })}
                  className="flex-1 py-1.5 rounded-lg text-[10px] font-bold bg-rose-500/10 text-rose-500 hover:bg-rose-500/20 flex items-center justify-center gap-1"
                >
                  <Ban className="w-3 h-3" />
                  حذف
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Pagination */}
      {total > pageSize && (
        <div className="flex items-center justify-center gap-2 pt-2">
          <button
            onClick={() => setPage((p) => Math.max(0, p - 1))}
            disabled={page === 0}
            className="px-3 py-1.5 rounded-lg text-xs font-bold bg-foreground/5 hover:bg-foreground/10 disabled:opacity-30 flex items-center gap-1"
          >
            <ChevronLeft className="w-3 h-3" />
            السابق
          </button>
          <span className="text-xs text-muted-foreground">
            {page + 1} / {Math.ceil(total / pageSize)}
          </span>
          <button
            onClick={() => setPage((p) => p + 1)}
            disabled={(page + 1) * pageSize >= total}
            className="px-3 py-1.5 rounded-lg text-xs font-bold bg-foreground/5 hover:bg-foreground/10 disabled:opacity-30 flex items-center gap-1"
          >
            التالي
            <ChevronLeft className="w-3 h-3 rotate-180" />
          </button>
        </div>
      )}

      {confirmAction && (
        <ConfirmModal
          title={
            confirmAction.action === 'delete'
              ? `حذف حساب @${confirmAction.user.username}؟`
              : confirmAction.action === 'verify'
              ? `توثيق @${confirmAction.user.username}؟`
              : `إزالة توثيق @${confirmAction.user.username}؟`
          }
          message={
            confirmAction.action === 'delete'
              ? 'سيتم حذف البروفايل وجميع منشوراته نهائيًا. لا يمكن التراجع عن هذا الإجراء.'
              : confirmAction.action === 'verify'
              ? 'سيتم منح شارة التوثيق الرسمية لهذا المستخدم.'
              : 'سيتم إزالة شارة التوثيق من هذا المستخدم.'
          }
          confirmLabel={confirmAction.action === 'delete' ? 'حذف نهائي' : 'تأكيد'}
          onConfirm={handleAction}
          onCancel={() => setConfirmAction(null)}
          danger={confirmAction.action === 'delete'}
        />
      )}
    </div>
  )
}

// ============================================================
// Verifications Tab
// ============================================================
function VerificationsTab() {
  const [requests, setRequests] = useState<AdminVerificationRequest[]>([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState<'pending' | 'approved' | 'rejected' | 'all'>('pending')
  const [rejecting, setRejecting] = useState<AdminVerificationRequest | null>(null)
  const [rejectNote, setRejectNote] = useState('')

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const { requests } = await fetchVerificationRequests(50, 0, filter)
      setRequests(requests)
    } catch {
      toast.error('فشل تحميل طلبات التوثيق')
    } finally {
      setLoading(false)
    }
  }, [filter])

  useEffect(() => { void load() }, [load])

  const handleApprove = async (req: AdminVerificationRequest) => {
    try {
      await adminApproveVerification(req.id, req.user_id, req.requested_type)
      toast.success('تمت الموافقة على الطلب وتوثيق المستخدم')
      await load()
    } catch (e: any) {
      toast.error(e.message || 'فشلت العملية')
    }
  }

  const handleReject = async () => {
    if (!rejecting) return
    if (!rejectNote.trim()) {
      toast.error('أضف سبب الرفض')
      return
    }
    try {
      await adminRejectVerification(rejecting.id, rejectNote)
      toast.success('تم رفض الطلب')
      setRejecting(null)
      setRejectNote('')
      await load()
    } catch (e: any) {
      toast.error(e.message || 'فشلت العملية')
    }
  }

  if (loading && requests.length === 0) return <CenteredLoader label="جارٍ تحميل طلبات التوثيق..." />

  return (
    <div className="w-full px-3 py-4 space-y-3">
      <div className="flex items-center justify-between">
        <h2 className="font-display text-lg font-bold">طلبات التوثيق</h2>
        <button onClick={load} className="p-1.5 rounded-lg hover:bg-foreground/5">
          <RefreshCw className="w-4 h-4 text-muted-foreground" />
        </button>
      </div>

      <div className="flex gap-1.5 overflow-x-auto mishri-scrollbar-hide">
        {([
          { id: 'pending', label: 'معلّقة' },
          { id: 'approved', label: 'موافق' },
          { id: 'rejected', label: 'مرفوضة' },
          { id: 'all', label: 'الكل' },
        ] as const).map((f) => (
          <button
            key={f.id}
            onClick={() => setFilter(f.id)}
            className={`flex-shrink-0 px-3 py-1 rounded-full text-xs font-bold ${
              filter === f.id
                ? 'mishri-gradient-primary text-white'
                : 'bg-foreground/5 text-muted-foreground'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {requests.length === 0 ? (
        <EmptyState icon={BadgeCheck} label="لا توجد طلبات توثيق بهذه الحالة" />
      ) : (
        <div className="space-y-2">
          {requests.map((req) => (
            <div key={req.id} className="rounded-2xl border border-foreground/8 bg-foreground/[0.02] p-3">
              <div className="flex items-start gap-2.5 mb-2">
                <div
                  className="w-9 h-9 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0"
                  style={{
                    background: `linear-gradient(135deg, ${req.profile?.avatar_color || '#1F4E8C'}, ${req.profile?.avatar_color || '#0E2A4F'}aa)`,
                  }}
                >
                  {(req.profile?.display_name || req.profile?.username || '؟').charAt(0).toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-bold truncate">
                    @{req.profile?.username || 'محذوف'}
                  </div>
                  <div className="text-[10px] text-muted-foreground">
                    {new Date(req.created_at).toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short' })}
                  </div>
                </div>
                <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-amber-500/15 text-amber-600">
                  {req.requested_type}
                </span>
              </div>

              <p className="text-[11px] leading-relaxed bg-foreground/5 rounded-lg p-2 mb-2">
                {req.reason}
              </p>

              {req.status !== 'pending' && (
                <div className="text-[10px] text-muted-foreground mb-2">
                  الحالة: <span className={`font-bold ${
                    req.status === 'approved' ? 'text-emerald-500' : 'text-rose-500'
                  }`}>
                    {req.status === 'approved' ? 'موافق عليها' : 'مرفوضة'}
                  </span>
                  {req.admin_notes && (
                    <span className="block mt-0.5">ملاحظة: {req.admin_notes}</span>
                  )}
                </div>
              )}

              {req.status === 'pending' && (
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleApprove(req)}
                    className="flex-1 py-1.5 rounded-lg text-[11px] font-bold bg-emerald-500/10 text-emerald-600 hover:bg-emerald-500/20 flex items-center justify-center gap-1"
                  >
                    <UserCheck className="w-3 h-3" />
                    موافقة وتوثيق
                  </button>
                  <button
                    onClick={() => { setRejecting(req); setRejectNote('') }}
                    className="flex-1 py-1.5 rounded-lg text-[11px] font-bold bg-rose-500/10 text-rose-500 hover:bg-rose-500/20 flex items-center justify-center gap-1"
                  >
                    <X className="w-3 h-3" />
                    رفض
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Reject modal */}
      {rejecting && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-6" onClick={() => setRejecting(null)}>
          <div className="bg-background rounded-3xl p-5 max-w-sm w-full" onClick={(e) => e.stopPropagation()}>
            <h3 className="font-display text-base font-bold mb-3">رفض طلب التوثيق</h3>
            <p className="text-xs text-muted-foreground mb-3">
              اكتب سبب الرفض (سيظهر للمستخدم):
            </p>
            <textarea
              value={rejectNote}
              onChange={(e) => setRejectNote(e.target.value)}
              rows={3}
              className="mishri-input w-full rounded-xl p-3 text-sm outline-none resize-none mb-3"
              placeholder="مثال: المحتوى غير كافٍ للتوثيق..."
            />
            <div className="flex gap-2">
              <button
                onClick={() => setRejecting(null)}
                className="flex-1 py-2 rounded-xl bg-foreground/5 text-xs font-bold"
              >
                إلغاء
              </button>
              <button
                onClick={handleReject}
                className="flex-1 py-2 rounded-xl bg-rose-500 text-white text-xs font-bold"
              >
                رفض الطلب
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// ============================================================
// Helpers
// ============================================================

function CenteredLoader({ label }: { label: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-20">
      <Loader2 className="w-6 h-6 text-amber-500 animate-spin mb-3" />
      <p className="text-xs text-muted-foreground">{label}</p>
    </div>
  )
}

function EmptyState({ icon: Icon, label }: { icon: typeof Users; label: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-12">
      <div className="w-14 h-14 rounded-2xl bg-foreground/5 flex items-center justify-center mb-3">
        <Icon className="w-6 h-6 text-muted-foreground" />
      </div>
      <p className="text-xs text-muted-foreground">{label}</p>
    </div>
  )
}

function ConfirmModal({
  title,
  message,
  confirmLabel,
  onConfirm,
  onCancel,
  danger = false,
}: {
  title: string
  message: string
  confirmLabel: string
  onConfirm: () => void
  onCancel: () => void
  danger?: boolean
}) {
  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-6" onClick={onCancel}>
      <div className="bg-background rounded-3xl p-5 max-w-sm w-full" onClick={(e) => e.stopPropagation()}>
        <div className={`w-12 h-12 rounded-2xl flex items-center justify-center mb-3 ${
          danger ? 'bg-rose-500/10' : 'bg-amber-500/10'
        }`}>
          <AlertCircle className={`w-6 h-6 ${danger ? 'text-rose-500' : 'text-amber-500'}`} />
        </div>
        <h3 className="font-display text-base font-bold mb-2">{title}</h3>
        <p className="text-xs text-muted-foreground mb-4 leading-relaxed">{message}</p>
        <div className="flex gap-2">
          <button
            onClick={onCancel}
            className="flex-1 py-2.5 rounded-xl bg-foreground/5 text-xs font-bold"
          >
            إلغاء
          </button>
          <button
            onClick={onConfirm}
            className={`flex-1 py-2.5 rounded-xl text-xs font-bold text-white ${
              danger ? 'bg-rose-500 hover:bg-rose-600' : 'mishri-gradient-primary'
            }`}
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  )
}
