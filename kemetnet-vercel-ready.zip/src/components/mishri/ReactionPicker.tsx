'use client'

import { useState, useRef, useEffect } from 'react'
import { REACTION_EMOJIS, type ReactionEmoji, type ReactionGroup, getReactionEmoji } from '@/lib/message-reactions'

interface ReactionPickerProps {
 open: boolean
 onClose: () => void
 onSelect: (emoji: ReactionEmoji) => void
 anchorRect?: DOMRect | null
}

export function ReactionPicker({ open, onClose, onSelect, anchorRect }: ReactionPickerProps) {
 if (!open) return null

 return (
 <>
 {open && (
 <>
 {/* overlay */}
 <div
 className="fixed inset-0 z-[90]"
 onClick={onClose}
 />
 <div
 className="fixed z-[100] rounded-xl bg-foreground/5-strong rounded-full p-1.5 shadow-2xl flex items-center gap-0.5 transition-colors duration-200"
 style={{
 // وضع الـ picker فوق الرسالة
 bottom: anchorRect ? window.innerHeight - anchorRect.top + 8 : '50%',
 left: anchorRect ? anchorRect.left + anchorRect.width / 2 : '50%',
 transform: anchorRect ? 'translateX(-50%)' : 'translate(-50%, -50%)',
 }}
 >
 {REACTION_EMOJIS.map((r, i) => (
 <button
 key={r.id}
 onClick={() => {
 onSelect(r.id)
 onClose()
 }}
 className="w-9 h-9 rounded-full hover:bg-foreground/10 hover:scale-110 transition-colors duration-200 flex items-center justify-center text-lg"
 aria-label={r.label}
 title={r.label}
 >
 {r.emoji}
 </button>
 ))}
 </div>
 </>
 )}
 </>
 )
}

// ========================================
// مكون: عرض ردود الأفعال المتراكمة
// ========================================

interface ReactionsDisplayProps {
 reactions: ReactionGroup[]
 onReactionClick?: (emoji: ReactionEmoji) => void
 isMine: boolean
}

export function ReactionsDisplay({ reactions, onReactionClick, isMine }: ReactionsDisplayProps) {
 if (reactions.length === 0) return null

 return (
 <div className={`flex flex-wrap gap-1 mt-1 ${isMine ? 'justify-start' : 'justify-end'}`}>
 {reactions.slice(0, 4).map((group) => {
 const emoji = getReactionEmoji(group.emoji)
 return (
 <button
 key={group.emoji}
 onClick={() => onReactionClick?.(group.emoji)}
 className={`flex items-center gap-0.5 px-1.5 py-0.5 rounded-full text-[10px] font-semibold transition-colors duration-200 ${
 group.reactedByMe
 ? 'bg-amber-500/20 text-amber-700 dark:text-amber-300 ring-1 ring-amber-500/40'
 : 'bg-foreground/10 text-foreground/70 hover:bg-foreground/15'
 }`}
 >
 <span className="text-xs">{emoji}</span>
 <span className="tabular-nums">{group.count}</span>
 </button>
 )
 })}
 {reactions.length > 4 && (
 <span className="text-[9px] text-muted-foreground self-center px-1">
 +{reactions.length - 4}
 </span>
 )}
 </div>
 )
}
