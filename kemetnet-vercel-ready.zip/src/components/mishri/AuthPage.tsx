'use client'

import { useState, useEffect, useRef } from 'react'
import { useRouter } from 'next/navigation'
import { Eye, EyeOff, User, Lock, Sparkles, ArrowLeft, Check, Loader2, Palette } from 'lucide-react'
import { MishriLogoMark } from './MishriLogo'
import { signUpWithUsername, signInWithUsername, validateUsername, checkUsernameAvailability } from '@/lib/supabase/auth'
import { checkRateLimit, resetRateLimit, checkPasswordStrength } from '@/lib/security'
import { useAppStore } from '@/store/app-store'
import { toast } from 'sonner'

type Mode = 'login' | 'register'

export function AuthPage() {
 const [mode, setMode] = useState<Mode>('login')
 const [username, setUsername] = useState('')
 const [displayName, setDisplayName] = useState('')
 const [password, setPassword] = useState('')
 const [showPassword, setShowPassword] = useState(false)
 const [loading, setLoading] = useState(false)
 const [usernameStatus, setUsernameStatus] = useState<'idle' | 'checking' | 'available' | 'taken' | 'invalid'>('idle')
 // V-08: rate limiting على العميل — تأخير تصاعدي بعد المحاولات الفاشلة
 const [failedAttempts, setFailedAttempts] = useState(0)
 const setUser = useAppStore((s) => s.setUser)
 const router = useRouter()
 const lastCheckedRef = useRef<string>('')

 // التحقق من توفر اليوزرنيم — مع تنظيف صحيح لـ setTimeout
 useEffect(() => {
 let timeout: ReturnType<typeof setTimeout> | undefined

 const checkAvailability = async () => {
 if (mode !== 'register' || !username) {
 setUsernameStatus('idle')
 lastCheckedRef.current = ''
 return
 }
 const validation = validateUsername(username)
 if (!validation.valid) {
 setUsernameStatus('invalid')
 return
 }
 if (lastCheckedRef.current === username) return

 setUsernameStatus('checking')
 timeout = setTimeout(async () => {
 const available = await checkUsernameAvailability(username)
 lastCheckedRef.current = username
 setUsernameStatus(available ? 'available' : 'taken')
 }, 600)
 }

 void checkAvailability()

 return () => {
 if (timeout) clearTimeout(timeout)
 }
 }, [username, mode])

 const handleSubmit = async (e: React.FormEvent) => {
 e.preventDefault()
 // V-08: rate limiting — تأخير تصاعدي بعد 3 محاولات فاشلة
 if (failedAttempts >= 3) {
 const delay = Math.min(failedAttempts * 2000, 10000)
 toast.error(`محاولات كثيرة. انتظر ${Math.ceil(delay / 1000)} ثانية`)
 return
 }
 // Rate limiting إضافي (5 محاولات/دقيقة)
 const rateLimit = checkRateLimit(mode === 'login' ? 'login' : 'signup', 5, 60_000)
 if (!rateLimit.allowed) {
   const waitSec = Math.ceil((rateLimit.resetAt - Date.now()) / 1000)
   toast.error(`محاولات كثيرة. انتظر ${waitSec} ثانية`)
   return
 }
 setLoading(true)
 try {
 if (mode === 'register') {
 const validation = validateUsername(username)
 if (!validation.valid) {
 toast.error(validation.error!)
 setLoading(false)
 return
 }
 // فحص قوة كلمة المرور
 const strength = checkPasswordStrength(password)
 if (strength.score < 2) {
   toast.error(`كلمة المرور ضعيفة: ${strength.suggestions[0] || 'استخدم 8 أحرف على الأقل'}`)
   setLoading(false)
   return
 }
 const result = await signUpWithUsername(username, password, displayName || username)
 if (!result.success) {
 toast.error(result.error!)
 setFailedAttempts((a) => a + 1)
 setLoading(false)
 return
 }
 resetRateLimit('signup')
 toast.success('تم إنشاء حسابك! أهلاً بك في KemetNet')
 } else {
 const result = await signInWithUsername(username, password)
 if (!result.success) {
 toast.error(result.error!)
 setFailedAttempts((a) => a + 1)
 setLoading(false)
 return
 }
 resetRateLimit('login')
 toast.success('أهلاً بعودتك إلى KemetNet')
 }
 // التنقل عبر router بدل window.location.reload
 setFailedAttempts(0)
 router.replace('/home')
 } catch (err) {
 // [removed in production] err
 toast.error('حدث خطأ غير متوقع')
 setLoading(false)
 }
 }

 return (
 <div className="min-h-screen mishri-aurora-bg flex flex-col">
 {/* خلفية ديكورية */}
 <div className="fixed inset-0 pointer-events-none overflow-hidden">
 <div className="absolute top-0 -left-32 w-96 h-96 rounded-full bg-blue-700/30 blur-3xl mishri-float" />
 <div
 className="absolute bottom-0 -right-32 w-96 h-96 rounded-full bg-amber-500/25 blur-3xl mishri-float"
 style={{ animationDelay: '1.5s' }}
 />
 <div
 className="absolute top-1/3 left-1/2 w-64 h-64 rounded-full bg-yellow-400/15 blur-3xl mishri-float"
 style={{ animationDelay: '0.8s' }}
 />
 </div>

 <div className="relative z-10 flex-1 flex flex-col px-6 pt-16 pb-8 max-w-md mx-auto w-full">
 {/* تنبيه الإعداد محذوف — يعرض معلومات تقنية داخلية */}

 {/* الرأس */}
 <div
 className="text-center mb-10"
 >
 <div className="inline-flex items-center justify-center mb-4 mishri-pulse rounded-3xl">
 <MishriLogoMark size={88} animated />
 </div>
 <h1 className="font-display text-4xl font-bold mishri-gradient-text mb-2">KemetNet</h1>
 <p className="text-sm text-muted-foreground">
 {mode === 'login' ? 'أهلاً بعودتك إلى عالم الإلهام' : 'انضم إلى مجتمع الإبداع والإلهام'}
 </p>
 </div>

 {/* البطاقة */}
 <div
 className="rounded-2xl bg-foreground/5 p-6 "
 >
 {/* تبديل الوضع - مع مؤشر متحرك */}
 <div className="relative flex bg-foreground/5 rounded-2xl p-1 mb-6">
 <div
 className="absolute top-1 bottom-1 w-[calc(50%-4px)] mishri-gradient-primary rounded-xl shadow-md mishri-glow-soft transition-all duration-300"
 style={{ right: 0, transform: mode === 'login' ? 'translateX(0)' : 'translateX(calc(-100% - 8px))' }}
 />
 <button
 type="button"
 onClick={() => setMode('login')}
 className={`relative z-10 flex-1 py-2.5 rounded-xl text-sm font-semibold transition-colors duration-200 ${
 mode === 'login' ? 'text-white' : 'text-muted-foreground'
 }`}
 >
 دخول
 </button>
 <button
 type="button"
 onClick={() => setMode('register')}
 className={`relative z-10 flex-1 py-2.5 rounded-xl text-sm font-semibold transition-colors duration-200 ${
 mode === 'register' ? 'text-white' : 'text-muted-foreground'
 }`}
 >
 حساب جديد
 </button>
 </div>

 <form onSubmit={handleSubmit} className="space-y-4">
 {/* اليوزرنيم */}
 <div>
 <label className="block text-xs font-semibold mb-1.5 text-foreground/80">
 اليوزرنيم
 </label>
 <div className="relative">
 <User className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
 <input
 type="text"
 value={username}
 onChange={(e) => setUsername(e.target.value)}
 placeholder="username"
 className="mishri-input w-full rounded-xl py-3 pr-10 pl-10 text-sm font-medium outline-none"
 dir="ltr"
 autoComplete="username"
 required
 />
 <UsernameStatusIcon status={usernameStatus} />
 </div>
 {usernameStatus === 'available' && (
 <p
 className="text-xs text-emerald-600 mt-1 mr-1"
 >
 ✓ اليوزرنيم متاح
 </p>
 )}
 {usernameStatus === 'taken' && (
 <p
 className="text-xs text-rose-500 mt-1 mr-1"
 >
 هذا اليوزرنيم محجوز
 </p>
 )}
 {usernameStatus === 'invalid' && (
 <p
 className="text-xs text-amber-500 mt-1 mr-1"
 >
 3-20 حرف: أحرف إنجليزية، أرقام، و_
 </p>
 )}
 </div>

 {/* الاسم المعروض (للتسجيل فقط) */}
 {mode === 'register' && (
 <div
 className="overflow-hidden"
 >
 <label className="block text-xs font-semibold mb-1.5 text-foreground/80">
 الاسم المعروض (اختياري)
 </label>
 <div className="relative">
 <Sparkles className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
 <input
 type="text"
 value={displayName}
 onChange={(e) => setDisplayName(e.target.value)}
 placeholder="الاسم الذي سيظهر للجميع"
 className="mishri-input w-full rounded-xl py-3 pr-10 pl-3 text-sm font-medium outline-none"
 maxLength={30}
 />
 </div>
 </div>
 )}

 {/* كلمة المرور */}
 <div>
 <label className="block text-xs font-semibold mb-1.5 text-foreground/80">
 كلمة المرور
 </label>
 <div className="relative">
 <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
 <input
 type={showPassword ? 'text' : 'password'}
 value={password}
 onChange={(e) => setPassword(e.target.value)}
 placeholder="••••••••"
 className="mishri-input w-full rounded-xl py-3 pr-10 pl-10 text-sm font-medium outline-none"
 dir="ltr"
 autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
 required
 minLength={8}
 />
 <button
 type="button"
 onClick={() => setShowPassword((v) => !v)}
 className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
 tabIndex={-1}
 >
 {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
 </button>
 </div>
 </div>

 {/* زر الإرسال */}
 <button
 type="submit"
 disabled={loading || usernameStatus === 'taken' || usernameStatus === 'invalid'}
 className="relative w-full mishri-gradient-primary text-white font-bold py-3.5 rounded-xl mishri-glow-soft mishri-shine disabled:opacity-60 disabled:cursor-not-allowed overflow-hidden flex items-center justify-center gap-2 mt-2 transition-colors duration-200"
 >
 {loading ? (
 <div
 key="loading"
 className="flex items-center gap-2"
 >
 <Loader2 className="w-4 h-4 animate-spin" />
 جارٍ المعالجة...
 </div>
 ) : (
 <div
 key="text"
 >
 {mode === 'login' ? 'تسجيل الدخول' : 'إنشاء حساب'}
 </div>
 )}
 </button>
 </form>

 {/* نسيت كلمة المرور — في وضع تسجيل الدخول فقط */}
 {mode === 'login' && (
 <div className="text-center mt-4">
 <button
 onClick={() => router.push('/forgot-password')}
 className="text-xs text-amber-500 hover:text-amber-600 hover:underline transition-colors"
 >
 نسيت كلمة المرور؟
 </button>
 </div>
 )}

 {/* ملاحظة */}
 <p className="text-xs text-muted-foreground text-center mt-5 leading-relaxed">
 بالتسجيل أنت توافق على شروط الاستخدام وسياسة الخصوصية
 </p>
 </div>

 {/* مميزات */}
 <div
 className="grid grid-cols-3 gap-3 mt-6"
 >
 <FeatureMini icon={<Sparkles className="w-5 h-5 text-amber-500" />} label="بصمة فريدة" />
 <FeatureMini icon={<Lock className="w-5 h-5 text-amber-500" />} label="دخول آمن" />
 <FeatureMini icon={<Palette className="w-5 h-5 text-amber-500" />} label="تصميم حديث" />
 </div>

 {/* زر العودة */}
 <button
 onClick={() => router.push('/')}
 className="mt-6 mx-auto text-xs text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1"
 >
 <ArrowLeft className="w-3 h-3" />
 رجوع
 </button>
 </div>
 </div>
 )
}

function UsernameStatusIcon({ status }: { status: string }) {
 if (status === 'checking') {
 return (
 <Loader2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground animate-spin" />
 )
 }
 if (status === 'available') {
 return <Check className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-500" />
 }
 return null
}

function FeatureMini({ icon, label }: { icon: React.ReactNode; label: string }) {
 return (
 <div className="rounded-2xl bg-foreground/5 p-3 text-center">
 <div className="flex justify-center mb-1">{icon}</div>
 <div className="text-[10px] font-semibold text-muted-foreground">{label}</div>
 </div>
 )
}
