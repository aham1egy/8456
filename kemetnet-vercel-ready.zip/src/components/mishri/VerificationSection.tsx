'use client'

import { useState, useEffect } from 'react'
import { BadgeCheck, Loader2, CheckCircle2, XCircle, Clock, Send, Sparkles, Building2, Zap, AlertCircle } from 'lucide-react'
import {
 createVerificationRequest,
 fetchMyVerificationRequests,
 cancelVerificationRequest,
 getVerificationLabel,
 getVerificationDescription,
 type VerificationType,
 type VerificationRequest,
} from '@/lib/verification-requests'
import { useAppStore } from '@/store/app-store'
import { useNotificationSound } from '@/hooks/use-sound'
import { VerifiedBadge } from './VerifiedBadge'
import { toast } from 'sonner'

const VERIFICATION_TYPES: VerificationType[] = ['official', 'business', 'creator', 'early_adopter']

const TYPE_ICONS: Record<VerificationType, typeof BadgeCheck> = {
 official: BadgeCheck,
 business: Building2,
 creator: Sparkles,
 early_adopter: Zap,
}

const STATUS_CONFIG: Record<string, { label: string; color: string; icon: typeof Clock }> = {
 pending: { label: 'قيد المراجعة', color: '#F59E0B', icon: Clock },
 approved: { label: 'تمت الموافقة', color: '#10B981', icon: CheckCircle2 },
 rejected: { label: 'تم الرفض', color: '#EF4444', icon: XCircle },
 needs_info: { label: 'يحتاج معلومات إضافية', color: '#3B82F6', icon: AlertCircle },
}

export function VerificationSection() {
 const user = useAppStore((s) => s.user)
 const { playSound } = useNotificationSound()
 const [requests, setRequests] = useState<VerificationRequest[]>([])
 const [loading, setLoading] = useState(true)
 const [showForm, setShowForm] = useState(false)
 const [selectedType, setSelectedType] = useState<VerificationType>('creator')
 const [reason, setReason] = useState('')
 const [contactEmail, setContactEmail] = useState('')
 const [socialLinks, setSocialLinks] = useState('')
 const [submitting, setSubmitting] = useState(false)

 useEffect(() => {
 if (!user) {
 setLoading(false)
 return
 }
 let cancelled = false
 void (async () => {
 setLoading(true)
 const result = await fetchMyVerificationRequests(user.id)
 if (!cancelled) {
 setRequests(result)
 setLoading(false)
 }
 })()
 return () => {
 cancelled = true
 }
 }, [user])

 const handleSubmit = async () => {
 if (!user) return
 if (reason.trim().length < 20) {
 toast.error('يرجى تقديم سبب مفصّل (20 حرف على الأقل)')
 return
 }

 setSubmitting(true)
 const links = socialLinks
 .split('\n')
 .map((l) => l.trim())
 .filter(Boolean)

 // ✅ أمني: التحقق من صحة الروابط
 if (links.length > 0) {
 const urlRegex = /^https?:\/\/[^\s/$.?#].[^\s]*$/i
 const invalidLinks = links.filter((l) => !urlRegex.test(l))
 if (invalidLinks.length > 0) {
 toast.error('بعض الروابط غير صالحة')
 setSubmitting(false)
 return
 }
 }

 const result = await createVerificationRequest(
 user.id,
 selectedType,
 reason,
 contactEmail || undefined,
 links.length > 0 ? links : undefined
 )

 if (result.success) {
 playSound('success')
 toast.success('تم إرسال طلب التحقق بنجاح')
 setShowForm(false)
 setReason('')
 setContactEmail('')
 setSocialLinks('')
 // إعادة جلب الطلبات
 const fresh = await fetchMyVerificationRequests(user.id)
 setRequests(fresh)
 } else {
 toast.error(result.error || 'تعذّر إرسال الطلب')
 }
 setSubmitting(false)
 }

 const handleCancel = async (requestId: string) => {
 if (!user) return
 const result = await cancelVerificationRequest(user.id, requestId)
 if (result.success) {
 toast.success('تم إلغاء الطلب')
 const fresh = await fetchMyVerificationRequests(user.id)
 setRequests(fresh)
 } else {
 toast.error(result.error || 'تعذّر الإلغاء')
 }
 }

 if (!user) return null

 // إذا كان المستخدم موثّقاً بالفعل
 if (user.is_verified) {
 return (
 <div className="space-y-4">
 <div
 className="rounded-2xl bg-foreground/5 p-6 text-center transition-colors duration-200"
 >
 <div className="flex justify-center mb-3">
 <VerifiedBadge type={user.verified_type} size="lg" showTooltip={false} />
 </div>
 <h3 className="font-display text-lg font-bold mb-1">
 حسابك موثّق!
 </h3>
 <p className="text-xs text-muted-foreground mb-2">
 {getVerificationLabel(user.verified_type!)}
 </p>
 <p className="text-[11px] text-muted-foreground/70 leading-relaxed">
 {getVerificationDescription(user.verified_type!)}
 </p>
 {user.verified_at && (
 <p className="text-[10px] text-muted-foreground/60 mt-3">
 تم التحقق في {new Date(user.verified_at).toLocaleDateString('ar-EG', {
 year: 'numeric',
 month: 'long',
 day: 'numeric',
 })}
 </p>
 )}
 </div>
 </div>
 )
 }

 const activeRequest = requests.find((r) => r.status === 'pending')

 return (
 <div className="space-y-4">
 {/* رأس */}
 <div className="rounded-2xl p-4 bg-foreground/5 ">
 <div className="flex items-center gap-3 mb-4">
 <div className="w-12 h-12 rounded-xl mishri-gradient-primary mishri-glow-soft flex items-center justify-center">
 <BadgeCheck className="w-6 h-6 text-white" />
 </div>
 <div>
 <h3 className="font-bold text-sm">شارة التحقق</h3>
 <p className="text-xs text-muted-foreground">احصل على شارة موثّق لحسابك</p>
 </div>
 </div>

 {/* أنواع التحقق */}
 <div className="space-y-2 mb-4">
 <p className="text-[11px] font-bold text-muted-foreground mb-2">الأنواع المتاحة:</p>
 {VERIFICATION_TYPES.map((type) => {
 const Icon = TYPE_ICONS[type]
 return (
 <div key={type} className="flex items-center gap-2 p-2 rounded-xl bg-foreground/5">
 <div className="w-7 h-7 rounded-lg bg-foreground/10 flex items-center justify-center">
 <Icon className="w-4 h-4" />
 </div>
 <div className="flex-1 min-w-0">
 <div className="text-xs font-bold">{getVerificationLabel(type)}</div>
 <div className="text-[10px] text-muted-foreground leading-snug">
 {getVerificationDescription(type)}
 </div>
 </div>
 <VerifiedBadge type={type} size="sm" showTooltip={false} />
 </div>
 )
 })}
 </div>

 {/* زر تقديم طلب */}
 {activeRequest ? (
 <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 mb-3">
 <div className="flex items-center gap-2 mb-1">
 <Clock className="w-4 h-4 text-amber-500" />
 <span className="text-xs font-bold text-amber-600 dark:text-amber-400">
 لديك طلب قيد المراجعة
 </span>
 </div>
 <p className="text-[11px] text-muted-foreground mb-2">
 النوع: {getVerificationLabel(activeRequest.requested_type)}
 </p>
 <button
 onClick={() => handleCancel(activeRequest.id)}
 className="text-[11px] text-rose-500 hover:underline"
 >
 إلغاء الطلب
 </button>
 </div>
 ) : (
 !showForm && (
 <button
 onClick={() => setShowForm(true)}
 className="w-full py-2.5 rounded-xl mishri-gradient-primary text-white text-sm font-bold mishri-press flex items-center justify-center gap-2"
 >
 <BadgeCheck className="w-4 h-4" />
 طلب شارة التحقق
 </button>
 )
 )}
 </div>

 {/* نموذج الطلب */}
 {showForm && !activeRequest && (
 <div
 className="overflow-hidden transition-all duration-200"
 >
 <div className="rounded-2xl p-4 bg-foreground/5 space-y-4">
 <h4 className="font-bold text-sm">تقديم طلب تحقق</h4>

 {/* اختيار النوع */}
 <div>
 <label className="block text-xs font-bold mb-2 text-muted-foreground">
 نوع التحقق المطلوب
 </label>
 <div className="grid grid-cols-2 gap-2">
 {VERIFICATION_TYPES.map((type) => {
 const Icon = TYPE_ICONS[type]
 return (
 <button
 key={type}
 onClick={() => setSelectedType(type)}
 className={`flex items-center gap-2 p-2.5 rounded-xl border-2 transition-all ${
 selectedType === type
 ? 'bg-amber-500/10 border-amber-500/40'
 : 'bg-foreground/5 border-transparent hover:bg-foreground/10'
 }`}
 >
 <Icon className="w-4 h-4 flex-shrink-0" />
 <span className="text-[11px] font-semibold text-right flex-1">
 {getVerificationLabel(type)}
 </span>
 </button>
 )
 })}
 </div>
 <p className="text-[10px] text-muted-foreground mt-1.5 leading-relaxed">
 {getVerificationDescription(selectedType)}
 </p>
 </div>

 {/* السبب */}
 <div>
 <label className="block text-xs font-bold mb-2 text-muted-foreground">
 لماذا تستحق هذه الشارة؟
 </label>
 <textarea
 value={reason}
 onChange={(e) => setReason(e.target.value)}
 placeholder="اشرح بإيجاز لماذا يجب التحقق من حسابك..."
 className="mishri-input w-full rounded-xl py-2.5 px-3 text-sm outline-none resize-none"
 rows={3}
 maxLength={500}
 />
 <div className="text-left text-[10px] text-muted-foreground mt-1">
 {reason.length}/500
 </div>
 </div>

 {/* البريد */}
 <div>
 <label className="block text-xs font-bold mb-2 text-muted-foreground">
 بريد التواصل (اختياري)
 </label>
 <input
 type="email"
 value={contactEmail}
 onChange={(e) => setContactEmail(e.target.value)}
 placeholder="email@example.com"
 dir="ltr"
 className="mishri-input w-full rounded-xl py-2.5 px-3 text-sm outline-none"
 />
 </div>

 {/* روابط التواصل */}
 <div>
 <label className="block text-xs font-bold mb-2 text-muted-foreground">
 روابط (اختياري — كل رابط في سطر)
 </label>
 <textarea
 value={socialLinks}
 onChange={(e) => setSocialLinks(e.target.value)}
 placeholder="https://instagram.com/..."
 dir="ltr"
 className="mishri-input w-full rounded-xl py-2.5 px-3 text-sm outline-none resize-none"
 rows={2}
 />
 </div>

 {/* أزرار */}
 <div className="flex gap-2">
 <button
 onClick={() => setShowForm(false)}
 className="flex-1 py-2.5 rounded-xl bg-foreground/5 text-sm font-bold"
 >
 إلغاء
 </button>
 <button
 onClick={handleSubmit}
 disabled={submitting || reason.trim().length < 20}
 className="flex-1 py-2.5 rounded-xl mishri-gradient-primary text-white text-sm font-bold disabled:opacity-50 flex items-center justify-center gap-2 mishri-press"
 >
 {submitting ? (
 <>
 <Loader2 className="w-4 h-4 animate-spin" />
 جارٍ الإرسال...
 </>
 ) : (
 <>
 <Send className="w-4 h-4" />
 إرسال الطلب
 </>
 )}
 </button>
 </div>
 </div>
 </div>
 )}

 {/* سجل الطلبات */}
 {requests.length > 0 && (
 <div className="rounded-2xl bg-foreground/5 p-4">
 <h4 className="text-xs font-bold text-muted-foreground mb-3">سجل الطلبات</h4>
 <div className="space-y-2">
 {requests.map((req) => {
 const status = STATUS_CONFIG[req.status]
 const StatusIcon = status.icon
 return (
 <div key={req.id} className="flex items-center gap-3 p-2.5 rounded-xl bg-foreground/5">
 <div
 className="w-8 h-8 rounded-lg flex items-center justify-center"
 style={{ background: `${status.color}20` }}
 >
 <StatusIcon className="w-4 h-4" style={{ color: status.color }} />
 </div>
 <div className="flex-1 min-w-0">
 <div className="text-xs font-bold">{getVerificationLabel(req.requested_type)}</div>
 <div className="text-[10px] text-muted-foreground" style={{ color: status.color }}>
 {status.label} · {new Date(req.created_at).toLocaleDateString('ar-EG')}
 </div>
 </div>
 </div>
 )
 })}
 </div>
 </div>
 )}

 {/* معلومة */}
 <div className="rounded-2xl bg-foreground/5 p-4 flex items-start gap-3">
 <AlertCircle className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
 <div className="text-[11px] text-muted-foreground leading-relaxed">
 تُراجع طلبات التحقق يدوياً من قبل فريق KemetNet. قد تستغرق العملية من أيام إلى أسابيع. سيظهر إشعار عند البت في طلبك.
 </div>
 </div>
 </div>
 )
}
