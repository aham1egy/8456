'use client'

import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { Home, Compass, PlusCircle, User, MessageCircle, Bell } from 'lucide-react'
import { useAppStore } from '@/store/app-store'

interface NavItem {
 href: string
 icon: typeof Home
 label: string
 matchPath?: (pathname: string) => boolean
}

const NAV_ITEMS: NavItem[] = [
 { href: '/home', icon: Home, label: 'الرئيسية', matchPath: (p) => p === '/home' },
 { href: '/explore', icon: Compass, label: 'استكشاف', matchPath: (p) => p === '/explore' },
 { href: '/create', icon: PlusCircle, label: 'إنشاء', matchPath: (p) => p === '/create' },
 {
 href: '/notifications',
 icon: Bell,
 label: 'إشعارات',
 matchPath: (p) => p === '/notifications',
 },
 { href: '/messages', icon: MessageCircle, label: 'رسائل', matchPath: (p) => p === '/messages' || p.startsWith('/messages/') },
 { href: '/profile', icon: User, label: 'حسابي', matchPath: (p) => p === '/profile' || p.startsWith('/profile/') },
]

/**
 * شريط تنقل سفلي رفيع وبسيط (44px فقط)
 * - عند النقر على "الرئيسية" وهي نشطة: يتمرير لأعلى الصفحة
 * - عند النقر على "الرئيسية" من صفحة أخرى: ينتقل للرئيسية
 */
export function BottomNav() {
 const pathname = usePathname()
 const router = useRouter()
 const unread = useAppStore((s) => s.unreadNotifications)

 const handleHomeClick = (e: React.MouseEvent, isActive: boolean) => {
   if (isActive) {
     e.preventDefault()
     // ابحث عن منطقة التمرير وانتقل لأعلاها
     const scrollArea = document.querySelector('[data-scroll-area]') as HTMLElement
     if (scrollArea) {
       scrollArea.scrollTo({ top: 0, behavior: 'smooth' })
     } else {
       window.scrollTo({ top: 0, behavior: 'smooth' })
     }
   }
 }

 return (
 <nav
 className="flex-shrink-0 border-t border-foreground/8 bg-background/95 backdrop-blur-md"
 style={{ paddingBottom: 'env(safe-area-inset-bottom, 0px)' }}
 aria-label="التنقل الرئيسي"
 >
 <div className="max-w-md mx-auto flex items-center justify-around h-11">
 {NAV_ITEMS.map((item) => {
 const isActive = item.matchPath ? item.matchPath(pathname) : pathname === item.href
 const isNotifications = item.href === '/notifications'
 const isHome = item.href === '/home'
 const Icon = item.icon

 return (
 <Link
 key={item.href}
 href={item.href}
 onClick={(e) => { if (isHome) handleHomeClick(e, isActive) }}
 className="relative flex items-center justify-center w-10 h-9"
 aria-label={item.label}
 aria-current={isActive ? 'page' : undefined}
 prefetch={false}
 >
 <div className="relative">
 <Icon
 className={`w-[18px] h-[18px] transition-all duration-200 ${
 isActive ? 'text-foreground scale-110' : 'text-muted-foreground'
 }`}
 strokeWidth={isActive ? 2.4 : 1.6}
 />

 {isNotifications && unread > 0 && (
 <span className="absolute -top-1.5 -right-1.5 min-w-[14px] h-[14px] px-1 rounded-full bg-rose-500 text-white text-[8px] font-bold flex items-center justify-center border border-background">
 {unread > 9 ? '9+' : unread}
 </span>
 )}
 </div>
 </Link>
 )
 })}
 </div>
 </nav>
 )
}
