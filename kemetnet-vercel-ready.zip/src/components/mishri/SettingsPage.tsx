'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import {
 ArrowLeft, Moon, Sun, Palette, Bell, Globe, Shield, HelpCircle,
 LogOut, ChevronLeft, User, Mail, Lock, Eye, EyeOff, Sparkles,
 Info, Heart, FileText, Star, Send, Database, Volume2, VolumeX,
 GlassWater, Play, AtSign, Trash2, AlertTriangle, Check, Loader2, X, Ban, MonitorSmartphone,
 MessageCircle, Repeat2, Clock, Activity, BadgeCheck, ShieldCheck, LayoutDashboard
} from 'lucide-react'
import { useAppStore, type ThemeMode } from '@/store/app-store'
import { updateProfile, signOut, validateUsername, checkUsernameAvailability } from '@/lib/supabase/auth'
import { supabase } from '@/lib/supabase/client'
import { changeUsername, deleteAccount, checkPasswordStrength } from '@/lib/account'
import { fetchBlockedUsers, unblockUser, type Block } from '@/lib/moderation'
import { VerificationSection } from './VerificationSection'
import { isAdminProfile } from '@/lib/admin-config'
import { useNotificationSound } from '@/hooks/use-sound'
import { toast } from 'sonner'
// import { DatabaseSetup } from './DatabaseSetup'

const AVATAR_COLORS = [
 '#FBBF24', '#FB7185', '#A78BFA', '#34D399',
 '#60A5FA', '#FB923C', '#F472B6', '#FACC15',
]

type SettingsSection = 'main' | 'profile' | 'username' | 'password' | 'account' | 'blocked' | 'verification' | 'appearance' | 'notifications' | 'privacy' | 'about' | 'sound'

export function SettingsPage() {
 const [section, setSection] = useState<SettingsSection>('main')
 const user = useAppStore((s) => s.user)
 const setUser = useAppStore((s) => s.setUser)
 const router = useRouter()
 const theme = useAppStore((s) => s.theme)
 const setTheme = useAppStore((s) => s.setTheme)
 const glassOpacity = useAppStore((s) => s.glassOpacity)
 const setGlassOpacity = useAppStore((s) => s.setGlassOpacity)
 const notificationVolume = useAppStore((s) => s.notificationVolume)
 const setNotificationVolume = useAppStore((s) => s.setNotificationVolume)
 const soundEnabled = useAppStore((s) => s.soundEnabled)
 const setSoundEnabled = useAppStore((s) => s.setSoundEnabled)

 const { playSound } = useNotificationSound()

 const [displayName, setDisplayName] = useState(user?.display_name || '')
 const [bio, setBio] = useState(user?.bio || '')
 const [avatarColor, setAvatarColor] = useState(user?.avatar_color || AVATAR_COLORS[0])
 const [saving, setSaving] = useState(false)

 // إعدادات الخصوصية
 const [privateAccount, setPrivateAccount] = useState(false)
 const [showActivity, setShowActivity] = useState(true)

 // تطبيق الثيم على مستوى التطبيق (مع دعم الوضع التلقائي)
 useEffect(() => {
 const root = document.documentElement

 const apply = (mode: ThemeMode) => {
 if (mode === 'system') {
 const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches
 root.classList.toggle('dark', prefersDark)
 } else if (mode === 'midnight') {
 root.classList.add('dark')
 } else {
 root.classList.remove('dark')
 }
 }

 apply(theme)

 // الاستماع لتغيرات نظام الجهاز في الوضع التلقائي
 if (theme === 'system' && typeof window !== 'undefined') {
 const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)')
 const handler = () => apply('system')
 mediaQuery.addEventListener('change', handler)
 return () => mediaQuery.removeEventListener('change', handler)
 }
 }, [theme])

 const handleSaveProfile = async () => {
 // V-12: التحقق من avatar_color
 if (!/^#[0-9A-Fa-f]{6}$/.test(avatarColor)) {
 toast.error('لون الصورة الرمزية غير صالح')
 return
 }
 if (displayName && displayName.length > 30) {
 toast.error('الاسم المعروض طويل جدًا (حد أقصى 30 حرف)')
 return
 }
 if (bio && bio.length > 500) {
 toast.error('النبذة طويلة جدًا (حد أقصى 500 حرف)')
 return
 }
 setSaving(true)
 const result = await updateProfile({
 display_name: displayName,
 bio,
 avatar_color: avatarColor,
 })
 setSaving(false)
 if (result.success) {
 playSound('success')
 toast.success('تم حفظ التغييرات')
 if (user) {
 setUser({ ...user, display_name: displayName, bio, avatar_color: avatarColor })
 }
 } else {
 toast.error(result.error || 'فشل الحفظ')
 }
 }

 const handleSignOut = async () => {
 await signOut()
 setUser(null)
 toast.success('تم تسجيل الخروج بنجاح')
 router.replace('/')
 }

 if (section !== 'main') {
 return (
 <div className="flex flex-col flex-1 min-h-0">
 <header className="flex-shrink-0 border-b border-foreground/5 bg-background/80 backdrop-blur-xl z-40" style={{ paddingTop: 'env(safe-area-inset-top, 0px)' }}>
 <div className="max-w-md mx-auto px-4 py-3 flex items-center gap-3">
 <button
 onClick={() => setSection('main')}
 className="p-2 rounded-full hover:bg-foreground/5"
 >
 <ArrowLeft className="w-5 h-5" />
 </button>
 <h1 className="font-display text-xl font-bold">
 {section === 'profile' && 'الملف الشخصي'}
 {section === 'username' && 'تغيير اليوزرنيم'}
 {section === 'password' && 'كلمة المرور'}
 {section === 'account' && 'إدارة الحساب'}
 {section === 'blocked' && 'المستخدمون المحجوبون'}
 {section === 'verification' && 'شارة التحقق'}
 {section === 'appearance' && 'المظهر'}
 {section === 'notifications' && 'الإشعارات'}
 {section === 'privacy' && 'الخصوصية'}
 {section === 'about' && 'حول التطبيق'}

 {section === 'sound' && 'الصوت والشفافية'}
 </h1>
 </div>
 </header>

 <div data-scroll-area className="flex-1 overflow-y-auto overscroll-y-contain">
 <main className="max-w-md mx-auto px-4 pt-4 pb-4">
 {section === 'profile' && (
 <ProfileSection
 displayName={displayName}
 setDisplayName={setDisplayName}
 bio={bio}
 setBio={setBio}
 avatarColor={avatarColor}
 setAvatarColor={setAvatarColor}
 username={user?.username || ''}
 onSave={handleSaveProfile}
 saving={saving}
 />
 )}
 {section === 'username' && (
 <UsernameSection
 currentUsername={user?.username || ''}
 userId={user?.id || ''}
 onUsernameChanged={(newUsername) => {
 if (user) {
 setUser({ ...user, username: newUsername })
 }
 setSection('main')
 }}
 />
 )}
 {section === 'password' && <PasswordSection />}
 {section === 'account' && (
 <AccountSection
 userId={user?.id || ''}
 onAccountDeleted={() => {
 setUser(null)
 router.replace('/')
 }}
 />
 )}
 {section === 'blocked' && <BlockedUsersSection />}
 {section === 'verification' && <VerificationSection />}
 {section === 'appearance' && (
 <AppearanceSection theme={theme} setTheme={setTheme} />
 )}
 {section === 'notifications' && <NotificationsSection />}
 {section === 'privacy' && (
 <PrivacySection
 privateAccount={privateAccount}
 setPrivateAccount={setPrivateAccount}
 showActivity={showActivity}
 setShowActivity={setShowActivity}
 />
 )}
 {section === 'sound' && (
 <SoundAndGlassSection
 glassOpacity={glassOpacity}
 setGlassOpacity={setGlassOpacity}
 notificationVolume={notificationVolume}
 setNotificationVolume={setNotificationVolume}
 soundEnabled={soundEnabled}
 setSoundEnabled={setSoundEnabled}
 onTestSound={playSound}
 />
 )}
 {/* محذوف: قاعدة البيانات */}
 {section === 'about' && <AboutSection />}
 </main>
 </div>
 </div>
 )
 }

 return (
 <div className="flex flex-col flex-1 min-h-0">
 <header className="flex-shrink-0 border-b border-foreground/5 bg-background/80 backdrop-blur-xl z-40" style={{ paddingTop: 'env(safe-area-inset-top, 0px)' }}>
 <div className="max-w-md mx-auto px-4 py-3 flex items-center gap-3">
 <button onClick={() => router.back()} className="p-2 rounded-full hover:bg-foreground/5">
 <ArrowLeft className="w-5 h-5" />
 </button>
 <h1 className="font-display text-2xl font-bold mishri-gradient-text">الإعدادات</h1>
 </div>
 </header>

 <div data-scroll-area className="flex-1 overflow-y-auto overscroll-y-contain">
 <main className="max-w-md mx-auto px-4 pt-4 pb-4">
 {/* بطاقة المستخدم — بسيطة */}
 <div className="flex items-center gap-3 mb-6 p-3 rounded-2xl bg-foreground/5">
 {user?.avatar_url ? (
 <img src={user.avatar_url} alt="" className="w-12 h-12 rounded-full object-cover" />
 ) : (
 <div
 className="w-12 h-12 rounded-full flex items-center justify-center text-white text-lg font-bold"
 style={{ background: `linear-gradient(135deg, ${user?.avatar_color || '#FBBF24'} 0%, ${user?.avatar_color || '#FBBF24'}aa 100%)` }}
 >
 {(user?.display_name || user?.username || '؟').charAt(0).toUpperCase()}
 </div>
 )}
 <div className="flex-1 min-w-0">
 <div className="font-bold text-sm truncate">{user?.display_name || user?.username}</div>
 <div className="text-xs text-muted-foreground" dir="ltr">@{user?.username}</div>
 </div>
 <button
 onClick={() => setSection('profile')}
 className="px-4 py-2 rounded-full bg-foreground text-background text-xs font-bold"
 >
 تعديل
 </button>
 </div>

 {/* الأقسام */}
 <div className="space-y-3">
 <SectionGroup title="عام">
 <SettingItem
 icon={User}
 label="الملف الشخصي"
 desc="اسمك، نبذتك، صورة الحساب"
 onClick={() => setSection('profile')}
 />
 <SettingItem
 icon={AtSign}
 label="تغيير اليوزرنيم"
 desc={`@${user?.username || ''} - غيّر معرّفك`}
 onClick={() => setSection('username')}
 />
 <SettingItem
 icon={BadgeCheck}
 label="شارة التحقق"
 desc={user?.is_verified ? 'حسابك موثّق' : 'احصل على شارة موثّق'}
 onClick={() => setSection('verification')}
 />
 <SettingItem
 icon={Lock}
 label="كلمة المرور"
 desc="حدّث كلمة مرورك"
 onClick={() => setSection('password')}
 />
 <SettingItem
 icon={Palette}
 label="المظهر"
 desc="السمة، الألوان، الوضع الليلي"
 onClick={() => setSection('appearance')}
 />
 <SettingItem
 icon={Bell}
 label="الإشعارات"
 desc="تحكم فيما تصلك من تنبيهات"
 onClick={() => setSection('notifications')}
 />
 <SettingItem
 icon={Shield}
 label="الخصوصية والأمان"
 desc="خصوصية الحساب"
 onClick={() => setSection('privacy')}
 />
 {/* قاعدة البيانات محذوفة — مخصصة للمطورين فقط */}
 <SettingItem
 icon={Volume2}
 label="الصوت والشفافية"
 desc="أصوات الإشعارات، شفافية الزجاج"
 onClick={() => setSection('sound')}
 />
 </SectionGroup>

 <SectionGroup title="الدعم">
 <SettingItem
 icon={HelpCircle}
 label="المساعدة والأسئلة الشائعة"
 desc="دليل شامل لاستخدام KemetNet"
 onClick={() => router.push('/help')}
 />
 <SettingItem icon={FileText} label="شروط الاستخدام" onClick={() => toast.info('قريبًا')} />
 <SettingItem icon={Info} label="حول التطبيق" onClick={() => setSection('about')} />
 </SectionGroup>

 {/* لوحة الإدارة - تظهر فقط للمدراء */}
 {isAdminProfile(user) && (
 <SectionGroup title="الإدارة">
 <SettingItem
 icon={ShieldCheck}
 label="لوحة الإدارة"
 desc="إدارة المنشورات، البلاغات، الحسابات، التوثيقات"
 onClick={() => router.push('/admin')}
 />
 </SectionGroup>
 )}

 {/* مميزات حصرية محذوفة — تعرض معلومات تطوير داخلية */}

 <SectionGroup title="حسابي">
 <SettingItem
 icon={User}
 label="إدارة الحساب"
 desc="حذف الحساب، إعدادات متقدمة"
 onClick={() => setSection('account')}
 />
 <SettingItem
 icon={Ban}
 label="المستخدمون المحجوبون"
 desc="إدارة قائمة الحجب"
 onClick={() => setSection('blocked')}
 />
 <SettingItem
 icon={LogOut}
 label="تسجيل الخروج"
 desc="الخروج من حسابك"
 onClick={handleSignOut}
 danger
 />
 </SectionGroup>

 {/* تذييل */}
 <div className="text-center py-6">
 <p className="text-xs text-muted-foreground mb-1">تطبيق KemetNet · الإصدار 1.0.0</p>
 <p className="text-[10px] text-muted-foreground/60">صُنع بحب في العالم العربي</p>
 </div>
 </div>
 </main>
 </div>
 </div>
 )
}

function SectionGroup({ title, children }: { title: string; children: React.ReactNode }) {
 return (
 <div>
 <h3 className="text-xs font-bold text-muted-foreground px-3 mb-2">{title}</h3>
 <div className="rounded-2xl overflow-hidden bg-foreground/5">
 {children}
 </div>
 </div>
 )
}

function SettingItem({
 icon: Icon,
 label,
 desc,
 onClick,
 danger,
}: {
 icon: typeof User
 label: string
 desc?: string
 onClick: () => void
 danger?: boolean
}) {
 return (
 <button
 onClick={onClick}
 className="w-full flex items-center gap-3 p-3.5 hover:bg-foreground/5 transition-colors border-b border-foreground/5 last:border-0 text-right"
 >
 <div
 className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${
 danger ? 'bg-rose-500/10' : 'bg-amber-500/10'
 }`}
 >
 <Icon className={`w-4 h-4 ${danger ? 'text-rose-500' : 'text-amber-500'}`} />
 </div>
 <div className="flex-1 min-w-0">
 <div className={`text-sm font-semibold ${danger ? 'text-rose-500' : ''}`}>{label}</div>
 {desc && <div className="text-xs text-muted-foreground truncate">{desc}</div>}
 </div>
 {!danger && <ChevronLeft className="w-4 h-4 text-muted-foreground" />}
 </button>
 )
}

function ProfileSection({
 displayName,
 setDisplayName,
 bio,
 setBio,
 avatarColor,
 setAvatarColor,
 username,
 onSave,
 saving,
}: {
 displayName: string
 setDisplayName: (v: string) => void
 bio: string
 setBio: (v: string) => void
 avatarColor: string
 setAvatarColor: (v: string) => void
 username: string
 onSave: () => void
 saving: boolean
}) {
 return (
 <div className="space-y-4">
 <div className="rounded-2xl p-4 bg-foreground/5">
 <h3 className="font-bold text-sm mb-4">معلومات الملف</h3>

 {/* معاينة */}
 <div className="flex items-center gap-3 mb-5">
 <div
 className="w-16 h-16 rounded-2xl flex items-center justify-center text-white text-2xl font-bold shadow-md"
 style={{
 background: `linear-gradient(135deg, ${avatarColor} 0%, ${avatarColor}aa 100%)`,
 }}
 >
 {(displayName || username).charAt(0).toUpperCase()}
 </div>
 <div>
 <div className="text-sm font-bold">{displayName || username}</div>
 <div className="text-xs text-muted-foreground" dir="ltr">@{username}</div>
 </div>
 </div>

 {/* الاسم */}
 <div className="mb-4">
 <label className="block text-xs font-semibold mb-1.5 text-muted-foreground">الاسم المعروض</label>
 <input
 type="text"
 value={displayName}
 onChange={(e) => setDisplayName(e.target.value)}
 placeholder="الاسم الذي سيظهر للجميع"
 className="mishri-input w-full rounded-xl py-2.5 px-3 text-sm font-medium outline-none"
 maxLength={30}
 />
 </div>

 {/* النبذة */}
 <div className="mb-4">
 <label className="block text-xs font-semibold mb-1.5 text-muted-foreground">النبذة</label>
 <textarea
 value={bio}
 onChange={(e) => setBio(e.target.value)}
 placeholder="اكتب نبذة قصيرة عنك..."
 className="mishri-input w-full rounded-xl py-2.5 px-3 text-sm outline-none resize-none"
 rows={3}
 maxLength={160}
 />
 <p className="text-[10px] text-muted-foreground mt-1 text-left" dir="ltr">
 {bio.length}/160
 </p>
 </div>

 {/* لون الصورة الرمزية */}
 <div>
 <label className="block text-xs font-semibold mb-2 text-muted-foreground">لون الصورة الرمزية</label>
 <div className="grid grid-cols-8 gap-2">
 {AVATAR_COLORS.map((color) => (
 <button
 key={color}
 onClick={() => setAvatarColor(color)}
 className={`aspect-square rounded-xl transition-all mishri-press ${
 avatarColor === color ? 'ring-2 ring-offset-2 ring-foreground scale-110' : ''
 }`}
 style={{ background: color }}
 aria-label={`لون ${color}`}
 />
 ))}
 </div>
 </div>
 </div>

 <button
 onClick={onSave}
 disabled={saving}
 className="w-full mishri-gradient-primary text-white font-bold py-3.5 rounded-xl mishri-glow-soft mishri-press disabled:opacity-60"
 >
 {saving ? 'جارٍ الحفظ...' : 'حفظ التغييرات'}
 </button>
 </div>
 )
}

function AppearanceSection({ theme, setTheme }: { theme: ThemeMode; setTheme: (t: ThemeMode) => void }) {
 const themes: { id: ThemeMode; label: string; desc: string; icon: typeof Sun }[] = [
 { id: 'dawn', label: 'الفجر', desc: 'فاتح ودافئ', icon: Sun },
 { id: 'midnight', label: 'منتصف الليل', desc: 'داكن وفاخر', icon: Moon },
 { id: 'system', label: 'تلقائي', desc: 'يتبع نظام جهازك', icon: MonitorSmartphone },
 ]

 return (
 <div className="space-y-4">
 <div className="rounded-2xl p-4 bg-foreground/5">
 <h3 className="font-bold text-sm mb-4">سمة التطبيق</h3>
 <div className="space-y-2">
 {themes.map((t) => {
 const Icon = t.icon
 const active = theme === t.id
 return (
 <button
 key={t.id}
 onClick={() => setTheme(t.id)}
 className={`w-full flex items-center gap-3 p-3 rounded-2xl transition-all mishri-press ${
 active ? 'bg-amber-500/10 border-2 border-amber-500/30' : 'bg-foreground/5 border-2 border-transparent'
 }`}
 >
 <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${active ? 'mishri-gradient-primary text-white' : 'bg-foreground/10'}`}>
 <Icon className="w-5 h-5" />
 </div>
 <div className="flex-1 text-right">
 <div className={`text-sm font-bold ${active ? 'text-amber-600 dark:text-amber-300' : ''}`}>{t.label}</div>
 <div className="text-xs text-muted-foreground">{t.desc}</div>
 </div>
 {active && <div className="w-2 h-2 rounded-full bg-amber-500 mishri-pulse" />}
 </button>
 )
 })}
 </div>
 </div>

 <div className="rounded-2xl p-4 bg-foreground/5">
 <h3 className="font-bold text-sm mb-4">حجم الخط</h3>
 <div className="space-y-2">
 {['صغير', 'متوسط', 'كبير'].map((size, i) => (
 <button
 key={size}
 className={`w-full flex items-center justify-between p-3 rounded-2xl transition-all mishri-press ${
 i === 1 ? 'bg-amber-500/10 border border-amber-500/30' : 'bg-foreground/5'
 }`}
 >
 <span className="text-sm font-semibold" style={{ fontSize: 13 + i * 2 }}>
 {size}
 </span>
 {i === 1 && <div className="w-2 h-2 rounded-full bg-amber-500" />}
 </button>
 ))}
 </div>
 </div>
 </div>
 )
}

function NotificationsSection() {
 const prefs = useAppStore((s) => s.notifPreferences)
 const setNotifPreference = useAppStore((s) => s.setNotifPreference)
 const resetNotifPreferences = useAppStore((s) => s.resetNotifPreferences)

 return (
 <div className="space-y-4">
 <div className="rounded-2xl bg-foreground/5 p-2">
 <NotifRow
 icon={Heart}
 label="الإعجابات"
 desc="عند إعجاب أحد بمنشوراتك"
 value={prefs.likes}
 onChange={(v) => setNotifPreference('likes', v)}
 />
 <NotifRow
 icon={MessageCircle}
 label="التعليقات"
 desc="عند تعليق أحد على منشوراتك"
 value={prefs.comments}
 onChange={(v) => setNotifPreference('comments', v)}
 />
 <NotifRow
 icon={User}
 label="المتابعون الجدد"
 desc="عند متابعة أحد لك"
 value={prefs.follows}
 onChange={(v) => setNotifPreference('follows', v)}
 />
 <NotifRow
 icon={AtSign}
 label="الإشارات"
 desc="عند ذكرك في منشور أو تعليق"
 value={prefs.mentions}
 onChange={(v) => setNotifPreference('mentions', v)}
 />
 <NotifRow
 icon={MessageCircle}
 label="الرسائل"
 desc="عند وصول رسالة جديدة"
 value={prefs.messages}
 onChange={(v) => setNotifPreference('messages', v)}
 />
 <NotifRow
 icon={Repeat2}
 label="إعادة النشر"
 desc="عند إعادة نشر منشوراتك"
 value={prefs.reposts}
 onChange={(v) => setNotifPreference('reposts', v)}
 />
 </div>

 {/* الإعدادات العامة */}
 <div className="rounded-2xl bg-foreground/5 p-2">
 <NotifRow
 icon={Volume2}
 label="أصوات الإشعارات"
 desc="تشغيل صوت عند وصول إشعار"
 value={prefs.sound}
 onChange={(v) => setNotifPreference('sound', v)}
 />
 <NotifRow
 icon={Ban}
 label="الاهتزاز"
 desc="اهتزاز الجهاز عند الإشعار"
 value={prefs.vibration}
 onChange={(v) => setNotifPreference('vibration', v)}
 />
 </div>

 {/* زر إعادة التعيين */}
 <button
 onClick={() => {
 resetNotifPreferences()
 toast.success('تمت إعادة تعيين الإعدادات')
 }}
 className="w-full py-2.5 rounded-xl bg-foreground/5 text-xs font-bold text-muted-foreground hover:bg-foreground/10 transition-colors mishri-press"
 >
 إعادة تعيين الإعدادات الافتراضية
 </button>
 </div>
 )
}

function NotifRow({
 icon: Icon, label, desc, value, onChange,
}: {
 icon: typeof Heart
 label: string
 desc: string
 value: boolean
 onChange: (v: boolean) => void
}) {
 return (
 <div className="flex items-center gap-3 p-3 border-b border-foreground/5 last:border-0">
 <div className="w-9 h-9 rounded-xl bg-amber-500/10 flex items-center justify-center">
 <Icon className="w-4 h-4 text-amber-500" />
 </div>
 <div className="flex-1">
 <div className="text-sm font-semibold">{label}</div>
 <div className="text-xs text-muted-foreground">{desc}</div>
 </div>
 <Toggle value={value} onChange={onChange} />
 </div>
 )
}

function Toggle({ value, onChange }: { value: boolean; onChange: (v: boolean) => void }) {
 return (
 <button
 onClick={() => onChange(!value)}
 className={`relative w-12 h-7 rounded-full transition-colors ${
 value ? 'mishri-gradient-primary' : 'bg-foreground/15'
 }`}
 >
 <div
 className="absolute top-1 right-1 w-5 h-5 rounded-full bg-white shadow-md transition-all duration-300"
 style={{ transform: value ? 'translateX(-22px)' : 'translateX(0)' }}
 />
 </button>
 )
}

function PrivacySection({
 privateAccount, setPrivateAccount,
 showActivity, setShowActivity,
}: {
 privateAccount: boolean; setPrivateAccount: (v: boolean) => void
 showActivity: boolean; setShowActivity: (v: boolean) => void
}) {
 const user = useAppStore((s) => s.user)
 const setUser = useAppStore((s) => s.setUser)
 const [showLastSeen, setShowLastSeen] = useState(user?.show_last_seen ?? true)
 const [showOnlineStatus, setShowOnlineStatus] = useState(user?.show_online_status ?? true)

 const handleToggleLastSeen = async (value: boolean) => {
 setShowLastSeen(value)
 if (!user) return
 try {
 const { error } = await supabase
 .from('profiles')
 .update({ show_last_seen: value })
 .eq('id', user.id)
 if (error) {
 toast.error('تعذّر تحديث الإعداد')
 setShowLastSeen(!value)
 } else {
 setUser({ ...user, show_last_seen: value })
 toast.success(value ? 'تم تفعيل إظهار آخر ظهور' : 'تم إخفاء آخر ظهور')
 }
 } catch (e) {
 // [removed in production] e
 setShowLastSeen(!value)
 }
 }

 const handleToggleOnlineStatus = async (value: boolean) => {
 setShowOnlineStatus(value)
 if (!user) return
 try {
 const { error } = await supabase
 .from('profiles')
 .update({ show_online_status: value })
 .eq('id', user.id)
 if (error) {
 toast.error('تعذّر تحديث الإعداد')
 setShowOnlineStatus(!value)
 } else {
 setUser({ ...user, show_online_status: value })
 toast.success(value ? 'تم تفعيل إظهار حالة الاتصال' : 'تم إخفاء حالة الاتصال')
 }
 } catch (e) {
 // [removed in production] e
 setShowOnlineStatus(!value)
 }
 }

 return (
 <div className="space-y-4">
 <div className="rounded-2xl bg-foreground/5 p-2">
 <NotifRow
 icon={Lock}
 label="حساب خاص"
 desc="يمكن للأشخاص رؤية منشوراتك فقط بعد الموافقة"
 value={privateAccount}
 onChange={setPrivateAccount}
 />
 <NotifRow
 icon={Eye}
 label="إظهار النشاط"
 desc="السماح للآخرين برؤية ما يعجبك"
 value={showActivity}
 onChange={setShowActivity}
 />
 <NotifRow
 icon={Clock}
 label="إظهار آخر ظهور"
 desc="السماح للآخرين برؤية وقت آخر نشاط لك"
 value={showLastSeen}
 onChange={handleToggleLastSeen}
 />
 <NotifRow
 icon={Activity}
 label="إظهار حالة الاتصال"
 desc="إظهار متصل الآن / بعيد في المحادثات"
 value={showOnlineStatus}
 onChange={handleToggleOnlineStatus}
 />
 </div>

 <div className="rounded-2xl bg-foreground/5 p-4 flex items-start gap-3">
 <Shield className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
 <div className="text-[11px] text-muted-foreground leading-relaxed">
 <strong className="text-foreground">خصوصيتك تهمنا.</strong> عند إيقاف إظهار آخر ظهور أو حالة الاتصال، لن يستطيع الآخرون رؤية هذه المعلومات. ومع ذلك، لن تتمكن أنت أيضاً من رؤية آخر ظهور الآخرين وحالتهم.
 </div>
 </div>
 </div>
 )
}

// ========================================
// قسم تغيير اليوزرنيم
// ========================================
function UsernameSection({
 currentUsername,
 userId,
 onUsernameChanged,
}: {
 currentUsername: string
 userId: string
 onUsernameChanged: (newUsername: string) => void
}) {
 const [newUsername, setNewUsername] = useState('')
 const [checking, setChecking] = useState(false)
 const [available, setAvailable] = useState<boolean | null>(null)
 const [saving, setSaving] = useState(false)
 const { playSound } = useNotificationSound()

 // التحقق من التوفر عند الكتابة (debounced)
 useEffect(() => {
 if (!newUsername.trim()) {
 setAvailable(null)
 return
 }

 const validation = validateUsername(newUsername)
 if (!validation.valid) {
 setAvailable(false)
 return
 }

 // إذا كان نفس اليوزرنيم الحالي
 if (newUsername.toLowerCase().trim() === currentUsername.toLowerCase()) {
 setAvailable(false)
 return
 }

 setChecking(true)
 const timer = setTimeout(async () => {
 const result = await checkUsernameAvailability(newUsername)
 setAvailable(result)
 setChecking(false)
 }, 500)

 return () => clearTimeout(timer)
 }, [newUsername, currentUsername])

 const handleSave = async () => {
 if (!userId || !newUsername.trim()) return
 if (available !== true) {
 toast.error('اليوزرنيم غير متاح')
 return
 }
 setSaving(true)
 try {
 const result = await changeUsername(userId, newUsername)
 if (result.success) {
 playSound('success')
 toast.success('تم تغيير اليوزرنيم بنجاح')
 onUsernameChanged(result.newUsername || newUsername.toLowerCase().trim())
 } else {
 toast.error(result.error || 'تعذّر تغيير اليوزرنيم')
 }
 } catch (e) {
 // [removed in production] 'Username change error:', e
 toast.error('حدث خطأ')
 } finally {
 setSaving(false)
 }
 }

 const validation = validateUsername(newUsername)
 const isValidFormat = validation.valid
 const canSave = isValidFormat && available === true && !saving

 return (
 <div className="space-y-4">
 <div className="rounded-2xl p-4 bg-foreground/5">
 <h3 className="font-bold text-sm mb-4">تغيير اليوزرنيم</h3>

 {/* اليوزرنيم الحالي */}
 <div className="mb-4 p-3 rounded-2xl bg-foreground/5 flex items-center gap-3">
 <AtSign className="w-4 h-4 text-muted-foreground flex-shrink-0" />
 <div>
 <div className="text-[10px] text-muted-foreground">اليوزرنيم الحالي</div>
 <div className="text-sm font-bold" dir="ltr">@{currentUsername}</div>
 </div>
 </div>

 {/* اليوزرنيم الجديد */}
 <div className="mb-3">
 <label className="block text-xs font-semibold mb-2 text-muted-foreground">
 اليوزرنيم الجديد
 </label>
 <div className="relative">
 <input
 type="text"
 value={newUsername}
 onChange={(e) => setNewUsername(e.target.value)}
 placeholder="أدخل اليوزرنيم الجديد"
 className="mishri-input w-full rounded-xl py-3 px-4 pl-10 text-sm font-medium outline-none"
 maxLength={20}
 dir="ltr"
 disabled={saving}
 autoFocus
 />
 {/* مؤشر الحالة */}
 {newUsername && (
 <div className="absolute top-1/2 -translate-y-1/2 left-3">
 {checking ? (
 <Loader2 className="w-4 h-4 text-muted-foreground animate-spin" />
 ) : available === true ? (
 <Check className="w-4 h-4 text-emerald-500" />
 ) : available === false ? (
 <X className="w-4 h-4 text-rose-500" />
 ) : null}
 </div>
 )}
 </div>
 </div>

 {/* رسائل التحقق */}
 {newUsername && !isValidFormat && (
 <p className="text-[11px] text-rose-500 mb-3">{validation.error}</p>
 )}
 {newUsername && isValidFormat && available === false && !checking && (
 <p className="text-[11px] text-rose-500 mb-3">
 {newUsername.toLowerCase() === currentUsername.toLowerCase()
 ? 'هذا هو يوزرنيمك الحالي'
 : 'هذا اليوزرنيم محجوز'}
 </p>
 )}
 {newUsername && isValidFormat && available === true && (
 <p className="text-[11px] text-emerald-500 mb-3">اليوزرنيم متاح ✓</p>
 )}

 {/* قواعد اليوزرنيم */}
 <div className="text-[10px] text-muted-foreground/80 space-y-1 mb-4 p-3 rounded-xl bg-foreground/5">
 <div className="font-bold mb-1">قواعد اليوزرنيم:</div>
 <div>• 3 إلى 20 حرفًا</div>
 <div>• أحرف إنجليزية، أرقام، وشرطة سفلية (_)</div>
 <div>• لا يمكن تغييره بسهولة، اختر بحكمة</div>
 </div>

 <button
 onClick={handleSave}
 disabled={!canSave}
 className="w-full mishri-gradient-primary text-white font-bold py-3.5 rounded-xl mishri-glow-soft mishri-press disabled:opacity-50 flex items-center justify-center gap-2"
 >
 {saving ? (
 <>
 <Loader2 className="w-4 h-4 animate-spin" />
 جارٍ الحفظ...
 </>
 ) : (
 'حفظ اليوزرنيم الجديد'
 )}
 </button>
 </div>

 <div className="rounded-2xl bg-foreground/5 p-4 flex items-start gap-3">
 <AlertTriangle className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
 <div className="text-[11px] text-muted-foreground leading-relaxed">
 <strong className="text-foreground">تنبيه:</strong> تغيير اليوزرنيم قد يؤثر على الإشارات @username القديمة في المنشورات والتعليقات. لن تتمكن الإشارات القديمة من الوصول لملفك الجديد.
 </div>
 </div>
 </div>
 )
}

// ========================================
// قسم تغيير كلمة المرور
// ========================================
function PasswordSection() {
 const [currentPassword, setCurrentPassword] = useState('')
 const [newPassword, setNewPassword] = useState('')
 const [confirmPassword, setConfirmPassword] = useState('')
 const [showPasswords, setShowPasswords] = useState(false)
 const [saving, setSaving] = useState(false)
 const { playSound } = useNotificationSound()

 const strength = checkPasswordStrength(newPassword)

 const canSave =
 currentPassword.trim() &&
 newPassword.trim() &&
 confirmPassword.trim() &&
 newPassword === confirmPassword &&
 strength.score >= 2 &&
 !saving

 const handleSave = async () => {
 if (!canSave) return
 setSaving(true)
 try {
 const { changePassword } = await import('@/lib/account')
 const result = await changePassword(currentPassword, newPassword)
 if (result.success) {
 playSound('success')
 toast.success('تم تحديث كلمة المرور بنجاح')
 setCurrentPassword('')
 setNewPassword('')
 setConfirmPassword('')
 } else {
 toast.error(result.error || 'تعذّر تحديث كلمة المرور')
 }
 } catch (e) {
 // [removed in production] 'Password change error:', e
 toast.error('حدث خطأ')
 } finally {
 setSaving(false)
 }
 }

 return (
 <div className="space-y-4">
 <div className="rounded-2xl p-4 bg-foreground/5">
 <h3 className="font-bold text-sm mb-4">تغيير كلمة المرور</h3>

 {/* كلمة المرور الحالية */}
 <div className="mb-4">
 <label className="block text-xs font-semibold mb-2 text-muted-foreground">
 كلمة المرور الحالية
 </label>
 <div className="relative">
 <input
 type={showPasswords ? 'text' : 'password'}
 value={currentPassword}
 onChange={(e) => setCurrentPassword(e.target.value)}
 placeholder="••••••••"
 className="mishri-input w-full rounded-xl py-3 px-4 pl-10 text-sm font-medium outline-none"
 disabled={saving}
 dir="ltr"
 />
 <button
 onClick={() => setShowPasswords(!showPasswords)}
 className="absolute top-1/2 -translate-y-1/2 left-3 p-1"
 aria-label={showPasswords ? 'إخفاء' : 'إظهار'}
 >
 {showPasswords ? (
 <EyeOff className="w-4 h-4 text-muted-foreground" />
 ) : (
 <Eye className="w-4 h-4 text-muted-foreground" />
 )}
 </button>
 </div>
 </div>

 {/* كلمة المرور الجديدة */}
 <div className="mb-4">
 <label className="block text-xs font-semibold mb-2 text-muted-foreground">
 كلمة المرور الجديدة
 </label>
 <input
 type={showPasswords ? 'text' : 'password'}
 value={newPassword}
 onChange={(e) => setNewPassword(e.target.value)}
 placeholder="••••••••"
 className="mishri-input w-full rounded-xl py-3 px-4 text-sm font-medium outline-none"
 disabled={saving}
 dir="ltr"
 />

 {/* مؤشر القوة */}
 {newPassword && (
 <div className="mt-2 space-y-1">
 <div className="flex items-center gap-1">
 {[0, 1, 2, 3].map((i) => (
 <div
 key={i}
 className="h-1 flex-1 rounded-full transition-colors"
 style={{
 background: i <= strength.score ? strength.color : 'rgba(0,0,0,0.1)',
 }}
 />
 ))}
 <span className="text-[10px] font-bold mr-2" style={{ color: strength.color }}>
 {strength.label}
 </span>
 </div>
 <div className="flex flex-wrap gap-1 mt-1">
 <StrengthBadge label="8+ أحرف" active={strength.checks.length} />
 <StrengthBadge label="أحرف" active={strength.checks.hasLetter} />
 <StrengthBadge label="أرقام" active={strength.checks.hasNumber} />
 <StrengthBadge label="رمز خاص" active={strength.checks.hasSpecial} />
 </div>
 </div>
 )}
 </div>

 {/* تأكيد كلمة المرور */}
 <div className="mb-4">
 <label className="block text-xs font-semibold mb-2 text-muted-foreground">
 تأكيد كلمة المرور الجديدة
 </label>
 <input
 type={showPasswords ? 'text' : 'password'}
 value={confirmPassword}
 onChange={(e) => setConfirmPassword(e.target.value)}
 placeholder="••••••••"
 className="mishri-input w-full rounded-xl py-3 px-4 text-sm font-medium outline-none"
 disabled={saving}
 dir="ltr"
 />
 {confirmPassword && newPassword !== confirmPassword && (
 <p className="text-[11px] text-rose-500 mt-1">كلمتا المرور غير متطابقتين</p>
 )}
 </div>

 <button
 onClick={handleSave}
 disabled={!canSave}
 className="w-full mishri-gradient-primary text-white font-bold py-3.5 rounded-xl mishri-glow-soft mishri-press disabled:opacity-50 flex items-center justify-center gap-2"
 >
 {saving ? (
 <>
 <Loader2 className="w-4 h-4 animate-spin" />
 جارٍ الحفظ...
 </>
 ) : (
 'تحديث كلمة المرور'
 )}
 </button>
 </div>
 </div>
 )
}

function StrengthBadge({ label, active }: { label: string; active: boolean }) {
 return (
 <span
 className={`text-[9px] px-2 py-0.5 rounded-full ${
 active ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400' : 'bg-foreground/5 text-muted-foreground'
 }`}
 >
 {active ? '✓' : '○'} {label}
 </span>
 )
}

// ========================================
// قسم إدارة الحساب (حذف الحساب)
// ========================================
function AccountSection({
 userId,
 onAccountDeleted,
}: {
 userId: string
 onAccountDeleted: () => void
}) {
 const [stage, setStage] = useState<'info' | 'confirm'>('info')
 const [confirmationText, setConfirmationText] = useState('')
 const [deleting, setDeleting] = useState(false)
 const { playSound } = useNotificationSound()

 const handleDelete = async () => {
 if (!userId) return
 setDeleting(true)
 try {
 const result = await deleteAccount(userId, confirmationText)
 if (result.success) {
 playSound('success')
 toast.success('تم حذف الحساب بنجاح')
 // إعطاء وقت قصير قبل إعادة التوجيه
 setTimeout(() => onAccountDeleted(), 500)
 } else {
 toast.error(result.error || 'تعذّر حذف الحساب')
 }
 } catch (e) {
 // [removed in production] 'Delete account error:', e
 toast.error('حدث خطأ أثناء حذف الحساب')
 } finally {
 setDeleting(false)
 }
 }

 if (stage === 'confirm') {
 return (
 <div className="space-y-4">
 <div
 className="rounded-2xl p-4 bg-foreground/5 border-2 border-rose-500/30"
 >
 <div className="text-center mb-5">
 <div className="w-16 h-16 mx-auto mb-3 rounded-2xl bg-rose-500/15 flex items-center justify-center">
 <AlertTriangle className="w-8 h-8 text-rose-500" />
 </div>
 <h3 className="font-display text-lg font-bold text-rose-500 mb-1">
 تأكيد حذف الحساب
 </h3>
 <p className="text-xs text-muted-foreground leading-relaxed">
 سيتم حذف جميع منشوراتك وتعليقاتك وإعجاباتك ومتابعيك ورسائلك نهائياً.
 <br />
 <strong className="text-rose-500">لا يمكن التراجع عن هذا الإجراء.</strong>
 </p>
 </div>

 {/* ما سيتم حذفه */}
 <div className="bg-rose-500/5 rounded-2xl p-3 mb-4">
 <div className="text-[11px] font-bold text-rose-500 mb-2">سيتم حذف:</div>
 <div className="space-y-1.5 text-[11px] text-muted-foreground">
 <DeleteItem label="كل منشوراتك وصورك" />
 <DeleteItem label="كل تعليقاتك وردودك" />
 <DeleteItem label="كل إعجاباتك ومتابعاتك" />
 <DeleteItem label="كل رسائلك ومحادثاتك" />
 <DeleteItem label="ملفك الشخصي وبياناتك" />
 </div>
 </div>

 {/* تأكيد الكتابة */}
 <div className="mb-4">
 <label className="block text-xs font-semibold mb-2 text-muted-foreground">
 اكتب <span className="font-bold text-rose-500">&ldquo;حذف&rdquo;</span> للتأكيد
 </label>
 <input
 type="text"
 value={confirmationText}
 onChange={(e) => setConfirmationText(e.target.value)}
 placeholder="حذف"
 className="mishri-input w-full rounded-xl py-3 px-4 text-sm font-bold outline-none text-center"
 disabled={deleting}
 dir="ltr"
 />
 </div>

 <div className="flex gap-2">
 <button
 onClick={() => {
 setStage('info')
 setConfirmationText('')
 }}
 disabled={deleting}
 className="flex-1 py-3 rounded-xl bg-foreground/5 text-sm font-bold disabled:opacity-50"
 >
 إلغاء
 </button>
 <button
 onClick={handleDelete}
 disabled={confirmationText.trim() !== 'حذف' || deleting}
 className="flex-1 py-3 rounded-xl bg-rose-500 text-white text-sm font-bold disabled:opacity-50 flex items-center justify-center gap-2 mishri-press"
 >
 {deleting ? (
 <>
 <Loader2 className="w-4 h-4 animate-spin" />
 جارٍ الحذف...
 </>
 ) : (
 <>
 <Trash2 className="w-4 h-4" />
 حذف نهائي
 </>
 )}
 </button>
 </div>
 </div>
 </div>
 )
 }

 return (
 <div className="space-y-4">
 <div className="rounded-2xl p-4 bg-foreground/5">
 <h3 className="font-bold text-sm mb-4">إدارة الحساب</h3>

 <div className="space-y-3">
 {/* معلومات الحساب */}
 <div className="p-3 rounded-2xl bg-foreground/5">
 <div className="text-[11px] font-bold text-muted-foreground mb-2">معلومات الحساب</div>
 <div className="space-y-2 text-xs">
 <div className="flex items-center justify-between">
 <span className="text-muted-foreground">المعرّف:</span>
 <span className="font-mono" dir="ltr">{userId.slice(0, 8)}...</span>
 </div>
 </div>
 </div>

 {/* منطقة الخطر */}
 <div className="p-3 rounded-2xl bg-rose-500/5 border border-rose-500/20">
 <div className="flex items-center gap-2 mb-2">
 <AlertTriangle className="w-4 h-4 text-rose-500" />
 <span className="text-xs font-bold text-rose-500">منطقة الخطر</span>
 </div>
 <p className="text-[11px] text-muted-foreground leading-relaxed mb-3">
 حذف الحساب إجراء دائم. سيتم حذف كل بياناتك نهائياً ولا يمكن استعادتها.
 </p>
 <button
 onClick={() => setStage('confirm')}
 className="w-full py-2.5 rounded-xl bg-rose-500/10 text-rose-500 text-xs font-bold hover:bg-rose-500/20 transition-colors mishri-press flex items-center justify-center gap-2"
 >
 <Trash2 className="w-3.5 h-3.5" />
 حذف حسابي نهائياً
 </button>
 </div>
 </div>
 </div>
 </div>
 )
}

function DeleteItem({ label }: { label: string }) {
 return (
 <div className="flex items-center gap-2">
 <div className="w-1 h-1 rounded-full bg-rose-500" />
 <span>{label}</span>
 </div>
 )
}

// ========================================
// قسم المستخدمين المحجوبين
// ========================================
function BlockedUsersSection() {
 const user = useAppStore((s) => s.user)
 const router = useRouter()
 const { playSound } = useNotificationSound()
 const [blocks, setBlocks] = useState<Block[]>([])
 const [loading, setLoading] = useState(true)
 const [unblockLoading, setUnblockLoading] = useState<string | null>(null)

 useEffect(() => {
 if (!user) {
 setLoading(false)
 return
 }
 let cancelled = false
 void (async () => {
 setLoading(true)
 const result = await fetchBlockedUsers(user.id)
 if (!cancelled) {
 setBlocks(result)
 setLoading(false)
 }
 })()
 return () => {
 cancelled = true
 }
 }, [user])

 const handleUnblock = async (blockedId: string, name: string) => {
 if (!user) return
 setUnblockLoading(blockedId)
 try {
 const result = await unblockUser(user.id, blockedId)
 if (result.success) {
 playSound('success')
 toast.success(`تم إلغاء حجب ${name}`)
 setBlocks((prev) => prev.filter((b) => b.blocked_id !== blockedId))
 } else {
 toast.error(result.error || 'تعذّر إلغاء الحجب')
 }
 } catch (e) {
 // [removed in production] 'Unblock error:', e
 toast.error('حدث خطأ')
 } finally {
 setUnblockLoading(null)
 }
 }

 return (
 <div className="space-y-4">
 <div className="rounded-2xl p-4 bg-foreground/5">
 <div className="flex items-center gap-3 mb-4">
 <div className="w-10 h-10 rounded-xl bg-rose-500/10 flex items-center justify-center">
 <Ban className="w-5 h-5 text-rose-500" />
 </div>
 <div>
 <div className="font-bold text-sm">المستخدمون المحجوبون</div>
 <div className="text-xs text-muted-foreground">
 {blocks.length} مستخدم محجوب
 </div>
 </div>
 </div>

 {loading ? (
 <div className="space-y-2">
 {Array.from({ length: 3 }).map((_, i) => (
 <div
 key={i}
 className="rounded-2xl bg-foreground/5 p-3 h-14 mishri-shimmer"
 />
 ))}
 </div>
 ) : blocks.length === 0 ? (
 <div className="text-center py-10">
 <div className="w-14 h-14 mx-auto mb-3 rounded-2xl bg-foreground/5 flex items-center justify-center">
 <Ban className="w-7 h-7 text-muted-foreground/50" />
 </div>
 <p className="text-sm font-semibold mb-1">لا يوجد مستخدمون محجوبون</p>
 <p className="text-xs text-muted-foreground">
 عند حجب مستخدم، سيظهر هنا
 </p>
 </div>
 ) : (
 <div className="space-y-2">
 {blocks.map((block, idx) => {
 const profile = block.blocked
 const name = profile?.display_name || profile?.username || 'مستخدم محذوف'
 return (
 <div
 key={block.blocked_id + "-" + idx}
 className="flex items-center gap-3 p-2 rounded-2xl hover:bg-foreground/5 transition-colors"
 >
 <button
 onClick={() => {
 if (profile?.username) router.push(`/profile/${profile.username}`)
 }}
 className="flex-shrink-0 mishri-press"
 >
 {profile?.avatar_url ? (
 <img
 src={profile.avatar_url}
 alt=""
 className="w-10 h-10 rounded-xl object-cover"
 />
 ) : (
 <div
 className="w-10 h-10 rounded-xl flex items-center justify-center text-white text-sm font-bold"
 style={{
 background: `linear-gradient(135deg, ${profile?.avatar_color || '#FBBF24'} 0%, ${profile?.avatar_color || '#FBBF24'}aa 100%)`,
 }}
 >
 {name.charAt(0).toUpperCase()}
 </div>
 )}
 </button>
 <button
 onClick={() => {
 if (profile?.username) router.push(`/profile/${profile.username}`)
 }}
 className="flex-1 text-right mishri-press"
 >
 <div className="text-sm font-bold">{name}</div>
 <div className="text-[11px] text-muted-foreground" dir="ltr">
 @{profile?.username || 'محذوف'}
 </div>
 </button>
 <button
 onClick={() => handleUnblock(block.blocked_id, name)}
 disabled={unblockLoading === block.blocked_id}
 className="px-3 py-1.5 rounded-xl bg-foreground/5 text-xs font-bold hover:bg-foreground/10 transition-colors mishri-press disabled:opacity-50 flex items-center gap-1"
 >
 {unblockLoading === block.blocked_id ? (
 <Loader2 className="w-3 h-3 animate-spin" />
 ) : (
 'إلغاء الحجب'
 )}
 </button>
 </div>
 )
 })}
 </div>
 )}
 </div>

 <div className="rounded-2xl bg-foreground/5 p-4 flex items-start gap-3">
 <Info className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
 <div className="text-[11px] text-muted-foreground leading-relaxed">
 عند حجب مستخدم: يتم حذف متابعته لك تلقائياً، لا يمكنه مراسلتك أو رؤية منشوراتك في صندوق الوارد. يمكنك إلغاء الحجب في أي وقت.
 </div>
 </div>
 </div>
 )
}

// ========================================
// قسم حول التطبيق
// ========================================
function AboutSection() {
 return (
 <div className="space-y-4">
 <div className="rounded-2xl bg-foreground/5 p-6 text-center">
 <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl mishri-gradient-primary mishri-glow-soft mb-3">
 <Sparkles className="w-10 h-10 text-white" />
 </div>
 <h3 className="font-display text-xl font-bold mishri-gradient-text">KemetNet</h3>
 <p className="text-xs text-muted-foreground mt-1">منصة عربية للإلهام والإبداع</p>
 <p className="text-[10px] text-muted-foreground/60 mt-1" dir="ltr">v1.0.0</p>
 </div>

 <div className="rounded-2xl p-4 bg-foreground/5">
 <h3 className="font-bold text-sm mb-3">عن التطبيق</h3>
 <p className="text-sm text-muted-foreground leading-relaxed">
 تطبيق "KemetNet" هو منصة عربية حديثة للإبداع والمشاركة، مستوحاة من عظمة الحضارة المصرية القديمة. صُمم التطبيق بهوية بصرية تجمع بين الأزرق اللازوردي والذهبي، رمزًا للخلود والحكمة، ليكون منارة للمحتوى العربي المميز.
 </p>
 </div>

 <div className="rounded-2xl p-4 bg-foreground/5">
 <h3 className="font-bold text-sm mb-3">المميزات</h3>
 <div className="space-y-2">
 {[
 'تسجيل دخول آمن باليوزرنيم',
 'فلاتر متقدمة للمنشورات',
 'تصميم عصري وأنيق',
 'وضع ليلي فاخر',
 'مزامنة لحظية للإشعارات',
 'يعمل على الويب والجوال',
 ].map((feature) => (
 <div key={feature} className="flex items-center gap-2 text-sm">
 <div className="w-5 h-5 rounded-full bg-amber-500/20 flex items-center justify-center flex-shrink-0">
 <div className="w-2 h-2 rounded-full mishri-gradient-primary" />
 </div>
 {feature}
 </div>
 ))}
 </div>
 </div>

 <div className="rounded-2xl p-4 bg-foreground/5 text-center">
 <p className="text-sm text-muted-foreground mb-2">صُنع بـ</p>
 <div className="inline-flex items-center gap-1 text-rose-500 font-bold">
 <Heart className="w-4 h-4 fill-rose-500 mishri-heartbeat" />
 <span>في العالم العربي</span>
 </div>
 </div>
 </div>
 )
}

// ====================================
// قسم الصوت والشفافية - حصري
// ====================================
interface SoundAndGlassProps {
 glassOpacity: number
 setGlassOpacity: (v: number) => void
 notificationVolume: number
 setNotificationVolume: (v: number) => void
 soundEnabled: boolean
 setSoundEnabled: (v: boolean) => void
 onTestSound: (type: 'like' | 'comment' | 'follow' | 'notification' | 'success' | 'send' | 'error') => void
}

function SoundAndGlassSection({
 glassOpacity,
 setGlassOpacity,
 notificationVolume,
 setNotificationVolume,
 soundEnabled,
 setSoundEnabled,
 onTestSound,
}: SoundAndGlassProps) {
 return (
 <div className="space-y-4">
 {/* تفعيل الصوت */}
 <div className="rounded-2xl p-4 bg-foreground/5">
 <div className="flex items-center justify-between mb-4">
 <div className="flex items-center gap-3">
 <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center">
 {soundEnabled ? <Volume2 className="w-5 h-5 text-amber-500" /> : <VolumeX className="w-5 h-5 text-muted-foreground" />}
 </div>
 <div>
 <div className="font-bold text-sm">تفعيل الأصوات</div>
 <div className="text-xs text-muted-foreground">أصوات الإعجاب، التعليق، الإشعارات</div>
 </div>
 </div>
 <Toggle value={soundEnabled} onChange={setSoundEnabled} />
 </div>

 {soundEnabled && (
 <>
 {/* مستوى الصوت */}
 <div className="mt-4 pt-4 border-t border-foreground/5">
 <div className="flex items-center justify-between mb-2">
 <label className="text-xs font-semibold text-muted-foreground">مستوى الصوت</label>
 <span className="text-xs font-bold text-amber-500">{notificationVolume}%</span>
 </div>
 <input
 type="range"
 min={0}
 max={100}
 value={notificationVolume}
 onChange={(e) => setNotificationVolume(Number(e.target.value))}
 className="w-full h-2 bg-foreground/10 rounded-full appearance-none cursor-pointer accent-amber-500"
 style={{
 background: `linear-gradient(to left, #FBBF24 ${notificationVolume}%, transparent ${notificationVolume}%)`,
 }}
 />
 </div>

 {/* أزرار تجربة الأصوات */}
 <div className="mt-4 pt-4 border-t border-foreground/5">
 <label className="text-xs font-semibold text-muted-foreground mb-3 block">جرّب الأصوات</label>
 <div className="grid grid-cols-3 gap-2">
 <TestSoundButton label="إعجاب" onClick={() => onTestSound('like')} />
 <TestSoundButton label="تعليق" onClick={() => onTestSound('comment')} />
 <TestSoundButton label="متابعة" onClick={() => onTestSound('follow')} />
 <TestSoundButton label="إشعار" onClick={() => onTestSound('notification')} />
 <TestSoundButton label="إرسال" onClick={() => onTestSound('send')} />
 <TestSoundButton label="نجاح" onClick={() => onTestSound('success')} />
 </div>
 </div>
 </>
 )}
 </div>

 {/* شفافية الزجاج السائل */}
 <div className="rounded-2xl p-4 bg-foreground/5">
 <div className="flex items-center gap-3 mb-4">
 <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center">
 <GlassWater className="w-5 h-5 text-amber-500" />
 </div>
 <div>
 <div className="font-bold text-sm">شفافية الزجاج السائل</div>
 <div className="text-xs text-muted-foreground">تحكم في شفافية البطاقات والقوائم الزجاجية</div>
 </div>
 </div>

 {/* معاينة حية */}
 <div className="mb-4 p-4 rounded-2xl bg-gradient-to-br from-amber-500/20 via-rose-500/20 to-violet-500/20">
 <div className="rounded-xl bg-foreground/5 p-3 text-center">
 <p className="text-xs font-semibold">معاينة الشفافية</p>
 <p className="text-[10px] text-muted-foreground mt-1">{glassOpacity}% شفافية</p>
 </div>
 </div>

 {/* شريط التحكم */}
 <div className="flex items-center justify-between mb-2">
 <span className="text-xs text-muted-foreground">شفاف</span>
 <span className="text-xs font-bold text-amber-500">{glassOpacity}%</span>
 <span className="text-xs text-muted-foreground">معتم</span>
 </div>
 <input
 type="range"
 min={0}
 max={100}
 value={glassOpacity}
 onChange={(e) => setGlassOpacity(Number(e.target.value))}
 className="w-full h-2 bg-foreground/10 rounded-full appearance-none cursor-pointer accent-amber-500"
 style={{
 background: `linear-gradient(to left, #FBBF24 ${glassOpacity}%, transparent ${glassOpacity}%)`,
 }}
 />

 {/* قيم سريعة */}
 <div className="grid grid-cols-4 gap-2 mt-4">
 <QuickValueButton label="خفيف" value={30} current={glassOpacity} onClick={setGlassOpacity} />
 <QuickValueButton label="متوسط" value={60} current={glassOpacity} onClick={setGlassOpacity} />
 <QuickValueButton label="قوي" value={85} current={glassOpacity} onClick={setGlassOpacity} />
 <QuickValueButton label="معتم" value={100} current={glassOpacity} onClick={setGlassOpacity} />
 </div>
 </div>
 </div>
 )
}

function TestSoundButton({ label, onClick }: { label: string; onClick: () => void }) {
 return (
 <button
 onClick={onClick}
 className="flex items-center justify-center gap-1 py-2.5 rounded-xl bg-foreground/5 hover:bg-foreground/10 transition-colors mishri-press text-xs font-semibold"
 >
 <Play className="w-3 h-3" />
 {label}
 </button>
 )
}

function QuickValueButton({ label, value, current, onClick }: { label: string; value: number; current: number; onClick: (v: number) => void }) {
 const active = current === value
 return (
 <button
 onClick={() => onClick(value)}
 className={`py-2 rounded-xl text-xs font-semibold transition-all mishri-press ${
 active ? 'mishri-gradient-primary text-white shadow-md' : 'bg-foreground/5 hover:bg-foreground/10 text-muted-foreground'
 }`}
 >
 {label}
 </button>
 )
}
