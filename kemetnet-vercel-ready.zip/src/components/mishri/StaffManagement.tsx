'use client'

import { useState, useEffect, useCallback } from 'react'
import {
  UserPlus, Trash2, Shield, ShieldCheck, X, Check, Loader2, RefreshCw,
  Search, Crown, UserCog, Eye, EyeOff, AlertCircle, Edit3, Ban,
} from 'lucide-react'
import { supabase, type Profile } from '@/lib/supabase/client'
import {
  fetchStaffMembers, addStaffMember, updateStaffPermissions, removeStaffMember,
  type StaffMember,
} from '@/lib/admin'
import {
  ALL_PERMISSIONS, ROLE_PRESETS, type Permission,
} from '@/lib/admin-config'
import { toast } from 'sonner'

interface StaffManagementProps {
  currentUserId: string
}

export function StaffManagement({ currentUserId }: StaffManagementProps) {
  const [staff, setStaff] = useState<StaffMember[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [searchResults, setSearchResults] = useState<Profile[]>([])
  const [searching, setSearching] = useState(false)
  const [showAddModal, setShowAddModal] = useState(false)
  const [selectedUser, setSelectedUser] = useState<Profile | null>(null)
  const [newRole, setNewRole] = useState<'admin' | 'moderator' | 'custom'>('moderator')
  const [selectedPerms, setSelectedPerms] = useState<string[]>([])
  const [newNotes, setNewNotes] = useState('')
  const [editingStaff, setEditingStaff] = useState<StaffMember | null>(null)
  const [confirmRemove, setConfirmRemove] = useState<StaffMember | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const list = await fetchStaffMembers()
      setStaff(list)
    } catch (e: any) {
      toast.error(e.message || 'فشل تحميل الفريق')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { void load() }, [load])

  // بحث المستخدمين لإضافتهم كموظفين
  const searchUsers = useCallback(async (q: string) => {
    if (!q || q.length < 2) {
      setSearchResults([])
      return
    }
    setSearching(true)
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .or(`username.ilike.%${q}%,display_name.ilike.%${q}%`)
        .limit(10)
      if (error) throw error
      // استبعاد الموظفين الحاليين
      const existingIds = new Set(staff.map((s) => s.user_id))
      const filtered = (data || []).filter((p: any) =>
        !existingIds.has(p.id) && p.id !== currentUserId && p.username !== 'kemetnet'
      )
      setSearchResults(filtered as Profile[])
    } catch (e: any) {
      toast.error('فشل البحث')
    } finally {
      setSearching(false)
    }
  }, [staff, currentUserId])

  // تطبيق preset عند تغيير الدور
  const applyRolePreset = (role: 'admin' | 'moderator' | 'custom') => {
    setNewRole(role)
    if (role === 'admin') {
      setSelectedPerms(ROLE_PRESETS.admin.permissions)
    } else if (role === 'moderator') {
      setSelectedPerms(ROLE_PRESETS.moderator.permissions)
    } else {
      setSelectedPerms([])
    }
  }

  const togglePerm = (perm: Permission) => {
    setSelectedPerms((prev) =>
      prev.includes(perm)
        ? prev.filter((p) => p !== perm)
        : [...prev, perm]
    )
  }

  const handleAddStaff = async () => {
    if (!selectedUser) return
    if (newRole === 'custom' && selectedPerms.length === 0) {
      toast.error('اختر صلاحية واحدة على الأقل')
      return
    }
    try {
      await addStaffMember(selectedUser.id, newRole, selectedPerms, newNotes)
      toast.success(`تمت إضافة @${selectedUser.username} للفريق`)
      setShowAddModal(false)
      setSelectedUser(null)
      setNewNotes('')
      setSelectedPerms([])
      setNewRole('moderator')
      await load()
    } catch (e: any) {
      toast.error(e.message || 'فشلت الإضافة')
    }
  }

  const handleUpdateStaff = async () => {
    if (!editingStaff) return
    try {
      await updateStaffPermissions(editingStaff.user_id, selectedPerms, {
        newRole: newRole,
        newNotes: newNotes || undefined,
      })
      toast.success('تم تحديث صلاحيات الموظف')
      setEditingStaff(null)
      setSelectedPerms([])
      setNewNotes('')
      setNewRole('moderator')
      await load()
    } catch (e: any) {
      toast.error(e.message || 'فشل التحديث')
    }
  }

  const handleToggleActive = async (member: StaffMember) => {
    try {
      await updateStaffPermissions(member.user_id, member.permissions, {
        newActive: !member.active,
      })
      toast.success(member.active ? 'تم تعطيل الموظف' : 'تم تفعيل الموظف')
      await load()
    } catch (e: any) {
      toast.error(e.message || 'فشل التحديث')
    }
  }

  const handleRemove = async () => {
    if (!confirmRemove) return
    try {
      await removeStaffMember(confirmRemove.user_id)
      toast.success(`تمت إزالة @${confirmRemove.profile?.username || 'الموظف'}`)
      setConfirmRemove(null)
      await load()
    } catch (e: any) {
      toast.error(e.message || 'فشلت الإزالة')
    }
  }

  // فتح modal تعديل صلاحيات موظف موجود
  const openEditModal = (member: StaffMember) => {
    setEditingStaff(member)
    setNewRole(member.role as 'admin' | 'moderator' | 'custom')
    setSelectedPerms(member.permissions || [])
    setNewNotes(member.notes || '')
  }

  // فتح modal إضافة موظف جديد
  const openAddModal = () => {
    setShowAddModal(true)
    setSelectedUser(null)
    setNewRole('moderator')
    setSelectedPerms(ROLE_PRESETS.moderator.permissions)
    setNewNotes('')
    setSearch('')
    setSearchResults([])
  }

  const closeModal = () => {
    setShowAddModal(false)
    setEditingStaff(null)
    setSelectedUser(null)
    setSelectedPerms([])
    setNewNotes('')
  }

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <Loader2 className="w-6 h-6 text-amber-500 animate-spin mb-3" />
        <p className="text-xs text-muted-foreground">جارٍ تحميل الفريق...</p>
      </div>
    )
  }

  return (
    <div className="w-full px-3 py-4 space-y-3">
      <div className="flex items-center justify-between">
        <h2 className="font-display text-lg font-bold">
          الفريق <span className="text-sm text-muted-foreground font-normal">({staff.length})</span>
        </h2>
        <div className="flex items-center gap-1.5">
          <button
            onClick={openAddModal}
            className="px-3 py-1.5 rounded-lg mishri-gradient-primary text-white text-xs font-bold flex items-center gap-1.5 mishri-press"
          >
            <UserPlus className="w-3.5 h-3.5" />
            إضافة موظف
          </button>
          <button onClick={load} className="p-1.5 rounded-lg hover:bg-foreground/5">
            <RefreshCw className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>
      </div>

      {/* قائمة الموظفين */}
      {staff.length === 0 ? (
        <div className="rounded-2xl border border-foreground/8 bg-foreground/[0.02] p-6 text-center">
          <UserCog className="w-10 h-10 text-muted-foreground/50 mx-auto mb-3" />
          <p className="text-sm text-muted-foreground">لا يوجد موظفون بعد</p>
          <p className="text-xs text-muted-foreground/70 mt-1">
            أضِف موظفين للمساعدة في إدارة التطبيق
          </p>
        </div>
      ) : (
        <div className="space-y-2">
          {staff.map((member) => (
            <div
              key={member.id}
              className={`rounded-2xl border p-3 ${
                member.active
                  ? 'border-foreground/8 bg-foreground/[0.02]'
                  : 'border-foreground/8 bg-foreground/[0.02] opacity-60'
              }`}
            >
              <div className="flex items-start gap-2.5 mb-2">
                <div
                  className="w-9 h-9 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0"
                  style={{
                    background: `linear-gradient(135deg, ${member.profile?.avatar_color || '#1F4E8C'}, ${member.profile?.avatar_color || '#0E2A4F'}aa)`,
                  }}
                >
                  {(member.profile?.display_name || member.profile?.username || '؟').charAt(0).toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold truncate">
                      @{member.profile?.username || 'محذوف'}
                    </span>
                    <RoleBadge role={member.role} />
                    {!member.active && (
                      <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-foreground/10 text-muted-foreground">
                        معطّل
                      </span>
                    )}
                  </div>
                  <div className="text-[10px] text-muted-foreground mt-0.5">
                    انضم {new Date(member.added_at).toLocaleDateString('ar-EG')}
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => openEditModal(member)}
                    className="p-1.5 rounded-lg bg-foreground/5 hover:bg-foreground/10"
                    aria-label="تعديل الصلاحيات"
                  >
                    <Edit3 className="w-3 h-3" />
                  </button>
                  <button
                    onClick={() => handleToggleActive(member)}
                    className="p-1.5 rounded-lg bg-foreground/5 hover:bg-foreground/10"
                    aria-label={member.active ? 'تعطيل' : 'تفعيل'}
                  >
                    {member.active
                      ? <EyeOff className="w-3 h-3" />
                      : <Eye className="w-3 h-3" />}
                  </button>
                  <button
                    onClick={() => setConfirmRemove(member)}
                    className="p-1.5 rounded-lg bg-rose-500/10 text-rose-500 hover:bg-rose-500/20"
                    aria-label="إزالة"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              </div>

              {/* الصلاحيات */}
              <div className="flex flex-wrap gap-1 mt-2">
                {(member.permissions || []).length === 0 ? (
                  <span className="text-[10px] text-muted-foreground">لا توجد صلاحيات محددة</span>
                ) : (
                  (member.permissions || []).map((permId) => {
                    const perm = ALL_PERMISSIONS.find((p) => p.id === permId)
                    if (!perm) return null
                    return (
                      <span
                        key={permId}
                        className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-amber-500/10 text-amber-700 dark:text-amber-300"
                      >
                        {perm.icon} {perm.label}
                      </span>
                    )
                  })
                )}
              </div>

              {member.notes && (
                <p className="text-[10px] text-muted-foreground mt-2 bg-foreground/5 rounded-lg p-2">
                  {member.notes}
                </p>
              )}
            </div>
          ))}
        </div>
      )}

      {/* تنبيه المالك */}
      <div className="rounded-2xl border border-amber-500/20 bg-amber-500/5 p-3">
        <div className="flex items-start gap-2">
          <Crown className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
          <div className="text-[11px] leading-relaxed">
            <p className="font-bold text-amber-700 dark:text-amber-300 mb-1">
              مالك التطبيق
            </p>
            <p className="text-muted-foreground">
              أنت المالك (@kemetnet) — لديك كل الصلاحيات. يمكنك إضافة موظفين وإعطاء كل واحد صلاحيات محددة حسب دوره.
            </p>
          </div>
        </div>
      </div>

      {/* Modal: إضافة موظف */}
      {showAddModal && (
        <StaffModal
          title="إضافة موظف جديد"
          subtitle="اختر المستخدم والصلاحيات"
          onClose={closeModal}
          onConfirm={handleAddStaff}
          confirmLabel="إضافة للفريق"
        >
          {/* البحث عن مستخدم */}
          {!selectedUser ? (
            <div className="space-y-3">
              <div className="relative">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => {
                    setSearch(e.target.value)
                    void searchUsers(e.target.value)
                  }}
                  placeholder="ابحث باليوزرنيم..."
                  className="mishri-input w-full rounded-xl py-2.5 pr-9 pl-3 text-sm outline-none"
                  autoFocus
                />
              </div>

              {searching && (
                <div className="flex items-center justify-center py-4">
                  <Loader2 className="w-5 h-5 text-amber-500 animate-spin" />
                </div>
              )}

              {!searching && searchResults.length > 0 && (
                <div className="space-y-1.5 max-h-60 overflow-y-auto">
                  {searchResults.map((user) => (
                    <button
                      key={user.id}
                      onClick={() => setSelectedUser(user)}
                      className="w-full flex items-center gap-2.5 p-2.5 rounded-xl bg-foreground/5 hover:bg-foreground/10 text-right"
                    >
                      <div
                        className="w-8 h-8 rounded-full flex items-center justify-center text-white text-[10px] font-bold"
                        style={{
                          background: `linear-gradient(135deg, ${user.avatar_color || '#1F4E8C'}, ${user.avatar_color || '#0E2A4F'}aa)`,
                        }}
                      >
                        {(user.display_name || user.username || '؟').charAt(0).toUpperCase()}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-xs font-bold truncate">@{user.username}</div>
                        {user.display_name && (
                          <div className="text-[10px] text-muted-foreground truncate">
                            {user.display_name}
                          </div>
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              )}

              {!searching && search.length >= 2 && searchResults.length === 0 && (
                <p className="text-center text-xs text-muted-foreground py-4">
                  لا توجد نتائج
                </p>
              )}
            </div>
          ) : (
            <PermissionsEditor
              user={selectedUser}
              role={newRole}
              onRoleChange={applyRolePreset}
              selectedPerms={selectedPerms}
              onTogglePerm={togglePerm}
              notes={newNotes}
              onNotesChange={setNewNotes}
            />
          )}
        </StaffModal>
      )}

      {/* Modal: تعديل صلاحيات موظف */}
      {editingStaff && (
        <StaffModal
          title={`تعديل صلاحيات @${editingStaff.profile?.username || 'الموظف'}`}
          subtitle="عدّل الصلاحيات والدور"
          onClose={closeModal}
          onConfirm={handleUpdateStaff}
          confirmLabel="حفظ التغييرات"
        >
          <PermissionsEditor
            user={editingStaff.profile || null}
            role={newRole}
            onRoleChange={applyRolePreset}
            selectedPerms={selectedPerms}
            onTogglePerm={togglePerm}
            notes={newNotes}
            onNotesChange={setNewNotes}
          />
        </StaffModal>
      )}

      {/* Modal: تأكيد الإزالة */}
      {confirmRemove && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-6" onClick={() => setConfirmRemove(null)}>
          <div className="bg-background rounded-3xl p-5 max-w-sm w-full" onClick={(e) => e.stopPropagation()}>
            <div className="w-12 h-12 rounded-2xl bg-rose-500/10 flex items-center justify-center mb-3">
              <AlertCircle className="w-6 h-6 text-rose-500" />
            </div>
            <h3 className="font-display text-base font-bold mb-2">
              إزالة @{confirmRemove.profile?.username || 'الموظف'}؟
            </h3>
            <p className="text-xs text-muted-foreground mb-4 leading-relaxed">
              سيفقد الموظف كل صلاحياته ولن يتمكن من الوصول للوحة الإدارة. يمكن إضافته مجددًا لاحقًا.
            </p>
            <div className="flex gap-2">
              <button
                onClick={() => setConfirmRemove(null)}
                className="flex-1 py-2.5 rounded-xl bg-foreground/5 text-xs font-bold"
              >
                إلغاء
              </button>
              <button
                onClick={handleRemove}
                className="flex-1 py-2.5 rounded-xl bg-rose-500 text-white text-xs font-bold hover:bg-rose-600"
              >
                إزالة نهائية
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// ============================================================
// شارة الدور
// ============================================================
function RoleBadge({ role }: { role: string }) {
  const config: Record<string, { label: string; color: string; icon: typeof Shield }> = {
    admin: { label: 'مدير عام', color: 'bg-blue-500/15 text-blue-600', icon: ShieldCheck },
    moderator: { label: 'مشرف', color: 'bg-emerald-500/15 text-emerald-600', icon: Shield },
    custom: { label: 'مخصص', color: 'bg-amber-500/15 text-amber-600', icon: UserCog },
  }
  const c = config[role] || config.custom
  const Icon = c.icon
  return (
    <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold flex items-center gap-0.5 ${c.color}`}>
      <Icon className="w-2.5 h-2.5" />
      {c.label}
    </span>
  )
}

// ============================================================
// Modal wrapper
// ============================================================
function StaffModal({
  title, subtitle, onClose, onConfirm, confirmLabel, children,
}: {
  title: string
  subtitle: string
  onClose: () => void
  onConfirm: () => void
  confirmLabel: string
  children: React.ReactNode
}) {
  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-background rounded-3xl max-w-md w-full max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="sticky top-0 bg-background/95 backdrop-blur-xl border-b border-foreground/8 p-4 flex items-center justify-between">
          <div>
            <h3 className="font-display text-base font-bold">{title}</h3>
            <p className="text-[10px] text-muted-foreground">{subtitle}</p>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-foreground/5">
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="p-4 space-y-4">
          {children}
          <div className="flex gap-2 pt-2">
            <button
              onClick={onClose}
              className="flex-1 py-2.5 rounded-xl bg-foreground/5 text-xs font-bold"
            >
              إلغاء
            </button>
            <button
              onClick={onConfirm}
              className="flex-1 py-2.5 rounded-xl mishri-gradient-primary text-white text-xs font-bold mishri-press"
            >
              {confirmLabel}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

// ============================================================
// محرر الصلاحيات
// ============================================================
function PermissionsEditor({
  user, role, onRoleChange, selectedPerms, onTogglePerm, notes, onNotesChange,
}: {
  user: Profile | null
  role: 'admin' | 'moderator' | 'custom'
  onRoleChange: (role: 'admin' | 'moderator' | 'custom') => void
  selectedPerms: string[]
  onTogglePerm: (perm: Permission) => void
  notes: string
  onNotesChange: (notes: string) => void
}) {
  return (
    <div className="space-y-4">
      {/* المستخدم المختار */}
      {user && (
        <div className="flex items-center gap-2.5 p-2.5 rounded-xl bg-foreground/5">
          <div
            className="w-10 h-10 rounded-full flex items-center justify-center text-white text-xs font-bold"
            style={{
              background: `linear-gradient(135deg, ${user.avatar_color || '#1F4E8C'}, ${user.avatar_color || '#0E2A4F'}aa)`,
            }}
          >
            {(user.display_name || user.username || '؟').charAt(0).toUpperCase()}
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-xs font-bold truncate">@{user.username}</div>
            {user.display_name && (
              <div className="text-[10px] text-muted-foreground truncate">{user.display_name}</div>
            )}
          </div>
        </div>
      )}

      {/* اختيار الدور (preset) */}
      <div>
        <label className="text-xs font-bold text-muted-foreground mb-2 block">الدور</label>
        <div className="grid grid-cols-3 gap-1.5">
          {([
            { id: 'admin', label: 'مدير عام', desc: 'صلاحيات شاملة' },
            { id: 'moderator', label: 'مشرف', desc: 'إشراف محتوى' },
            { id: 'custom', label: 'مخصص', desc: 'اختر يدويًا' },
          ] as const).map((r) => (
            <button
              key={r.id}
              onClick={() => onRoleChange(r.id)}
              className={`p-2.5 rounded-xl text-center transition-all ${
                role === r.id
                  ? 'mishri-gradient-primary text-white'
                  : 'bg-foreground/5 text-muted-foreground hover:bg-foreground/10'
              }`}
            >
              <div className="text-xs font-bold">{r.label}</div>
              <div className="text-[9px] mt-0.5 opacity-80">{r.desc}</div>
            </button>
          ))}
        </div>
      </div>

      {/* الصلاحيات التفصيلية */}
      <div>
        <label className="text-xs font-bold text-muted-foreground mb-2 block">
          الصلاحيات ({selectedPerms.length})
        </label>
        <div className="space-y-1.5 max-h-72 overflow-y-auto">
          {ALL_PERMISSIONS.map((perm) => {
            const isChecked = selectedPerms.includes(perm.id)
            return (
              <button
                key={perm.id}
                onClick={() => onTogglePerm(perm.id)}
                className={`w-full flex items-start gap-2.5 p-2.5 rounded-xl text-right transition-all ${
                  isChecked
                    ? 'bg-amber-500/10 border border-amber-500/30'
                    : 'bg-foreground/5 border border-transparent hover:bg-foreground/10'
                }`}
              >
                <div className={`w-5 h-5 rounded-md flex items-center justify-center flex-shrink-0 mt-0.5 ${
                  isChecked ? 'bg-amber-500 text-white' : 'bg-foreground/10'
                }`}>
                  {isChecked && <Check className="w-3 h-3" />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-bold flex items-center gap-1">
                    <span>{perm.icon}</span>
                    {perm.label}
                  </div>
                  <div className="text-[10px] text-muted-foreground mt-0.5">
                    {perm.description}
                  </div>
                </div>
              </button>
            )
          })}
        </div>
      </div>

      {/* ملاحظات */}
      <div>
        <label className="text-xs font-bold text-muted-foreground mb-1.5 block">
          ملاحظات (اختياري)
        </label>
        <textarea
          value={notes}
          onChange={(e) => onNotesChange(e.target.value)}
          rows={2}
          placeholder="مثال: مسؤول عن مراجعة البلاغات اليوم..."
          className="mishri-input w-full rounded-xl p-2.5 text-xs outline-none resize-none"
        />
      </div>
    </div>
  )
}
