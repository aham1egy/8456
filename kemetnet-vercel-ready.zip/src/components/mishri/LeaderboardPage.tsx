'use client'

import { useState, useEffect, useCallback } from 'react'
import { useRouter } from 'next/navigation'
import { Trophy, Crown, Medal, ArrowLeft, Loader2, Sparkles, TrendingUp } from 'lucide-react'
import { fetchTopUsers } from '@/lib/reputation'
import { getLevelColor, getLevelTitle, calculateLevel } from '@/lib/reputation'
import { VerifiedBadgeMini } from './VerifiedBadge'
import type { Profile } from '@/lib/supabase/client'

interface LeaderboardUser {
 id: string
 username: string
 display_name: string | null
 avatar_url: string | null
 avatar_color: string | null
 reputation_points: number
 reputation_level: number
 is_verified: boolean
 verified_type: 'official' | 'business' | 'creator' | 'early_adopter' | null
}

type Period = 'all' | 'weekly' | 'monthly'

export function LeaderboardPage() {
 const router = useRouter()
 const [users, setUsers] = useState<LeaderboardUser[]>([])
 const [loading, setLoading] = useState(true)
 const [period, setPeriod] = useState<Period>('all')

 const loadLeaderboard = useCallback(async () => {
 setLoading(true)
 const result = await fetchTopUsers(50)
 setUsers(result as LeaderboardUser[])
 setLoading(false)
 }, [])

 useEffect(() => {
 void loadLeaderboard()
 }, [loadLeaderboard])

 const top3 = users.slice(0, 3)
 const rest = users.slice(3)

 return (
 <div className="flex flex-col flex-1 min-h-0">
 {/* الرأس */}
 <header className="flex-shrink-0 bg-background/80 backdrop-blur-xl safe-top z-40">
 <div className="max-w-md mx-auto px-4 py-3 flex items-center gap-3">
 <button
 onClick={() => router.back()}
 className="p-2 rounded-full hover:bg-foreground/5 mishri-press"
 aria-label="رجوع"
 >
 <ArrowLeft className="w-4 h-4" />
 </button>
 <h1 className="font-display text-lg font-bold flex-1">المتصدرون</h1>
 <Trophy className="w-5 h-5 text-amber-500" />
 </div>

 {/* تبويبات الفترة */}
 <div className="max-w-md mx-auto px-4 pb-3">
 <div className="flex bg-foreground/5 rounded-xl p-1">
 <PeriodTab active={period === 'all'} onClick={() => setPeriod('all')} label="الكل" />
 <PeriodTab active={period === 'weekly'} onClick={() => setPeriod('weekly')} label="هذا الأسبوع" />
 <PeriodTab active={period === 'monthly'} onClick={() => setPeriod('monthly')} label="هذا الشهر" />
 </div>
 </div>
 </header>

 <div data-scroll-area className="flex-1 overflow-y-auto overscroll-y-contain">
 <main className="max-w-md mx-auto px-4 pt-4 pb-6">
 {loading ? (
 <div className="flex flex-col items-center justify-center py-20">
 <Loader2 className="w-8 h-8 text-amber-500 animate-spin mb-3" />
 <p className="text-xs text-muted-foreground">جارٍ تحميل المتصدرين...</p>
 </div>
 ) : users.length === 0 ? (
 <div className="text-center py-20">
 <div className="w-16 h-16 mx-auto mb-3 rounded-2xl bg-foreground/5 flex items-center justify-center">
 <Trophy className="w-8 h-8 text-muted-foreground/50" />
 </div>
 <p className="text-sm font-semibold mb-1">لا يوجد متصدرين بعد</p>
 <p className="text-xs text-muted-foreground">كن أول من يتصدر القائمة!</p>
 </div>
 ) : (
 <>
 {/* منصة التتويج - أعلى 3 */}
 {top3.length > 0 && (
 <div
 className="flex items-end justify-center gap-2 mb-6 mt-4 transition-colors duration-200"
 >
 {/* المركز الثاني */}
 {top3[1] && (
 <PodiumCard user={top3[1]} rank={2} />
 )}
 {/* المركز الأول */}
 {top3[0] && (
 <PodiumCard user={top3[0]} rank={1} />
 )}
 {/* المركز الثالث */}
 {top3[2] && (
 <PodiumCard user={top3[2]} rank={3} />
 )}
 </div>
 )}

 {/* بقية القائمة */}
 {rest.length > 0 && (
 <div className="space-y-2">
 <div className="flex items-center gap-1.5 mb-3 px-2">
 <TrendingUp className="w-3.5 h-3.5 text-muted-foreground" />
 <span className="text-[11px] font-bold text-muted-foreground">المزيد</span>
 </div>
 {rest.map((user, i) => {
 const rank = i + 4
 const level = user.reputation_level || 1
 const color = getLevelColor(level)
 return (
 <button
 key={user.id}
 onClick={() => router.push(`/profile/${user.username}`)}
 className="w-full rounded-2xl bg-foreground/5 p-3 flex items-center gap-3 text-right mishri-press mishri-hover-lift transition-colors duration-200"
 >
 {/* الترتيب */}
 <div className="w-7 h-7 rounded-lg bg-foreground/5 flex items-center justify-center flex-shrink-0">
 <span className="text-xs font-bold text-muted-foreground tabular-nums">{rank}</span>
 </div>

 {/* الصورة */}
 {user.avatar_url ? (
 <img
 src={user.avatar_url}
 alt={user.display_name || user.username}
 className="w-10 h-10 rounded-xl object-cover flex-shrink-0"
 />
 ) : (
 <div
 className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold text-sm flex-shrink-0"
 style={{
 background: `linear-gradient(135deg, ${user.avatar_color || '#FBBF24'} 0%, ${user.avatar_color || '#FBBF24'}aa 100%)`,
 }}
 >
 {(user.display_name || user.username || '؟').charAt(0).toUpperCase()}
 </div>
 )}

 {/* المعلومات */}
 <div className="flex-1 min-w-0">
 <div className="text-sm font-bold truncate flex items-center gap-1">
 <span className="truncate">{user.display_name || user.username}</span>
 {user.is_verified && <VerifiedBadgeMini type={user.verified_type} />}
 </div>
 <div className="text-[11px] text-muted-foreground flex items-center gap-1.5">
 <span dir="ltr">@{user.username}</span>
 <span>·</span>
 <span style={{ color }}>{getLevelTitle(level)}</span>
 </div>
 </div>

 {/* النقاط */}
 <div className="text-left flex-shrink-0">
 <div className="flex items-center gap-0.5 text-amber-500 font-bold text-sm">
 <Sparkles className="w-3 h-3" />
 <span className="tabular-nums">{(user.reputation_points || 0).toLocaleString('ar-EG')}</span>
 </div>
 <div className="text-[9px] text-muted-foreground">
 مستوى {level}
 </div>
 </div>
 </button>
 )
 })}
 </div>
 )}

 {/* معلومة */}
 <div className="mt-6 rounded-2xl bg-foreground/5 p-4 flex items-start gap-3">
 <Trophy className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
 <div className="text-[11px] text-muted-foreground leading-relaxed">
 تُحسب النقاط بناءً على نشاطك في المنصة: المنشورات، الإعجابات، التعليقات، المتابعين، والمزيد. كلما تفاعلت أكثر، ارتفع مستواك!
 </div>
 </div>
 </>
 )}
 </main>
 </div>
 </div>
 )
}

// ========================================
// مكون: بطاقة المنصة (Podium)
// ========================================

function PodiumCard({ user, rank }: { user: LeaderboardUser; rank: number }) {
 const router = useRouter()
 const level = user.reputation_level || 1
 const color = getLevelColor(level)

 const config = {
 1: { height: 'h-28', crown: '👑', medal: '#FBBF24', label: 'الأول', icon: Crown },
 2: { height: 'h-24', crown: '🥈', medal: '#9CA3AF', label: 'الثاني', icon: Medal },
 3: { height: 'h-20', crown: '🥉', medal: '#D97706', label: 'الثالث', icon: Medal },
 }[rank] as { height: string; crown: string; medal: string; label: string; icon: typeof Crown }

 return (
 <button
 onClick={() => router.push(`/profile/${user.username}`)}
 className="flex flex-col items-center mishri-press transition-colors duration-200"
 >
 {/* التاج */}
 <div className="text-2xl mb-1">{config.crown}</div>

 {/* الصورة */}
 <div className="relative">
 {user.avatar_url ? (
 <img
 src={user.avatar_url}
 alt={user.display_name || user.username}
 className={`w-16 h-16 rounded-2xl object-cover border-2 ${rank === 1 ? 'w-20 h-20' : ''}`}
 style={{ borderColor: config.medal }}
 />
 ) : (
 <div
 className={`rounded-2xl flex items-center justify-center text-white font-bold text-2xl border-2 ${rank === 1 ? 'w-20 h-20' : 'w-16 h-16'}`}
 style={{
 background: `linear-gradient(135deg, ${user.avatar_color || '#FBBF24'} 0%, ${user.avatar_color || '#FBBF24'}aa 100%)`,
 borderColor: config.medal,
 }}
 >
 {(user.display_name || user.username || '؟').charAt(0).toUpperCase()}
 </div>
 )}
 {/* شارة التحقق */}
 {user.is_verified && (
 <div className="absolute -bottom-1 -right-1">
 <VerifiedBadgeMini type={user.verified_type} />
 </div>
 )}
 </div>

 {/* الاسم */}
 <div className="text-xs font-bold mt-1.5 max-w-[80px] truncate text-center">
 {user.display_name || user.username}
 </div>

 {/* المنصة */}
 <div
 className={`${config.height} w-16 mt-2 rounded-t-xl flex flex-col items-center justify-start pt-2 relative overflow-hidden`}
 style={{
 background: `linear-gradient(180deg, ${config.medal}40 0%, ${config.medal}10 100%)`,
 }}
 >
 {/* رقم الترتيب */}
 <div className="text-2xl font-bold" style={{ color: config.medal }}>
 {rank}
 </div>
 {/* النقاط */}
 <div className="text-[10px] font-bold text-amber-500 tabular-nums mt-0.5">
 {(user.reputation_points || 0).toLocaleString('ar-EG')}
 </div>
 <div className="text-[9px] text-muted-foreground">نقطة</div>
 </div>
 </button>
 )
}

// ========================================
// مكون: تبويب الفترة
// ========================================

function PeriodTab({
 active,
 onClick,
 label,
}: {
 active: boolean
 onClick: () => void
 label: string
}) {
 return (
 <button
 onClick={onClick}
 className={`flex-1 py-1.5 rounded-lg text-xs font-semibold transition-all ${
 active ? 'bg-white dark:bg-white/10 text-amber-500 shadow-sm' : 'text-muted-foreground'
 }`}
 >
 {label}
 </button>
 )
}
