'use client'

import { useState, useEffect } from 'react'
import { TrendingUp, ChevronDown, ChevronUp, Star, Zap, Award } from 'lucide-react'
import {
 fetchReputationLog,
 getReputationInfo,
 getLevelTitle,
 getLevelColor,
 ACTIVITY_LABELS,
 ACTIVITY_ICONS,
 type ReputationLogEntry,
} from '@/lib/reputation'
import type { Profile } from '@/lib/supabase/client'

interface ReputationPanelProps {
 profile: Profile
}

export function ReputationPanel({ profile }: ReputationPanelProps) {
 const [log, setLog] = useState<ReputationLogEntry[]>([])
 const [loading, setLoading] = useState(true)
 const [expanded, setExpanded] = useState(false)

 const info = getReputationInfo(
 profile.reputation_points || 0,
 profile.reputation_level || 1,
 profile.total_earned_points || 0
 )

 useEffect(() => {
 let cancelled = false
 void (async () => {
 setLoading(true)
 const result = await fetchReputationLog(profile.id, 10)
 if (!cancelled) {
 setLog(result)
 setLoading(false)
 }
 })()
 return () => {
 cancelled = true
 }
 }, [profile.id])

 const levelColor = getLevelColor(info.level)
 const levelTitle = getLevelTitle(info.level)

 return (
 <div className="rounded-2xl bg-foreground/5 p-4 ">
 {/* الرأس */}
 <div className="flex items-center justify-between mb-3">
 <div className="flex items-center gap-2">
 <div
 className="w-8 h-8 rounded-xl flex items-center justify-center"
 style={{ background: `${levelColor}20` }}
 >
 <Award className="w-4 h-4" style={{ color: levelColor }} />
 </div>
 <h3 className="font-bold text-sm">السمعة</h3>
 </div>
 <button
 onClick={() => setExpanded(!expanded)}
 className="p-1.5 rounded-full hover:bg-foreground/5 transition-colors"
 aria-label={expanded ? 'طي' : 'توسيع'}
 >
 {expanded ? (
 <ChevronUp className="w-4 h-4 text-muted-foreground" />
 ) : (
 <ChevronDown className="w-4 h-4 text-muted-foreground" />
 )}
 </button>
 </div>

 {/* المستوى + النقاط */}
 <div className="flex items-center gap-3 mb-3">
 {/* رقم المستوى */}
 <div
 className="w-14 h-14 rounded-2xl flex flex-col items-center justify-center text-white font-bold"
 style={{
 background: `linear-gradient(135deg, ${levelColor} 0%, ${levelColor}aa 100%)`,
 }}
 >
 <span className="text-[9px] opacity-90">المستوى</span>
 <span className="text-xl leading-none">{info.level}</span>
 </div>

 {/* النقاط + اللقب */}
 <div className="flex-1 min-w-0">
 <div className="font-bold text-sm" style={{ color: levelColor }}>
 {levelTitle}
 </div>
 <div className="flex items-center gap-1.5 mt-0.5">
 <Zap className="w-3 h-3 text-amber-500" fill="#FBBF24" />
 <span className="text-xs font-bold tabular-nums">
 {info.currentPoints.toLocaleString('ar-EG')} نقطة
 </span>
 </div>
 {info.totalEarned > info.currentPoints && (
 <div className="text-[10px] text-muted-foreground mt-0.5">
 إجمالي مكتسب: {info.totalEarned.toLocaleString('ar-EG')}
 </div>
 )}
 </div>
 </div>

 {/* شريط التقدم للمستوى التالي */}
 <div className="mb-3">
 <div className="flex items-center justify-between mb-1">
 <span className="text-[10px] text-muted-foreground">
 المستوى {info.level + 1}
 </span>
 <span className="text-[10px] font-bold tabular-nums" style={{ color: levelColor }}>
 {info.progressPercent}%
 </span>
 </div>
 <div className="h-2 bg-foreground/5 rounded-full overflow-hidden">
 <div
 style={{ width: `${info.progressPercent}%`, background: `linear-gradient(90deg, ${levelColor}, ${levelColor}cc)` }}
 className="h-full rounded-full relative overflow-hidden transition-all duration-300 mishri-shine"
 />
 </div>
 <div className="text-[10px] text-muted-foreground mt-1 text-center">
 تحتاج {info.pointsToNextLevel.toLocaleString('ar-EG')} نقطة للمستوى التالي
 </div>
 </div>

 {/* السجل القابل للطي */}
 {expanded && (
 <div
 className="overflow-hidden transition-all duration-200"
 >
 <div className="border-t border-foreground/5 pt-3">
 <div className="flex items-center gap-1.5 mb-2">
 <TrendingUp className="w-3.5 h-3.5 text-muted-foreground" />
 <span className="text-[11px] font-bold text-muted-foreground">آخر النقاط المكتسبة</span>
 </div>

 {loading ? (
 <div className="space-y-2">
 {Array.from({ length: 3 }).map((_, i) => (
 <div key={i} className="h-10 mishri-shimmer rounded-xl" />
 ))}
 </div>
 ) : log.length === 0 ? (
 <p className="text-[11px] text-muted-foreground text-center py-3">
 لا توجد نقاط بعد. ابدأ بالتفاعل لاكتساب النقاط!
 </p>
 ) : (
 <div className="space-y-1.5 max-h-48 overflow-y-auto">
 {log.map((entry) => (
 <div
 key={entry.id}
 className="flex items-center gap-2 p-2 rounded-xl bg-foreground/5 transition-colors duration-200"
 >
 <span className="text-base flex-shrink-0">
 {ACTIVITY_ICONS[entry.activity_type]}
 </span>
 <div className="flex-1 min-w-0">
 <div className="text-xs font-semibold truncate">
 {ACTIVITY_LABELS[entry.activity_type]}
 </div>
 <div className="text-[9px] text-muted-foreground">
 {new Date(entry.created_at).toLocaleDateString('ar-EG', {
 month: 'short',
 day: 'numeric',
 })}{' '}
 ·{' '}
 {new Date(entry.created_at).toLocaleTimeString('ar-EG', {
 hour: '2-digit',
 minute: '2-digit',
 })}
 </div>
 </div>
 <div className="flex items-center gap-0.5 text-amber-500 font-bold text-xs flex-shrink-0">
 <span>+</span>
 <span className="tabular-nums">{entry.points_earned}</span>
 </div>
 </div>
 ))}
 </div>
 )}
 </div>
 </div>
 )}
 </div>
 )
}
