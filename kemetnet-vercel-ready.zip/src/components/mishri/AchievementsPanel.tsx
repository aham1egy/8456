'use client'

import { useState, useEffect } from 'react'
import { ChevronDown, ChevronUp, Lock, Check, Loader2, Award } from 'lucide-react'
import {
 fetchAllAchievements,
 fetchUserAchievements,
 TIER_CONFIG,
 CATEGORY_LABELS,
 type Achievement,
 type UserAchievement,
 type AchievementCategory,
} from '@/lib/achievements'

interface AchievementsPanelProps {
 userId: string
 isOwnProfile: boolean
}

export function AchievementsPanel({ userId, isOwnProfile }: AchievementsPanelProps) {
 const [allAchievements, setAllAchievements] = useState<Achievement[]>([])
 const [userAchievements, setUserAchievements] = useState<UserAchievement[]>([])
 const [loading, setLoading] = useState(true)
 const [expanded, setExpanded] = useState(false)
 const [activeCategory, setActiveCategory] = useState<AchievementCategory | 'all'>('all')

 useEffect(() => {
 let cancelled = false
 void (async () => {
 setLoading(true)
 const [all, user] = await Promise.all([
 fetchAllAchievements(),
 fetchUserAchievements(userId),
 ])
 if (!cancelled) {
 setAllAchievements(all)
 setUserAchievements(user)
 setLoading(false)
 }
 })()
 return () => {
 cancelled = true
 }
 }, [userId])

 // دمج البيانات
 const userMap = new Map(userAchievements.map((ua) => [ua.achievement_slug, ua]))
 const merged = allAchievements.map((a) => ({
 ...a,
 userAchievement: userMap.get(a.slug),
 }))

 const completedCount = merged.filter((m) => m.userAchievement?.completed).length
 const totalCount = merged.length

 const filtered = activeCategory === 'all'
 ? merged
 : merged.filter((m) => m.category === activeCategory)

 const categories: (AchievementCategory | 'all')[] = ['all', 'posts', 'social', 'engagement', 'milestone', 'special']

 return (
 <div className="rounded-2xl bg-foreground/5 p-4 ">
 {/* الرأس */}
 <div className="flex items-center justify-between mb-3">
 <div className="flex items-center gap-2">
 <div className="w-8 h-8 rounded-xl bg-amber-500/15 flex items-center justify-center">
 <Award className="w-4 h-4 text-amber-500" />
 </div>
 <div>
 <h3 className="font-bold text-sm">الإنجازات</h3>
 <p className="text-[10px] text-muted-foreground">
 {completedCount} / {totalCount} مكتمل
 </p>
 </div>
 </div>
 <button
 onClick={() => setExpanded(!expanded)}
 className="p-1.5 rounded-full hover:bg-foreground/5 transition-colors"
 aria-label={expanded ? 'طي' : 'توسيع'}
 >
 {expanded ? (
 <ChevronUp className="w-4 h-4 text-muted-foreground" />
 ) : (
 <ChevronDown className="w-4 h-4 text-muted-foreground" />
 )}
 </button>
 </div>

 {/* شريط التقدم */}
 <div className="mb-3">
 <div className="flex items-center justify-between mb-1">
 <span className="text-[10px] text-muted-foreground">التقدم الكلي</span>
 <span className="text-[10px] font-bold text-amber-500 tabular-nums">
 {Math.round((completedCount / Math.max(totalCount, 1)) * 100)}%
 </span>
 </div>
 <div className="h-2 bg-foreground/5 rounded-full overflow-hidden">
 <div
 style={{ width: `${(completedCount / Math.max(totalCount, 1)) * 100}%` }}
 className="h-full rounded-full mishri-gradient-primary relative overflow-hidden transition-all duration-300 mishri-shine"
 />
 </div>
 </div>

 {/* عرض الإنجازات المكتملة (مختصر) */}
 {!expanded && (
 <div className="flex flex-wrap gap-1.5">
 {merged
 .filter((m) => m.userAchievement?.completed)
 .slice(0, 8)
 .map((m) => (
 <div
 key={m.slug}
 className="w-9 h-9 rounded-xl flex items-center justify-center text-base relative hover:scale-110 transition-colors duration-200"
 style={{ background: `${m.color}20` }}
 title={`${m.name} - ${m.description}`}
 >
 {m.icon}
 <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-emerald-500 border border-background flex items-center justify-center">
 <Check className="w-2 h-2 text-white" strokeWidth={3} />
 </div>
 </div>
 ))}
 {completedCount > 8 && (
 <div className="w-9 h-9 rounded-xl bg-foreground/5 flex items-center justify-center text-[10px] font-bold text-muted-foreground">
 +{completedCount - 8}
 </div>
 )}
 </div>
 )}

 {/* العرض المفصّل */}
 {expanded && (
 <div
 className="overflow-hidden transition-all duration-200"
 >
 {/* فلاتر الفئات */}
 <div className="flex gap-1.5 overflow-x-auto pb-2 mb-3">
 {categories.map((cat) => (
 <button
 key={cat}
 onClick={() => setActiveCategory(cat)}
 className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
 activeCategory === cat
 ? 'mishri-gradient-primary text-white shadow-sm'
 : 'bg-foreground/5 text-muted-foreground hover:bg-foreground/10'
 }`}
 >
 {cat === 'all' ? 'الكل' : CATEGORY_LABELS[cat as AchievementCategory]}
 </button>
 ))}
 </div>

 {/* قائمة الإنجازات */}
 {loading ? (
 <div className="flex justify-center py-6">
 <Loader2 className="w-6 h-6 text-amber-500 animate-spin" />
 </div>
 ) : (
 <div className="space-y-2 max-h-[40vh] overflow-y-auto">
 {filtered.map((achievement, i) => {
 const tierConfig = TIER_CONFIG[achievement.tier]
 const userAch = achievement.userAchievement
 const completed = userAch?.completed || false
 const progress = userAch?.progress || 0
 const target = achievement.target_value
 const progressPercent = target
 ? Math.min(100, Math.round((progress / target) * 100))
 : completed ? 100 : 0

 return (
 <div
 key={achievement.slug}
 className={`rounded-2xl p-3 transition-colors duration-200 ${
 completed
 ? 'bg-emerald-500/5 border border-emerald-500/20'
 : 'bg-foreground/5 border border-transparent'
 }`}
 >
 <div className="flex items-center gap-3">
 {/* الأيقونة */}
 <div
 className={`w-10 h-10 rounded-xl flex items-center justify-center text-lg flex-shrink-0 ${
 completed ? '' : 'grayscale opacity-50'
 }`}
 style={{ background: `${achievement.color}20` }}
 >
 {achievement.icon}
 </div>

 {/* المعلومات */}
 <div className="flex-1 min-w-0">
 <div className="flex items-center gap-1.5">
 <span className="text-xs font-bold truncate">{achievement.name}</span>
 <span
 className="text-[9px] px-1.5 py-0.5 rounded-full font-bold flex-shrink-0"
 style={{ background: `${tierConfig.color}20`, color: tierConfig.color }}
 >
 {tierConfig.label}
 </span>
 </div>
 <p className="text-[10px] text-muted-foreground truncate">
 {achievement.description}
 </p>

 {/* شريط التقدم */}
 {target && (
 <div className="mt-1.5">
 <div className="flex items-center justify-between mb-0.5">
 <div className="h-1 w-16 bg-foreground/10 rounded-full overflow-hidden">
 <div
 style={{ width: `${progressPercent}%` }}
 className={`h-full rounded-full transition-all duration-300 ${completed ? 'bg-emerald-500' : 'mishri-gradient-primary'}`}
 />
 </div>
 <span className="text-[9px] text-muted-foreground tabular-nums">
 {progress} / {target}
 </span>
 </div>
 </div>
 )}
 </div>

 {/* المكافأة */}
 <div className="text-center flex-shrink-0">
 {completed ? (
 <div className="w-7 h-7 rounded-full bg-emerald-500 flex items-center justify-center">
 <Check className="w-4 h-4 text-white" strokeWidth={3} />
 </div>
 ) : (
 <div className="flex flex-col items-center">
 <span className="text-[9px] text-muted-foreground">مكافأة</span>
 <span className="text-xs font-bold text-amber-500 tabular-nums">
 +{achievement.points_reward}
 </span>
 </div>
 )}
 </div>
 </div>
 </div>
 )
 })}
 </div>
 )}
 </div>
 )}
 </div>
 )
}
