'use client'

import { useState, useEffect } from 'react'
import { TrendingUp, Award, Calendar, Heart, MessageCircle, Sparkles, ChevronDown, ChevronUp } from 'lucide-react'
import { fetchUserStats, getCategoryLabel, type UserStats } from '@/lib/stats'
import { CATEGORIES } from '@/lib/supabase/client'

interface StatsPanelProps {
 userId: string
}

export function StatsPanel({ userId }: StatsPanelProps) {
 const [stats, setStats] = useState<UserStats | null>(null)
 const [loading, setLoading] = useState(true)
 const [expanded, setExpanded] = useState(false)

 useEffect(() => {
 let cancelled = false
 void (async () => {
 setLoading(true)
 const result = await fetchUserStats(userId)
 if (!cancelled) {
 setStats(result)
 setLoading(false)
 }
 })()
 return () => {
 cancelled = true
 }
 }, [userId])

 if (loading) {
 return (
 <div className="rounded-2xl bg-foreground/5 p-4">
 <div className="h-6 w-32 mishri-shimmer rounded-lg mb-3" />
 <div className="grid grid-cols-3 gap-2">
 {Array.from({ length: 3 }).map((_, i) => (
 <div key={i} className="h-16 mishri-shimmer rounded-xl" />
 ))}
 </div>
 </div>
 )
 }

 if (!stats || stats.totalPosts === 0) {
 return (
 <div className="rounded-2xl bg-foreground/5 p-4 text-center">
 <div className="w-10 h-10 mx-auto mb-2 rounded-xl bg-foreground/5 flex items-center justify-center">
 <Sparkles className="w-5 h-5 text-muted-foreground" />
 </div>
 <p className="text-xs text-muted-foreground">لا توجد إحصائيات بعد</p>
 </div>
 )
 }

 const maxActivity = Math.max(
 ...stats.activityLast7Days.map((d) => d.posts + d.likes / 5),
 1
 )

 return (
 <div className="rounded-2xl bg-foreground/5 p-4 ">
 {/* الرأس */}
 <div className="flex items-center justify-between mb-3">
 <div className="flex items-center gap-2">
 <div className="w-8 h-8 rounded-xl mishri-gradient-primary flex items-center justify-center">
 <TrendingUp className="w-4 h-4 text-white" />
 </div>
 <h3 className="font-bold text-sm">إحصائيات النشاط</h3>
 </div>
 <button
 onClick={() => setExpanded(!expanded)}
 className="p-1.5 rounded-full hover:bg-foreground/5 transition-colors"
 aria-label={expanded ? 'طي' : 'توسيع'}
 >
 {expanded ? (
 <ChevronUp className="w-4 h-4 text-muted-foreground" />
 ) : (
 <ChevronDown className="w-4 h-4 text-muted-foreground" />
 )}
 </button>
 </div>

 {/* البطاقات الأساسية */}
 <div className="grid grid-cols-3 gap-2 mb-3">
 <StatCard
 icon={<Heart className="w-3.5 h-3.5" />}
 label="إعجابات"
 value={stats.totalLikes}
 color="#FB7185"
 />
 <StatCard
 icon={<MessageCircle className="w-3.5 h-3.5" />}
 label="تعليقات"
 value={stats.totalComments}
 color="#60A5FA"
 />
 <StatCard
 icon={<Award className="w-3.5 h-3.5" />}
 label="تفاعل"
 value={stats.engagementRate}
 color="#FBBF24"
 suffix="/منشور"
 />
 </div>

 {/* التفاصيل القابلة للطي */}
 {expanded && (
 <div
 className="overflow-hidden transition-all duration-200"
 >
 {/* النشاط آخر 7 أيام */}
 <div className="mb-4">
 <div className="flex items-center gap-1.5 mb-2">
 <Calendar className="w-3.5 h-3.5 text-muted-foreground" />
 <span className="text-[11px] font-bold text-muted-foreground">آخر 7 أيام</span>
 </div>
 <div className="flex items-end justify-between h-20 gap-1.5">
 {stats.activityLast7Days.map((day, i) => {
 const total = day.posts + day.likes / 5
 const height = (total / maxActivity) * 100
 return (
 <div key={i} className="flex-1 flex flex-col items-center gap-1">
 <div className="w-full flex-1 flex items-end">
 <div
 style={{
 height: `${Math.max(height, 5)}%`,
 minHeight: total > 0 ? '4px' : '0',
 opacity: total > 0 ? 1 : 0.3,
 }}
 className="w-full rounded-t-md mishri-gradient-primary transition-all duration-300"
 />
 </div>
 <span className="text-[9px] text-muted-foreground">
 {day.day.slice(0, 3)}
 </span>
 </div>
 )
 })}
 </div>
 </div>

 {/* توزيع الفئات */}
 {stats.categoryDistribution.length > 0 && (
 <div>
 <div className="flex items-center gap-1.5 mb-2">
 <Sparkles className="w-3.5 h-3.5 text-muted-foreground" />
 <span className="text-[11px] font-bold text-muted-foreground">توزيع الفئات</span>
 </div>
 <div className="space-y-2">
 {stats.categoryDistribution.map((cat) => {
 const percentage = (cat.count / stats.totalPosts) * 100
 return (
 <div key={cat.category} className="flex items-center gap-2">
 <span className="text-[10px] font-semibold w-12 flex-shrink-0">
 {getCategoryLabel(cat.category)}
 </span>
 <div className="flex-1 h-2 bg-foreground/5 rounded-full overflow-hidden">
 <div
 style={{ width: `${percentage}%`, background: cat.color }}
 className="h-full rounded-full transition-all duration-300"
 />
 </div>
 <span className="text-[10px] text-muted-foreground w-8 text-left tabular-nums">
 {cat.count}
 </span>
 </div>
 )
 })}
 </div>
 </div>
 )}

 {/* أكثر فئة */}
 {stats.topCategory && (
 <div className="mt-3 p-2.5 rounded-xl bg-amber-500/10 flex items-center gap-2">
 <Award className="w-4 h-4 text-amber-500 flex-shrink-0" />
 <div className="flex-1">
 <div className="text-[11px] font-bold">الفئة المفضلة</div>
 <div className="text-[10px] text-muted-foreground">
 {getCategoryLabel(stats.topCategory.category)} ({stats.topCategory.count} منشور)
 </div>
 </div>
 </div>
 )}
 </div>
 )}
 </div>
 )
}

function StatCard({
 icon,
 label,
 value,
 color,
 suffix,
}: {
 icon: React.ReactNode
 label: string
 value: number
 color: string
 suffix?: string
}) {
 return (
 <div className="rounded-2xl bg-foreground/5 p-2.5 text-center">
 <div
 className="w-6 h-6 mx-auto mb-1 rounded-lg flex items-center justify-center"
 style={{ background: `${color}20`, color }}
 >
 {icon}
 </div>
 <div className="text-sm font-bold tabular-nums">{value.toLocaleString('ar-EG')}</div>
 <div className="text-[9px] text-muted-foreground">
 {label}
 {suffix && <span className="opacity-70"> {suffix}</span>}
 </div>
 </div>
 )
}
