'use client'

import { useEffect, useState } from 'react'
import { AlertTriangle, RefreshCw, WifiOff } from 'lucide-react'

interface UseErrorHandlerResult {
  hasError: boolean
  error: Error | null
  reset: () => void
}

/**
 * Hook للتعامل مع الأخطاء غير المتوقعة
 */
export function useErrorHandler(): UseErrorHandlerResult {
  const [hasError, setHasError] = useState(false)
  const [error, setError] = useState<Error | null>(null)

  useEffect(() => {
    const handler = (event: ErrorEvent) => {
      console.error('Caught error:', event.error)
      setHasError(true)
      setError(event.error || new Error(event.message))
    }
    window.addEventListener('error', handler)
    return () => window.removeEventListener('error', handler)
  }, [])

  const reset = () => {
    setHasError(false)
    setError(null)
  }

  return { hasError, error, reset }
}

/**
 * Hook لمراقبة حالة الاتصال
 */
export function useOnlineStatus(): boolean {
  const [isOnline, setIsOnline] = useState(true)

  useEffect(() => {
    const updateStatus = () => setIsOnline(navigator.onLine)
    updateStatus()
    window.addEventListener('online', updateStatus)
    window.addEventListener('offline', updateStatus)
    return () => {
      window.removeEventListener('online', updateStatus)
      window.removeEventListener('offline', updateStatus)
    }
  }, [])

  return isOnline
}

/**
 * Hook لتحسين الـ images مع lazy loading و fallback
 */
export function useOptimizedImage(src: string | null | undefined) {
  const [loaded, setLoaded] = useState(false)
  const [error, setError] = useState(false)

  useEffect(() => {
    setLoaded(false)
    setError(false)
    if (!src) return
    const img = new Image()
    img.src = src
    img.onload = () => setLoaded(true)
    img.onerror = () => setError(true)
  }, [src])

  return { loaded, error }
}

/**
 * Hook للكشف عن ضعف الأداء
 */
export function usePerformanceMonitor() {
  useEffect(() => {
    if (typeof window === 'undefined') return
    if (!('performance' in window)) return

    // قياس وقت تحميل الصفحة
    const measurePageLoad = () => {
      const nav = performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming | undefined
      if (nav) {
        const loadTime = nav.loadEventEnd - nav.loadEventStart
        if (loadTime > 3000) {
          // removed console output
        }
      }
    }

    // قياس بعد تحميل الصفحة
    if (document.readyState === 'complete') {
      measurePageLoad()
    } else {
      window.addEventListener('load', measurePageLoad)
      return () => window.removeEventListener('load', measurePageLoad)
    }
  }, [])
}

/**
 * Hook للكشف عن المستخدمين الذين يستخدمون extensions مشبوهة
 */
export function useSecurityCheck(): { suspicious: boolean; reasons: string[] } {
  const [suspicious, setSuspicious] = useState(false)
  const [reasons, setReasons] = useState<string[]>([])

  useEffect(() => {
    if (typeof window === 'undefined') return

    const checks: string[] = []
    // فحص autopilot / devtools
    if ((window as any).webdriver) checks.push('automation detected')
    // فحص headless browser
    if (!navigator.plugins || navigator.plugins.length === 0) {
      // ليس بالضرورة مشبوه — لكن نتجاهل
    }
    // فحص حجم النافذة (headless عادةً صغيرة)
    if (window.outerWidth < 100 || window.outerHeight < 100) {
      checks.push('suspicious window size')
    }

    setSuspicious(checks.length > 0)
    setReasons(checks)
  }, [])

  return { suspicious, reasons }
}

/**
 * مكون عرض حالة الاتصال
 */
export function OfflineBanner() {
  const isOnline = useOnlineStatus()
  if (isOnline) return null

  return (
    <div className="fixed top-0 left-0 right-0 z-[100] bg-rose-500 text-white px-4 py-2 flex items-center justify-center gap-2 text-sm font-bold">
      <WifiOff className="w-4 h-4" />
      لا يوجد اتصال بالإنترنت
    </div>
  )
}

/**
 * مكون زر إعادة المحاولة
 */
export function RetryButton({ onRetry, label = 'إعادة المحاولة' }: { onRetry: () => void; label?: string }) {
  return (
    <button
      onClick={onRetry}
      className="px-4 py-2 rounded-xl mishri-gradient-primary text-white text-sm font-bold flex items-center gap-2 mishri-press"
    >
      <RefreshCw className="w-4 h-4" />
      {label}
    </button>
  )
}

/**
 * مكون حالة فارغة محسنة
 */
export function EnhancedEmptyState({
  icon: Icon,
  title,
  description,
  action,
}: {
  icon: React.ComponentType<{ className?: string }>
  title: string
  description?: string
  action?: React.ReactNode
}) {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-6">
      <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-amber-500/10 to-blue-500/10 flex items-center justify-center mb-4">
        <Icon className="w-10 h-10 text-muted-foreground" />
      </div>
      <h3 className="font-display text-lg font-bold mb-1">{title}</h3>
      {description && (
        <p className="text-xs text-muted-foreground text-center max-w-xs">{description}</p>
      )}
      {action && <div className="mt-4">{action}</div>}
    </div>
  )
}

/**
 * مكون حالة خطأ
 */
export function ErrorState({
  title = 'حدث خطأ',
  description = 'يرجى المحاولة مرة أخرى',
  onRetry,
}: {
  title?: string
  description?: string
  onRetry?: () => void
}) {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-6">
      <div className="w-16 h-16 rounded-2xl bg-rose-500/10 flex items-center justify-center mb-4">
        <AlertTriangle className="w-8 h-8 text-rose-500" />
      </div>
      <h3 className="font-display text-base font-bold mb-1">{title}</h3>
      <p className="text-xs text-muted-foreground text-center mb-4">{description}</p>
      {onRetry && <RetryButton onRetry={onRetry} />}
    </div>
  )
}
