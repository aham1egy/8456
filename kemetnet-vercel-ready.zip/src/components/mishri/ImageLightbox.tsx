'use client'

import { useState, useEffect, useCallback } from 'react'
import { X, ZoomIn, ZoomOut, RotateCw } from 'lucide-react'

interface ImageLightboxProps {
  src: string | null
  alt?: string
  onClose: () => void
}

/**
 * عارض صور بملء الشاشة — Lightbox
 * - يفتح عند النقر على صورة منشور
 * - دعم التكبير/التصغير (pinch/double-tap)
 * - دعم التدوير
 * - إغلاق بالنقر خارج الصورة أو زر X
 * - منع تمرير الخلفية
 */
export function ImageLightbox({ src, alt = 'صورة', onClose }: ImageLightboxProps) {
  const [scale, setScale] = useState(1)
  const [rotation, setRotation] = useState(0)
  const [translate, setTranslate] = useState({ x: 0, y: 0 })
  const [startTouch, setStartTouch] = useState<{ x: number; y: number } | null>(null)
  const [lastTap, setLastTap] = useState(0)

  // منع تمرير الخلفية
  useEffect(() => {
    document.body.style.overflow = 'hidden'
    return () => {
      document.body.style.overflow = ''
    }
  }, [])

  // إغلاق بمفتاح Escape
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [onClose])

  // إعادة تعيين عند فتح صورة جديدة
  useEffect(() => {
    setScale(1)
    setRotation(0)
    setTranslate({ x: 0, y: 0 })
  }, [src])

  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      const now = Date.now()
      // double-tap to zoom
      if (now - lastTap < 300) {
        setScale((s) => (s === 1 ? 2.5 : 1))
        setTranslate({ x: 0, y: 0 })
      }
      setLastTap(now)
      setStartTouch({ x: e.touches[0].clientX, y: e.touches[0].clientY })
    }
  }, [lastTap])

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (scale > 1 && startTouch && e.touches.length === 1) {
      const dx = e.touches[0].clientX - startTouch.x
      const dy = e.touches[0].clientY - startTouch.y
      setTranslate({ x: dx, y: dy })
    }
  }, [scale, startTouch])

  const handleTouchEnd = useCallback(() => {
    setStartTouch(null)
  }, [])

  if (!src) return null

  return (
    <div
      className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-sm flex items-center justify-center"
      onClick={onClose}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {/* زر الإغلاق */}
      <button
        onClick={onClose}
        className="absolute top-4 right-4 z-10 w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
        aria-label="إغلاق"
      >
        <X className="w-5 h-5 text-white" />
      </button>

      {/* أدوات التحكم */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-10 flex items-center gap-2 bg-white/10 backdrop-blur-md rounded-2xl px-3 py-2">
        <button
          onClick={(e) => {
            e.stopPropagation()
            setScale((s) => Math.max(1, s - 0.5))
            if (scale <= 1.5) setTranslate({ x: 0, y: 0 })
          }}
          className="w-9 h-9 rounded-full hover:bg-white/20 flex items-center justify-center"
          aria-label="تصغير"
        >
          <ZoomOut className="w-4 h-4 text-white" />
        </button>
        <span className="text-white text-xs font-bold tabular-nums w-10 text-center">
          {Math.round(scale * 100)}%
        </span>
        <button
          onClick={(e) => {
            e.stopPropagation()
            setScale((s) => Math.min(5, s + 0.5))
          }}
          className="w-9 h-9 rounded-full hover:bg-white/20 flex items-center justify-center"
          aria-label="تكبير"
        >
          <ZoomIn className="w-4 h-4 text-white" />
        </button>
        <div className="w-px h-6 bg-white/20 mx-1" />
        <button
          onClick={(e) => {
            e.stopPropagation()
            setRotation((r) => r + 90)
          }}
          className="w-9 h-9 rounded-full hover:bg-white/20 flex items-center justify-center"
          aria-label="تدوير"
        >
          <RotateCw className="w-4 h-4 text-white" />
        </button>
      </div>

      {/* الصورة */}
      <img
        src={src}
        alt={alt}
        onClick={(e) => e.stopPropagation()}
        className="max-w-full max-h-full object-contain transition-transform duration-200 select-none"
        style={{
          transform: `translate(${translate.x}px, ${translate.y}px) scale(${scale}) rotate(${rotation}deg)`,
          cursor: scale > 1 ? 'grab' : 'pointer',
        }}
        draggable={false}
      />
    </div>
  )
}

// Hook لإدارة حالة الـ lightbox
export function useImageLightbox() {
  const [lightboxSrc, setLightboxSrc] = useState<string | null>(null)

  const openLightbox = useCallback((src: string) => {
    setLightboxSrc(src)
  }, [])

  const closeLightbox = useCallback(() => {
    setLightboxSrc(null)
  }, [])

  return {
    lightboxSrc,
    openLightbox,
    closeLightbox,
    Lightbox: (
      <ImageLightbox src={lightboxSrc} onClose={closeLightbox} />
    ),
  }
}
