'use client'

import { useState, useEffect, useCallback } from 'react'
import { useRouter } from 'next/navigation'
import { Bell, Heart, MessageCircle, UserPlus, AtSign, CheckCheck, Settings2, BellOff } from 'lucide-react'
import { useAppStore } from '@/store/app-store'
import { useNotificationSound } from '@/hooks/use-sound'
import { supabase } from '@/lib/supabase/client'
import { toast } from 'sonner'

interface NotificationItem {
 id: string
 type: 'like' | 'comment' | 'follow' | 'mention' | 'comment_mention' | 'comment_like' | 'reply' | 'system'
 title: string
 body: string | null
 actor_id: string | null
 actor_name?: string | null
 actor_color?: string | null
 post_id: string | null
 read: boolean
 created_at: string
}

export function NotificationsPage() {
 const user = useAppStore((s) => s.user)
 const setUnreadNotifications = useAppStore((s) => s.setUnreadNotifications)
 const router = useRouter()
 const { playSound } = useNotificationSound()

 const [notifications, setNotifications] = useState<NotificationItem[]>([])
 const [filter, setFilter] = useState<'all' | 'unread' | 'likes' | 'comments' | 'mentions' | 'follows'>('all')
 const [loading, setLoading] = useState(true)

 // مسح عداد الإشعارات عند الدخول للصفحة
 useEffect(() => {
 setUnreadNotifications(0)
 }, [setUnreadNotifications])

 // جلب الإشعارات من قاعدة البيانات
 const fetchNotifications = useCallback(async () => {
 if (!user) {
 setLoading(false)
 return
 }
 setLoading(true)
 try {
 const { data, error } = await supabase
 .from('notifications')
 .select('id, type, title, body, actor_id, post_id, read, created_at')
 .eq('user_id', user.id)
 .order('created_at', { ascending: false })
 .limit(50)

 if (!error && data) {
 // جلب معلومات الـ actors بشكل منفصل
 const actorIds = Array.from(new Set(data.map((n) => n.actor_id).filter((id): id is string => id !== null)))
 let actorsMap: Record<string, { display_name: string | null; avatar_color: string | null; username: string | null }> = {}

 if (actorIds.length > 0) {
 const { data: actorsData, error: actorsError } = await supabase
 .from('profiles')
 .select('id, display_name, avatar_color, username')
 .in('id', actorIds)

 if (!actorsError && actorsData) {
 actorsMap = Object.fromEntries(actorsData.map((a) => [a.id, a]))
 }
 }

 const items: NotificationItem[] = data.map((n) => {
 const actor = n.actor_id ? actorsMap[n.actor_id] : null
 return {
 id: n.id,
 type: n.type,
 title: n.title,
 body: n.body,
 actor_id: n.actor_id,
 actor_name: actor?.display_name || actor?.username || null,
 actor_color: actor?.avatar_color || null,
 post_id: n.post_id,
 read: n.read,
 created_at: n.created_at,
 }
 })
 setNotifications(items)
 } else {
 // لا توجد بيانات أو خطأ - عرض قائمة فارغة
 setNotifications([])
 }
 } catch (e) {
 // [removed in production] 'Fetch notifications error:', e
 setNotifications([])
 } finally {
 setLoading(false)
 }
 }, [user])

 useEffect(() => {
 void fetchNotifications()
 }, [fetchNotifications])

 // الاستماع لإشعارات realtime جديدة
 useEffect(() => {
 if (!user) return

 const channel = supabase
 .channel('notifications-list-realtime')
 .on(
 'postgres_changes',
 {
 event: 'INSERT',
 schema: 'public',
 table: 'notifications',
 filter: `user_id=eq.${user.id}`,
 },
 () => {
 // إعادة جلب القائمة عند وصول إشعار جديد
 void fetchNotifications()
 }
 )
 .on(
 'postgres_changes',
 {
 event: 'UPDATE',
 schema: 'public',
 table: 'notifications',
 filter: `user_id=eq.${user.id}`,
 },
 () => {
 void fetchNotifications()
 }
 )
 .subscribe()

 return () => {
 void supabase.removeChannel(channel)
 }
 }, [user, fetchNotifications])

 const markAsRead = useCallback(async (id: string) => {
 // تحديث متفائل
 setNotifications((prev) =>
 prev.map((n) => (n.id === id ? { ...n, read: true } : n))
 )

 // محاولة التحديث في DB
 if (user) {
 const { error } = await supabase
 .from('notifications')
 .update({ read: true })
 .eq('id', id)
 .eq('user_id', user.id)

 if (error && !error.message.includes('Could not find')) {
 // [removed in production] 'Mark as read error:', error
 }
 }

 playSound('notification')
 }, [user, playSound])

 const markAllAsRead = useCallback(async () => {
 setNotifications((prev) => prev.map((n) => ({ ...n, read: true })))

 if (user) {
 const { error } = await supabase
 .from('notifications')
 .update({ read: true })
 .eq('user_id', user.id)
 .eq('read', false)

 if (error && !error.message.includes('Could not find')) {
 // [removed in production] 'Mark all as read error:', error
 }
 }

 playSound('success')
 toast.success('تم تعليم الكل كمقروء')
 }, [user, playSound])

 const filtered = (() => {
 switch (filter) {
 case 'unread':
 return notifications.filter((n) => !n.read)
 case 'likes':
 return notifications.filter((n) => n.type === 'like')
 case 'comments':
 return notifications.filter((n) => n.type === 'comment' || n.type === 'comment_mention')
 case 'mentions':
 return notifications.filter((n) => n.type === 'mention' || n.type === 'comment_mention')
 case 'follows':
 return notifications.filter((n) => n.type === 'follow')
 default:
 return notifications
 }
 })()

 // عدّادات لكل نوع
 const counts = {
 all: notifications.length,
 unread: notifications.filter((n) => !n.read).length,
 likes: notifications.filter((n) => n.type === 'like').length,
 comments: notifications.filter((n) => n.type === 'comment' || n.type === 'comment_mention').length,
 mentions: notifications.filter((n) => n.type === 'mention' || n.type === 'comment_mention').length,
 follows: notifications.filter((n) => n.type === 'follow').length,
 }

 return (
 <div className="flex flex-col flex-1 min-h-0">
 <header className="flex-shrink-0 border-b border-foreground/8 bg-background/80 backdrop-blur-xl z-40" style={{ paddingTop: 'env(safe-area-inset-top, 0px)' }}>
 <div className="max-w-md mx-auto px-4 py-2">
 <div className="flex items-center justify-between mb-2">
 <h1 className="font-display text-xl font-bold mishri-gradient-text">الإشعارات</h1>
 {counts.unread > 0 && (
 <button
 onClick={markAllAsRead}
 className="text-xs font-semibold text-amber-500 flex items-center gap-1"
 >
 <CheckCheck className="w-3.5 h-3.5" />
 تعليم الكل
 </button>
 )}
 </div>
 {/* فلاتر التصنيف - قابلة للتمرير */}
 <div className="flex gap-1.5 overflow-x-auto pb-1 mishri-scrollbar-hide">
 <FilterChip
 active={filter === 'all'}
 onClick={() => setFilter('all')}
 label="الكل"
 count={counts.all}
 />
 <FilterChip
 active={filter === 'unread'}
 onClick={() => setFilter('unread')}
 label="غير مقروء"
 count={counts.unread}
 highlight={counts.unread > 0}
 />
 <FilterChip
 active={filter === 'likes'}
 onClick={() => setFilter('likes')}
 label="إعجابات"
 count={counts.likes}
 icon={<Heart className="w-3 h-3" />}
 />
 <FilterChip
 active={filter === 'comments'}
 onClick={() => setFilter('comments')}
 label="تعليقات"
 count={counts.comments}
 icon={<MessageCircle className="w-3 h-3" />}
 />
 <FilterChip
 active={filter === 'mentions'}
 onClick={() => setFilter('mentions')}
 label="إشارات"
 count={counts.mentions}
 icon={<AtSign className="w-3 h-3" />}
 />
 <FilterChip
 active={filter === 'follows'}
 onClick={() => setFilter('follows')}
 label="متابعات"
 count={counts.follows}
 icon={<UserPlus className="w-3 h-3" />}
 />
 </div>
 </div>
 </header>

 <div data-scroll-area className="flex-1 overflow-y-auto overscroll-y-contain">
 <main className="max-w-md mx-auto px-4 pt-4 pb-4 space-y-2">
 {loading ? (
 <div className="space-y-2">
 {Array.from({ length: 4 }).map((_, i) => (
 <div key={i} className="rounded-2xl bg-foreground/5 p-3 h-16 mishri-shimmer" />
 ))}
 </div>
 ) : filtered.length === 0 ? (
 <div className="text-center py-16">
 <div className="w-16 h-16 mx-auto mb-4 rounded-2xl rounded-xl bg-foreground/5 flex items-center justify-center">
 <BellOff className="w-7 h-7 text-muted-foreground" />
 </div>
 <h3 className="font-bold text-sm mb-1">لا توجد إشعارات</h3>
 <p className="text-xs text-muted-foreground">
 {filter === 'unread' ? 'لا توجد إشعارات غير مقروءة' : 'ستظهر الإشعارات هنا فور وصولها'}
 </p>
 </div>
 ) : (
 <>
 {filtered.map((n, i) => (
 <div
 key={n.id}
 onClick={() => {
 if (!n.read) markAsRead(n.id)
 }}
 className={`rounded-2xl bg-foreground/5 p-3 flex items-start gap-3 cursor-pointer mishri-press transition-colors duration-200 ${
 !n.read ? 'border-r-2 border-amber-500' : ''
 }`}
 >
 {/* أيقونة النوع */}
 <div
 className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
 style={{ background: `${getNotifColor(n.type)}20`, color: getNotifColor(n.type) }}
 >
 {n.actor_name ? (
 <span
 className="text-sm font-bold"
 style={{ color: n.actor_color || getNotifColor(n.type) }}
 >
 {n.actor_name.charAt(0)}
 </span>
 ) : (
 getNotifIcon(n.type)
 )}
 </div>

 <div className="flex-1 min-w-0">
 <div className="flex items-baseline justify-between gap-2">
 <span className="text-sm font-bold truncate">{n.title}</span>
 <span className="text-[10px] text-muted-foreground whitespace-nowrap">
 {getTimeAgo(n.created_at)}
 </span>
 </div>
 {n.body && (
 <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{n.body}</p>
 )}
 </div>

 {!n.read && (
 <span className="w-2 h-2 rounded-full bg-amber-500 flex-shrink-0 mt-2 mishri-pulse" />
 )}
 </div>
 ))}
 </>
 )}

 {/* زر الإعدادات */}
 <button
 onClick={() => router.push('/settings')}
 className="w-full mt-6 py-3 rounded-2xl rounded-xl bg-foreground/5 text-sm font-semibold text-muted-foreground flex items-center justify-center gap-2 mishri-press"
 >
 <Settings2 className="w-4 h-4" />
 إعدادات الإشعارات
 </button>
 </main>
 </div>
 </div>
 )
}

function getNotifIcon(type: NotificationItem['type']) {
 const icons = {
 like: <Heart className="w-5 h-5" />,
 comment: <MessageCircle className="w-5 h-5" />,
 follow: <UserPlus className="w-5 h-5" />,
 mention: <AtSign className="w-5 h-5" />,
 system: <Bell className="w-5 h-5" />,
 }
 return icons[type]
}

function getNotifColor(type: NotificationItem['type']): string {
 const colors = {
 like: '#FB7185',
 comment: '#60A5FA',
 follow: '#34D399',
 mention: '#FBBF24',
 system: '#A78BFA',
 }
 return colors[type]
}

function getTimeAgo(dateStr: string): string {
 const date = new Date(dateStr)
 const now = new Date()
 const diff = (now.getTime() - date.getTime()) / 1000
 if (diff < 60) return 'الآن'
 if (diff < 3600) return `${Math.floor(diff / 60)} د`
 if (diff < 86400) return `${Math.floor(diff / 3600)} س`
 if (diff < 604800) return `${Math.floor(diff / 86400)} ي`
 return `${Math.floor(diff / 604800)} أ`
}

// ========================================
// مكون: شريط فلترة مصغر
// ========================================
function FilterChip({
 active,
 onClick,
 label,
 count,
 icon,
 highlight,
}: {
 active: boolean
 onClick: () => void
 label: string
 count: number
 icon?: React.ReactNode
 highlight?: boolean
}) {
 return (
 <button
 onClick={onClick}
 className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all mishri-press flex-shrink-0 ${
 active
 ? 'mishri-gradient-primary text-white shadow-sm'
 : highlight
 ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400'
 : 'bg-foreground/5 text-muted-foreground hover:bg-foreground/10'
 }`}
 >
 {icon}
 <span>{label}</span>
 {count > 0 && (
 <span
 className={`text-[10px] tabular-nums ${
 active ? 'opacity-90' : 'opacity-60'
 }`}
 >
 ({count})
 </span>
 )}
 </button>
 )
}
