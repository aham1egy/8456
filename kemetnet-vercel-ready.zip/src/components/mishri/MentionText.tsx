'use client'

import { useRouter } from 'next/navigation'
import { parseMentions } from '@/lib/mentions'

interface MentionTextProps {
 text: string
 className?: string
 mentionClassName?: string
}

/**
 * عرض نص مع إبراز الإشارات @username
 * الإشارات قابلة للنقر وتنقل لملف المستخدم
 */
export function MentionText({
 text,
 className = '',
 mentionClassName = '',
}: MentionTextProps) {
 const router = useRouter()
 const segments = parseMentions(text)

 return (
 <span className={className}>
 {segments.map((seg, i) => {
 if (seg.type === 'mention' && seg.username) {
 return (
 <button
 key={i}
 onClick={(e) => {
 e.stopPropagation()
 e.preventDefault()
 router.push(`/profile/${seg.username}`)
 }}
 className={`text-amber-500 hover:text-amber-600 dark:text-amber-300 dark:hover:text-amber-200 font-semibold cursor-pointer hover:underline ${mentionClassName}`}
 dir="ltr"
 >
 {seg.content}
 </button>
 )
 }
 return <span key={i}>{seg.content}</span>
 })}
 </span>
 )
}
