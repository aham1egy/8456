'use client'

/**
 * مكونات Skeleton للتحميل التدريجي
 * تظهر أثناء تحميل البيانات لتحسين UX
 */

export function PostCardSkeleton() {
  return (
    <div className="rounded-2xl bg-card border border-foreground/5 overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-2.5 p-3">
        <div className="w-9 h-9 rounded-full bg-foreground/10 mishri-shimmer" />
        <div className="flex-1 space-y-1">
          <div className="h-3 w-24 rounded bg-foreground/10 mishri-shimmer" />
          <div className="h-2 w-16 rounded bg-foreground/5 mishri-shimmer" />
        </div>
        <div className="w-6 h-6 rounded-full bg-foreground/5 mishri-shimmer" />
      </div>
      {/* Content */}
      <div className="px-3 pb-3 space-y-2">
        <div className="h-3 w-full rounded bg-foreground/10 mishri-shimmer" />
        <div className="h-3 w-4/5 rounded bg-foreground/10 mishri-shimmer" />
        <div className="h-3 w-3/5 rounded bg-foreground/10 mishri-shimmer" />
      </div>
      {/* Image placeholder */}
      <div className="aspect-square w-full bg-foreground/5 mishri-shimmer" />
      {/* Actions */}
      <div className="flex items-center justify-between p-3">
        <div className="flex items-center gap-4">
          <div className="w-5 h-5 rounded bg-foreground/10 mishri-shimmer" />
          <div className="w-5 h-5 rounded bg-foreground/10 mishri-shimmer" />
          <div className="w-5 h-5 rounded bg-foreground/10 mishri-shimmer" />
        </div>
        <div className="w-5 h-5 rounded bg-foreground/10 mishri-shimmer" />
      </div>
    </div>
  )
}

export function UserCardSkeleton() {
  return (
    <div className="flex items-center gap-2.5 p-2.5 rounded-2xl bg-foreground/[0.02]">
      <div className="w-9 h-9 rounded-full bg-foreground/10 mishri-shimmer" />
      <div className="flex-1 space-y-1">
        <div className="h-3 w-24 rounded bg-foreground/10 mishri-shimmer" />
        <div className="h-2 w-16 rounded bg-foreground/5 mishri-shimmer" />
      </div>
      <div className="w-16 h-7 rounded-xl bg-foreground/10 mishri-shimmer" />
    </div>
  )
}

export function NotificationSkeleton() {
  return (
    <div className="flex items-center gap-2.5 p-3 rounded-2xl bg-foreground/[0.02]">
      <div className="w-9 h-9 rounded-full bg-foreground/10 mishri-shimmer" />
      <div className="flex-1 space-y-1">
        <div className="h-3 w-3/4 rounded bg-foreground/10 mishri-shimmer" />
        <div className="h-2 w-1/4 rounded bg-foreground/5 mishri-shimmer" />
      </div>
    </div>
  )
}

export function MessageSkeleton() {
  return (
    <div className="flex items-center gap-2 px-4 py-2">
      <div className="w-8 h-8 rounded-full bg-foreground/10 mishri-shimmer flex-shrink-0" />
      <div className="flex-1 space-y-1">
        <div className="h-2.5 w-1/2 rounded-full bg-foreground/10 mishri-shimmer" />
        <div className="h-2 w-2/5 rounded-full bg-foreground/5 mishri-shimmer" />
      </div>
    </div>
  )
}

/**
 * قائمة من skeleton cards
 */
export function SkeletonList({
  count = 3,
  type = 'post',
}: {
  count?: number
  type?: 'post' | 'user' | 'notification' | 'message'
}) {
  const Component =
    type === 'post'
      ? PostCardSkeleton
      : type === 'user'
      ? UserCardSkeleton
      : type === 'notification'
      ? NotificationSkeleton
      : MessageSkeleton

  return (
    <div className="space-y-3">
      {Array.from({ length: count }).map((_, i) => (
        <Component key={i} />
      ))}
    </div>
  )
}

/**
 * شاشة تحميل بسيطة (بدون skeleton)
 */
export function LoadingSpinner({ label }: { label?: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-12">
      <div className="w-8 h-8 border-2 border-amber-500 border-t-transparent rounded-full animate-spin mb-3" />
      {label && <p className="text-xs text-muted-foreground">{label}</p>}
    </div>
  )
}

/**
 * حالة فارغة — عند عدم وجود بيانات
 */
export function EmptyState({
  icon: Icon,
  title,
  description,
  action,
}: {
  icon: React.ComponentType<{ className?: string }>
  title: string
  description?: string
  action?: { label: string; onClick: () => void }
}) {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-6 text-center">
      <div className="w-16 h-16 rounded-2xl bg-foreground/5 flex items-center justify-center mb-4">
        <Icon className="w-8 h-8 text-muted-foreground" />
      </div>
      <h3 className="font-bold text-sm mb-1">{title}</h3>
      {description && (
        <p className="text-xs text-muted-foreground leading-relaxed max-w-xs">
          {description}
        </p>
      )}
      {action && (
        <button
          onClick={action.onClick}
          className="mt-4 px-5 py-2 rounded-xl mishri-gradient-primary text-white text-xs font-bold mishri-press"
        >
          {action.label}
        </button>
      )}
    </div>
  )
}
