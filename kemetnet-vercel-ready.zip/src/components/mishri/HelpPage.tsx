'use client'

import { useRouter } from 'next/navigation'
import {
 ArrowLeft, ChevronDown, Search, Sparkles, User, Lock, Bell, Image as ImageIcon,
 MessageCircle, AtSign, Ban, Shield, HelpCircle, Lightbulb, Settings, Repeat2
} from 'lucide-react'
import { useState } from 'react'

interface FAQItem {
 question: string
 answer: string
 category: string
}

const FAQS: FAQItem[] = [
 {
 category: 'الحساب',
 question: 'كيف أنشئ حساباً في KemetNet؟',
 answer: 'اضغط على "إنشاء حساب" في الصفحة الرئيسية، ثم اختر يوزرنيم (3-20 حرف: أحرف إنجليزية، أرقام، شرطة سفلية) وكلمة مرور قوية (8 أحرف على الأقل، أحرف وأرقام). لا تحتاج لبريد إلكتروني — التسجيل باليوزرنيم فقط.',
 },
 {
 category: 'الحساب',
 question: 'هل يمكنني تغيير اليوزرنيم؟',
 answer: 'نعم، اذهب للإعدادات → تغيير اليوزرنيم. أدخل اليوزرنيم الجديد وتحقق من توفره، ثم احفظ. ملاحظة: الإشارات @username القديمة في المنشورات والتعليقات لن تربط بملفك الجديد.',
 },
 {
 category: 'الحساب',
 question: 'كيف أحذف حسابي نهائياً؟',
 answer: 'الإعدادات → إدارة الحساب → حذف حسابي نهائياً. ستُحذف كل بياناتك (منشورات، تعليقات، إعجابات، رسائل) بشكل دائم. يجب كتابة "حذف" للتأكيد. لا يمكن التراجع عن هذا الإجراء.',
 },
 {
 category: 'المنشورات',
 question: 'ما الحد الأقصى لمحتوى المنشور؟',
 answer: 'يمكن أن يحتوي المنشور على حتى 2000 حرف، مع صورة واحدة (حتى 5 ميجابايت، نسبة 4:5)، حتى 5 وسوم، فئة واحدة، ومود اختياري.',
 },
 {
 category: 'المنشورات',
 question: 'كيف أعدّل أو أحذف منشوراً؟',
 answer: 'اضغط على الثلاث نقاط (...) في أعلى المنشور، ثم اختر "تعديل" أو "حذف". يمكن فقط لصاحب المنشور تعديله أو حذفه.',
 },
 {
 category: 'المنشورات',
 question: 'ما الفرق بين الحفظ والإعجاب؟',
 answer: 'الإعجاب (Heart) يظهر للجميع ويزيد عدّاد المنشور. الحفظ (Bookmark) يضيف المنشور لقائمتك الخاصة في الملف الشخصي → تبويب "المحفوظات"، ولا يراه أحد غيرك.',
 },
 {
 category: 'المنشورات',
 question: 'كيف أعيد نشر منشور؟',
 answer: 'اضغط على أيقونة إعادة النشر (سهمين دائريين) بجانب زر الإعجاب. سيظهر المنشور في ملفك الشخصي مع إشارة لصاحبه الأصلي. لا يمكن إعادة نشر منشورك.',
 },
 {
 category: 'التعليقات',
 question: 'هل يمكنني الرد على تعليق؟',
 answer: 'نعم، اضغط على "رد" أسفل أي تعليق. سيظهر ردك بشكل متداخل تحت التعليق الأصلي، تماماً مثل إنستجرام.',
 },
 {
 category: 'التعليقات',
 question: 'كيف أثبّت تعليقاً في منشوري؟',
 answer: 'إذا كنت صاحب المنشور، اضغط على الثلاث نقاط بجانب التعليق، ثم "تثبيت التعليق". يسمح بتثبيت تعليق واحد فقط لكل منشور، ويظهر في الأعلى مع شارة ذهبية.',
 },
 {
 category: 'الإشارات',
 question: 'كيف أذكر مستخدماً في منشور أو تعليق؟',
 answer: 'اكتب @ ثم اسم المستخدم. ستظهر قائمة منسدلة بالمستخدمين المطابقين أثناء الكتابة. يمكنك التنقل بالأسهم واختيار بالـ Enter. سيستلم المستخدم المذكور إشعاراً.',
 },
 {
 category: 'الرسائل',
 question: 'كيف أبدأ محادثة مع مستخدم؟',
 answer: 'اذهب لملف المستخدم → اضغط على أيقونة الرسالة. إذا لم تتابعوه أو يتابعكم، سيُرسل طلب مراسلة يجب قبوله أولاً.',
 },
 {
 category: 'الرسائل',
 question: 'هل يمكنني إرسال صور في الرسائل؟',
 answer: 'نعم، اضغط على أيقونة الصورة بجانب حقل الكتابة، اختر صورة (حتى 5 ميجابايت)، ستظهر معاينة قبل الإرسال. يمكن إرسال صورة + نص معاً أو صورة فقط.',
 },
 {
 category: 'الرسائل',
 question: 'هل تُحفظ المسودات تلقائياً؟',
 answer: 'نعم، كل ما تكتبه في صندوق الرسائل أو صندوق إنشاء المنشور يُحفظ تلقائياً (localStorage) لمدة 7 أيام. ستجد مؤشر "مسودة محفوظة تلقائياً" أسفل الحقل.',
 },
 {
 category: 'الأمان والخصوصية',
 question: 'ماذا يحدث عند حجب مستخدم؟',
 answer: 'عند الحجب: 1) تُحذف متابعته لك في الاتجاهين، 2) تُحذف طلبات المراسلة بينكما، 3) لن ترى منشوراته في الصفحة الرئيسية، 4) لن يتمكن من مراسلتك. يمكنك إلغاء الحجب في أي وقت من الإعدادات → المستخدمون المحجوبون.',
 },
 {
 category: 'الأمان والخصوصية',
 question: 'كيف أبلغ عن محتوى مخالف؟',
 answer: 'اضغط على الثلاث نقاط في المنشور أو التعليق أو الملف الشخصي، اختر "إبلاغ"، اختر السبب (9 أسباب: محتوى مزعج، مضايقة، خطاب كراهية، إلخ)، أضف وصفاً اختيارياً، ثم أرسل. يمكنك أيضاً حجب المستخدم بعد الإبلاغ.',
 },
 {
 category: 'الإشعارات',
 question: 'لماذا لا تصلك إشعاراتي؟',
 answer: 'تأكد من تفعيل الإشعارات في الإعدادات → الإشعارات. قد تحتاج أيضاً للسماح بإشعارات المتصفح (سيطلب منك ذلك عند أول زيارة). على الجوال، تأكد من تفعيل إشعارات الموقع في إعدادات المتصفح.',
 },
 {
 category: 'التطبيق',
 question: 'هل يمكنني تثبيت التطبيق على جهازي؟',
 answer: 'نعم، يمكن تثبيت التطبيق على جهازك. على Chrome/Edge: اضغط على أيقونة التثبيت في شريط العنوان. على iOS Safari: مشاركة → "إضافة إلى الشاشة الرئيسية". سيعمل كتطبيق أصلي.',
 },
 {
 category: 'التطبيق',
 question: 'هل يعمل التطبيق بدون إنترنت؟',
 answer: 'جزئياً. يمكنك تصفّح المنشورات والملفات التي زرتها سابقاً. لن تتمكن من نشر أو التفاعل أو الرسائل حتى يعود الاتصال. سترى شارة "أنت غير متصل" في الأعلى عند الانقطاع.',
 },
 {
 category: 'التطبيق',
 question: 'كيف أفعّل الوضع الليلي التلقائي؟',
 answer: 'الإعدادات → المظهر → اختر "تلقائي". سيتبع التطبيق إعداد نظام جهازك (فاتح/داكن) تلقائياً، ويتغير فوراً عند تغيير إعداد الجهاز.',
 },
]

const CATEGORIES = ['الكل', 'الحساب', 'المنشورات', 'التعليقات', 'الإشارات', 'الرسائل', 'الأمان والخصوصية', 'الإشعارات', 'التطبيق']

export function HelpPage() {
 const router = useRouter()
 const [search, setSearch] = useState('')
 const [activeCategory, setActiveCategory] = useState('الكل')
 const [openIndex, setOpenIndex] = useState<number | null>(0)

 const filteredFaqs = FAQS.filter((faq) => {
 const matchesCategory = activeCategory === 'الكل' || faq.category === activeCategory
 const matchesSearch =
 !search ||
 faq.question.includes(search) ||
 faq.answer.includes(search) ||
 faq.category.includes(search)
 return matchesCategory && matchesSearch
 })

 return (
 <div className="flex flex-col flex-1 min-h-0">
 {/* الرأس */}
 <header className="flex-shrink-0 bg-background/80 backdrop-blur-xl safe-top z-40">
 <div className="max-w-md mx-auto px-4 py-3 flex items-center gap-3">
 <button
 onClick={() => router.back()}
 className="p-2 rounded-full hover:bg-foreground/5 mishri-press"
 aria-label="رجوع"
 >
 <ArrowLeft className="w-4 h-4" />
 </button>
 <h1 className="font-display text-lg font-bold flex-1">المساعدة والأسئلة الشائعة</h1>
 </div>
 </header>

 <div data-scroll-area className="flex-1 overflow-y-auto overscroll-y-contain">
 <main className="max-w-md mx-auto px-4 pt-4 pb-6">
 {/* بطاقة ترحيب */}
 <div
 className="rounded-2xl p-4 bg-foreground/5 mb-4 text-center transition-colors duration-200"
 >
 <div className="w-14 h-14 mx-auto mb-3 rounded-2xl mishri-gradient-primary mishri-glow-soft flex items-center justify-center">
 <HelpCircle className="w-7 h-7 text-white" />
 </div>
 <h2 className="font-display text-base font-bold mb-1">كيف يمكننا مساعدتك؟</h2>
 <p className="text-xs text-muted-foreground">
 ابحث في الأسئلة الشائعة أو تصفّح حسب الفئة
 </p>
 </div>

 {/* البحث */}
 <div className="relative mb-3">
 <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
 <input
 type="text"
 value={search}
 onChange={(e) => setSearch(e.target.value)}
 placeholder="ابحث في الأسئلة..."
 className="mishri-input w-full rounded-xl py-2.5 pr-10 pl-4 text-sm font-medium outline-none"
 />
 </div>

 {/* فئات */}
 <div className="flex gap-1.5 overflow-x-auto pb-2 mb-4 mishri-scrollbar-hide">
 {CATEGORIES.map((cat) => (
 <button
 key={cat}
 onClick={() => setActiveCategory(cat)}
 className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all mishri-press flex-shrink-0 ${
 activeCategory === cat
 ? 'mishri-gradient-primary text-white shadow-sm'
 : 'bg-foreground/5 text-muted-foreground hover:bg-foreground/10'
 }`}
 >
 {cat}
 </button>
 ))}
 </div>

 {/* قائمة الأسئلة */}
 {filteredFaqs.length === 0 ? (
 <div className="text-center py-10">
 <div className="w-14 h-14 mx-auto mb-3 rounded-2xl bg-foreground/5 flex items-center justify-center">
 <Search className="w-7 h-7 text-muted-foreground/50" />
 </div>
 <p className="text-sm font-semibold mb-1">لا توجد نتائج</p>
 <p className="text-xs text-muted-foreground">جرّب كلمة بحث أخرى</p>
 </div>
 ) : (
 <div className="space-y-2">
 {filteredFaqs.map((faq, i) => {
 const isOpen = openIndex === i
 return (
 <div
 key={`${faq.question}-${i}`}
 className="rounded-2xl bg-foreground/5 overflow-hidden transition-colors duration-200"
 >
 <button
 onClick={() => setOpenIndex(isOpen ? null : i)}
 className="w-full p-3 flex items-center gap-3 text-right mishri-press"
 >
 <div className="w-8 h-8 rounded-lg bg-amber-500/10 flex items-center justify-center flex-shrink-0">
 <Lightbulb className="w-4 h-4 text-amber-500" />
 </div>
 <div className="flex-1 min-w-0">
 <div className="text-[10px] text-muted-foreground mb-0.5">{faq.category}</div>
 <div className="text-sm font-bold leading-snug">{faq.question}</div>
 </div>
 <div style={{ transform: isOpen ? 'rotate(180deg)' : 'rotate(0)' }} className="transition-all duration-200">
 <ChevronDown className="w-4 h-4 text-muted-foreground flex-shrink-0" />
 </div>
 </button>
 <div
 className="overflow-hidden transition-all duration-200"
 style={{ maxHeight: isOpen ? '500px' : '0', opacity: isOpen ? 1 : 0 }}
 >
 <div className="px-3 pb-3 pt-1">
 <div className="pr-11 pl-1">
 <p className="text-xs text-foreground/80 leading-relaxed">{faq.answer}</p>
 </div>
 </div>
 </div>
 </div>
 )
 })}
 </div>
 )}

 {/* روابط سريعة */}
 <div className="mt-6">
 <h3 className="text-xs font-bold text-muted-foreground mb-3 px-3">روابط سريعة</h3>
 <div className="rounded-2xl bg-foreground/5 overflow-hidden">
 <QuickLink icon={Settings} label="الإعدادات" desc="تخصيص التطبيق" onClick={() => router.push('/settings')} />
 <QuickLink icon={Shield} label="الخصوصية والأمان" desc="إعدادات الحساب الخاص" onClick={() => router.push('/settings')} />
 <QuickLink icon={Sparkles} label="عن التطبيق" desc="معلومات حول KemetNet" onClick={() => router.push('/settings')} />
 </div>
 </div>

 {/* تذييل */}
 <div className="text-center mt-6">
 <p className="text-xs text-muted-foreground">لم تجد إجابتك؟</p>
 <p className="text-[11px] text-muted-foreground/70 mt-1">
 تواصل معنا عبر البريد: <span dir="ltr" className="font-mono">support@kemetnet.app</span>
 </p>
 </div>
 </main>
 </div>
 </div>
 )
}

function QuickLink({
 icon: Icon,
 label,
 desc,
 onClick,
}: {
 icon: typeof Settings
 label: string
 desc: string
 onClick: () => void
}) {
 return (
 <button
 onClick={onClick}
 className="w-full flex items-center gap-3 p-3 hover:bg-foreground/5 transition-colors mishri-press border-b border-foreground/5 last:border-0 text-right"
 >
 <div className="w-9 h-9 rounded-xl bg-amber-500/10 flex items-center justify-center">
 <Icon className="w-4 h-4 text-amber-500" />
 </div>
 <div className="flex-1 min-w-0">
 <div className="text-sm font-bold">{label}</div>
 <div className="text-xs text-muted-foreground truncate">{desc}</div>
 </div>
 <ChevronDown className="w-4 h-4 text-muted-foreground -rotate-90" />
 </button>
 )
}
