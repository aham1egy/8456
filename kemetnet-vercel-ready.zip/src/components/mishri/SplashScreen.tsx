'use client'

import { useEffect, useState } from 'react'
import { MishriSplashMark } from './MishriLogo'

/**
 * شاشة البداية الاحترافية - KemetNet
 *
 * التصميم مستوحى من:
 *   - كارتوش الملوك المصريين (الإطار الذهبي المتوهج)
 *   - حلقة الهيروغليف الدوّارة (تمثل دوران الزمن والحضارة)
 *   - خط النيل الذهبي (شريط التحميل)
 *   - رمز عنخ (Ankh) بين زخارف الزاوية (الحياة الأبدية)
 *
 * العناصر:
 *   1. خلفية لازوردية عميقة مع توهجات ذهبية وذهبية حمراء
 *   2. كارتوش (إطار فاخر) يحوي الشعار في المنتصف
 *   3. حلقة هيروغليفية دوارة حول الشعار
 *   4. اسم التطبيق بتدرج ذهبي-لازوردي
 *   5. شعار فرعي مع نقطة فاصلة ذهبية متوهجة
 *   6. شريط تحميل ذهبي مع تأثير مسح ضوئي
 *   7. نسبة مئوية بأرقام tabular
 *   8. نقاط تحميل نابضة في الأسفل
 */
export function SplashScreen() {
  const [progress, setProgress] = useState(0)
  const [visible, setVisible] = useState(true)

  useEffect(() => {
    // تحميل بصري تدريجي - ينتهي عند 90% ويبقى حتى يُغلق من الخارج
    const interval = setInterval(() => {
      setProgress((p) => {
        if (p >= 90) return p
        const remaining = 90 - p
        const speed = remaining < 20 ? 2 : remaining < 60 ? 8 : 4
        return Math.min(90, p + speed + Math.random() * 3)
      })
    }, 100)

    return () => clearInterval(interval)
  }, [])

  const displayPercent = Math.min(Math.floor(progress), 90)

  if (!visible) return null

  return (
    <div
      key="splash"
      className="fixed inset-0 mishri-aurora-bg flex flex-col items-center justify-center overflow-hidden z-50 transition-opacity duration-500"
      role="status"
      aria-live="polite"
      aria-label="جارٍ تحميل تطبيق KemetNet"
    >
      {/* ====== الخلفية الديكورية المتعددة الطبقات ====== */}
      <div className="absolute inset-0 pointer-events-none" aria-hidden="true">
        {/* طبقة 1: توهجات لازوردية كبيرة */}
        <div className="absolute top-[8%] left-[8%] w-80 h-80 rounded-full bg-blue-800/40 blur-3xl mishri-float" />
        <div
          className="absolute bottom-[12%] right-[8%] w-96 h-96 rounded-full bg-blue-900/40 blur-3xl mishri-float"
          style={{ animationDelay: '1.2s' }}
        />
        {/* طبقة 2: توهجات ذهبية أصغر */}
        <div
          className="absolute top-[35%] right-[20%] w-64 h-64 rounded-full bg-amber-500/25 blur-3xl mishri-float"
          style={{ animationDelay: '0.5s' }}
        />
        <div
          className="absolute bottom-[35%] left-[20%] w-72 h-72 rounded-full bg-yellow-500/15 blur-3xl mishri-float"
          style={{ animationDelay: '1.8s' }}
        />
        {/* طبقة 3: نقاط ذهبية متناثرة (نجوم) */}
        {[...Array(12)].map((_, i) => {
          const top = (i * 37 + 5) % 100
          const left = (i * 53 + 8) % 100
          const size = (i % 3) + 1
          const delay = (i * 0.3) % 2
          return (
            <div
              key={i}
              className="absolute rounded-full bg-amber-200/60 mishri-pulse"
              style={{
                top: `${top}%`,
                left: `${left}%`,
                width: `${size}px`,
                height: `${size}px`,
                animationDelay: `${delay}s`,
                animationDuration: '3s',
              }}
            />
          )
        })}

        {/* خطوط ذهبية رفيعة - حواف الشاشة (إطار خارجي) */}
        <div className="absolute inset-3 rounded-[28px] border border-amber-500/15 pointer-events-none" />
        <div className="absolute inset-5 rounded-[24px] border border-amber-400/8 pointer-events-none" />
      </div>

      {/* ====== المحتوى الرئيسي: الكارتوش ====== */}
      <div className="relative z-10 flex flex-col items-center px-6">
        <div
          className="kemet-cartouche kemet-rise"
          style={{ animationDelay: '0.05s', animationDuration: '0.8s' }}
        >
          {/* زخارف الزوايا الأربعة (L-shape gold corners) */}
          <span className="kemet-corner tl" aria-hidden="true" />
          <span className="kemet-corner tr" aria-hidden="true" />
          <span className="kemet-corner bl" aria-hidden="true" />
          <span className="kemet-corner br" aria-hidden="true" />

          {/* الشعار داخل حلقة هيروغليف دوارة */}
          <div className="relative flex items-center justify-center">
            {/* الهالة الذهبية الخلفية */}
            <div
              className="absolute inset-0 rounded-full bg-amber-500/30 blur-2xl kemet-halo"
              aria-hidden="true"
            />

            {/* حلقة الهيروغليف الخارجية */}
            <div className="kemet-glyph-ring" aria-hidden="true">
              <svg viewBox="0 0 200 200" className="w-full h-full">
                <defs>
                  <linearGradient id="glyph-grad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#F5D78A" />
                    <stop offset="100%" stopColor="#A87A1F" />
                  </linearGradient>
                </defs>
                {/* دائرة رفيعة خارجية */}
                <circle
                  cx="100" cy="100" r="96"
                  fill="none" stroke="url(#glyph-grad)" strokeWidth="0.5" opacity="0.5"
                />
                {/* نقاط ذهبية حول المحيط (نقاط هيروغليف) - 12 نقطة */}
                {[...Array(12)].map((_, i) => {
                  const angle = (i * 30 - 90) * (Math.PI / 180)
                  const x = 100 + 92 * Math.cos(angle)
                  const y = 100 + 92 * Math.sin(angle)
                  return (
                    <circle key={i} cx={x} cy={y} r="1.5" fill="url(#glyph-grad)" opacity="0.7" />
                  )
                })}
                {/* رموز صغيرة بين النقاط (Ankh ≋) */}
                {[...Array(6)].map((_, i) => {
                  const angle = (i * 60 + 30 - 90) * (Math.PI / 180)
                  const x = 100 + 80 * Math.cos(angle)
                  const y = 100 + 80 * Math.sin(angle)
                  return (
                    <text
                      key={i}
                      x={x} y={y + 3}
                      textAnchor="middle"
                      fontSize="6"
                      fill="url(#glyph-grad)"
                      opacity="0.55"
                      fontWeight="bold"
                    >
                      𓂀
                    </text>
                  )
                })}
              </svg>
            </div>

            {/* حلقة داخلية منقطة */}
            <div className="kemet-glyph-ring-inner" aria-hidden="true" />

            {/* الشعار نفسه */}
            <div className="relative">
              <MishriSplashMark size={130} />
            </div>
          </div>

          {/* اسم التطبيق */}
          <h1
            className="mt-7 font-display text-5xl font-bold mishri-gradient-text tracking-tight text-center kemet-rise"
            style={{ animationDelay: '0.25s' }}
          >
            KemetNet
          </h1>

          {/* الشعار الفرعي مع نقطة فاصلة ذهبية */}
          <div
            className="mt-3 flex items-center gap-3 kemet-rise"
            style={{ animationDelay: '0.4s' }}
          >
            <span className="text-xs text-amber-200/80 font-medium tracking-[0.2em] kemet-text-shimmer">
              منصة الإلهام
            </span>
            <span className="kemet-divider" />
            <span className="text-xs text-amber-200/80 font-medium tracking-[0.2em] kemet-text-shimmer">
              والمشاركة
            </span>
          </div>
        </div>

        {/* نص قصير تحت الكارتوش - بالخط العربي */}
        <p
          className="mt-5 text-[11px] text-amber-100/50 font-medium tracking-widest kemet-rise"
          style={{ animationDelay: '0.55s' }}
        >
          من أرض الكِمْت • إلى العالم
        </p>
      </div>

      {/* ====== شريط التحميل الذهبي ====== */}
      <div
        className="absolute bottom-20 z-10 flex flex-col items-center gap-3 kemet-rise"
        style={{ animationDelay: '0.7s' }}
      >
        {/* شريط التحميل */}
        <div className="relative w-64 h-[3px] bg-amber-950/40 rounded-full overflow-hidden border border-amber-500/15">
          <div
            className="absolute inset-y-0 right-0 mishri-gradient-primary rounded-full transition-all duration-150"
            style={{ width: `${displayPercent}%` }}
          />
          {/* تأثير المسح الذهبي */}
          <div className="kemet-scan" aria-hidden="true" />
        </div>

        {/* النسبة المئوية + الحالة */}
        <div className="flex items-center gap-3">
          <span className="text-[10px] text-amber-200/60 font-medium tracking-wider">
            {displayPercent >= 90 ? 'جاهز' : 'جارٍ التحضير'}
          </span>
          <span className="text-[10px] text-amber-200/30">•</span>
          <span
            key={Math.floor(displayPercent / 5)}
            className="text-xs text-amber-100 font-bold tabular-nums mishri-gradient-text"
          >
            {displayPercent}%
          </span>
        </div>
      </div>

      {/* ====== نقاط التحميل النابضة + العلامة المائية ====== */}
      <div
        className="absolute bottom-8 flex flex-col items-center gap-2"
        aria-hidden="true"
      >
        <div className="flex gap-2">
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              className="w-1 h-1 rounded-full bg-amber-400 mishri-pulse"
              style={{
                animationDelay: `${i * 0.25}s`,
                animationDuration: '1.5s',
              }}
            />
          ))}
        </div>
        <span className="text-[9px] text-amber-100/30 tracking-[0.3em] font-medium">
          v1.0.0
        </span>
      </div>
    </div>
  )
}
