'use client'

import { useEffect, useState, useRef } from 'react'
import { useRouter, usePathname } from 'next/navigation'
import { useAppStore } from '@/store/app-store'
import { getCurrentProfile } from '@/lib/supabase/auth'
import { supabase } from '@/lib/supabase/client'
import { SplashScreen } from '@/components/mishri/SplashScreen'
import { BottomNav } from '@/components/mishri/BottomNav'
import { GlassOpacityController } from '@/components/mishri/GlassOpacityController'
import { useRealtimeNotifications } from '@/hooks/use-realtime'
import { useSwipeBack } from '@/hooks/use-swipe-back'
import { startAutoRepair, trackEvent } from '@/lib/self-improving'

/**
 * Layout مشترك للصفحات المحمية (التي تتطلب تسجيل دخول)
 * - يفحص الجلسة عند البدء
 * - يحوّل المستخدم غير المسجل لـ /
 * - يعرض Splash أثناء التحقق
 * - يفعّل البث المباشر للإشعارات
 * - يعرض BottomNav ثابت في الأسفل
 * - يوفر حاوية تمرير للمحتوى (header ثابت فوقها، الشريط السفلي ثابت تحتها)
 */
export function ProtectedLayout({ children }: { children: React.ReactNode }) {
 const router = useRouter()
 const pathname = usePathname()
 const user = useAppStore((s) => s.user)
 const setUser = useAppStore((s) => s.setUser)
 const theme = useAppStore((s) => s.theme)
 const [hydrated, setHydrated] = useState(false)
 const [checking, setChecking] = useState(true)
 const hydratedRef = useRef(false)

 // تفعيل السحب من الجانب للرجوع
 useSwipeBack()

 // إخفاء BottomNav في صفحات المحادثة وصفحات المنشور الفردي
 const hideBottomNav = pathname?.startsWith('/messages/') || pathname?.startsWith('/post/') || pathname?.startsWith('/leaderboard') || pathname?.startsWith('/help')

 useRealtimeNotifications()

 // تفعيل نظام التحسين الذاتي
 useEffect(() => {
   startAutoRepair()
   trackEvent('app_open', pathname)
 }, [pathname])

 // استعادة حالة Zustand - مرة واحدة فقط
 useEffect(() => {
 if (hydratedRef.current) return
 hydratedRef.current = true
 Promise.resolve(useAppStore.persist.rehydrate()).finally(() => {
 setHydrated(true)
 })
 }, [])

 // تهيئة الثيم (مع دعم system)
 useEffect(() => {
 const root = document.documentElement
 const apply = (mode: typeof theme) => {
 if (mode === 'system') {
 const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches
 root.classList.toggle('dark', prefersDark)
 } else if (mode === 'midnight') {
 root.classList.add('dark')
 } else {
 root.classList.remove('dark')
 }
 }
 apply(theme)
 if (theme === 'system' && typeof window !== 'undefined') {
 const mq = window.matchMedia('(prefers-color-scheme: dark)')
 const handler = () => apply('system')
 mq.addEventListener('change', handler)
 return () => mq.removeEventListener('change', handler)
 }
 }, [theme])

 // تفعيل service worker للتخزين المؤقت (تجربة كتطبيق أصلي)
 useEffect(() => {
 if ('serviceWorker' in navigator && process.env.NODE_ENV === 'production') {
 navigator.serviceWorker.register('/sw.js').catch(() => {
 // تجاهل أخطاء التسجيل
 })
 }
 }, [])

 // فحص الجلسة عند الدخول للصفحة المحمية
 useEffect(() => {
 let mounted = true

 const checkSession = async () => {
 try {
 const { data: { session } } = await supabase.auth.getSession()
 if (!mounted) return

 if (session?.user) {
 if (!user) {
 const profile = await getCurrentProfile()
 if (!mounted) return
 setUser(profile)
 if (!profile) {
 router.replace('/')
 return
 }
 }
 setChecking(false)
 } else {
 setUser(null)
 router.replace('/')
 }
 } catch (err) {
 // [removed in production] 'Session check error:', err instanceof Error ? err.message : 'unknown'
 router.replace('/')
 }
 }

 if (hydrated) {
 void checkSession()
 }

 return () => {
 mounted = false
 }
 }, [hydrated, user, router, setUser])

 // الاستماع لتغييرات المصادقة
 useEffect(() => {
 const { data: authListener } = supabase.auth.onAuthStateChange((event) => {
 if (event === 'SIGNED_OUT') {
 setUser(null)
 router.replace('/')
 }
 })

 return () => {
 authListener.subscription.unsubscribe()
 }
 }, [router, setUser])

 // Splash أثناء الفحص
 if (!hydrated || checking || !user) {
 return <SplashScreen />
 }

 return (
 <div className="h-[100dvh] flex flex-col overflow-hidden">
 <GlassOpacityController />
 {/* المحتوى مع انتقال دخول سلس */}
 <main id="main-content" className="flex-1 overflow-hidden flex flex-col page-enter" key={pathname}>
 {children}
 </main>
 {!hideBottomNav && <BottomNav />}
 </div>
 )
}
