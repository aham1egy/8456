// src/components/mishri/MishriLogo.tsx
// شعار تطبيق KemetNet — عين حورس (Wedjat) + قرص الشمس (Aten)
// هوية بصرية مستوحاة من الحضارة المصرية القديمة:
//   - عين حورس: رمز الحماية والرؤية والإلهام
//   - قرص الشمس (آتون): رمز الحياة والنور
//   - الأزرق اللازوردي + الذهبي: ألوان مصرية أصيلة
// (أسماء الكلاسات mishri-* محفوظة للتوافق مع النظام)

import { cn } from '@/lib/utils'

interface MishriLogoProps {
  size?: number
  className?: string
  animated?: boolean
  showText?: boolean
}

export function MishriLogoMark({ size = 40, className, animated = false }: Omit<MishriLogoProps, 'showText'>) {
  return (
    <div
      className={cn('relative inline-flex items-center justify-center', className)}
      style={{ width: size, height: size }}
      aria-label="KemetNet"
    >
      <svg
        viewBox="0 0 100 100"
        width={size}
        height={size}
        className={cn(animated && 'mishri-spin-slow')}
      >
        <defs>
          <linearGradient id="kemet-bg" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#1F4E8C" />
            <stop offset="50%" stopColor="#0E2A4F" />
            <stop offset="100%" stopColor="#081F38" />
          </linearGradient>
          <linearGradient id="kemet-gold" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#F5D78A" />
            <stop offset="50%" stopColor="#D4A644" />
            <stop offset="100%" stopColor="#A87A1F" />
          </linearGradient>
          <radialGradient id="kemet-glow" cx="50%" cy="50%" r="55%">
            <stop offset="0%" stopColor="#D4A644" stopOpacity="0.30" />
            <stop offset="100%" stopColor="#D4A644" stopOpacity="0" />
          </radialGradient>
        </defs>

        {/* الخلفية: أزرق لازوردي عميق */}
        <rect width="100" height="100" rx="22" fill="url(#kemet-bg)" />

        {/* توهج ذهبي خلف العين */}
        <circle cx="50" cy="50" r="42" fill="url(#kemet-glow)" />

        {/* إطار ذهبي رفيع (كارتوش) */}
        <rect x="6" y="6" width="88" height="88" fill="none" stroke="#D4A644" strokeWidth="0.5" opacity="0.30" rx="4" />

        {/* قرص الشمس (آتون) */}
        <circle cx="50" cy="22" r="6" fill="url(#kemet-gold)" />
        <circle cx="50" cy="22" r="4" fill="#0E2A4F" />
        <circle cx="50" cy="22" r="2.5" fill="url(#kemet-gold)" />

        {/* أشعة الشمس */}
        <g stroke="url(#kemet-gold)" strokeWidth="0.6" opacity="0.55" strokeLinecap="round">
          <line x1="50" y1="29" x2="50" y2="33" />
          <line x1="45" y1="29" x2="43" y2="33" />
          <line x1="55" y1="29" x2="57" y2="33" />
        </g>

        {/* ====== عين حورس (Wedjat) ====== */}
        <g>
          {/* الحاجب */}
          <path
            d="M 25 38 Q 50 31 75 38 Q 74 42 71 42.5 Q 50 36 29 42.5 Q 26 42 25 38 Z"
            fill="url(#kemet-gold)"
          />

          {/* العين (لوزة) */}
          <path d="M 23 50 Q 50 41 77 50 Q 50 59 23 50 Z" fill="url(#kemet-gold)" />
          <path d="M 26 50 Q 50 43.5 74 50 Q 50 56.5 26 50 Z" fill="#0E2A4F" />

          {/* الحدقة */}
          <circle cx="50" cy="50" r="7" fill="url(#kemet-gold)" />
          <circle cx="50" cy="50" r="5" fill="#0E2A4F" />
          <circle cx="50" cy="50" r="3" fill="url(#kemet-gold)" />

          {/* لمسة على الحدقة */}
          <circle cx="48" cy="48" r="0.9" fill="#F5D78A" opacity="0.95" />

          {/* الدمعة (علامة خد الصقر) */}
          <path
            d="M 50 57 L 50 76 Q 50 80 46 80.5 Q 41 80.5 41 76 Q 41 72.5 45 72.5 L 47 72.5 L 47 57 Z"
            fill="url(#kemet-gold)"
          />

          {/* لفافة الجانب */}
          <path
            d="M 77 50 Q 82 53 82.5 58 Q 83 63 78 65 Q 74 66 71 64 Q 75 62.5 76.5 60 Q 78 56 76.5 53 Q 75 51 73 50.5 Z"
            fill="url(#kemet-gold)"
          />

          {/* نقاط الزاوية */}
          <circle cx="26" cy="50" r="0.7" fill="#F5D78A" />
          <circle cx="74" cy="50" r="0.7" fill="#F5D78A" />
        </g>

        {/* خط الماء السفلي (النيل — خصوبة) */}
        <path
          d="M 25 86 Q 35 84 42 86 Q 50 87 58 86 Q 65 84 75 86"
          stroke="#D4A644"
          strokeWidth="0.5"
          opacity="0.45"
          strokeLinecap="round"
          fill="none"
        />
      </svg>
    </div>
  )
}

export function MishriLogo({ size = 40, className, animated = false, showText = false }: MishriLogoProps) {
  if (!showText) {
    return <MishriLogoMark size={size} className={className} animated={animated} />
  }
  return (
    <div className={cn('inline-flex items-center gap-2', className)}>
      <MishriLogoMark size={size} animated={animated} />
      <span
        className="font-display font-bold mishri-gradient-text"
        style={{ fontSize: size * 0.55 }}
      >
        KemetNet
      </span>
    </div>
  )
}

// شاشة التحميل - splash
export function MishriSplashMark({ size = 120 }: { size?: number }) {
  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <MishriLogoMark size={size} animated />
      <div className="absolute inset-0 mishri-pulse rounded-3xl" style={{ animationDuration: '3s' }} />
    </div>
  )
}
