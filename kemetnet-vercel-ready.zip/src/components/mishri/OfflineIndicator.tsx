'use client'

import { Wifi, WifiOff, CloudOff } from 'lucide-react'
import { useOnlineStatus } from '@/hooks/use-online-status'

export function OfflineIndicator() {
 const { isOnline, wasOffline } = useOnlineStatus()

 return (
 <>
 {!isOnline && (
 <div
 className="fixed top-0 left-0 right-0 z-[200] safe-top pointer-events-none transition-colors duration-200"
 >
 <div className="max-w-md mx-auto px-3 pt-2 pointer-events-auto">
 <div className="bg-rose-500/95 backdrop-blur-md rounded-2xl p-2.5 shadow-2xl flex items-center gap-2.5">
 <div className="mishri-pulse">
 <WifiOff className="w-4 h-4 text-white" />
 </div>
 <div className="flex-1 min-w-0">
 <div className="text-xs font-bold text-white">أنت غير متصل</div>
 <div className="text-[10px] text-white/80">
 بعض الميزات قد لا تعمل. سنعرض البيانات المحفوظة.
 </div>
 </div>
 </div>
 </div>
 </div>
 )}

 {isOnline && wasOffline && (
 <div
 className="fixed top-0 left-0 right-0 z-[200] safe-top pointer-events-none transition-colors duration-200"
 >
 <div className="max-w-md mx-auto px-3 pt-2 pointer-events-auto">
 <div className="bg-emerald-500/95 backdrop-blur-md rounded-2xl p-2.5 shadow-2xl flex items-center gap-2.5">
 <div className="mishri-pulse">
 <Wifi className="w-4 h-4 text-white" />
 </div>
 <div className="flex-1 min-w-0">
 <div className="text-xs font-bold text-white">عاد الاتصال</div>
 <div className="text-[10px] text-white/80">
 يمكنك الآن تحديث المحتوى
 </div>
 </div>
 </div>
 </div>
 </div>
 )}
 </>
 )
}

// شارة "وضع عدم الاتصال" للبطاقات
export function OfflineBadge({ show }: { show: boolean }) {
 if (!show) return null
 return (
 <div className="absolute top-2 left-2 z-10 px-2 py-1 rounded-full bg-rose-500/90 backdrop-blur-md text-white text-[10px] font-bold flex items-center gap-1">
 <CloudOff className="w-3 h-3" />
 غير متصل
 </div>
 )
}
