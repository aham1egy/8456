'use client'

import { useState, useEffect, useCallback, useRef } from 'react'
import { usePageCache } from '@/hooks/use-page-cache'
import { useRouter } from 'next/navigation'
import { ArrowLeft, Send, Check, CheckCheck, Edit2, Trash2, Copy, X, Image as ImageIcon, Loader2, Smile } from 'lucide-react'
import { useAppStore } from '@/store/app-store'
import { supabase } from '@/lib/supabase/client'
import type { Profile } from '@/lib/supabase/client'
import {
 fetchMessages,
 sendMessage,
 editMessage,
 deleteMessage,
 markMessagesAsRead,
 type Message,
} from '@/lib/messaging'
import { uploadMessageImage } from '@/lib/supabase/storage'
import { useMessageDraft, setPendingImage, getPendingImage, clearPendingImage } from '@/lib/drafts'
import { initPresence, subscribeToTyping, subscribeToUserPresence, setTyping, type PresenceState } from '@/lib/presence'
import { fetchMessagesReactions, toggleMessageReaction, type ReactionGroup, type ReactionEmoji } from '@/lib/message-reactions'
import { ReactionPicker, ReactionsDisplay } from './ReactionPicker'
import { VerifiedBadgeMini } from './VerifiedBadge'
import { useNotificationSound } from '@/hooks/use-sound'
import { MentionsInput } from './MentionsInput'
import { MentionText } from './MentionText'
import { toast } from 'sonner'

interface ConversationPageProps {
 conversationId: string
}

export function ConversationPage({ conversationId }: ConversationPageProps) {
 const router = useRouter()
 const user = useAppStore((s) => s.user)
 const { playSound } = useNotificationSound()

 const [messages, setMessages] = useState<Message[]>([])

 // scroll restoration للمحادثة
 usePageCache(`conversation-${conversationId}`, {
 backgroundSyncInterval: 0, // لا مزامنة دورية (البث المباشر موجود)
 })
 const [reactionsMap, setReactionsMap] = useState<Record<string, ReactionGroup[]>>({})
 const [reactionPickerFor, setReactionPickerFor] = useState<string | null>(null)
 const [pickerAnchor, setPickerAnchor] = useState<DOMRect | null>(null)
 const [otherParticipant, setOtherParticipant] = useState<Profile | null>(null)
 const [otherPresence, setOtherPresence] = useState<PresenceState | null>(null)
 const [isOtherTyping, setIsOtherTyping] = useState(false)
 const [loading, setLoading] = useState(true)
 const [sending, setSending] = useState(false)
 const [editingId, setEditingId] = useState<string | null>(null)
 const [editContent, setEditContent] = useState('')
 const [selectedMessageId, setSelectedMessageId] = useState<string | null>(null)
 const scrollRef = useRef<HTMLDivElement>(null)
 const fileInputRef = useRef<HTMLInputElement>(null)
 const [uploadingImage, setUploadingImage] = useState(false)
 const [pendingImageBlob, setPendingImageBlob] = useState<string | null>(null)

 // نظام المسودات التلقائية
 const draft = useMessageDraft(conversationId)
 const newMessage = draft.content
 const setNewMessage = draft.setContent

 // تحميل الصورة المعلّقة من المسودة (إن وُجدت)
 useEffect(() => {
 if (draft.pendingImageKey) {
 const blobUrl = getPendingImage(draft.pendingImageKey)
 if (blobUrl) {
 setPendingImageBlob(blobUrl)
 } else {
 // الصورة لم تعد متاحة (انتهت الجلسة)
 draft.setPendingImageKey(null)
 setPendingImageBlob(null)
 }
 }
 // eslint-disable-next-line react-hooks/exhaustive-deps
 }, [conversationId])

 // تنظيف الصورة المعلّقة عند مغادرة المحادثة
 useEffect(() => {
 return () => {
 if (draft.pendingImageKey) {
 // لا نحذف هنا لأن المستخدم قد يعود — نحذف فقط عند الإرسال أو الحذف اليدوي
 }
 }
 // eslint-disable-next-line react-hooks/exhaustive-deps
 }, [conversationId])

 // جلب الرسائل وبيانات الطرف الآخر
 const loadData = useCallback(async () => {
 if (!user || !conversationId) return
 try {
 // جلب المحادثة لمعرفة الطرف الآخر
 const { data: conv } = await supabase
 .from('conversations')
 .select('participant_1, participant_2')
 .eq('id', conversationId)
 .maybeSingle()

 if (!conv) {
 toast.error('المحادثة غير موجودة')
 router.replace('/messages')
 return
 }

 const otherId = conv.participant_1 === user.id ? conv.participant_2 : conv.participant_1
 const { data: otherProfile } = await supabase
 .from('profiles')
 .select('*')
 .eq('id', otherId)
 .maybeSingle()
 setOtherParticipant(otherProfile as Profile | null)

 // جلب الرسائل
 const msgs = await fetchMessages(conversationId)
 setMessages(msgs)

 // جلب ردود الأفعال لكل الرسائل
 if (msgs.length > 0) {
 const reactions = await fetchMessagesReactions(
 msgs.map((m) => m.id),
 user.id
 )
 setReactionsMap(reactions)
 }

 // تعليم كمقروء
 await markMessagesAsRead(conversationId, user.id)

 // تهيئة الـ presence للمستخدم الحالي
 initPresence(user.id)

 // الاشتراك في حالة حضور الطرف الآخر
 if (otherId) {
 const unsubscribePresence = subscribeToUserPresence(otherId, (state) => {
 setOtherPresence(state)
 })
 const unsubscribeTyping = subscribeToTyping(conversationId, otherId, (isTyping) => {
 setIsOtherTyping(isTyping)
 })

 // تنظيف عند مغادرة المحادثة
 // ملاحظة: استخدم window.__cleanup للتنظيف في useEffect آخر
 ;(window as unknown as { __presenceCleanup?: () => void }).__presenceCleanup = () => {
 unsubscribePresence()
 unsubscribeTyping()
 }
 }
 } catch (e) {
 // [removed in production] 'Load conversation error:', e
 } finally {
 setLoading(false)
 }
 }, [user, conversationId, router])

 useEffect(() => {
 void loadData()
 return () => {
 // تنظيف الـ presence عند مغادرة الصفحة
 const cleanup = (window as unknown as { __presenceCleanup?: () => void }).__presenceCleanup
 if (cleanup) {
 cleanup()
 delete (window as unknown as { __presenceCleanup?: () => void }).__presenceCleanup
 }
 // إيقاف حالة الكتابة عند المغادرة
 if (user) {
 void setTyping(null)
 }
 }
 }, [loadData, user])

 // تحديث حالة الكتابة عند كتابة رسالة
 useEffect(() => {
 if (!user) return
 // مؤقت: نرسل typing فقط إذا كان هناك محتوى
 if (newMessage.trim()) {
 void setTyping(conversationId)
 } else {
 // إذا أفرغ المستخدم الحقل، أوقف حالة الكتابة
 void setTyping(null)
 }
 // إيقاف حالة الكتابة بعد 3 ثوانٍ من آخر كتابة
 const timer = setTimeout(() => {
 if (!newMessage.trim()) {
 void setTyping(null)
 }
 }, 3000)
 return () => clearTimeout(timer)
 // eslint-disable-next-line react-hooks/exhaustive-deps
 }, [newMessage, conversationId, user])

 // البث المباشر للرسائل الجديدة
 useEffect(() => {
 if (!conversationId) return

 const channel = supabase
 .channel(`conversation-${conversationId}-realtime`)
 .on(
 'postgres_changes',
 {
 event: 'INSERT',
 schema: 'public',
 table: 'messages',
 filter: `conversation_id=eq.${conversationId}`,
 },
 async (payload) => {
 const newMsg = payload.new as Message
 // إزالة التكرار تلقائيًا عبر Map
 setMessages((prev) => {
 const map = new Map(prev.map((m) => [m.id, m]))
 map.set(newMsg.id, newMsg)
 return Array.from(map.values())
 })

 // تعليم كمقروء إذا لم يكن المرسل
 if (user && newMsg.sender_id !== user.id) {
 playSound('message')
 await markMessagesAsRead(conversationId, user.id)
 }
 }
 )
 .on(
 'postgres_changes',
 {
 event: 'UPDATE',
 schema: 'public',
 table: 'messages',
 filter: `conversation_id=eq.${conversationId}`,
 },
 (payload) => {
 const updated = payload.new as Message
 setMessages((prev) => prev.map((m) => (m.id === updated.id ? updated : m)))
 }
 )
 .subscribe()

 return () => {
 void supabase.removeChannel(channel)
 }
 }, [conversationId, user, playSound])

 // التمرير للأسفل عند وصول رسالة جديدة
 useEffect(() => {
 if (scrollRef.current) {
 scrollRef.current.scrollTop = scrollRef.current.scrollHeight
 }
 }, [messages])

 const handleSend = async () => {
 if (!user) return
 if (!newMessage.trim() && !pendingImageBlob) return

 setSending(true)
 let imageUrl: string | null = null

 // رفع الصورة أولاً إن وُجدت
 if (pendingImageBlob) {
 try {
 // تحويل blob URL إلى File
 const response = await fetch(pendingImageBlob)
 const blob = await response.blob()
 const file = new File([blob], `msg-${Date.now()}.jpg`, { type: blob.type || 'image/jpeg' })
 const uploadResult = await uploadMessageImage(user.id, file)
 if (uploadResult.url) {
 imageUrl = uploadResult.url
 } else {
 toast.error(uploadResult.error || 'تعذّر رفع الصورة')
 setSending(false)
 return
 }
 } catch (e) {
 // [removed in production] 'Image upload error:', e
 toast.error('تعذّر رفع الصورة')
 setSending(false)
 return
 }
 }

 const result = await sendMessage(conversationId, user.id, newMessage, imageUrl)
 if (result.success && result.message) {
 // إزالة التكرار تلقائيًا عبر Map
 setMessages((prev) => {
 const map = new Map(prev.map((m) => [m.id, m]))
 map.set(result.message!.id, result.message!)
 return Array.from(map.values())
 })
 // تنظيف المسودة والصورة المعلّقة
 draft.clearDraft()
 if (pendingImageBlob) {
 // تم رفع الصورة للخادم، لا حاجة للـ blob المحلي
 setPendingImageBlob(null)
 }
 playSound('send')
 // إيقاف حالة الكتابة بعد الإرسال
 void setTyping(null)
 } else {
 toast.error(result.error || 'تعذّر إرسال الرسالة')
 }
 setSending(false)
 }

 // اختيار صورة من الجهاز
 const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
 const file = e.target.files?.[0]
 if (!file || !user) return

 // التحقق من النوع
 if (!file.type.startsWith('image/')) {
 toast.error('الملف يجب أن يكون صورة')
 return
 }
 if (file.type === 'image/svg+xml') {
 toast.error('صور SVG غير مسموحة')
 return
 }
 if (file.size > 5 * 1024 * 1024) {
 toast.error('حجم الصورة يجب ألا يتجاوز 5 ميجابايت')
 return
 }

 // إنشاء blob URL وعرضه
 const blobUrl = URL.createObjectURL(file)
 setPendingImageBlob(blobUrl)

 // حفظ الـ blob URL في الـ pending images
 const key = `msg-${conversationId}-${Date.now()}`
 setPendingImage(key, blobUrl)
 draft.setPendingImageKey(key)

 // إفراغ حقل الملف
 if (fileInputRef.current) fileInputRef.current.value = ''
 }

 // إزالة الصورة المعلّقة
 const handleRemovePendingImage = () => {
 if (draft.pendingImageKey) {
 clearPendingImage(draft.pendingImageKey)
 }
 draft.setPendingImageKey(null)
 setPendingImageBlob(null)
 }

 const handleEdit = async (messageId: string) => {
 if (!editContent.trim() || !user) return
 const result = await editMessage(messageId, user.id, editContent)
 if (result.success) {
 setMessages((prev) =>
 prev.map((m) =>
 m.id === messageId
 ? { ...m, content: editContent.trim(), is_edited: true, edited_at: new Date().toISOString() }
 : m
 )
 )
 setEditingId(null)
 setEditContent('')
 toast.success('تم تعديل الرسالة')
 } else {
 toast.error(result.error || 'تعذّر التعديل')
 }
 }

 const handleDelete = async (messageId: string) => {
 if (!user) return
 const result = await deleteMessage(messageId, user.id)
 if (result.success) {
 setMessages((prev) =>
 prev.map((m) =>
 m.id === messageId
 ? { ...m, is_deleted: true, content: '[تم حذف هذه الرسالة]', deleted_at: new Date().toISOString() }
 : m
 )
 )
 toast.success('تم حذف الرسالة')
 } else {
 toast.error(result.error || 'تعذّر الحذف')
 }
 setSelectedMessageId(null)
 }

 const handleCopy = (content: string) => {
 void navigator.clipboard?.writeText(content)
 toast.success('تم نسخ النص')
 setSelectedMessageId(null)
 }

 // تبديل رد فعل على رسالة
 const handleReactionToggle = async (messageId: string, emoji: ReactionEmoji) => {
 if (!user) return
 // تحديث متفائل: ابحث عن رد الفعل الحالي
 const current = reactionsMap[messageId] || []
 const existingGroup = current.find((g) => g.reactedByMe)
 const targetGroup = current.find((g) => g.emoji === emoji)

 // نسخة محدّثة للـ UI فوراً
 let updatedGroups: ReactionGroup[] = []
 if (existingGroup && existingGroup.emoji === emoji) {
 // نفس الـ emoji — إزالة
 updatedGroups = current
 .map((g) =>
 g.emoji === emoji
 ? { ...g, count: g.count - 1, reactedByMe: false, userIds: g.userIds.filter((id) => id !== user.id) }
 : g
 )
 .filter((g) => g.count > 0)
 } else if (existingGroup) {
 // رد فعل مختلف — تغيير
 updatedGroups = current
 .map((g) => {
 if (g.emoji === existingGroup.emoji) {
 return { ...g, count: g.count - 1, reactedByMe: false, userIds: g.userIds.filter((id) => id !== user.id) }
 }
 if (g.emoji === emoji) {
 return { ...g, count: g.count + 1, reactedByMe: true, userIds: [...g.userIds, user.id] }
 }
 return g
 })
 .filter((g) => g.count > 0)
 // إذا لم يكن الـ emoji موجوداً، أضفه
 if (!targetGroup) {
 updatedGroups.push({
 emoji,
 count: 1,
 reactedByMe: true,
 userIds: [user.id],
 })
 }
 } else {
 // لا يوجد رد فعل — إضافة جديد
 updatedGroups = targetGroup
 ? current.map((g) =>
 g.emoji === emoji
 ? { ...g, count: g.count + 1, reactedByMe: true, userIds: [...g.userIds, user.id] }
 : g
 )
 : [...current, { emoji, count: 1, reactedByMe: true, userIds: [user.id] }]
 }

 updatedGroups.sort((a, b) => b.count - a.count)
 setReactionsMap((prev) => ({ ...prev, [messageId]: updatedGroups }))
 playSound('like')

 // إرسال للخادم
 const result = await toggleMessageReaction(messageId, user.id, emoji)
 if (!result.success) {
 toast.error(result.error || 'تعذّر إضافة رد الفعل')
 // إعادة التحميل لاستعادة الحالة الصحيحة
 const freshReactions = await fetchMessagesReactions([messageId], user.id)
 setReactionsMap((prev) => ({ ...prev, ...freshReactions }))
 }
 }

 // فتح picker للرسالة
 const handleOpenReactionPicker = (messageId: string, e: React.MouseEvent) => {
 const rect = (e.currentTarget as HTMLElement).getBoundingClientRect()
 setPickerAnchor(rect)
 setReactionPickerFor(messageId)
 }

 // الاشتراك في realtime لردود الأفعال
 useEffect(() => {
 if (!conversationId) return

 const channel = supabase
 .channel(`message-reactions:${conversationId}`)
 .on(
 'postgres_changes',
 {
 event: '*',
 schema: 'public',
 table: 'message_reactions',
 },
 async () => {
 // إعادة جلب ردود الأفعال لكل الرسائل
 if (messages.length > 0 && user) {
 const fresh = await fetchMessagesReactions(
 messages.map((m) => m.id),
 user.id
 )
 setReactionsMap(fresh)
 }
 }
 )
 .subscribe()

 return () => {
 void supabase.removeChannel(channel)
 }
 }, [conversationId, messages, user])

 return (
 <div className="flex flex-col flex-1 min-h-0">
 {/* رأس المحادثة — عرض كامل */}
 <header className="flex-shrink-0 border-b border-foreground/8 bg-background/95 backdrop-blur-xl z-40" style={{ paddingTop: 'env(safe-area-inset-top, 0px)' }}>
 <div className="w-full px-3 py-2 flex items-center gap-2">
 <button
 onClick={() => router.push('/messages')}
 className="w-9 h-9 rounded-full hover:bg-foreground/5 flex items-center justify-center transition-colors flex-shrink-0"
 aria-label="رجوع"
 >
 <ArrowLeft className="w-[18px] h-[18px]" />
 </button>

 {/* معلومات الطرف الآخر */}
 <div className="flex items-center gap-2 flex-1 min-w-0">
 <div className="relative flex-shrink-0">
 {otherParticipant?.avatar_url ? (
 <img
 src={otherParticipant.avatar_url}
 alt={otherParticipant.display_name || otherParticipant.username || 'مستخدم'}
 className="w-10 h-10 rounded-2xl object-cover"
 />
 ) : (
 <div
 className="w-10 h-10 rounded-2xl flex items-center justify-center text-white font-bold text-base"
 style={{
 background: `linear-gradient(135deg, ${otherParticipant?.avatar_color || '#FBBF24'} 0%, ${otherParticipant?.avatar_color || '#FBBF24'}aa 100%)`,
 }}
 >
 {(otherParticipant?.display_name || otherParticipant?.username || '؟').charAt(0).toUpperCase()}
 </div>
 )}
 {/* مؤشر حالة الاتصال */}
 {otherPresence?.status === 'online' && (
 <div className="absolute bottom-0 left-0 w-3 h-3 rounded-full bg-emerald-500 border-2 border-background" />
 )}
 {otherPresence?.status === 'away' && (
 <div className="absolute bottom-0 left-0 w-3 h-3 rounded-full bg-amber-500 border-2 border-background" />
 )}
 </div>
 <div className="min-w-0">
 <div className="text-sm font-bold truncate flex items-center gap-1">
 <span className="truncate">{otherParticipant?.display_name || otherParticipant?.username || 'مستخدم'}</span>
 {otherParticipant?.is_verified && (
 <VerifiedBadgeMini type={otherParticipant.verified_type} />
 )}
 </div>
 {/* حالة الاتصال أو الكتابة */}
 {isOtherTyping ? (
 <div className="text-[11px] text-sky-500 font-semibold flex items-center gap-1">
 يكتب الآن
 <span className="flex gap-0.5">
 {[0, 1, 2].map((i) => (
 <span key={i} className="w-1 h-1 rounded-full bg-sky-500 animate-pulse" style={{ animationDelay: `${i * 0.15}s` }} />
 ))}
 </span>
 </div>
 ) : otherPresence?.status === 'online' ? (
 <div className="text-[11px] text-emerald-500 flex items-center gap-1">
 <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
 متصل الآن
 </div>
 ) : otherPresence?.status === 'away' ? (
 <div className="text-[11px] text-amber-500">بعيد</div>
 ) : (
 <div className="text-[11px] text-muted-foreground" dir="ltr">
 @{otherParticipant?.username || 'unknown'}
 </div>
 )}
 </div>
 </div>
 </div>
 </header>

 {/* الرسائل — عرض كامل */}
 <div ref={scrollRef} data-scroll-area className="flex-1 overflow-y-auto overscroll-y-contain">
 <div className="w-full px-3 py-3 space-y-2">
 {loading ? (
 <div className="space-y-2">
 {Array.from({ length: 5 }).map((_, i) => (
 <div key={i} className="rounded-2xl bg-foreground/5 p-3 h-12 mishri-shimmer" />
 ))}
 </div>
 ) : messages.length === 0 ? (
 <div className="text-center py-16">
 <p className="text-sm text-muted-foreground">لا توجد رسائل بعد. ابدأ المحادثة!</p>
 </div>
 ) : (
 messages.map((msg, i) => (
 <MessageBubble
 key={msg.id}
 message={msg}
 isMine={msg.sender_id === user?.id}
 showAvatar={i === 0 || messages[i - 1].sender_id !== msg.sender_id}
 otherParticipant={otherParticipant}
 editingId={editingId}
 editContent={editContent}
 setEditContent={setEditContent}
 reactions={reactionsMap[msg.id] || []}
 onReactionToggle={(emoji) => handleReactionToggle(msg.id, emoji)}
 onOpenReactionPicker={(e) => handleOpenReactionPicker(msg.id, e)}
 onEdit={() => {
 setEditingId(msg.id)
 setEditContent(msg.content)
 }}
 onSaveEdit={() => handleEdit(msg.id)}
 onCancelEdit={() => {
 setEditingId(null)
 setEditContent('')
 }}
 onDelete={() => handleDelete(msg.id)}
 onCopy={() => handleCopy(msg.content)}
 isSelected={selectedMessageId === msg.id}
 onSelect={() => setSelectedMessageId(selectedMessageId === msg.id ? null : msg.id)}
 />
 ))
 )}
 </div>
 </div>

 {/* picker لردود الأفعال */}
 <ReactionPicker
 open={!!reactionPickerFor}
 onClose={() => {
 setReactionPickerFor(null)
 setPickerAnchor(null)
 }}
 onSelect={(emoji) => {
 if (reactionPickerFor) {
 void handleReactionToggle(reactionPickerFor, emoji)
 }
 }}
 anchorRect={pickerAnchor}
 />

 {/* صندوق الكتابة */}
 <div className="flex-shrink-0 border-t border-foreground/8 bg-background/95 backdrop-blur-xl" style={{ paddingBottom: 'env(safe-area-inset-bottom, 0px)' }}>
 <div className="w-full px-3 py-2.5">
 {/* معاينة الصورة المعلّقة */}
 
 {pendingImageBlob && (
 <div
 className="mb-2 relative inline-block"
 >
 <div className="relative rounded-2xl overflow-hidden">
 <img
 src={pendingImageBlob}
 alt="صورة معلّقة"
 className="w-32 h-32 object-cover"
 />
 <button
 onClick={handleRemovePendingImage}
 className="absolute top-1 right-1 w-6 h-6 rounded-full bg-black/60 backdrop-blur-md text-white flex items-center justify-center"
 aria-label="إزالة الصورة"
 >
 <X className="w-3 h-3" />
 </button>
 {uploadingImage && (
 <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
 <Loader2 className="w-5 h-5 text-white animate-spin" />
 </div>
 )}
 </div>
 </div>
 )}
 

 {/* مؤشر المسودة المحفوظة */}
 {newMessage.trim() && !sending && (
 <div className="text-[10px] text-muted-foreground/60 mb-1 px-2 flex items-center gap-1">
 <span className="w-1 h-1 rounded-full bg-emerald-500 mishri-pulse" />
 مسودة محفوظة تلقائياً
 </div>
 )}

 {/* حقل الإدخال */}
 <input
 ref={fileInputRef}
 type="file"
 accept="image/png,image/jpeg,image/webp,image/gif"
 onChange={handleImageSelect}
 className="hidden"
 />
 <div className="flex items-center gap-2">
 {/* زر إرفاق صورة */}
 <button
 onClick={() => fileInputRef.current?.click()}
 disabled={sending || !user || uploadingImage}
 className="w-9 h-9 rounded-xl bg-foreground/5 flex items-center justify-center flex-shrink-0 mishri-press disabled:opacity-50"
 aria-label="إرفاق صورة"
 >
 {uploadingImage ? (
 <Loader2 className="w-[18px] h-[18px] animate-spin text-amber-500" />
 ) : (
 <ImageIcon className="w-[18px] h-[18px] text-amber-500" />
 )}
 </button>

 <MentionsInput
 value={newMessage}
 onChange={setNewMessage}
 onSend={handleSend}
 placeholder="اكتب رسالة..."
 className="flex-1 rounded-2xl"
 maxLength={4000}
 disabled={sending || !user}
 />

 <button
 onClick={handleSend}
 disabled={sending || (!newMessage.trim() && !pendingImageBlob)}
 className="w-9 h-9 rounded-full mishri-gradient-primary text-white shadow-md mishri-glow-soft disabled:opacity-40 flex items-center justify-center flex-shrink-0"
 aria-label="إرسال"
 >
 {sending ? (
 <div
 >
 <Send className="w-[18px] h-[18px]" />
 </div>
 ) : (
 <Send className="w-[18px] h-[18px]" />
 )}
 </button>
 </div>
 </div>
 </div>
 </div>
 )
}

// ========================================
// مكون: فقاعة رسالة
// ========================================
function MessageBubble({
 message,
 isMine,
 showAvatar,
 otherParticipant,
 editingId,
 editContent,
 setEditContent,
 onEdit,
 onSaveEdit,
 onCancelEdit,
 onDelete,
 onCopy,
 isSelected,
 onSelect,
 reactions,
 onReactionToggle,
 onOpenReactionPicker,
}: {
 message: Message
 isMine: boolean
 showAvatar: boolean
 otherParticipant: Profile | null
 editingId: string | null
 editContent: string
 setEditContent: (v: string) => void
 onEdit: () => void
 onSaveEdit: () => void
 onCancelEdit: () => void
 onDelete: () => void
 onCopy: () => void
 isSelected: boolean
 onSelect: () => void
 reactions: ReactionGroup[]
 onReactionToggle: (emoji: ReactionEmoji) => void
 onOpenReactionPicker: (e: React.MouseEvent) => void
}) {
 const isEditing = editingId === message.id

 return (
 <div className={`flex gap-2 ${isMine ? 'flex-row-reverse' : 'flex-row'}`}>
 {/* الصورة الرمزية */}
 <div className="w-8 flex-shrink-0">
 {showAvatar && !isMine && (
 <div
 className="w-8 h-8 rounded-xl flex items-center justify-center text-white text-xs font-bold"
 style={{
 background: `linear-gradient(135deg, ${otherParticipant?.avatar_color || '#FBBF24'} 0%, ${otherParticipant?.avatar_color || '#FBBF24'}aa 100%)`,
 }}
 >
 {(otherParticipant?.display_name || otherParticipant?.username || '؟').charAt(0).toUpperCase()}
 </div>
 )}
 </div>

 {/* الفقاعة */}
 <div
 className={`relative max-w-[75%] group ${isMine ? 'items-end' : 'items-start'}`}
 onClick={onSelect}
 >
 {isEditing ? (
 // وضع التعديل
 <div className="rounded-2xl bg-foreground/5 p-2 flex flex-col gap-2">
 <input
 type="text"
 value={editContent}
 onChange={(e) => setEditContent(e.target.value)}
 onKeyDown={(e) => {
 if (e.key === 'Enter') onSaveEdit()
 if (e.key === 'Escape') onCancelEdit()
 }}
 autoFocus
 className="mishri-input rounded-xl px-3 py-2 text-sm outline-none"
 maxLength={4000}
 />
 <div className="flex gap-2 justify-end">
 <button
 onClick={onSaveEdit}
 className="px-3 py-1 rounded-lg mishri-gradient-primary text-white text-xs font-semibold"
 >
 حفظ
 </button>
 <button
 onClick={onCancelEdit}
 className="px-3 py-1 rounded-lg bg-foreground/5 text-muted-foreground text-xs font-semibold"
 >
 إلغاء
 </button>
 </div>
 </div>
 ) : (
 <div
 className={`rounded-2xl px-3.5 py-2.5 ${
 isMine
 ? 'mishri-gradient-primary text-white rounded-tl-md'
 : 'rounded-xl bg-foreground/5 text-foreground rounded-tr-md'
 } ${message.is_deleted ? 'opacity-60 italic' : ''}`}
 >
 {/* عرض الصورة */}
 {!message.is_deleted && message.image_url && (
 <div className="mb-2 -mx-1 -mt-1 rounded-xl overflow-hidden">
 <img
 src={message.image_url}
 alt="صورة"
 className="w-full max-w-[240px] max-h-[280px] object-cover cursor-pointer"
 loading="lazy"
 onClick={() => window.open(message.image_url || '', '_blank', 'noopener,noreferrer')}
 />
 </div>
 )}

 {/* عرض النص */}
 {message.is_deleted || (message.content && message.content.trim()) ? (
 <p className="text-sm leading-relaxed break-words whitespace-pre-wrap">
 {message.is_deleted ? (
 message.content
 ) : (
 <MentionText
 text={message.content}
 mentionClassName={isMine ? 'text-amber-100' : 'text-amber-500'}
 />
 )}
 </p>
 ) : null}

 {/* المؤشرات */}
 <div className={`flex items-center gap-1 mt-1 ${isMine ? 'justify-start' : 'justify-end'}`}>
 <span className="text-[9px] opacity-60">
 {formatMessageTime(message.created_at)}
 </span>
 {message.is_edited && !message.is_deleted && (
 <span className="text-[9px] opacity-50">· تم التعديل</span>
 )}
 {isMine && !message.is_deleted && (
 message.read_at ? (
 <CheckCheck className="w-3 h-3 opacity-60" />
 ) : (
 <Check className="w-3 h-3 opacity-60" />
 )
 )}
 </div>
 </div>
 )}

 {/* قائمة الإجراءات */}
 
 {isSelected && !isEditing && !message.is_deleted && (
 <div
 className={`absolute ${isMine ? 'left-0' : 'right-0'} -top-10 flex gap-1 z-10`}
 >
 <button
 onClick={onOpenReactionPicker}
 className="w-8 h-8 rounded-lg rounded-xl bg-foreground/5 shadow-md flex items-center justify-center text-muted-foreground hover:text-amber-500"
 aria-label="رد فعل"
 >
 <Smile className="w-3.5 h-3.5" />
 </button>
 <button
 onClick={onCopy}
 className="w-8 h-8 rounded-lg rounded-xl bg-foreground/5 shadow-md flex items-center justify-center text-muted-foreground hover:text-amber-500"
 aria-label="نسخ"
 >
 <Copy className="w-3.5 h-3.5" />
 </button>
 {isMine && (
 <>
 <button
 onClick={onEdit}
 className="w-8 h-8 rounded-lg rounded-xl bg-foreground/5 shadow-md flex items-center justify-center text-muted-foreground hover:text-amber-500"
 aria-label="تعديل"
 >
 <Edit2 className="w-3.5 h-3.5" />
 </button>
 <button
 onClick={onDelete}
 className="w-8 h-8 rounded-lg rounded-xl bg-foreground/5 shadow-md flex items-center justify-center text-muted-foreground hover:text-rose-500"
 aria-label="حذف"
 >
 <Trash2 className="w-3.5 h-3.5" />
 </button>
 </>
 )}
 </div>
 )}
 

 {/* عرض ردود الأفعال */}
 {!message.is_deleted && reactions.length > 0 && (
 <ReactionsDisplay
 reactions={reactions}
 onReactionClick={onReactionToggle}
 isMine={isMine}
 />
 )}
 </div>
 </div>
 )
}

function formatMessageTime(dateStr: string): string {
 const date = new Date(dateStr)
 return date.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })
}
