'use client'

import { useState, useEffect, useCallback, useRef } from 'react'
import { Settings, Grid3x3, Heart, Calendar, ArrowLeft, Share2, Camera, Loader2, Search, MessageCircle, MoreHorizontal, Flag, Ban, X, Bookmark, Clock, Pin, Link2 } from 'lucide-react'
import { useRouter } from 'next/navigation'
import { supabase, type Profile, type Post } from '@/lib/supabase/client'
import { useAppStore } from '@/store/app-store'
import { updateProfile } from '@/lib/supabase/auth'
import { uploadAvatar } from '@/lib/supabase/storage'
import { useNotificationSound } from '@/hooks/use-sound'
import { PostCard } from './PostCard'
import { ImageEditor } from './ImageEditor'
import { ReportModal, BlockConfirmModal } from './ReportModal'
import { VerifiedBadge } from './VerifiedBadge'
import { fetchSavedPosts } from '@/lib/reposts'
import { formatLastSeen, shouldShowLastSeen } from '@/lib/last-seen'
import { toast } from 'sonner'

interface ProfilePageProps {
 username?: string
}

export function ProfilePage({ username }: ProfilePageProps) {
 const user = useAppStore((s) => s.user)
 const setUser = useAppStore((s) => s.setUser)
 const router = useRouter()
 const { playSound } = useNotificationSound()
 const fileInputRef = useRef<HTMLInputElement>(null)

 const [profile, setProfile] = useState<Profile | null>(null)
 const [posts, setPosts] = useState<Post[]>([])
 const [pinnedPost, setPinnedPost] = useState<Post | null>(null)
 const [savedPosts, setSavedPosts] = useState<Post[]>([])
 const [likedPosts, setLikedPosts] = useState<Post[]>([])
 const [loading, setLoading] = useState(true)
 const [tab, setTab] = useState<'posts' | 'saved' | 'likes'>('posts')
 const [isFollowing, setIsFollowing] = useState(false)
 const [uploadingAvatar, setUploadingAvatar] = useState(false)
 const [showMoreMenu, setShowMoreMenu] = useState(false)
 const [showReportModal, setShowReportModal] = useState(false)
 const [showBlockModal, setShowBlockModal] = useState(false)
 const [pendingAvatarFile, setPendingAvatarFile] = useState<File | null>(null)

 const isOwnProfile = !username || username === user?.username
 const targetUsername = username || user?.username
 const [isBlockedByMe, setIsBlockedByMe] = useState(false)

 const loadProfile = useCallback(async () => {
 if (!targetUsername) {
 setLoading(false)
 return
 }
 const { data, error } = await supabase
 .from('profiles')
 .select('*')
 .eq('username', targetUsername)
 .maybeSingle()
 if (error) {
 toast.error('تعذّر تحميل الملف الشخصي')
 setLoading(false)
 return
 }
 setProfile(data)
 if (!isOwnProfile && user && data) {
 // فحص الحجب: هل حجبتُ هذا المستخدم؟
 const { data: blockRow } = await supabase
 .from('blocks')
 .select('blocked_id')
 .eq('blocker_id', user.id)
 .eq('blocked_id', data.id)
 .maybeSingle()
 if (blockRow) {
 setIsBlockedByMe(true)
 setLoading(false)
 return
 }

 const { data: follow } = await supabase
 .from('follows')
 .select('id')
 .match({ follower_id: user.id, following_id: data.id })
 .maybeSingle()
 setIsFollowing(!!follow)
 }
 }, [targetUsername, isOwnProfile, user])

 const loadPosts = useCallback(async () => {
 if (!profile?.id) return
 setLoading(true)
 const { data, error } = await supabase
 .from('posts')
 .select('*, profile:profiles(*)')
 .eq('user_id', profile.id)
 .order('is_pinned', { ascending: false })
 .order('created_at', { ascending: false })
 if (error) {
 // [removed in production] error
 } else {
 const pinned = (data || []).find((p) => p.is_pinned) || null
 const regular = (data || []).filter((p) => !p.is_pinned)
 setPinnedPost(pinned)
 setPosts(regular)

 // تحميل المنشورات المحفوظة والمعجب بها (للملف الشخصي الخاص فقط)
 if (isOwnProfile && user) {
   // المنشورات المحفوظة
   try {
     const saved = await fetchSavedPosts(user.id)
     setSavedPosts(saved)
   } catch {}

   // المنشورات المعجب بها
   try {
     const { data: likedData } = await supabase
       .from('likes')
       .select(`
         post:posts!likes_post_id_fkey(*)
       `)
       .eq('user_id', user.id)
       .order('created_at', { ascending: false })
       .limit(60)
     if (likedData) {
       const liked = likedData
         .map((item: any) => item.post)
         .filter(Boolean) as Post[]
       setLikedPosts(liked)
     }
   } catch {}
 }
 }
 setLoading(false)
 }, [profile?.id, isOwnProfile, user])

 useEffect(() => {
 if (!targetUsername) return
 let cancelled = false
 void (async () => {
 await loadProfile()
 if (!cancelled) await loadPosts()
 })()
 return () => { cancelled = true }
 }, [targetUsername, loadProfile, loadPosts])

 const handleFollow = async () => {
 if (!user || !profile) return
 const wasFollowing = isFollowing
 setIsFollowing(!wasFollowing)
 setProfile((p) => p ? { ...p, followers_count: Math.max(0, (p.followers_count || 0) + (wasFollowing ? -1 : 1)) } : p)
 try {
 if (wasFollowing) {
 const { error } = await supabase.from('follows').delete().match({ follower_id: user.id, following_id: profile.id })
 if (error && !error.message.includes('Could not find')) throw error
 toast.success('تم إلغاء المتابعة')
 } else {
 const { error } = await supabase.from('follows').insert({ follower_id: user.id, following_id: profile.id })
 if (error && !error.message.includes('duplicate')) throw error
 toast.success(`تتابع ${profile.display_name || profile.username} الآن`)
 }
 } catch (err) {
 setIsFollowing(wasFollowing)
 setProfile((p) => p ? { ...p, followers_count: Math.max(0, (p.followers_count || 0) + (wasFollowing ? 1 : -1)) } : p)
 toast.error('تعذّر تحديث المتابعة')
 }
 }

 const handleMessage = async () => {
 if (!user || !profile) return
 try {
 const { getOrCreateConversation, sendMessageRequest } = await import('@/lib/messaging')
 const result = await getOrCreateConversation(user.id, profile.id)
 if (result.conversationId) {
 router.push(`/messages/${result.conversationId}`)
 } else if (result.needsRequest) {
 const reqResult = await sendMessageRequest(user.id, profile.id)
 if (reqResult.success) toast.success('تم إرسال طلب المراسلة')
 else toast.error(reqResult.error || 'تعذّر إرسال الطلب')
 }
 } catch (e) {
 toast.error('حدث خطأ')
 }
 }

 const handleAvatarSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
 const file = e.target.files?.[0]
 if (!file || !user) return
 setPendingAvatarFile(file)
 if (fileInputRef.current) fileInputRef.current.value = ''
 }

 const handleAvatarEditSave = async (result: { blob: Blob; url: string }) => {
 if (!user) return
 setPendingAvatarFile(null)
 setUploadingAvatar(true)
 try {
 const editedFile = new File([result.blob], 'avatar.jpg', { type: 'image/jpeg' })
 const uploadResult = await uploadAvatar(user.id, editedFile)
 if (uploadResult.url) {
 const updateResult = await updateProfile({ avatar_url: uploadResult.url })
 if (updateResult.success) {
 const updatedProfile = { ...profile, avatar_url: uploadResult.url } as Profile
 setProfile(updatedProfile)
 setUser({ ...user, avatar_url: uploadResult.url })
 playSound('success')
 toast.success('تم تحديث صورة الملف الشخصي')
 }
 }
 } catch (err) {
 toast.error('حدث خطأ أثناء الرفع')
 } finally {
 setUploadingAvatar(false)
 }
 }

 if (!profile && !loading) {
 return (
 <div className="flex flex-col items-center justify-center flex-1">
 <div className="w-16 h-16 mx-auto mb-4 rounded-2xl rounded-xl bg-foreground/5 flex items-center justify-center">
 <Search className="w-7 h-7 text-muted-foreground" />
 </div>
 <p className="text-sm text-muted-foreground mb-4">المستخدم غير موجود</p>
 <button onClick={() => router.back()} className="px-4 py-2 rounded-xl bg-foreground/5 text-sm font-semibold mishri-press">رجوع</button>
 </div>
 )
 }

 // شاشة المحجوب — تظهر عند محاولة فتح ملف مستخدم محجوب
 if (isBlockedByMe && profile) {
 return (
 <div className="flex flex-col flex-1">
 <div className="flex-shrink-0 flex items-center justify-between px-4 py-2 safe-top border-b border-foreground/8 bg-background/80 backdrop-blur-xl">
 <button onClick={() => router.back()} className="p-1.5 rounded-full hover:bg-foreground/5 mishri-press" aria-label="رجوع">
 <ArrowLeft className="w-[18px] h-[18px]" />
 </button>
 <span className="font-bold text-sm" dir="ltr">@{profile.username}</span>
 <div className="w-8 h-8" />
 </div>
 <div className="flex flex-col items-center justify-center flex-1 px-6 text-center">
 <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-rose-500/10 flex items-center justify-center">
 <Ban className="w-10 h-10 text-rose-500" />
 </div>
 <h2 className="font-bold text-base mb-2">قمت بحجب هذا المستخدم</h2>
 <p className="text-sm text-muted-foreground mb-6 leading-relaxed max-w-xs">
 لن تتمكن من رؤية منشوراته أو ملفه الشخصي. يمكنك إلغاء الحجب من الإعدادات ← المستخدمون المحجوبون.
 </p>
 <button
 onClick={() => router.push('/settings')}
 className="px-5 py-2 rounded-xl mishri-gradient-primary text-white text-sm font-bold mishri-press"
 >
 إدارة المحجوبين
 </button>
 </div>
 </div>
 )
 }

 const joinDate = profile ? new Date(profile.created_at).toLocaleDateString('ar-EG', { month: 'long', year: 'numeric' }) : ''

 return (
 <div className="flex flex-col flex-1 min-h-0">
 <input type="file" ref={fileInputRef} accept="image/png,image/jpeg,image/webp" onChange={handleAvatarSelect} className="hidden" />

 {/* شريط علوي رفيع */}
 <div className="flex-shrink-0 flex items-center justify-between px-4 py-2 safe-top border-b border-foreground/8 bg-background/80 backdrop-blur-xl">
 <button onClick={() => router.back()} className="p-1.5 rounded-full hover:bg-foreground/5 mishri-press" aria-label="رجوع">
 <ArrowLeft className="w-[18px] h-[18px]" />
 </button>
 <div className="flex items-center gap-1">
 <span className="font-bold text-sm" dir="ltr">@{profile?.username}</span>
 {profile?.is_verified && <VerifiedBadge type={profile.verified_type} size="sm" />}
 </div>
 <div className="flex items-center gap-1">
 {isOwnProfile ? (
 <button onClick={() => router.push('/settings')} className="p-1.5 rounded-full hover:bg-foreground/5 mishri-press" aria-label="إعدادات">
 <Settings className="w-[18px] h-[18px]" />
 </button>
 ) : (
 <>
 <button onClick={handleShare} className="p-1.5 rounded-full hover:bg-foreground/5 mishri-press" aria-label="مشاركة">
 <Share2 className="w-[18px] h-[18px]" />
 </button>
 <button onClick={() => setShowMoreMenu(true)} className="p-1.5 rounded-full hover:bg-foreground/5 mishri-press" aria-label="المزيد">
 <MoreHorizontal className="w-[18px] h-[18px]" />
 </button>
 </>
 )}
 </div>
 </div>

 {/* محتوى قابل للتمرير */}
 <div data-scroll-area className="flex-1 overflow-y-auto overscroll-y-contain">
 <div className="max-w-md mx-auto px-4 pb-4">

 {/* الصورة الرمزية + الإحصائيات في صف واحد */}
 <div className="flex items-center gap-6 mb-4">
 {/* الصورة */}
 <div className="relative flex-shrink-0">
 {profile?.avatar_url ? (
 <img src={profile.avatar_url} alt={profile.display_name || profile.username || 'مستخدم'} className="w-20 h-20 rounded-full object-cover ring-2 ring-foreground/10" />
 ) : (
 <div className="w-20 h-20 rounded-full flex items-center justify-center text-white text-3xl font-bold" style={{ background: `linear-gradient(135deg, ${profile?.avatar_color || '#FBBF24'} 0%, ${profile?.avatar_color || '#FBBF24'}aa 100%)` }}>
 {(profile?.display_name || profile?.username || '؟').charAt(0).toUpperCase()}
 </div>
 )}
 {isOwnProfile && (
 <button onClick={() => fileInputRef.current?.click()} disabled={uploadingAvatar} className="absolute bottom-0 right-0 w-7 h-7 rounded-full bg-foreground text-background flex items-center justify-center border-2 border-background" aria-label="تغيير الصورة">
 {uploadingAvatar ? <Loader2 className="w-3 h-3 animate-spin" /> : <Camera className="w-3 h-3" />}
 </button>
 )}
 </div>

 {/* الإحصائيات */}
 <div className="flex-1 flex justify-around">
 <StatItem value={profile?.posts_count || 0} label="منشور" />
 <StatItem value={profile?.followers_count || 0} label="متابع" />
 <StatItem value={profile?.following_count || 0} label="متابِع" />
 </div>
 </div>

 {/* الاسم + النبذة */}
 <div className="mb-3">
 <div className="flex items-center gap-1.5 mb-0.5">
 <h1 className="font-bold text-base">{profile?.display_name || profile?.username}</h1>
 {profile?.is_verified && <VerifiedBadge type={profile.verified_type} size="sm" />}
 </div>
 {profile?.bio && (
 <p className="text-sm text-foreground/80 leading-snug whitespace-pre-wrap break-words">{profile.bio}</p>
 )}
 <div className="flex items-center gap-1 mt-1 text-[11px] text-muted-foreground">
 <Calendar className="w-3 h-3" />
 انضم في {joinDate}
 </div>
 {!isOwnProfile && profile && shouldShowLastSeen(profile) && (
 <div className="flex items-center gap-1 mt-0.5 text-[11px] text-muted-foreground">
 <Clock className="w-3 h-3" />
 {formatLastSeen(profile.last_seen)}
 </div>
 )}
 {/* مستوى السمعة */}
 {profile && profile.reputation_level > 1 && (
 <div className="flex items-center gap-1 mt-1.5">
 <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-600 dark:text-amber-400">
 مستوى {profile.reputation_level} • {profile.reputation_points} نقطة
 </span>
 </div>
 )}
 </div>

 {/* أزرار الإجراء */}
 {isOwnProfile ? (
 <button onClick={() => router.push('/settings')} className="w-full mb-4 py-2 rounded-lg bg-foreground/5 hover:bg-foreground/10 text-sm font-semibold transition-colors mishri-press">
 تعديل الملف
 </button>
 ) : (
 <div className="flex gap-2 mb-4">
 <button onClick={handleFollow} className={`flex-1 py-2 rounded-lg text-sm font-bold transition-all mishri-press ${isFollowing ? 'bg-foreground/5 hover:bg-foreground/10' : 'mishri-gradient-primary text-white'}`}>
 {isFollowing ? 'تتابعه' : 'متابعة'}
 </button>
 <button onClick={handleMessage} className="px-4 py-2 rounded-lg bg-foreground/5 hover:bg-foreground/10 text-sm font-bold mishri-press">
 مراسلة
 </button>
 </div>
 )}

 {/* المنشور المثبت */}
 {pinnedPost && tab === 'posts' && (
 <div className="mb-3">
 <div className="flex items-center gap-1 mb-1.5 px-1">
 <Pin className="w-3 h-3 fill-amber-500 text-amber-500" />
 <span className="text-[10px] font-bold text-amber-600 dark:text-amber-400">مثبّت</span>
 </div>
 <PostCard post={pinnedPost} profile={pinnedPost.profile as Profile} />
 </div>
 )}

 {/* تبويبات */}
 <div className="flex border-t border-foreground/10">
 <button onClick={() => setTab('posts')} className={`flex-1 py-3 flex items-center justify-center border-t-2 -mt-px transition-colors ${tab === 'posts' ? 'border-foreground text-foreground' : 'border-transparent text-muted-foreground'}`}>
 <Grid3x3 className="w-5 h-5" />
 </button>
 {isOwnProfile && (
 <button onClick={() => setTab('saved')} className={`flex-1 py-3 flex items-center justify-center border-t-2 -mt-px transition-colors ${tab === 'saved' ? 'border-foreground text-foreground' : 'border-transparent text-muted-foreground'}`}>
 <Bookmark className="w-5 h-5" />
 </button>
 )}
 {isOwnProfile && (
 <button onClick={() => setTab('likes')} className={`flex-1 py-3 flex items-center justify-center border-t-2 -mt-px transition-colors ${tab === 'likes' ? 'border-foreground text-foreground' : 'border-transparent text-muted-foreground'}`}>
 <Heart className="w-5 h-5" />
 </button>
 )}
 </div>

 {/* المحتوى */}
 {loading ? (
 <div className="grid grid-cols-3 gap-0.5 mt-0.5">
 {Array.from({ length: 6 }).map((_, i) => (
 <div key={i} className="aspect-square mishri-shimmer" />
 ))}
 </div>
 ) : tab === 'posts' ? (
 posts.length === 0 ? (
 <div className="text-center py-16">
 <Grid3x3 className="w-10 h-10 mx-auto mb-2 text-muted-foreground/30" />
 <p className="text-sm text-muted-foreground">لا توجد منشورات</p>
 </div>
 ) : (
 <div className="grid grid-cols-3 gap-0.5 mt-0.5">
 {posts.map((post) => (
 <PostGridItem key={post.id} post={post} onClick={() => router.push(`/post/${post.id}`)} />
 ))}
 </div>
 )
 ) : tab === 'saved' ? (
 savedPosts.length === 0 ? (
 <div className="text-center py-16">
 <Bookmark className="w-10 h-10 mx-auto mb-2 text-muted-foreground/30" />
 <p className="text-sm text-muted-foreground">لا توجد منشورات محفوظة</p>
 </div>
 ) : (
 <div className="grid grid-cols-3 gap-0.5 mt-0.5">
 {savedPosts.map((post) => (
 <PostGridItem key={post.id} post={post} onClick={() => router.push(`/post/${post.id}`)} />
 ))}
 </div>
 )
 ) : tab === 'likes' ? (
 likedPosts.length === 0 ? (
 <div className="text-center py-16">
 <Heart className="w-10 h-10 mx-auto mb-2 text-muted-foreground/30" />
 <p className="text-sm text-muted-foreground">لا توجد منشورات معجب بها</p>
 </div>
 ) : (
 <div className="grid grid-cols-3 gap-0.5 mt-0.5">
 {likedPosts.map((post) => (
 <PostGridItem key={post.id} post={post} onClick={() => router.push(`/post/${post.id}`)} />
 ))}
 </div>
 )
 ) : null}
 </div>
 </div>

 {/* محرر الصورة */}
 {pendingAvatarFile && (
 <ImageEditor file={pendingAvatarFile} aspectRatio={1} onSave={handleAvatarEditSave} onCancel={() => setPendingAvatarFile(null)} title="تحرير الصورة" />
 )}

 {/* قائمة المزيد */}
 {showMoreMenu && !isOwnProfile && profile && (
 <div className="fixed inset-0 z-[100] bg-black/50 flex items-end sm:items-center justify-center p-0 sm:p-6" onClick={() => setShowMoreMenu(false)}>
 <div className="relative w-full sm:max-w-xs rounded-t-2xl bg-background/95 sm:rounded-3xl p-2 transition-colors duration-200" onClick={(e) => e.stopPropagation()}>
 <div className="flex items-center justify-between px-3 py-2 mb-1">
 <h3 className="font-bold text-sm">خيارات</h3>
 <button onClick={() => setShowMoreMenu(false)} className="p-1.5 rounded-full hover:bg-foreground/5"><X className="w-4 h-4" /></button>
 </div>
 <button onClick={() => { setShowMoreMenu(false); setShowReportModal(true) }} className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-foreground/5 text-right">
 <Flag className="w-4 h-4 text-rose-500" /><span className="text-sm font-semibold text-rose-500">إبلاغ عن المستخدم</span>
 </button>
 <button onClick={() => { setShowMoreMenu(false); setShowBlockModal(true) }} className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-foreground/5 text-right">
 <Ban className="w-4 h-4 text-rose-500" /><span className="text-sm font-semibold text-rose-500">حجب المستخدم</span>
 </button>
 <button onClick={() => { setShowMoreMenu(false); handleShare() }} className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-foreground/5 text-right">
 <Link2 className="w-4 h-4 text-amber-500" /><span className="text-sm font-semibold">نسخ الرابط</span>
 </button>
 </div>
 </div>
 )}

 <ReportModal open={showReportModal} onClose={() => setShowReportModal(false)} targetType="profile" targetId={profile?.id || ''} reportedUserId={profile?.id || ''} reportedUserName={profile?.display_name || profile?.username} />
 <BlockConfirmModal open={showBlockModal} onClose={() => setShowBlockModal(false)} blockedUserId={profile?.id || ''} blockedUserName={profile?.display_name || profile?.username} onBlocked={() => { setIsFollowing(false); router.back() }} />
 </div>
 )

 function handleShare() {
 const url = window.location.href
 if (navigator.share) {
 navigator.share({ title: `${profile?.display_name || profile?.username} على KemetNet`, url })
 } else {
 navigator.clipboard?.writeText(url)
 toast.success('تم نسخ الرابط')
 }
 }
}

function StatItem({ value, label }: { value: number; label: string }) {
 return (
 <div className="text-center">
 <div className="font-bold text-base tabular-nums">{value.toLocaleString('ar-EG')}</div>
 <div className="text-xs text-muted-foreground">{label}</div>
 </div>
 )
}

function PostGridItem({ post, onClick }: { post: Post; onClick: () => void }) {
 return (
 <button onClick={onClick} className="aspect-square relative overflow-hidden bg-foreground/5 group">
 {post.image_url ? (
 <img src={post.image_url} alt="" className="w-full h-full object-cover" loading="lazy" />
 ) : (
 <div className="w-full h-full flex items-center justify-center p-2">
 <p className="text-[10px] text-muted-foreground line-clamp-4 text-center">{post.content}</p>
 </div>
 )}
 {/* overlay عند hover */}
 <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
 <div className="flex items-center gap-1 text-white">
 <Heart className="w-4 h-4 fill-white" />
 <span className="text-xs font-bold tabular-nums">{post.likes_count}</span>
 </div>
 <div className="flex items-center gap-1 text-white">
 <MessageCircle className="w-4 h-4 fill-white" />
 <span className="text-xs font-bold tabular-nums">{post.comments_count}</span>
 </div>
 </div>
 {post.is_pinned && (
 <div className="absolute top-1 right-1"><Pin className="w-3 h-3 fill-white text-white drop-shadow" /></div>
 )}
 </button>
 )
}
