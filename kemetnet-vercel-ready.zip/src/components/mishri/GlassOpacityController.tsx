'use client'

import { useEffect } from 'react'
import { useAppStore } from '@/store/app-store'

// مكون لتطبيق شفافية الزجاج ديناميكيًا عبر CSS variables
export function GlassOpacityController() {
 const glassOpacity = useAppStore((s) => s.glassOpacity)

 useEffect(() => {
 // تحويل النسبة (0-100) إلى alpha (0-1)
 const alpha = glassOpacity / 100
 document.documentElement.style.setProperty('--glass-alpha', alpha.toString())
 }, [glassOpacity])

 return null
}
