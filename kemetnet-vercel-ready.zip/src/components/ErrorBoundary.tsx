'use client'

import { Component, ReactNode } from 'react'
import { AlertTriangle, RefreshCw, Home, Bug } from 'lucide-react'

interface ErrorBoundaryProps {
  children: ReactNode
  fallback?: ReactNode
}

interface ErrorBoundaryState {
  hasError: boolean
  error?: Error
  errorInfo?: React.ErrorInfo
}

export class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props)
    this.state = { hasError: false }
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error }
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    // تسجيل الخطأ (في الإنتاج، يمكن إرساله لخدمة مراقبة مثل Sentry)
    // [removed in production] '[ErrorBoundary] caught:', error, errorInfo
    this.setState({ errorInfo })
  }

  handleReload = () => {
    this.setState({ hasError: false, error: undefined, errorInfo: undefined })
    window.location.reload()
  }

  handleGoHome = () => {
    this.setState({ hasError: false, error: undefined, errorInfo: undefined })
    window.location.href = '/home'
  }

  handleCopyError = () => {
    if (!this.state.error) return
    const errorText = `Error: ${this.state.error.message}\nStack: ${this.state.error.stack || 'N/A'}\nComponent Stack: ${this.state.errorInfo?.componentStack || 'N/A'}`
    navigator.clipboard?.writeText(errorText)
  }

  render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback
      }

      return (
        <div className="min-h-screen mishri-aurora-bg flex flex-col items-center justify-center px-6">
          <div
            className="text-center max-w-sm"
          >
            <div className="w-20 h-20 mx-auto mb-6 rounded-3xl bg-rose-500/15 flex items-center justify-center">
                <AlertTriangle className="w-10 h-10 text-rose-500" />
            </div>

            <h1 className="font-display text-2xl font-bold mb-2">
              حدث خطأ غير متوقع
            </h1>
            <p className="text-sm text-muted-foreground mb-6 leading-relaxed">
              نعتذر عن هذا الخطأ. يمكنك إعادة تحميل الصفحة أو العودة للرئيسية.
              تم تسجيل الخطأ تلقائياً.
            </p>

            {/* تفاصيل الخطأ (في dev mode فقط) */}
            {process.env.NODE_ENV === 'development' && this.state.error && (
              <div className="mishri-glass rounded-2xl p-3 mb-4 text-left">
                <div className="flex items-center gap-2 mb-2">
                  <Bug className="w-3.5 h-3.5 text-rose-500" />
                  <span className="text-[11px] font-bold text-rose-500">تفاصيل الخطأ (dev)</span>
                </div>
                <pre className="text-[10px] text-muted-foreground overflow-x-auto whitespace-pre-wrap break-all max-h-32 overflow-y-auto" dir="ltr">
                  {this.state.error.message}
                  {this.state.error.stack && '\n\n' + this.state.error.stack.slice(0, 500)}
                </pre>
                <button
                  onClick={this.handleCopyError}
                  className="mt-2 text-[10px] text-amber-500 hover:underline"
                >
                  نسخ الخطأ
                </button>
              </div>
            )}

            <div className="flex gap-2 justify-center">
              <button
                onClick={this.handleReload}
                className="px-4 py-2.5 rounded-xl mishri-gradient-primary text-white text-sm font-bold shadow-md mishri-glow-soft mishri-press flex items-center gap-2"
              >
                <RefreshCw className="w-4 h-4" />
                إعادة التحميل
              </button>
              <button
                onClick={this.handleGoHome}
                className="px-4 py-2.5 rounded-xl mishri-glass text-sm font-bold mishri-press flex items-center gap-2"
              >
                <Home className="w-4 h-4" />
                الرئيسية
              </button>
            </div>
          </div>
        </div>
      )
    }

    return this.props.children
  }
}
