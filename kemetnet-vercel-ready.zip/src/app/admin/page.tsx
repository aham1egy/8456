import { AdminPage } from "@/components/mishri/AdminPage";

export default function Page() {
  return <AdminPage />;
}
