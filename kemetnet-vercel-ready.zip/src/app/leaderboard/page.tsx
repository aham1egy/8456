'use client'

import { ProtectedLayout } from '@/components/mishri/ProtectedLayout'
import { LeaderboardPage } from '@/components/mishri/LeaderboardPage'

export default function LeaderboardRoute() {
  return (
    <ProtectedLayout>
      <LeaderboardPage />
    </ProtectedLayout>
  )
}
