import { Home, ArrowLeft } from 'lucide-react'
import { NotFoundClient } from '@/components/mishri/NotFoundClient'

export default function NotFound() {
  return <NotFoundClient />
}

export function NotFoundStatic() {
  return (
    <div className="min-h-screen mishri-aurora-bg flex flex-col items-center justify-center px-6">
      <div className="text-center">
        <div className="w-20 h-20 mx-auto mb-6 rounded-3xl mishri-glass flex items-center justify-center mishri-glow-soft">
          <span className="font-display text-3xl font-bold mishri-gradient-text">404</span>
        </div>
        <h1 className="font-display text-3xl font-bold mb-2 mishri-gradient-text">
          الصفحة غير موجودة
        </h1>
        <p className="text-sm text-muted-foreground mb-8 max-w-xs mx-auto leading-relaxed">
          عذرًا، الصفحة التي تبحث عنها غير موجودة أو تم نقلها.
        </p>
        <div className="flex gap-3 justify-center">
          <a
            href="/"
            className="px-5 py-2.5 rounded-xl mishri-gradient-primary text-white text-sm font-bold shadow-md mishri-glow-soft mishri-press flex items-center gap-2"
          >
            <Home className="w-4 h-4" />
            العودة للرئيسية
          </a>
        </div>
      </div>
    </div>
  )
}
