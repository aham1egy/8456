'use client'

import { ProtectedLayout } from '@/components/mishri/ProtectedLayout'
import { HomePage } from '@/components/mishri/HomePage'

export default function HomePageRoute() {
  return (
    <ProtectedLayout>
      <HomePage />
    </ProtectedLayout>
  )
}
