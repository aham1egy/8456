import { ResetPasswordForm } from '@/components/mishri/PasswordResetPage'

export default function ResetPasswordRoute() {
  return <ResetPasswordForm />
}
