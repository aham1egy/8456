'use client'

import { ProtectedLayout } from '@/components/mishri/ProtectedLayout'
import { CreatePostPage } from '@/components/mishri/CreatePostPage'

export default function CreatePageRoute() {
  return (
    <ProtectedLayout>
      <CreatePostPage />
    </ProtectedLayout>
  )
}
