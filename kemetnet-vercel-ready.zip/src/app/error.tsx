'use client'

import { AlertTriangle, RefreshCw, Home } from 'lucide-react'
import { useRouter } from 'next/navigation'
import { useEffect } from 'react'
import { useAppStore } from '@/store/app-store'

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  const router = useRouter()
  const user = useAppStore((s) => s.user)

  useEffect(() => {
    // [removed in production] '[App Error]:', error
  }, [error])

  const handleReload = () => {
    reset()
    router.refresh()
  }

  const handleGoHome = () => {
    reset()
    router.push(user ? '/home' : '/')
  }

  return (
    <div className="min-h-screen mishri-aurora-bg flex flex-col items-center justify-center px-6">
      <div className="text-center max-w-sm">
        <div className="w-20 h-20 mx-auto mb-6 rounded-3xl bg-rose-500/15 flex items-center justify-center">
          <AlertTriangle className="w-10 h-10 text-rose-500 animate-pulse" />
        </div>

        <h1 className="font-display text-2xl font-bold mb-2">
          حدث خطأ غير متوقع
        </h1>
        <p className="text-sm text-muted-foreground mb-6 leading-relaxed">
          نعتذر عن هذا الخطأ. يمكنك المحاولة مرة أخرى أو العودة للرئيسية.
        </p>

        <div className="flex gap-2 justify-center">
          <button
            onClick={handleReload}
            className="px-4 py-2.5 rounded-xl mishri-gradient-primary text-white text-sm font-bold shadow-md mishri-glow-soft mishri-press flex items-center gap-2"
          >
            <RefreshCw className="w-4 h-4" />
            المحاولة مرة أخرى
          </button>
          <button
            onClick={handleGoHome}
            className="px-4 py-2.5 rounded-xl mishri-glass text-sm font-bold mishri-press flex items-center gap-2"
          >
            <Home className="w-4 h-4" />
            الرئيسية
          </button>
        </div>

        {error.digest && (
          <div className="mt-6 text-[10px] text-muted-foreground/50" dir="ltr">
            Error ID: {error.digest}
          </div>
        )}
      </div>
    </div>
  )
}
