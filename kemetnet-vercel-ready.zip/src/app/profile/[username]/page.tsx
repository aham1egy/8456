'use client'

import { ProtectedLayout } from '@/components/mishri/ProtectedLayout'
import { ProfilePage } from '@/components/mishri/ProfilePage'
import { use } from 'react'

export default function UserProfileRoute({ params }: { params: Promise<{ username: string }> }) {
  return (
    <ProtectedLayout>
      <UserProfileWrapper params={params} />
    </ProtectedLayout>
  )
}

function UserProfileWrapper({ params }: { params: Promise<{ username: string }> }) {
  const resolvedParams = use(params)
  return <ProfilePage username={resolvedParams.username} />
}
