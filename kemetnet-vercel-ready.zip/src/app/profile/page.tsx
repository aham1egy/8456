'use client'

import { ProtectedLayout } from '@/components/mishri/ProtectedLayout'
import { ProfilePage } from '@/components/mishri/ProfilePage'

export default function ProfilePageRoute() {
  return (
    <ProtectedLayout>
      <ProfilePage />
    </ProtectedLayout>
  )
}
