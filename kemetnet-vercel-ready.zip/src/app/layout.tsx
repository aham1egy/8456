import type { Metadata, Viewport } from "next";
import { Cairo, Tajawal } from "next/font/google";
import "./globals.css";
import "./page-transitions.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { InstallPrompt } from "@/components/mishri/InstallPrompt";
import { OfflineIndicator } from "@/components/mishri/OfflineIndicator";

const cairo = Cairo({
  variable: "--font-cairo",
  subsets: ["arabic", "latin"],
  weight: ["300", "400", "500", "600", "700", "800", "900"],
  display: "swap",
});

const tajawal = Tajawal({
  variable: "--font-tajawal",
  subsets: ["arabic", "latin"],
  weight: ["300", "400", "500", "700", "800", "900"],
  display: "swap",
});

const SITE_URL = "https://kemetnet.app";
const SITE_NAME = "KemetNet";
const SITE_DESCRIPTION =
  "KemetNet — منصة عربية حديثة للإلهام والمشاركة والتعبير. سجّل باليوزرنيم وشارك لحظاتك المضيئة مع مجتمع إبداعي.";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: "KemetNet · منصة الإلهام",
    template: "%s · KemetNet",
  },
  description: SITE_DESCRIPTION,
  keywords: [
    "KemetNet",
    "كيمت نت",
    "منصة عربية",
    "إلهام",
    "مشاركة",
    "إبداع",
    "كتابة",
    "مدونة",
    "تطبيق عربي",
  ],
  authors: [{ name: "KemetNet Team" }],
  creator: "KemetNet",
  publisher: "KemetNet",
  applicationName: SITE_NAME,
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: SITE_NAME,
  },
  icons: {
    icon: [
      { url: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
      { url: "/icons/icon-512.png", sizes: "512x512", type: "image/png" },
    ],
    apple: [{ url: "/icons/icon-192.png", sizes: "192x192" }],
    shortcut: ["/icons/icon-192.png"],
  },
  openGraph: {
    type: "website",
    locale: "ar_SA",
    url: SITE_URL,
    title: "KemetNet · منصة الإلهام",
    description: SITE_DESCRIPTION,
    siteName: SITE_NAME,
    images: [
      {
        url: "/icons/icon-512.png",
        width: 512,
        height: 512,
        alt: "شعار KemetNet",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "KemetNet · منصة الإلهام",
    description: SITE_DESCRIPTION,
    images: ["/icons/icon-512.png"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  alternates: {
    canonical: SITE_URL,
  },
  formatDetection: {
    telephone: false,
    email: false,
    address: false,
  },
  category: "social",
};

// viewport منفصل كما يتطلب Next.js 14+
export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  minimumScale: 1,
  viewportFit: "cover",
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#FFF8EB" },
    { media: "(prefers-color-scheme: dark)", color: "#0E2A4F" },
  ],
  colorScheme: "light dark",
}

const APP_THEME_COLOR = "#1F4E8C"

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <head>
        {/* PWA Meta tags - تجربة كتطبيق أصلي */}
        <meta name="application-name" content="KemetNet" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="apple-mobile-web-app-title" content="KemetNet" />
        <meta name="format-detection" content="telephone=no" />
        <meta name="msapplication-TileColor" content={APP_THEME_COLOR} />
        <meta name="msapplication-tap-highlight" content="no" />
        {/* منع التكبير على iOS */}
        <meta name="apple-touch-fullscreen" content="yes" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover" />

        {/* JSON-LD للتعريف بالتطبيق - يحسّن SEO */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "WebApplication",
              name: "KemetNet",
              alternateName: "كيمت نت",
              description: SITE_DESCRIPTION,
              applicationCategory: "SocialNetworking",
              operatingSystem: "Web, Android, iOS",
              inLanguage: "ar",
              offers: {
                "@type": "Offer",
                price: "0",
                priceCurrency: "USD",
              },
            }),
          }}
        />
      </head>
      <body
        className={`${cairo.variable} ${tajawal.variable} antialiased bg-background text-foreground min-h-[100dvh] overflow-hidden`}
      >
        {/* Background fill: يضمن أن اللون يمتد تحت شريط الحالة والـ notch
            عند تثبيت التطبيق على الشاشة الرئيسية (PWA fullscreen) */}
        <div
          aria-hidden="true"
          className="fixed inset-0 -z-50 bg-background"
          style={{ pointerEvents: 'none' }}
        />
        {/* Skip link للوصول (Accessibility) */}
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:right-4 focus:z-50 focus:px-4 focus:py-2 focus:bg-background focus:text-foreground focus:rounded-xl focus:shadow-lg"
        >
          تخطّي إلى المحتوى الرئيسي
        </a>

        {/* Error Boundary يلف التطبيق كله */}
        <ErrorBoundary>
          {/* مؤشرات PWA: موجه التثبيت + حالة الاتصال */}
          <InstallPrompt />
          <OfflineIndicator />

          <div id="app-root">
            {children}
          </div>
        </ErrorBoundary>

        <Toaster />
        <SonnerToaster 
          position="top-center" 
          dir="rtl"
          toastOptions={{
            duration: 2500,
            style: {
              animation: 'slide-up 0.15s ease-out forwards',
            },
          }}
        />
      </body>
    </html>
  );
}
