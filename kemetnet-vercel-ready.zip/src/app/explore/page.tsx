'use client'

import { ProtectedLayout } from '@/components/mishri/ProtectedLayout'
import { ExplorePage } from '@/components/mishri/ExplorePage'

export default function ExplorePageRoute() {
  return (
    <ProtectedLayout>
      <ExplorePage />
    </ProtectedLayout>
  )
}
