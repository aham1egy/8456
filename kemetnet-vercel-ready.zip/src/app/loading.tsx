export default function Loading() {
  return (
    <div className="min-h-screen mishri-aurora-bg flex flex-col items-center justify-center">
      <div className="flex flex-col items-center gap-4">
        <div className="relative">
          <div className="w-16 h-16 rounded-3xl mishri-gradient-primary mishri-glow-soft flex items-center justify-center mishri-float">
            <span className="font-display text-2xl font-bold text-white">م</span>
          </div>
        </div>
        <div className="flex items-center gap-1.5">
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              className="w-2 h-2 rounded-full mishri-gradient-primary animate-pulse"
              style={{ animationDelay: `${i * 0.15}s` }}
            />
          ))}
        </div>
      </div>
    </div>
  )
}
