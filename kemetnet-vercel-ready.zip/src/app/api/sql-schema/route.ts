// V-11: تم حذف endpoint لتسريب SQL schema نهائيًا
// SQL schema متاح فقط في ملف scripts/supabase-schema.sql في المستودع
import { NextResponse } from 'next/server'

export async function GET() {
  return NextResponse.json({ error: 'Not available' }, { status: 403 })
}
