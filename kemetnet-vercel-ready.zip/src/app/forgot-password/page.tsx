import { PasswordResetPage } from '@/components/mishri/PasswordResetPage'

export default function ForgotPasswordRoute() {
  return <PasswordResetPage />
}
