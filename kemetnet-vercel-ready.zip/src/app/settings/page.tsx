'use client'

import { ProtectedLayout } from '@/components/mishri/ProtectedLayout'
import { SettingsPage } from '@/components/mishri/SettingsPage'

export default function SettingsPageRoute() {
  return (
    <ProtectedLayout>
      <SettingsPage />
    </ProtectedLayout>
  )
}
