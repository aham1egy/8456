'use client'

import { ProtectedLayout } from '@/components/mishri/ProtectedLayout'
import { NotificationsPage } from '@/components/mishri/NotificationsPage'

export default function NotificationsPageRoute() {
  return (
    <ProtectedLayout>
      <NotificationsPage />
    </ProtectedLayout>
  )
}
