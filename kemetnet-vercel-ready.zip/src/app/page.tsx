'use client'

import { useEffect, useState, useCallback } from 'react'
import { useRouter } from 'next/navigation'
import { useAppStore } from '@/store/app-store'
import { getCurrentProfile } from '@/lib/supabase/auth'
import { supabase, isSupabaseConfigured } from '@/lib/supabase/client'
import { SplashScreen } from '@/components/mishri/SplashScreen'
import { AuthPage } from '@/components/mishri/AuthPage'

// ملاحظة: useRealtimeNotifications يُستدعى في ProtectedLayout فقط (لا تكرار)

// مهلة قصوى لإعداد المصادقة قبل عرض رسالة خطأ (10 ثوان)
const AUTH_TIMEOUT_MS = 10_000

type BootState = 'loading' | 'error' | 'ready' | 'unconfigured'

/**
 * الصفحة الجذرية - تعمل كـ redirect ذكي:
 * - إذا Supabase غير مضبوط → عرض AuthPage مع رسالة إعداد
 * - إذا المستخدم مسجل دخول → /home
 * - إذا غير مسجل → عرض AuthPage (تبقى على /)
 * - أثناء التحقق → Splash
 */
export default function Home() {
  const router = useRouter()
  const user = useAppStore((s) => s.user)
  const setUser = useAppStore((s) => s.setUser)
  const setLoadingAuth = useAppStore((s) => s.setLoadingAuth)
  const theme = useAppStore((s) => s.theme)

  const [bootState, setBootState] = useState<BootState>('loading')
  const [hydrated, setHydrated] = useState(false)
  const [retryKey, setRetryKey] = useState(0)

  // استعادة حالة Zustand بعد التركيب
  useEffect(() => {
    void useAppStore.persist.rehydrate()
    setHydrated(true)
  }, [])

  // تهيئة الثيم
  useEffect(() => {
    const root = document.documentElement
    if (theme === 'midnight') {
      root.classList.add('dark')
    } else {
      root.classList.remove('dark')
    }
  }, [theme])

  // فحص المصادقة - مع timeout آمن
  const initializeAuth = useCallback(async (signal: AbortSignal) => {
    setBootState('loading')
    setLoadingAuth(true)

    // إذا Supabase غير مضبوط، اعرض AuthPage مباشرة (بدون محاولة اتصال فاشلة)
    if (!isSupabaseConfigured) {
      setUser(null)
      setBootState('unconfigured')
      setLoadingAuth(false)
      return
    }

    const sessionPromise = supabase.auth.getSession()
    const timeoutPromise = new Promise<{ timedOut: true }>((resolve) => {
      setTimeout(() => resolve({ timedOut: true }), AUTH_TIMEOUT_MS)
    })

    try {
      const result = await Promise.race([sessionPromise, timeoutPromise])
      if (signal.aborted) return

      if ('timedOut' in result) {
        setBootState('error')
        setLoadingAuth(false)
        return
      }

      const { data: { session }, error } = result

      if (error) {
        setBootState('error')
        setLoadingAuth(false)
        return
      }

      if (session?.user) {
        // تحميل الملف الشخصي
        const profileTimeout = new Promise<null>((resolve) => setTimeout(() => resolve(null), 5000))
        const profile = await Promise.race([getCurrentProfile(), profileTimeout])

        if (signal.aborted) return

        setUser(profile)
        // إذا المستخدم مسجل، حوّله لـ /home
        if (profile) {
          router.replace('/home')
          return
        }
      } else {
        setUser(null)
      }
      setBootState('ready')
    } catch (err) {
      if (signal.aborted) return
      setBootState('error')
    } finally {
      if (!signal.aborted) {
        setLoadingAuth(false)
      }
    }
  }, [router, setLoadingAuth, setUser])

  useEffect(() => {
    const controller = new AbortController()
    void initializeAuth(controller.signal)

    // لا تُفعّل auth listener إذا Supabase غير مضبوط
    if (!isSupabaseConfigured) {
      return () => controller.abort()
    }

    const { data: authListener } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (controller.signal.aborted) return

      if (event === 'SIGNED_OUT') {
        setUser(null)
        router.replace('/')
      } else if (event === 'SIGNED_IN' && session?.user) {
        try {
          const profile = await getCurrentProfile()
          if (controller.signal.aborted) return
          setUser(profile)
          router.replace('/home')
        } catch (err) {
          // [removed in production]
        }
      }
    })

    return () => {
      controller.abort()
      authListener.subscription.unsubscribe()
    }
  }, [retryKey, initializeAuth])

  // شاشة الخطأ
  if (hydrated && bootState === 'error') {
    return <BootErrorScreen onRetry={() => setRetryKey((k) => k + 1)} />
  }

  // شاشة البداية - أثناء التحميل
  if (!hydrated || bootState === 'loading') {
    return <SplashScreen />
  }

  // إذا لم يسجّل الدخول، اعرض صفحة المصادقة (على /)
  if (!user) {
    return <AuthPage />
  }

  // إذا المستخدم مسجل لكن لم يحدث redirect، اعرض Splash (ينتقل تلقائيًا)
  return <SplashScreen />
}

function BootErrorScreen({ onRetry }: { onRetry: () => void }) {
  return (
    <div className="fixed inset-0 mishri-aurora-bg flex flex-col items-center justify-center px-6 z-50">
      <div className="text-center max-w-sm">
        <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-rose-500/10 flex items-center justify-center">
          <svg viewBox="0 0 24 24" className="w-8 h-8 text-rose-500" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M12 9v4M12 17h.01M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
        <h2 className="font-display text-xl font-bold mb-2">تعذّر تحميل التطبيق</h2>
        <p className="text-sm text-muted-foreground mb-6 leading-relaxed">
          تحقّق من اتصالك بالإنترنت ثم أعد المحاولة.
        </p>
        <button
          onClick={onRetry}
          className="px-6 py-2.5 rounded-xl mishri-gradient-primary text-white text-sm font-bold shadow-md mishri-glow-soft mishri-press"
        >
          إعادة المحاولة
        </button>
      </div>
    </div>
  )
}
