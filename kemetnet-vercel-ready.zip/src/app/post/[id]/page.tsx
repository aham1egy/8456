'use client'

import { ProtectedLayout } from '@/components/mishri/ProtectedLayout'
import { PostDetailPage } from '@/components/mishri/PostDetailPage'

export default function PostDetailRoute({ params }: { params: Promise<{ id: string }> }) {
  return (
    <ProtectedLayout>
      <PostDetailPageWrapper params={params} />
    </ProtectedLayout>
  )
}

import { use } from 'react'

function PostDetailPageWrapper({ params }: { params: Promise<{ id: string }> }) {
  const resolvedParams = use(params)
  return <PostDetailPage postId={resolvedParams.id} />
}
