'use client'

import { ProtectedLayout } from '@/components/mishri/ProtectedLayout'
import { MessagesPage } from '@/components/mishri/MessagesPage'

export default function MessagesPageRoute() {
  return (
    <ProtectedLayout>
      <MessagesPage />
    </ProtectedLayout>
  )
}
