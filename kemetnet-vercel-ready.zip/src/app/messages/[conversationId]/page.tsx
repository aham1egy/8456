'use client'

import { ProtectedLayout } from '@/components/mishri/ProtectedLayout'
import { ConversationPage } from '@/components/mishri/ConversationPage'
import { use } from 'react'

export default function ConversationRoute({ params }: { params: Promise<{ conversationId: string }> }) {
  return (
    <ProtectedLayout>
      <ConversationWrapper params={params} />
    </ProtectedLayout>
  )
}

function ConversationWrapper({ params }: { params: Promise<{ conversationId: string }> }) {
  const resolvedParams = use(params)
  return <ConversationPage conversationId={resolvedParams.conversationId} />
}
