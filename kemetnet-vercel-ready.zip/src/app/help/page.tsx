'use client'

import { ProtectedLayout } from '@/components/mishri/ProtectedLayout'
import { HelpPage } from '@/components/mishri/HelpPage'

export default function HelpRoute() {
  return (
    <ProtectedLayout>
      <HelpPage />
    </ProtectedLayout>
  )
}
