// src/store/app-store.ts
// مخزن الحالة المركزي - مشروع KemetNet
// يستخدم Zustand لإدارة الحالات غير المتعلقة بالتنقل
// (التنقل الآن يتم عبر Next.js App Router - روابط URL حقيقية)

import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { Profile } from '@/lib/supabase/client'

export type ThemeMode = 'dawn' | 'dusk' | 'midnight' | 'system'

export interface FilterState {
  category: string // 'all' | 'inspire' | ...
  mood: string | null
  sortBy: 'recent' | 'popular' | 'trending'
  searchQuery: string
}

interface AppState {
  // المصادقة
  user: Profile | null
  isLoadingAuth: boolean
  isAuthenticated: boolean
  setUser: (user: Profile | null) => void
  setLoadingAuth: (loading: boolean) => void

  // الفلاتر
  filters: FilterState
  setFilter: <K extends keyof FilterState>(key: K, value: FilterState[K]) => void
  resetFilters: () => void

  // المظهر
  theme: ThemeMode
  setTheme: (theme: ThemeMode) => void

  // شفافية الزجاج السائل (0-100)
  glassOpacity: number
  setGlassOpacity: (opacity: number) => void

  // مستوى صوت الإشعارات (0-100)
  notificationVolume: number
  setNotificationVolume: (volume: number) => void

  // تفعيل أصوات الإشعارات
  soundEnabled: boolean
  setSoundEnabled: (enabled: boolean) => void

  // عداد الإشعارات غير المقروءة
  unreadNotifications: number
  setUnreadNotifications: (count: number) => void

  // إعدادات الإشعارات المتقدمة (لكل نوع)
  notifPreferences: NotificationPreferences
  setNotifPreference: <K extends keyof NotificationPreferences>(key: K, value: NotificationPreferences[K]) => void
  resetNotifPreferences: () => void

  // === نظام Keep-Alive للصفحات ===
  // يحفظ بيانات + موضع التمرير لكل صفحة
  pageCache: Record<string, { scrollY: number }>
  setPageScroll: (page: string, scrollY: number) => void
  getPageScroll: (page: string) => number
  clearPageCache: (page?: string) => void
}

export interface NotificationPreferences {
  likes: boolean
  comments: boolean
  mentions: boolean
  follows: boolean
  messages: boolean
  reposts: boolean
  sound: boolean
  vibration: boolean
}

const defaultNotifPreferences: NotificationPreferences = {
  likes: true,
  comments: true,
  mentions: true,
  follows: true,
  messages: true,
  reposts: true,
  sound: true,
  vibration: true,
}

const defaultFilters: FilterState = {
  category: 'all',
  mood: null,
  sortBy: 'recent',
  searchQuery: '',
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      // المصادقة
      user: null,
      isLoadingAuth: true,
      isAuthenticated: false,
      setUser: (user) =>
        set({
          user,
          isAuthenticated: !!user,
          isLoadingAuth: false,
        }),
      setLoadingAuth: (loading) => set({ isLoadingAuth: loading }),

      // الفلاتر
      filters: defaultFilters,
      setFilter: (key, value) =>
        set({
          filters: { ...get().filters, [key]: value },
        }),
      resetFilters: () => set({ filters: defaultFilters }),

      // المظهر
      theme: 'dawn',
      setTheme: (theme) => set({ theme }),

      // شفافية الزجاج (افتراضي 60%)
      glassOpacity: 60,
      setGlassOpacity: (opacity) => set({ glassOpacity: Math.max(0, Math.min(100, opacity)) }),

      // صوت الإشعارات
      notificationVolume: 70,
      setNotificationVolume: (volume) => set({ notificationVolume: Math.max(0, Math.min(100, volume)) }),

      soundEnabled: true,
      setSoundEnabled: (enabled) => set({ soundEnabled: enabled }),

      // الإشعارات
      unreadNotifications: 0,
      setUnreadNotifications: (count) => set({ unreadNotifications: count }),

      // إعدادات الإشعارات المتقدمة
      notifPreferences: defaultNotifPreferences,
      setNotifPreference: (key, value) =>
        set((state) => ({
          notifPreferences: { ...state.notifPreferences, [key]: value },
        })),
      resetNotifPreferences: () => set({ notifPreferences: defaultNotifPreferences }),

      // === نظام Keep-Alive للصفحات ===
      pageCache: {},
      setPageScroll: (page, scrollY) =>
        set((state) => ({
          pageCache: { ...state.pageCache, [page]: { scrollY } },
        })),
      getPageScroll: (page) => {
        const state = get()
        return state.pageCache[page]?.scrollY || 0
      },
      clearPageCache: (page) =>
        set((state) => {
          if (!page) return { pageCache: {} }
          const newCache = { ...state.pageCache }
          delete newCache[page]
          return { pageCache: newCache }
        }),
    }),
    {
      name: 'kemetnet-store',
      skipHydration: true,
      partialize: (state) => ({
        theme: state.theme,
        filters: state.filters,
        glassOpacity: state.glassOpacity,
        notificationVolume: state.notificationVolume,
        soundEnabled: state.soundEnabled,
        notifPreferences: state.notifPreferences,
      }),
    }
  )
)
