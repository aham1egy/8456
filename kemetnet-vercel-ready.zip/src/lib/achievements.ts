// src/lib/achievements.ts
// نظام الإنجازات (Achievements)

import { supabase } from './supabase/client'

// ========================================
// أنواع البيانات
// ========================================

export type AchievementCategory = 'posts' | 'social' | 'engagement' | 'milestone' | 'special'
export type AchievementTier = 'bronze' | 'silver' | 'gold' | 'platinum' | 'diamond'

export interface Achievement {
  id: string
  slug: string
  name: string
  description: string
  category: AchievementCategory
  icon: string
  color: string
  points_reward: number
  target_value: number | null
  tier: AchievementTier
  created_at: string
}

export interface UserAchievement {
  id: string
  user_id: string
  achievement_slug: string
  progress: number
  completed: boolean
  completed_at: string | null
  created_at: string
  updated_at: string
  achievement?: Achievement
}

// ========================================
// تعريفات ثابتة
// ========================================

export const TIER_CONFIG: Record<AchievementTier, { label: string; color: string; gradient: string }> = {
  bronze: { label: 'برونزي', color: '#92400E', gradient: 'from-amber-700 to-amber-900' },
  silver: { label: 'فضي', color: '#6B7280', gradient: 'from-gray-400 to-gray-600' },
  gold: { label: 'ذهبي', color: '#FBBF24', gradient: 'from-amber-400 to-amber-600' },
  platinum: { label: 'بلاتيني', color: '#06B6D4', gradient: 'from-cyan-400 to-cyan-600' },
  diamond: { label: 'ماسي', color: '#A855F7', gradient: 'from-purple-400 to-pink-600' },
}

export const CATEGORY_LABELS: Record<AchievementCategory, string> = {
  posts: 'المنشورات',
  social: 'اجتماعي',
  engagement: 'التفاعل',
  milestone: 'معالم',
  special: 'مميز',
}

// ========================================
// جلب جميع الإنجازات
// ========================================

export async function fetchAllAchievements(): Promise<Achievement[]> {
  try {
    const { data, error } = await supabase
      .from('achievements')
      .select('*')
      .order('category', { ascending: true })
      .order('target_value', { ascending: true, nullsFirst: false })

    if (error || !data) {
      // [removed in production] '[fetchAllAchievements] error:', error
      return []
    }

    return data as Achievement[]
  } catch (e) {
    // [removed in production] '[fetchAllAchievements] error:', e
    return []
  }
}

// ========================================
// جلب إنجازات مستخدم
// ========================================

export async function fetchUserAchievements(userId: string): Promise<UserAchievement[]> {
  try {
    const { data, error } = await supabase
      .from('user_achievements')
      .select('*, achievement:achievements(*)')
      .eq('user_id', userId)
      .order('updated_at', { ascending: false })

    if (error || !data) {
      // [removed in production] '[fetchUserAchievements] error:', error
      return []
    }

    return data as UserAchievement[]
  } catch (e) {
    // [removed in production] '[fetchUserAchievements] error:', e
    return []
  }
}

// ========================================
// جلب ملخص الإنجازات
// ========================================

export interface AchievementsSummary {
  total: number
  completed: number
  inProgress: number
  totalPointsEarned: number
  byTier: Record<AchievementTier, number>
  byCategory: Record<AchievementCategory, number>
}

export async function fetchAchievementsSummary(userId: string): Promise<AchievementsSummary> {
  const allAchievements = await fetchAllAchievements()
  const userAchievements = await fetchUserAchievements(userId)

  const byTier: Record<AchievementTier, number> = {
    bronze: 0, silver: 0, gold: 0, platinum: 0, diamond: 0,
  }
  const byCategory: Record<AchievementCategory, number> = {
    posts: 0, social: 0, engagement: 0, milestone: 0, special: 0,
  }

  let totalPointsEarned = 0
  const completedSlugs = new Set<string>()

  for (const ua of userAchievements) {
    if (ua.completed && ua.achievement) {
      completedSlugs.add(ua.achievement_slug)
      byTier[ua.achievement.tier]++
      byCategory[ua.achievement.category]++
      totalPointsEarned += ua.achievement.points_reward
    }
  }

  return {
    total: allAchievements.length,
    completed: completedSlugs.size,
    inProgress: userAchievements.filter((ua) => !ua.completed).length,
    totalPointsEarned,
    byTier,
    byCategory,
  }
}

// ========================================
// تحديث تقدم إنجاز (يُستدعى تلقائياً عبر triggers)
// ========================================

export async function updateAchievementProgress(
  userId: string,
  slug: string,
  progress: number
): Promise<{ success: boolean; error?: string }> {
  try {
    const { error } = await supabase.rpc('update_achievement_progress', {
      target_user_id: userId,
      achievement_slug: slug,
      new_progress: progress,
    })

    if (error) {
      // [removed in production] '[updateAchievementProgress] error:', error
      return { success: false, error: 'تعذّر تحديث الإنجاز' }
    }

    return { success: true }
  } catch (e) {
    // [removed in production] '[updateAchievementProgress] error:', e
    return { success: false, error: 'حدث خطأ' }
  }
}

// ========================================
// مزامنة إنجازات المستخدم الحالي
// تُحدث الإنجازات بناءً على البيانات الحالية
// ========================================

export async function syncUserAchievements(
  userId: string,
  profile: {
    posts_count: number
    followers_count: number
    reputation_level: number
    is_verified: boolean
  }
): Promise<void> {
  try {
    // إنجازات المنشورات
    await updateAchievementProgress(userId, 'first_post', profile.posts_count)
    await updateAchievementProgress(userId, 'post_10', profile.posts_count)
    await updateAchievementProgress(userId, 'post_50', profile.posts_count)
    await updateAchievementProgress(userId, 'post_100', profile.posts_count)

    // إنجازات المتابعين
    await updateAchievementProgress(userId, 'first_follower', profile.followers_count)
    await updateAchievementProgress(userId, 'followers_10', profile.followers_count)
    await updateAchievementProgress(userId, 'followers_50', profile.followers_count)
    await updateAchievementProgress(userId, 'followers_100', profile.followers_count)
    await updateAchievementProgress(userId, 'followers_1000', profile.followers_count)

    // إنجازات المستوى
    await updateAchievementProgress(userId, 'level_5', profile.reputation_level)
    await updateAchievementProgress(userId, 'level_10', profile.reputation_level)
    await updateAchievementProgress(userId, 'level_25', profile.reputation_level)

    // إنجاز التحقق
    if (profile.is_verified) {
      await updateAchievementProgress(userId, 'verified', 1)
    }
  } catch (e) {
    // [removed in production] '[syncUserAchievements] error:', e
  }
}
