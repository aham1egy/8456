// src/lib/messaging.ts
// نظام المراسلة الكامل - مشروع KemetNet
// إدارة المحادثات، الرسائل، طلبات المراسلة، والبث المباشر

import { supabase } from '@/lib/supabase/client'
import type { Profile } from '@/lib/supabase/client'
import { assertValidUUID } from '@/lib/postgrest-utils'

// =====================================================
// أنواع البيانات
// =====================================================

export interface Conversation {
  id: string
  participant_1: string
  participant_2: string
  last_message_id: string | null
  last_message_at: string | null
  created_at: string
  updated_at: string
  other_participant?: Profile
  last_message?: Message | null
  unread_count?: number
}

export interface Message {
  id: string
  conversation_id: string
  sender_id: string
  content: string
  image_url: string | null
  is_edited: boolean
  edited_at: string | null
  is_deleted: boolean
  deleted_at: string | null
  deleted_by: string | null
  read_at: string | null
  created_at: string
  sender?: Profile
}

export interface MessageRequest {
  id: string
  sender_id: string
  receiver_id: string
  status: 'pending' | 'accepted' | 'rejected'
  created_at: string
  responded_at: string | null
  sender?: Profile
  receiver?: Profile
}

// =====================================================
// إدارة المحادثات
// =====================================================

/**
 * إنشاء أو الحصول على محادثة بين مستخدمين
 * يتحقق أولاً من وجود طلب مراسلة مقبول
 */
export async function getOrCreateConversation(
  currentUserId: string,
  otherUserId: string
): Promise<{ conversationId: string | null; error?: string; needsRequest?: boolean }> {
  try {
    // V-26: التحقق من صحة UUIDs قبل إدراجها في فلتر .or() لمنع PostgREST filter injection
    const uidA = assertValidUUID(currentUserId)
    const uidB = assertValidUUID(otherUserId)
    if (uidA === uidB) return { conversationId: null, error: 'مُعرّفات غير صالحة' }
    if (uidA === '00000000-0000-0000-0000-000000000000' || uidB === '00000000-0000-0000-0000-000000000000') {
      return { conversationId: null, error: 'مُعرّف المستخدم غير صالح' }
    }

    // 1. تحقق من محادثة موجودة أولاً
    const { data: existingConv } = await supabase
      .from('conversations')
      .select('id')
      .or(`and(participant_1.eq.${uidA},participant_2.eq.${uidB}),and(participant_1.eq.${uidB},participant_2.eq.${uidA})`)
      .maybeSingle()

    if (existingConv) {
      return { conversationId: existingConv.id }
    }

    // 2. تحقق من المتابعة المتبادلة
    const { data: iFollowThem } = await supabase
      .from('follows')
      .select('id')
      .match({ follower_id: currentUserId, following_id: otherUserId })
      .maybeSingle()

    const { data: theyFollowMe } = await supabase
      .from('follows')
      .select('id')
      .match({ follower_id: otherUserId, following_id: currentUserId })
      .maybeSingle()

    // 3. إذا كانا يتابعان بعضهما → محادثة مباشرة
    if (iFollowThem && theyFollowMe) {
      const [p1, p2] = [uidA, uidB].sort()
      const { data: newConv, error } = await supabase
        .from('conversations')
        .insert({ participant_1: p1, participant_2: p2 })
        .select('id')
        .single()

      if (error) {
        if (error.code === '23505') {
          const { data: retryConv } = await supabase
            .from('conversations')
            .select('id')
            .or(`and(participant_1.eq.${p1},participant_2.eq.${p2}),and(participant_1.eq.${p2},participant_2.eq.${p1})`)
            .maybeSingle()
          if (retryConv) return { conversationId: retryConv.id }
        }
        return { conversationId: null, error: 'تعذّر إنشاء المحادثة' }
      }

      return { conversationId: newConv.id }
    }

    // 4. تحقق من طلب مراسلة مقبول سابق
    const { data: acceptedRequest } = await supabase
      .from('message_requests')
      .select('id')
      .or(`and(sender_id.eq.${uidA},receiver_id.eq.${uidB},status.eq.accepted),and(sender_id.eq.${uidB},receiver_id.eq.${uidA},status.eq.accepted)`)
      .maybeSingle()

    if (acceptedRequest) {
      const [p1, p2] = [uidA, uidB].sort()
      const { data: newConv, error } = await supabase
        .from('conversations')
        .insert({ participant_1: p1, participant_2: p2 })
        .select('id')
        .single()

      if (error) {
        if (error.code === '23505') {
          const { data: retryConv } = await supabase
            .from('conversations')
            .select('id')
            .or(`and(participant_1.eq.${p1},participant_2.eq.${p2}),and(participant_1.eq.${p2},participant_2.eq.${p1})`)
            .maybeSingle()
          if (retryConv) return { conversationId: retryConv.id }
        }
        return { conversationId: null, error: 'تعذّر إنشاء المحادثة' }
      }

      return { conversationId: newConv.id }
    }

    // 5. تحقق من طلب مراسلة معلّق موجود
    const { data: pendingRequest } = await supabase
      .from('message_requests')
      .select('id, status')
      .or(`and(sender_id.eq.${uidA},receiver_id.eq.${uidB}),and(sender_id.eq.${uidB},receiver_id.eq.${uidA})`)
      .maybeSingle()

    if (pendingRequest) {
      if (pendingRequest.status === 'pending') {
        return { conversationId: null, needsRequest: true }
      }
    }

    // 6. لا متابعة متبادلة ولا طلب مقبول → يحتاج طلب مراسلة
    return { conversationId: null, needsRequest: true }
  } catch (e) {
    // [removed in production] 'getOrCreateConversation error:', e
    return { conversationId: null, error: 'حدث خطأ غير متوقع' }
  }
}

/**
 * جلب كل محادثات المستخدم مع آخر رسالة وبيانات الطرف الآخر
 */
export async function fetchConversations(userId: string): Promise<Conversation[]> {
  try {
    // V-26: التحقق من صحة UUID قبل استخدامه في فلتر .or()
    const uid = assertValidUUID(userId)
    if (uid === '00000000-0000-0000-0000-000000000000') return []

    // استعلام منفصل عن المحادثات (بدون join لتجنب أخطاء الـ foreign key)
    const { data: convs, error: convError } = await supabase
      .from('conversations')
      .select('*')
      .or(`participant_1.eq.${uid},participant_2.eq.${uid}`)
      .order('updated_at', { ascending: false })

    if (convError || !convs || convs.length === 0) return []

    const conversations = convs as Conversation[]

    // جلب آخر رسالة لكل محادثة
    const convIds = conversations.map((c) => c.id)
    const { data: lastMsgs } = await supabase
      .from('messages')
      .select('*')
      .in('conversation_id', convIds)
      .order('created_at', { ascending: false })

    // تجميع آخر رسالة لكل محادثة
    const lastMsgMap: Record<string, Message> = {}
    ;(lastMsgs || []).forEach((m: Message) => {
      if (!lastMsgMap[m.conversation_id]) {
        lastMsgMap[m.conversation_id] = m
      }
    })

    // جلب بيانات الطرف الآخر لكل محادثة
    const otherUserIds = conversations.map((c) =>
      c.participant_1 === uid ? c.participant_2 : c.participant_1
    )

    if (otherUserIds.length === 0) return []

    const { data: profiles } = await supabase
      .from('profiles')
      .select('*')
      .in('id', otherUserIds)

    const profileMap: Record<string, Profile> = {}
    ;(profiles || []).forEach((p: Profile) => {
      profileMap[p.id] = p
    })

    return conversations.map((c) => {
      const otherId = c.participant_1 === uid ? c.participant_2 : c.participant_1
      // حساب الرسائل غير المقروءة (مرسلة من الطرف الآخر ولم تُقرأ)
      const unreadCount = (lastMsgs || []).filter(
        (m: Message) => m.conversation_id === c.id
          && m.sender_id !== uid
          && m.read_at === null
          && !m.is_deleted
      ).length

      return {
        ...c,
        other_participant: profileMap[otherId] || null,
        last_message: lastMsgMap[c.id] || null,
        unread_count: unreadCount,
      }
    })
  } catch (e) {
    // [removed in production] 'fetchConversations error:', e
    return []
  }
}

// =====================================================
// إدارة الرسائل
// =====================================================

/**
 * جلب رسائل محادثة معينة (صفحات)
 */
export async function fetchMessages(
  conversationId: string,
  limit = 50,
  before?: string
): Promise<Message[]> {
  try {
    let query = supabase
      .from('messages')
      .select('*')
      .eq('conversation_id', conversationId)
      .order('created_at', { ascending: false })
      .limit(limit)

    if (before) {
      query = query.lt('created_at', before)
    }

    const { data, error } = await query
    if (error || !data) return []

    // ترتيب عكسي لعرض الأحدث في الأسفل
    return (data as Message[]).reverse()
  } catch (e) {
    // [removed in production] 'fetchMessages error:', e
    return []
  }
}

/**
 * إرسال رسالة جديدة (نصية أو صورية أو مختلطة)
 */
export async function sendMessage(
  conversationId: string,
  senderId: string,
  content: string,
  imageUrl?: string | null
): Promise<{ success: boolean; error?: string; message?: Message }> {
  const trimmed = content.trim()
  // السماح برسالة فارغة إذا كانت تحتوي على صورة
  if (!trimmed && !imageUrl) return { success: false, error: 'الرسالة فارغة' }
  if (trimmed.length > 4000) return { success: false, error: 'الرسالة طويلة جدًا (حد أقصى 4000 حرف)' }

  try {
    const insertData: Record<string, unknown> = {
      conversation_id: conversationId,
      sender_id: senderId,
      content: trimmed || '',
    }
    if (imageUrl) {
      insertData.image_url = imageUrl
    }

    const { data, error } = await supabase
      .from('messages')
      .insert(insertData)
      .select('*')
      .single()

    if (error) return { success: false, error: 'تعذّر إرسال الرسالة' }

    return { success: true, message: data as Message }
  } catch (e) {
    // [removed in production] 'sendMessage error:', e
    return { success: false, error: 'حدث خطأ غير متوقع' }
  }
}

/**
 * تعديل رسالة — يحدّث المحتوى ويضع علامة is_edited
 */
export async function editMessage(
  messageId: string,
  userId: string,
  newContent: string
): Promise<{ success: boolean; error?: string }> {
  const trimmed = newContent.trim()
  if (!trimmed) return { success: false, error: 'الرسالة فارغة' }
  if (trimmed.length > 4000) return { success: false, error: 'الرسالة طويلة جدًا' }

  try {
    const { error } = await supabase
      .from('messages')
      .update({
        content: trimmed,
        is_edited: true,
        edited_at: new Date().toISOString(),
      })
      .eq('id', messageId)
      .eq('sender_id', userId) // ✅ أمني: التحقق من المرسل

    if (error) return { success: false, error: 'تعذّر تعديل الرسالة' }
    return { success: true }
  } catch (e) {
    // [removed in production] '[editMessage] error:', e instanceof Error ? e.message : 'unknown'
    return { success: false, error: 'حدث خطأ غير متوقع' }
  }
}

/**
 * حذف رسالة (soft delete) — يضع علامة is_deleted ويحتفظ بالسجل
 */
export async function deleteMessage(
  messageId: string,
  userId: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const { error } = await supabase
      .from('messages')
      .update({
        is_deleted: true,
        deleted_at: new Date().toISOString(),
        deleted_by: userId,
        content: '[تم حذف هذه الرسالة]',
      })
      .eq('id', messageId)
      .eq('sender_id', userId) // ✅ أمني: التحقق من المرسل

    if (error) return { success: false, error: 'تعذّر حذف الرسالة' }
    return { success: true }
  } catch (e) {
    // [removed in production] '[deleteMessage] error:', e instanceof Error ? e.message : 'unknown'
    return { success: false, error: 'حدث خطأ غير متوقع' }
  }
}

/**
 * تعليم الرسائل كمقروءة
 */
export async function markMessagesAsRead(
  conversationId: string,
  userId: string
): Promise<void> {
  try {
    // ✅ أمني: استخدام RPC مخصصة بدلاً من update مباشر
    await supabase.rpc('mark_messages_read', {
      conv_id: conversationId,
      reader_id: userId,
    })
  } catch (e) {
    // [removed in production] '[markMessagesAsRead] error:', e instanceof Error ? e.message : 'unknown'
  }
}

/**
 * عدّ الرسائل غير المقروءة في كل المحادثات
 */
export async function getUnreadMessagesCount(userId: string): Promise<number> {
  try {
    // V-26: التحقق من صحة UUID
    const uid = assertValidUUID(userId)
    if (uid === '00000000-0000-0000-0000-000000000000') return 0

    const { count, error } = await supabase
      .from('messages')
      .select('id', { count: 'exact', head: true })
      .neq('sender_id', uid)
      .is('read_at', null)
      .in('conversation_id', (
        await supabase
          .from('conversations')
          .select('id')
          .or(`participant_1.eq.${uid},participant_2.eq.${uid}`)
      ).data?.map((c: { id: string }) => c.id) || [])

    if (error || count === null) return 0
    return count
  } catch (e) {
    // [removed in production] 'getUnreadMessagesCount error:', e
    return 0
  }
}

// =====================================================
// إدارة طلبات المراسلة
// =====================================================

/**
 * إرسال طلب مراسلة لمستخدم
 */
export async function sendMessageRequest(
  senderId: string,
  receiverId: string
): Promise<{ success: boolean; error?: string }> {
  if (senderId === receiverId) return { success: false, error: 'لا يمكنك مراسلة نفسك' }

  // V-26: التحقق من صحة UUIDs
  const sid = assertValidUUID(senderId)
  const rid = assertValidUUID(receiverId)
  if (sid === '00000000-0000-0000-0000-000000000000' || rid === '00000000-0000-0000-0000-000000000000') {
    return { success: false, error: 'مُعرّف المستخدم غير صالح' }
  }

  try {
    // تحقق من عدم وجود طلب سابق
    const { data: existing } = await supabase
      .from('message_requests')
      .select('id, status')
      .or(`and(sender_id.eq.${sid},receiver_id.eq.${rid}),and(sender_id.eq.${rid},receiver_id.eq.${sid})`)
      .maybeSingle()

    if (existing) {
      if (existing.status === 'accepted') return { success: false, error: 'تم قبول الطلب بالفعل' }
      if (existing.status === 'pending') return { success: false, error: 'طلب المراسلة قيد الانتظار' }
      if (existing.status === 'rejected') {
        // إذا كان مرفوضًا، اسمح بإعادة الإرسال
        const { error: updateError } = await supabase
          .from('message_requests')
          .update({ status: 'pending', responded_at: null, created_at: new Date().toISOString() })
          .eq('id', existing.id)
        if (updateError) return { success: false, error: 'تعذّر تحديث الطلب' }
        return { success: true }
      }
    }

    const { error } = await supabase
      .from('message_requests')
      .insert({ sender_id: sid, receiver_id: rid })

    if (error) return { success: false, error: 'تعذّر إرسال الطلب' }
    return { success: true }
  } catch (e) {
    // [removed in production] 'sendMessageRequest error:', e
    return { success: false, error: 'حدث خطأ غير متوقع' }
  }
}

/**
 * الرد على طلب مراسلة (قبول/رفض)
 */
export async function respondToMessageRequest(
  requestId: string,
  status: 'accepted' | 'rejected'
): Promise<{ success: boolean; error?: string; conversationId?: string }> {
  try {
    // جلب بيانات الطلب أولاً
    const { data: requestData, error: fetchErr } = await supabase
      .from('message_requests')
      .select('sender_id, receiver_id')
      .eq('id', requestId)
      .maybeSingle()

    if (fetchErr || !requestData) {
      return { success: false, error: 'الطلب غير موجود' }
    }

    // تحديث حالة الطلب
    const { error } = await supabase
      .from('message_requests')
      .update({ status, responded_at: new Date().toISOString() })
      .eq('id', requestId)

    if (error) return { success: false, error: 'تعذّر الرد على الطلب' }

    // إذا تم القبول، أنشئ محادثة
    if (status === 'accepted') {
      const { sender_id, receiver_id } = requestData as { sender_id: string; receiver_id: string }
      // V-26: التحقق من صحة UUIDs
      const p1Raw = assertValidUUID(sender_id)
      const p2Raw = assertValidUUID(receiver_id)
      if (p1Raw === '00000000-0000-0000-0000-000000000000' || p2Raw === '00000000-0000-0000-0000-000000000000') {
        return { success: true }
      }
      const [p1, p2] = [p1Raw, p2Raw].sort()

      const { data: newConv, error: convErr } = await supabase
        .from('conversations')
        .insert({ participant_1: p1, participant_2: p2 })
        .select('id')
        .single()

      if (convErr) {
        if (convErr.code === '23505') {
          // محادثة موجودة بالفعل
          const { data: existingConv } = await supabase
            .from('conversations')
            .select('id')
            .or(`and(participant_1.eq.${p1},participant_2.eq.${p2}),and(participant_1.eq.${p2},participant_2.eq.${p1})`)
            .maybeSingle()
          if (existingConv) {
            return { success: true, conversationId: existingConv.id }
          }
        }
        // حتى لو فشل إنشاء المحادثة، الطلب قُبل
        return { success: true }
      }

      return { success: true, conversationId: newConv.id }
    }

    return { success: true }
  } catch (e) {
    // [removed in production] 'respondToMessageRequest error:', e
    return { success: false, error: 'حدث خطأ غير متوقع' }
  }
}

/**
 * جلب طلبات المراسلة الواردة
 */
export async function fetchIncomingRequests(userId: string): Promise<MessageRequest[]> {
  try {
    const { data, error } = await supabase
      .from('message_requests')
      .select(`
        *,
        sender:profiles!message_requests_sender_id_fkey(*)
      `)
      .eq('receiver_id', userId)
      .eq('status', 'pending')
      .order('created_at', { ascending: false })

    if (error || !data) return []
    return data as MessageRequest[]
  } catch (e) {
    // [removed in production] 'fetchIncomingRequests error:', e
    return []
  }
}

/**
 * جلب طلبات المراسلة المُرسلة
 */
export async function fetchOutgoingRequests(userId: string): Promise<MessageRequest[]> {
  try {
    const { data, error } = await supabase
      .from('message_requests')
      .select(`
        *,
        receiver:profiles!message_requests_receiver_id_fkey(*)
      `)
      .eq('sender_id', userId)
      .eq('status', 'pending') // الطلبات المعلقة فقط
      .order('created_at', { ascending: false })

    if (error || !data) return []
    return data as MessageRequest[]
  } catch (e) {
    // [removed in production] 'fetchOutgoingRequests error:', e
    return []
  }
}

/**
 * التحقق من حالة طلب المراسلة بين مستخدمين
 */
export async function checkMessageRequestStatus(
  currentUserId: string,
  otherUserId: string
): Promise<'none' | 'pending' | 'accepted' | 'rejected' | 'conversation_exists'> {
  try {
    // V-26: التحقق من صحة UUIDs
    const uidA = assertValidUUID(currentUserId)
    const uidB = assertValidUUID(otherUserId)
    if (uidA === '00000000-0000-0000-0000-000000000000' || uidB === '00000000-0000-0000-0000-000000000000') {
      return 'none'
    }

    // تحقق من محادثة موجودة
    const { data: conv } = await supabase
      .from('conversations')
      .select('id')
      .or(`and(participant_1.eq.${uidA},participant_2.eq.${uidB}),and(participant_1.eq.${uidB},participant_2.eq.${uidA})`)
      .maybeSingle()

    if (conv) return 'conversation_exists'

    // تحقق من طلب مراسلة
    const { data: req } = await supabase
      .from('message_requests')
      .select('status')
      .or(`and(sender_id.eq.${uidA},receiver_id.eq.${uidB}),and(sender_id.eq.${uidB},receiver_id.eq.${uidA})`)
      .maybeSingle()

    if (!req) return 'none'
    return req.status as 'pending' | 'accepted' | 'rejected'
  } catch (e) {
    // [removed in production] 'checkMessageRequestStatus error:', e
    return 'none'
  }
}
