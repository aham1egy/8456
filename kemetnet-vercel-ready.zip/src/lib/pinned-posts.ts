// src/lib/pinned-posts.ts
// نظام المنشورات المثبتة في الملف الشخصي

import { supabase } from './supabase/client'

export interface PinnedPostResult {
  success: boolean
  error?: string
}

/**
 * تثبيت منشور في الملف الشخصي
 * (التثبيت واحد فقط لكل مستخدم — التريغر يُلغي القديم تلقائياً)
 */
export async function pinPost(userId: string, postId: string): Promise<PinnedPostResult> {
  try {
    const { error } = await supabase
      .from('posts')
      .update({
        is_pinned: true,
        pinned_at: new Date().toISOString(),
      })
      .eq('id', postId)
      .eq('user_id', userId)

    if (error) {
      // [removed in production] '[pinPost] error:', error
      return { success: false, error: 'تعذّر تثبيت المنشور' }
    }

    return { success: true }
  } catch (e) {
    // [removed in production] '[pinPost] error:', e
    return { success: false, error: 'حدث خطأ' }
  }
}

/**
 * إلغاء تثبيت منشور
 */
export async function unpinPost(userId: string, postId: string): Promise<PinnedPostResult> {
  try {
    const { error } = await supabase
      .from('posts')
      .update({
        is_pinned: false,
        pinned_at: null,
      })
      .eq('id', postId)
      .eq('user_id', userId)

    if (error) {
      // [removed in production] '[unpinPost] error:', error
      return { success: false, error: 'تعذّر إلغاء التثبيت' }
    }

    return { success: true }
  } catch (e) {
    // [removed in production] '[unpinPost] error:', e
    return { success: false, error: 'حدث خطأ' }
  }
}

/**
 * تبديل حالة التثبيت
 */
export async function togglePinPost(
  userId: string,
  postId: string,
  currentlyPinned: boolean
): Promise<PinnedPostResult> {
  return currentlyPinned ? unpinPost(userId, postId) : pinPost(userId, postId)
}

/**
 * جلب المنشور المثبت لمستخدم معين (واحد فقط)
 */
export async function fetchPinnedPost(userId: string) {
  try {
    const { data, error } = await supabase
      .from('posts')
      .select('*, profile:profiles(*)')
      .eq('user_id', userId)
      .eq('is_pinned', true)
      .maybeSingle()

    if (error) {
      // [removed in production] '[fetchPinnedPost] error:', error
      return null
    }

    return data
  } catch (e) {
    // [removed in production] '[fetchPinnedPost] error:', e
    return null
  }
}
