// src/lib/navigation.ts
// أدوات تنقل موحدة عبر Next.js App Router
// تستبدل التنقل القديم عبر Zustand

'use client'

import { useRouter, usePathname } from 'next/navigation'
import { useCallback } from 'react'

const ROUTES = {
  home: '/home',
  explore: '/explore',
  create: '/create',
  notifications: '/notifications',
  profile: '/profile',
  settings: '/settings',
  auth: '/',
} as const

export type RouteName = keyof typeof ROUTES

/**
 * Hook للتنقل عبر روابط URL حقيقية
 * - كل صفحة لها رابط خاص
 * - زر الرجوع في المتصفح يعمل
 * - Refresh على أي صفحة يعمل
 * - مشاركة الروابط تعمل
 */
export function useNavigation() {
  const router = useRouter()
  const pathname = usePathname()

  const navigate = useCallback(
    (route: RouteName | string) => {
      const path = (ROUTES as Record<string, string>)[route] || route
      router.push(path)
    },
    [router]
  )

  const navigateToProfile = useCallback(
    (username: string) => {
      router.push(`/profile/${username}`)
    },
    [router]
  )

  const navigateToPost = useCallback(
    (postId: string) => {
      router.push(`/post/${postId}`)
    },
    [router]
  )

  const goBack = useCallback(() => {
    router.back()
  }, [router])

  const replace = useCallback(
    (route: RouteName | string) => {
      const path = (ROUTES as Record<string, string>)[route] || route
      router.replace(path)
    },
    [router]
  )

  return {
    navigate,
    navigateToProfile,
    navigateToPost,
    goBack,
    replace,
    pathname,
  }
}
