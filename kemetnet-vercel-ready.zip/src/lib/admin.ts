// src/lib/admin.ts
// وظائف الإدارة - KemetNet Admin
// CRUD على المنشورات / البلاغات / الحسابات / التوثيقات

import { supabase } from './supabase/client'
import type { Profile, Post } from './supabase/client'

// ============= أنواع البيانات =============

export interface AdminReport {
  id: string
  reporter_id: string
  reported_user_id: string | null
  post_id: string | null
  comment_id: string | null
  reason: string
  details: string | null
  status: 'pending' | 'reviewing' | 'actioned' | 'dismissed'
  created_at: string
  // حقول إدارة البلاغات
  action_taken?: string | null
  admin_id?: string | null
  admin_note?: string | null
  resolved_at?: string | null
  // relations
  reporter_profile?: Profile | null
  reported_profile?: Profile | null
  reported_post?: Post | null
  admin_profile?: Profile | null
}

export interface AdminVerificationRequest {
  id: string
  user_id: string
  requested_type: 'official' | 'business' | 'creator' | 'early_adopter'
  reason: string
  status: 'pending' | 'approved' | 'rejected'
  admin_notes: string | null   // ملاحظة الإدارة (العمود في DB: admin_notes)
  created_at: string
  profile?: Profile | null
}

export interface AdminStats {
  total_users: number
  total_posts: number
  total_comments: number
  total_messages: number
  pending_reports: number
  pending_verifications: number
  verified_users: number
  new_users_today: number
  new_posts_today: number
}

export interface AdminUser extends Profile {
  status: 'active' | 'restricted' | 'banned'
  restricted_until: string | null
  restriction_reason: string | null
}

// ============= فحص الصلاحية =============

export async function checkAdminAuth(): Promise<boolean> {
  const { data: { session } } = await supabase.auth.getSession()
  if (!session?.user) return false

  const { data: profile } = await supabase
    .from('profiles')
    .select('username, is_verified, verified_type')
    .eq('id', session.user.id)
    .single()

  if (!profile) return false
  const { isAdminProfile } = await import('./admin-config')
  return isAdminProfile(profile as any)
}

// ============= Stats =============

export async function fetchAdminStats(): Promise<AdminStats> {
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  const todayISO = today.toISOString()

  const [
    usersRes, postsRes, commentsRes, messagesRes,
    reportsRes, verificationsRes, verifiedRes,
    newUsersRes, newPostsRes
  ] = await Promise.all([
    supabase.from('profiles').select('id', { count: 'exact', head: true }),
    supabase.from('posts').select('id', { count: 'exact', head: true }),
    supabase.from('comments').select('id', { count: 'exact', head: true }),
    supabase.from('messages').select('id', { count: 'exact', head: true }),
    supabase.from('reports').select('id', { count: 'exact', head: true }).eq('status', 'pending'),
    supabase.from('verification_requests').select('id', { count: 'exact', head: true }).eq('status', 'pending'),
    supabase.from('profiles').select('id', { count: 'exact', head: true }).eq('is_verified', true),
    supabase.from('profiles').select('id', { count: 'exact', head: true }).gte('created_at', todayISO),
    supabase.from('posts').select('id', { count: 'exact', head: true }).gte('created_at', todayISO),
  ])

  return {
    total_users: usersRes.count || 0,
    total_posts: postsRes.count || 0,
    total_comments: commentsRes.count || 0,
    total_messages: messagesRes.count || 0,
    pending_reports: reportsRes.count || 0,
    pending_verifications: verificationsRes.count || 0,
    verified_users: verifiedRes.count || 0,
    new_users_today: newUsersRes.count || 0,
    new_posts_today: newPostsRes.count || 0,
  }
}

// ============= المنشورات =============

export async function fetchAllPostsAdmin(limit = 50, offset = 0): Promise<{ posts: Post[]; total: number }> {
  const { data, count, error } = await supabase
    .from('posts')
    .select('*, profile:profiles!posts_user_id_fkey(*)', { count: 'exact' })
    .order('created_at', { ascending: false })
    .range(offset, offset + limit - 1)

  if (error) throw error
  return { posts: (data as unknown as Post[]) || [], total: count || 0 }
}

export async function adminDeletePost(postId: string): Promise<void> {
  const { error } = await supabase.from('posts').delete().eq('id', postId)
  if (error) throw error
}

export async function adminFeaturePost(postId: string, featured: boolean): Promise<void> {
  const { error } = await supabase
    .from('posts')
    .update({
      is_featured: featured,
      featured_at: featured ? new Date().toISOString() : null,
    })
    .eq('id', postId)
  if (error) throw error
}

export async function adminPinPost(postId: string, pinned: boolean): Promise<void> {
  const { error } = await supabase
    .from('posts')
    .update({
      is_pinned: pinned,
      pinned_at: pinned ? new Date().toISOString() : null,
    })
    .eq('id', postId)
  if (error) throw error
}

// ============= البلاغات =============

export async function fetchAllReports(limit = 50, offset = 0, status?: string): Promise<{ reports: AdminReport[]; total: number }> {
  let query = supabase
    .from('reports')
    .select(`
      *,
      reporter_profile:profiles!reports_reporter_id_fkey(*),
      reported_profile:profiles!reports_reported_user_id_fkey(*),
      reported_post:posts!reports_post_id_fkey(*),
      admin_profile:profiles!reports_admin_id_fkey(*)
    `, { count: 'exact' })
    .order('created_at', { ascending: false })

  if (status && status !== 'all') {
    query = query.eq('status', status)
  }

  const { data, count, error } = await query.range(offset, offset + limit - 1)
  if (error) throw error
  return { reports: (data as unknown as AdminReport[]) || [], total: count || 0 }
}

/**
 * تحديث حالة البلاغ مع تفاصيل الإجراء المتخذ
 */
export async function adminUpdateReportStatus(
  reportId: string,
  status: 'reviewing' | 'actioned' | 'dismissed',
  options: {
    actionTaken?: string
    adminNote?: string
  } = {}
): Promise<void> {
  const update: Record<string, any> = { status }

  if (options.actionTaken) {
    update.action_taken = options.actionTaken
  }
  if (options.adminNote !== undefined) {
    update.admin_note = options.adminNote
  }
  // إذا تم اتخاذ إجراء أو رفض، سجّل admin_id و resolved_at
  if (status === 'actioned' || status === 'dismissed') {
    const { data: { user } } = await supabase.auth.getUser()
    if (user) {
      update.admin_id = user.id
    }
    update.resolved_at = new Date().toISOString()
  }

  const { error } = await supabase
    .from('reports')
    .update(update)
    .eq('id', reportId)
  if (error) throw error
}

/**
 * تعيين البلاغ لنفسي (assign to me) — يصبح في حالة reviewing
 */
export async function adminAssignReportToMe(reportId: string): Promise<void> {
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) throw new Error('Not authenticated')

  const { error } = await supabase
    .from('reports')
    .update({
      status: 'reviewing',
      admin_id: user.id,
    })
    .eq('id', reportId)
    .eq('status', 'pending')  // فقط البلاغات المعلّقة
  if (error) throw error
}

/**
 * اتخاذ إجراء شامل على البلاغ:
 * - تحديث حالة البلاغ
 * - حذف المنشور المبلّغ عنه (اختياري)
 * - حظر/تقييد المستخدم المبلّغ عنه (اختياري)
 * - تسجيل الإجراء المتخذ
 */
export async function adminTakeReportAction(
  reportId: string,
  options: {
    action: 'actioned' | 'dismissed'
    actionType?: 'delete_post' | 'restrict_user' | 'warn_user' | 'no_action' | 'other'
    adminNote?: string
    deleteReportedPost?: boolean
    restrictUserDays?: number  // عدد أيام التقييد (0 = بدون تقييد)
  }
): Promise<void> {
  const { action, actionType = 'no_action', adminNote = '', deleteReportedPost = false, restrictUserDays = 0 } = options

  // 1) جلب تفاصيل البلاغ
  const { data: report, error: err1 } = await supabase
    .from('reports')
    .select('id, post_id, reported_user_id')
    .eq('id', reportId)
    .single()
  if (err1) throw err1
  if (!report) throw new Error('Report not found')

  // 2) حذف المنشور المبلّغ عنه (اختياري)
  if (deleteReportedPost && report.post_id) {
    const { error: err2 } = await supabase
      .from('posts')
      .delete()
      .eq('id', report.post_id)
    if (err2) {
      // قد يفشل بسبب RLS — سجّل كخطأ لكن تابع
      console.warn('Failed to delete post:', err2.message)
    }
  }

  // 3) تقييد المستخدم (اختياري)
  if (restrictUserDays > 0 && report.reported_user_id) {
    try {
      await supabase.rpc('admin_restrict_user', {
        target_user_id: report.reported_user_id,
        reason: `بلاغ #${reportId}: ${adminNote || 'مخالفة لسياسات التطبيق'}`,
        days: restrictUserDays,
      })
    } catch (e: any) {
      // RLS قد يمنع — نتجاهل
      console.warn('Failed to restrict user:', e.message)
    }
  }

  // 4) تحديث حالة البلاغ
  const actionLabel = {
    delete_post: 'تم حذف المنشور',
    restrict_user: `تم تقييد المستخدم ${restrictUserDays > 0 ? `لمدة ${restrictUserDays} يوم` : ''}`,
    warn_user: 'تم تحذير المستخدم',
    no_action: 'لا إجراء مطلوب',
    other: adminNote,
  }[actionType]

  await adminUpdateReportStatus(reportId, action, {
    actionTaken: actionLabel,
    adminNote,
  })
}

/**
 * إجراء جماعي على بلاغات متعددة
 */
export async function adminBulkUpdateReports(
  reportIds: string[],
  status: 'actioned' | 'dismissed'
): Promise<void> {
  const { error } = await supabase
    .from('reports')
    .update({
      status,
      resolved_at: new Date().toISOString(),
    })
    .in('id', reportIds)
  if (error) throw error
}

/**
 * إحصائيات البلاغات للـ dashboard
 */
export async function fetchReportsStats(): Promise<{
  total: number
  pending: number
  reviewing: number
  actioned: number
  dismissed: number
}> {
  const [total, pending, reviewing, actioned, dismissed] = await Promise.all([
    supabase.from('reports').select('id', { count: 'exact', head: true }),
    supabase.from('reports').select('id', { count: 'exact', head: true }).eq('status', 'pending'),
    supabase.from('reports').select('id', { count: 'exact', head: true }).eq('status', 'reviewing'),
    supabase.from('reports').select('id', { count: 'exact', head: true }).eq('status', 'actioned'),
    supabase.from('reports').select('id', { count: 'exact', head: true }).eq('status', 'dismissed'),
  ])

  return {
    total: total.count || 0,
    pending: pending.count || 0,
    reviewing: reviewing.count || 0,
    actioned: actioned.count || 0,
    dismissed: dismissed.count || 0,
  }
}

// ============= المستخدمون =============

export async function fetchAllUsers(limit = 50, offset = 0, search?: string): Promise<{ users: Profile[]; total: number }> {
  let query = supabase
    .from('profiles')
    .select('*', { count: 'exact' })
    .order('created_at', { ascending: false })

  if (search) {
    query = query.or(`username.ilike.%${search}%,display_name.ilike.%${search}%`)
  }

  const { data, count, error } = await query.range(offset, offset + limit - 1)
  if (error) throw error
  return { users: (data as Profile[]) || [], total: count || 0 }
}

export async function adminVerifyUser(
  userId: string,
  verifiedType: 'official' | 'business' | 'creator' | 'early_adopter',
  verified: boolean = true
): Promise<void> {
  const { error } = await supabase
    .from('profiles')
    .update({
      is_verified: verified,
      verified_type: verified ? verifiedType : null,
      verified_at: verified ? new Date().toISOString() : null,
    })
    .eq('id', userId)
  if (error) throw error
}

export async function adminUnverifyUser(userId: string): Promise<void> {
  const { error } = await supabase
    .from('profiles')
    .update({
      is_verified: false,
      verified_type: null,
      verified_at: null,
    })
    .eq('id', userId)
  if (error) throw error
}

export async function adminDeleteUser(userId: string): Promise<void> {
  // حذف البروفايل — auth.users لا يمكن حذفها من العميل
  // المستخدم يبقى في auth.users لكن بدون بروفايل
  const { error } = await supabase.from('profiles').delete().eq('id', userId)
  if (error) throw error
}

// تحديث النقاط/المستوى يدويًا (مع تجاوز RLS عبر RPC لو متاح)
export async function adminUpdateReputation(
  userId: string,
  points: number,
  level: number
): Promise<void> {
  const { error } = await supabase
    .from('profiles')
    .update({
      reputation_points: points,
      reputation_level: level,
    })
    .eq('id', userId)
  if (error) throw error
}

// ============= طلبات التوثيق =============

export async function fetchVerificationRequests(limit = 50, offset = 0, status = 'pending'): Promise<{ requests: AdminVerificationRequest[]; total: number }> {
  let query = supabase
    .from('verification_requests')
    .select('*, profile:profiles!verification_requests_user_id_fkey(*)', { count: 'exact' })
    .order('created_at', { ascending: false })

  if (status !== 'all') {
    query = query.eq('status', status)
  }

  const { data, count, error } = await query.range(offset, offset + limit - 1)
  if (error) throw error
  return { requests: (data as unknown as AdminVerificationRequest[]) || [], total: count || 0 }
}

export async function adminApproveVerification(
  requestId: string,
  userId: string,
  verifiedType: 'official' | 'business' | 'creator' | 'early_adopter',
  adminNote?: string
): Promise<void> {
  // 1) تحديث الطلب
  const { error: err1 } = await supabase
    .from('verification_requests')
    .update({
      status: 'approved',
      admin_notes: adminNote || null,
    })
    .eq('id', requestId)
  if (err1) throw err1

  // 2) توثيق المستخدم
  const { error: err2 } = await supabase
    .from('profiles')
    .update({
      is_verified: true,
      verified_type: verifiedType,
      verified_at: new Date().toISOString(),
    })
    .eq('id', userId)
  if (err2) throw err2
}

export async function adminRejectVerification(
  requestId: string,
  adminNote: string
): Promise<void> {
  const { error } = await supabase
    .from('verification_requests')
    .update({
      status: 'rejected',
      admin_notes: adminNote,
    })
    .eq('id', requestId)
  if (error) throw error
}

// ========================================
// ============= إدارة الفريق =============
// ========================================

export interface StaffMember {
  id: string
  user_id: string
  role: 'admin' | 'moderator' | 'custom'
  permissions: string[]
  added_by: string | null
  added_at: string
  updated_at: string
  active: boolean
  notes: string | null
  profile?: Profile | null
}

/**
 * جلب كل الموظفين (للمالك فقط)
 */
export async function fetchStaffMembers(): Promise<StaffMember[]> {
  const { data, error } = await supabase
    .from('staff_members')
    .select('*, profile:profiles!staff_members_user_id_fkey(*)')
    .order('added_at', { ascending: false })

  if (error) throw error
  return (data as unknown as StaffMember[]) || []
}

/**
 * إضافة موظف جديد (للمالك فقط)
 */
export async function addStaffMember(
  targetUserId: string,
  role: 'admin' | 'moderator' | 'custom',
  permissions: string[],
  notes?: string
): Promise<void> {
  const { error } = await supabase.rpc('add_staff_member', {
    target_user_id: targetUserId,
    staff_role: role,
    perms: permissions,
    staff_notes: notes || null,
  })
  if (error) throw error
}

/**
 * تحديث صلاحيات موظف (للمالك فقط)
 */
export async function updateStaffPermissions(
  targetUserId: string,
  newPermissions: string[],
  options: {
    newRole?: 'admin' | 'moderator' | 'custom'
    newActive?: boolean
    newNotes?: string
  } = {}
): Promise<void> {
  const { error } = await supabase.rpc('update_staff_permissions', {
    target_user_id: targetUserId,
    new_permissions: newPermissions,
    new_role: options.newRole || null,
    new_active: options.newActive ?? null,
    new_notes: options.newNotes || null,
  })
  if (error) throw error
}

/**
 * إزالة موظف (للمالك فقط)
 */
export async function removeStaffMember(targetUserId: string): Promise<void> {
  const { error } = await supabase.rpc('remove_staff_member', {
    target_user_id: targetUserId,
  })
  if (error) throw error
}

/**
 * فحص صلاحية محلية (بناءً على بيانات staff_members المحفوظة في العميل)
 */
export function hasPermissionLocal(
  profile: { role?: string | null; username?: string | null } | null,
  staffPermissions: string[] | null,
  perm: string
): boolean {
  if (!profile) return false
  // المالك يملك كل الصلاحيات
  if (profile.username === 'kemetnet') return true
  if (profile.role === 'owner') return true
  // الأدمن العام (ما عدا manage_staff)
  if (profile.role === 'admin' && perm !== 'manage_staff') return true
  // التحقق من قائمة الصلاحيات
  if (!staffPermissions || staffPermissions.length === 0) return false
  return staffPermissions.includes('*') || staffPermissions.includes(perm)
}
