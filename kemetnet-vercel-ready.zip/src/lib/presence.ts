// src/lib/presence.ts
// نظام الحضور (presence) - حالة الاتصال + مؤشر الكتابة
// يستخدم Supabase Realtime presence channel

import { supabase } from './supabase/client'

// ========================================
// أنواع البيانات
// ========================================

export type PresenceStatus = 'online' | 'away' | 'offline'

export interface PresenceState {
  user_id: string
  status: PresenceStatus
  last_seen: number
  // typing: معرف المحادثة التي يكتب فيها المستخدم حالياً
  typing_in?: string | null
}

// ========================================
// إدارة قناة presence العامة
// ========================================

const PRESENCE_CHANNEL_NAME = 'mishri-presence'
let presenceChannel: ReturnType<typeof supabase.channel> | null = null
let currentUserId: string | null = null
let lastActivity: number = Date.now()
let awayTimer: ReturnType<typeof setInterval> | null = null
let presenceListeners: { updateActivity: () => void; handleBeforeUnload: () => void } | null = null

const AWAY_TIMEOUT = 5 * 60 * 1000 // 5 دقائق بدون نشاط = away

/**
 * تهيئة حضور المستخدم في القناة العامة
 */
export function initPresence(userId: string): void {
  if (typeof window === 'undefined') return
  if (currentUserId === userId && presenceChannel) return

  currentUserId = userId
  lastActivity = Date.now()

  // إزالة القناة القديمة إن وُجدت
  if (presenceChannel) {
    supabase.removeChannel(presenceChannel)
  }

  // إنشاء قناة presence جديدة
  presenceChannel = supabase.channel(PRESENCE_CHANNEL_NAME, {
    config: {
      presence: {
        key: userId,
      },
    },
  })

  // الاشتراك وتعيين الحالة الأولية
  presenceChannel
    .on('presence', { event: 'sync' }, () => {
      // لا شيء هنا — التحديث يتم عبر getOnlineUsers
    })
    .on('presence', { event: 'join' }, ({ key, newPresences }) => {
      // يمكن استخدامها للإشعارات (اختياري)
    })
    .on('presence', { event: 'leave' }, () => {
      // يمكن استخدامها للإشعارات (اختياري)
    })
    .subscribe(async (status) => {
      if (status === 'SUBSCRIBED') {
        await presenceChannel?.track({
          user_id: userId,
          status: 'online' as PresenceStatus,
          last_seen: Date.now(),
          typing_in: null,
        })
      }
    })

  // مراقب النشاط (لتحديث last_activity)
  const updateActivity = () => {
    lastActivity = Date.now()
    updatePresenceStatus('online')
  }

  window.addEventListener('mousemove', updateActivity)
  window.addEventListener('keydown', updateActivity)
  window.addEventListener('touchstart', updateActivity)
  window.addEventListener('click', updateActivity)

  // مؤقت لتحويل المستخدم لـ away بعد 5 دقائق بدون نشاط
  if (awayTimer) clearInterval(awayTimer)
  awayTimer = setInterval(() => {
    if (Date.now() - lastActivity > AWAY_TIMEOUT) {
      updatePresenceStatus('away')
    }
  }, 60 * 1000)

  // عند مغادرة الصفحة، اعتبر المستخدم offline
  const handleBeforeUnload = () => {
    updatePresenceStatus('offline')
    if (awayTimer) clearInterval(awayTimer)
    // ✅ تنظيف مستمعي الأحداث لمنع تسريب الذاكرة
    window.removeEventListener('mousemove', updateActivity)
    window.removeEventListener('keydown', updateActivity)
    window.removeEventListener('touchstart', updateActivity)
    window.removeEventListener('click', updateActivity)
    window.removeEventListener('beforeunload', handleBeforeUnload)
  }
  window.addEventListener('beforeunload', handleBeforeUnload)

  // حفظ مراجع المستمعين للتنظيف لاحقاً
  presenceListeners = { updateActivity, handleBeforeUnload }
}

/**
 * تحديث حالة الحضور
 */
export async function updatePresenceStatus(status: PresenceStatus): Promise<void> {
  if (!presenceChannel || !currentUserId) return

  await presenceChannel.track({
    user_id: currentUserId,
    status,
    last_seen: Date.now(),
    typing_in: null,
  })
}

/**
 * تحديث حالة الكتابة (typing)
 */
export async function setTyping(conversationId: string | null): Promise<void> {
  if (!presenceChannel || !currentUserId) return

  await presenceChannel.track({
    user_id: currentUserId,
    status: 'online',
    last_seen: Date.now(),
    typing_in: conversationId,
  })
}

/**
 * تنظيف الحضور (عند تسجيل الخروج)
 */
export function cleanupPresence(): void {
  if (awayTimer) {
    clearInterval(awayTimer)
    awayTimer = null
  }
  // ✅ تنظيف مستمعي الأحداث لمنع تسريب الذاكرة
  if (presenceListeners) {
    window.removeEventListener('mousemove', presenceListeners.updateActivity)
    window.removeEventListener('keydown', presenceListeners.updateActivity)
    window.removeEventListener('touchstart', presenceListeners.updateActivity)
    window.removeEventListener('click', presenceListeners.updateActivity)
    window.removeEventListener('beforeunload', presenceListeners.handleBeforeUnload)
    presenceListeners = null
  }
  if (presenceChannel) {
    updatePresenceStatus('offline')
    supabase.removeChannel(presenceChannel)
    presenceChannel = null
  }
  currentUserId = null
}

/**
 * جلب حالة حضور مستخدم معين
 */
export async function getUserPresence(userId: string): Promise<PresenceState | null> {
  if (!presenceChannel) return null

  const state = presenceChannel.presenceState()
  // presence state يحتوي على arrays من الـ states (لأن نفس المستخدم يمكن أن يكون متصلاً من عدة أجهزة)
  const userStates = (state[userId] as unknown as PresenceState[] | undefined) || []
  if (userStates.length === 0) return null

  // خذ آخر تحديث (الأحدث)
  const latest = userStates.reduce((acc, curr) => {
    if (!acc || curr.last_seen > acc.last_seen) return curr
    return acc
  }, userStates[0])

  // تحقق من انتهاء الصلاحية (آخر رؤية قبل أكثر من 5 دقائق = offline)
  if (Date.now() - latest.last_seen > AWAY_TIMEOUT) {
    return {
      ...latest,
      status: 'offline',
    }
  }

  return latest
}

/**
 * الاشتراك في تحديثات حضور مستخدم معين (callback)
 */
export function subscribeToUserPresence(
  userId: string,
  callback: (state: PresenceState | null) => void
): () => void {
  if (!presenceChannel) {
    callback(null)
    return () => {}
  }

  // تشغيل الـ callback مرة أولى بالحالة الحالية
  void getUserPresence(userId).then(callback)

  // الاشتراك في تحديثات sync
  const handler = () => {
    void getUserPresence(userId).then(callback)
  }

  presenceChannel.on('presence', { event: 'sync' }, handler)

  // إرجاع دالة لإلغاء الاشتراك
  return () => {
    if (presenceChannel) {
      // لسوء الحظ supabase لا يدعم off لـ presence events بشكل مباشر
      // سيتم تنظيفها عند إزالة القناة
    }
  }
}

/**
 * الاشتراك في مؤشر الكتابة لمحادثة معينة
 */
export function subscribeToTyping(
  conversationId: string,
  otherUserId: string,
  callback: (isTyping: boolean) => void
): () => void {
  if (!presenceChannel) {
    callback(false)
    return () => {}
  }

  let lastTypingState = false

  const handler = () => {
    void getUserPresence(otherUserId).then((state) => {
      if (!state) {
        if (lastTypingState) {
          lastTypingState = false
          callback(false)
        }
        return
      }
      const isTyping = state.typing_in === conversationId
      if (isTyping !== lastTypingState) {
        lastTypingState = isTyping
        callback(isTyping)
      }
    })
  }

  presenceChannel.on('presence', { event: 'sync' }, handler)

  // تحقق دوري (احتياطي) كل ثانيتين
  const interval = setInterval(handler, 2000)

  return () => {
    clearInterval(interval)
  }
}
