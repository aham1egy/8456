// src/lib/drafts.ts
// نظام المسودات التلقائية - يحفظ في localStorage
// يدعم: مسودات الرسائل (لكل محادثة) + مسودات المنشورات

// ========================================
// أنواع المسودات
// ========================================

export interface MessageDraft {
  content: string
  pendingImageKey: string | null // مفتاح للصورة المعلّقة في memory
  updatedAt: number
}

export interface PostDraft {
  content: string
  category: string
  mood: string | null
  tags: string[]
  imageUrl: string | null // base64 data URL مؤقت
  updatedAt: number
}

// ========================================
// مفاتيح التخزين
// ========================================

const MESSAGE_DRAFTS_KEY = 'mishri-message-drafts'
const POST_DRAFT_KEY = 'mishri-post-draft'

// TTL للمسودات: 7 أيام
const DRAFT_TTL = 7 * 24 * 60 * 60 * 1000

// ========================================
// دوال مساعدة للوصول لـ localStorage
// ========================================

function safeGetItem(key: string): string | null {
  try {
    if (typeof window === 'undefined') return null
    return window.localStorage.getItem(key)
  } catch {
    return null
  }
}

function safeSetItem(key: string, value: string): boolean {
  try {
    if (typeof window === 'undefined') return false
    window.localStorage.setItem(key, value)
    return true
  } catch (e) {
    // قد يفشل بسبب امتلاء التخزين (quota)
    return false
  }
}

function safeRemoveItem(key: string): void {
  try {
    if (typeof window === 'undefined') return
    window.localStorage.removeItem(key)
  } catch {
    // ignore
  }
}

// ========================================
// مسودات الرسائل (لكل محادثة)
// ========================================

/**
 * تحميل كل مسودات الرسائل
 */
function loadAllMessageDrafts(): Record<string, MessageDraft> {
  const raw = safeGetItem(MESSAGE_DRAFTS_KEY)
  if (!raw) return {}
  try {
    const parsed = JSON.parse(raw) as Record<string, MessageDraft>
    // تنظيف المسودات القديمة (TTL)
    const now = Date.now()
    const valid: Record<string, MessageDraft> = {}
    for (const [key, draft] of Object.entries(parsed)) {
      if (now - draft.updatedAt < DRAFT_TTL) {
        valid[key] = draft
      }
    }
    return valid
  } catch {
    return {}
  }
}

function saveAllMessageDrafts(drafts: Record<string, MessageDraft>): void {
  safeSetItem(MESSAGE_DRAFTS_KEY, JSON.stringify(drafts))
}

/**
 * حفظ مسودة رسالة لمحادثة معينة
 */
export function saveMessageDraft(conversationId: string, content: string, pendingImageKey: string | null = null): void {
  const trimmed = content.trim()
  const all = loadAllMessageDrafts()

  if (!trimmed && !pendingImageKey) {
    // حذف المسودة إذا كانت فارغة
    delete all[conversationId]
  } else {
    all[conversationId] = {
      content: trimmed,
      pendingImageKey,
      updatedAt: Date.now(),
    }
  }
  saveAllMessageDrafts(all)
}

/**
 * تحميل مسودة رسالة لمحادثة معينة
 */
export function loadMessageDraft(conversationId: string): MessageDraft | null {
  const all = loadAllMessageDrafts()
  return all[conversationId] || null
}

/**
 * حذف مسودة رسالة
 */
export function clearMessageDraft(conversationId: string): void {
  const all = loadAllMessageDrafts()
  delete all[conversationId]
  saveAllMessageDrafts(all)
}

/**
 * حذف كل مسودات الرسائل
 */
export function clearAllMessageDrafts(): void {
  safeRemoveItem(MESSAGE_DRAFTS_KEY)
}

// ========================================
// مسودات المنشورات
// ========================================

/**
 * تحميل مسودة المنشور
 */
export function loadPostDraft(): PostDraft | null {
  const raw = safeGetItem(POST_DRAFT_KEY)
  if (!raw) return null
  try {
    const draft = JSON.parse(raw) as PostDraft
    // التحقق من TTL
    if (Date.now() - draft.updatedAt > DRAFT_TTL) {
      safeRemoveItem(POST_DRAFT_KEY)
      return null
    }
    return draft
  } catch {
    return null
  }
}

/**
 * حفظ مسودة المنشور
 */
export function savePostDraft(draft: Omit<PostDraft, 'updatedAt'>): void {
  const fullDraft: PostDraft = {
    ...draft,
    updatedAt: Date.now(),
  }
  safeSetItem(POST_DRAFT_KEY, JSON.stringify(fullDraft))
}

/**
 * حذف مسودة المنشور
 */
export function clearPostDraft(): void {
  safeRemoveItem(POST_DRAFT_KEY)
}

// ========================================
// تخزين الصور المعلّقة في memory (blob URLs)
// ========================================

// خريطة مؤقتة لـ blob URLs (لا تُحفظ في localStorage لأنها تختفي عند إعادة التحميل)
const pendingImageUrls = new Map<string, string>()

/**
 * حفظ blob URL مؤقت للصورة المعلّقة
 */
export function setPendingImage(key: string, blobUrl: string): void {
  pendingImageUrls.set(key, blobUrl)
}

/**
 * تحميل blob URL مؤقت
 */
export function getPendingImage(key: string | null): string | null {
  if (!key) return null
  return pendingImageUrls.get(key) || null
}

/**
 * حذف blob URL مؤقت
 */
export function clearPendingImage(key: string | null): void {
  if (!key) return
  const url = pendingImageUrls.get(key)
  if (url) {
    URL.revokeObjectURL(url)
    pendingImageUrls.delete(key)
  }
}

/**
 * تنظيف كل الصور المعلّقة
 */
export function clearAllPendingImages(): void {
  for (const url of pendingImageUrls.values()) {
    URL.revokeObjectURL(url)
  }
  pendingImageUrls.clear()
}

// ========================================
// هوك React للاستخدام السهل (Auto-save)
// ========================================

import { useEffect, useRef, useState } from 'react'

/**
 * هوك لحفظ مسودة رسالة تلقائياً
 * @param conversationId معرف المحادثة
 * @param initialContent المحتوى الأولي
 * @returns [content, setContent, clearDraft]
 */
export function useMessageDraft(conversationId: string) {
  const [content, setContent] = useState('')
  const [pendingImageKey, setPendingImageKey] = useState<string | null>(null)
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  // تحميل المسودة عند التحميل
  useEffect(() => {
    const draft = loadMessageDraft(conversationId)
    if (draft) {
      setContent(draft.content)
      setPendingImageKey(draft.pendingImageKey)
    }
  }, [conversationId])

  // حفظ تلقائي (debounce 500ms)
  useEffect(() => {
    if (debounceRef.current) {
      clearTimeout(debounceRef.current)
    }
    debounceRef.current = setTimeout(() => {
      saveMessageDraft(conversationId, content, pendingImageKey)
    }, 500)

    return () => {
      if (debounceRef.current) {
        clearTimeout(debounceRef.current)
      }
    }
  }, [conversationId, content, pendingImageKey])

  const clearDraft = () => {
    setContent('')
    if (pendingImageKey) {
      clearPendingImage(pendingImageKey)
    }
    setPendingImageKey(null)
    clearMessageDraft(conversationId)
  }

  return {
    content,
    setContent,
    pendingImageKey,
    setPendingImageKey,
    clearDraft,
  }
}

/**
 * هوك لحفظ مسودة منشور تلقائياً
 */
export function usePostDraft() {
  const [content, setContent] = useState('')
  const [category, setCategory] = useState('thoughts')
  const [mood, setMood] = useState<string | null>(null)
  const [tags, setTags] = useState<string[]>([])
  const [imageUrl, setImageUrl] = useState<string | null>(null)
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const loadedRef = useRef(false)

  // تحميل المسودة عند التحميل
  useEffect(() => {
    if (loadedRef.current) return
    loadedRef.current = true
    const draft = loadPostDraft()
    if (draft) {
      setContent(draft.content)
      setCategory(draft.category)
      setMood(draft.mood)
      setTags(draft.tags)
      setImageUrl(draft.imageUrl)
    }
  }, [])

  // حفظ تلقائي (debounce 800ms)
  useEffect(() => {
    if (debounceRef.current) {
      clearTimeout(debounceRef.current)
    }
    debounceRef.current = setTimeout(() => {
      // حفظ فقط إذا كان هناك محتوى أو صورة
      if (content.trim() || imageUrl) {
        savePostDraft({
          content,
          category,
          mood,
          tags,
          imageUrl,
        })
      } else {
        clearPostDraft()
      }
    }, 800)

    return () => {
      if (debounceRef.current) {
        clearTimeout(debounceRef.current)
      }
    }
  }, [content, category, mood, tags, imageUrl])

  const clearDraft = () => {
    setContent('')
    setCategory('thoughts')
    setMood(null)
    setTags([])
    setImageUrl(null)
    clearPostDraft()
  }

  const hasDraft = !!(content.trim() || imageUrl || tags.length > 0)

  return {
    content,
    setContent,
    category,
    setCategory,
    mood,
    setMood,
    tags,
    setTags,
    imageUrl,
    setImageUrl,
    clearDraft,
    hasDraft,
  }
}
