// src/lib/moderation.ts
// نظام الإبلاغ + حجب المستخدمين

import { supabase } from './supabase/client'
import type { Profile } from './supabase/client'

// ========================================
// أنواع البيانات
// ========================================

export type ReportTargetType = 'post' | 'comment' | 'message' | 'profile'

export type ReportReason =
  | 'spam'
  | 'harassment'
  | 'hate'
  | 'violence'
  | 'adult'
  | 'illegal'
  | 'impersonation'
  | 'misinformation'
  | 'other'

export type ReportStatus = 'pending' | 'reviewing' | 'resolved' | 'dismissed'

export interface Report {
  id: string
  reporter_id: string
  target_type: ReportTargetType
  target_id: string
  reported_user_id: string
  reason: ReportReason
  description: string | null
  status: ReportStatus
  admin_notes: string | null
  created_at: string
  resolved_at: string | null
  reported_user?: Profile
}

export interface Block {
  id?: string
  blocker_id: string
  blocked_id: string
  created_at: string
  blocked?: Profile | null
}

// ========================================
// أسباب البلاغ بالعربية
// ========================================

export const REPORT_REASONS: Record<ReportReason, { label: string; desc: string }> = {
  spam: { label: 'محتوى مزعج', desc: 'إعلانات أو تكرار غير مرغوب' },
  harassment: { label: 'مضايقة أو تنمر', desc: 'استهداف شخص بالإساءة' },
  hate: { label: 'خطاب كراهية', desc: 'تحريض ضد فئة معينة' },
  violence: { label: 'عنف أو تحريض', desc: 'دعوة للأذى أو العنف' },
  adult: { label: 'محتوى للبالغين', desc: 'محتوى غير لائق' },
  illegal: { label: 'نشاط غير قانوني', desc: 'أنشطة مخالفة للقانون' },
  impersonation: { label: 'انتحال شخصية', desc: 'ادعاء هوية شخص آخر' },
  misinformation: { label: 'معلومات مضللة', desc: 'نشر معلومات كاذبة' },
  other: { label: 'سبب آخر', desc: 'سبب غير المذكور أعلاه' },
}

// ========================================
// إدارة البلاغات
// ========================================

export interface CreateReportResult {
  success: boolean
  error?: string
  alreadyReported?: boolean
}

/**
 * إنشاء بلاغ عن محتوى
 */
export async function createReport(
  reporterId: string,
  targetType: ReportTargetType,
  targetId: string,
  reportedUserId: string,
  reason: ReportReason,
  description?: string
): Promise<CreateReportResult> {
  if (reporterId === reportedUserId) {
    return { success: false, error: 'لا يمكنك الإبلاغ عن نفسك' }
  }

  try {
    const { error } = await supabase
      .from('reports')
      .insert({
        reporter_id: reporterId,
        target_type: targetType,
        target_id: targetId,
        reported_user_id: reportedUserId,
        reason,
        description: description?.trim() || null,
      })

    if (error) {
      // إذا كان البلاغ موجوداً مسبقاً (UNIQUE constraint)
      if (error.message.includes('duplicate') || error.message.includes('unique') || error.code === '23505') {
        return { success: false, error: 'لقد بلّغت عن هذا المحتوى مسبقاً', alreadyReported: true }
      }
      // [removed in production] '[createReport] error:', error
      return { success: false, error: 'تعذّر إرسال البلاغ' }
    }

    return { success: true }
  } catch (e) {
    // [removed in production] '[createReport] error:', e
    return { success: false, error: 'حدث خطأ غير متوقع' }
  }
}

/**
 * التحقق مما إذا كان المستخدم قد بلّغ عن محتوى معين
 */
export async function hasReported(
  reporterId: string,
  targetType: ReportTargetType,
  targetId: string
): Promise<boolean> {
  try {
    const { data } = await supabase
      .from('reports')
      .select('blocked_id')
      .eq('reporter_id', reporterId)
      .eq('target_type', targetType)
      .eq('target_id', targetId)
      .maybeSingle()

    return !!data
  } catch (e) {
    // [removed in production] '[hasReported] error:', e
    return false
  }
}

/**
 * سحب بلاغ
 */
export async function withdrawReport(
  reporterId: string,
  targetType: ReportTargetType,
  targetId: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const { error } = await supabase
      .from('reports')
      .delete()
      .eq('reporter_id', reporterId)
      .eq('target_type', targetType)
      .eq('target_id', targetId)

    if (error) {
      // [removed in production] '[withdrawReport] error:', error
      return { success: false, error: 'تعذّر سحب البلاغ' }
    }

    return { success: true }
  } catch (e) {
    // [removed in production] '[withdrawReport] error:', e
    return { success: false, error: 'حدث خطأ' }
  }
}

// ========================================
// إدارة الحجب
// ========================================

export interface BlockResult {
  success: boolean
  error?: string
  alreadyBlocked?: boolean
}

/**
 * حجب مستخدم — نظام متكامل مثل Facebook
 * عند الحجب:
 * 1. إدراج في جدول blocks
 * 2. حذف المتابعة في الاتجاهين
 * 3. حذف طلبات المراسلة المعلقة
 */
export async function blockUser(
  blockerId: string,
  blockedId: string
): Promise<BlockResult> {
  if (blockerId === blockedId) {
    return { success: false, error: 'لا يمكنك حجب نفسك' }
  }

  try {
    // 1) إدراج في جدول blocks
    const { error } = await supabase
      .from('blocks')
      .insert({
        blocker_id: blockerId,
        blocked_id: blockedId,
      })

    if (error) {
      if (error.message.includes('duplicate') || error.message.includes('unique') || error.code === '23505') {
        // محاولة حذف المتابعات حتى لو كان محجوبًا بالفعل
        await cleanupAfterBlock(blockerId, blockedId)
        return { success: true, alreadyBlocked: true }
      }
      return { success: false, error: 'تعذّر حجب المستخدم' }
    }

    // 2) تنظيف المتابعات + طلبات المراسلة
    await cleanupAfterBlock(blockerId, blockedId)

    return { success: true }
  } catch (e) {
    return { success: false, error: 'حدث خطأ غير متوقع' }
  }
}

/**
 * تنظيف بعد الحجب:
 * - حذف متابعة blocker → blocked
 * - حذف متابعة blocked → blocker
 * - حذف طلبات المراسلة بينهما
 */
async function cleanupAfterBlock(blockerId: string, blockedId: string): Promise<void> {
  try {
    // حذف المتابعة في الاتجاهين
    await supabase
      .from('follows')
      .delete()
      .or(`and(follower_id.eq.${blockerId},followed_id.eq.${blockedId}),and(follower_id.eq.${blockedId},followed_id.eq.${blockerId})`)

    // حذف الإعجابات بينهما
    await supabase
      .from('likes')
      .delete()
      .or(`and(user_id.eq.${blockerId}),and(user_id.eq.${blockedId})`)
      .in('post_id', (
        await supabase
          .from('posts')
          .select('blocked_id')
          .or(`user_id.eq.${blockerId},user_id.eq.${blockedId}`)
      ).data?.map((p: any) => p.id) || [])

    // حذف طلبات المراسلة المعلقة
    await supabase
      .from('message_requests')
      .delete()
      .or(`and(sender_id.eq.${blockerId},receiver_id.eq.${blockedId}),and(sender_id.eq.${blockedId},receiver_id.eq.${blockerId})`)
  } catch {
    // تجاهل أخطاء التنظيف
  }
}

/**
 * إلغاء حجب مستخدم
 */
export async function unblockUser(
  blockerId: string,
  blockedId: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const { error } = await supabase
      .from('blocks')
      .delete()
      .eq('blocker_id', blockerId)
      .eq('blocked_id', blockedId)

    if (error) {
      // [removed in production] '[unblockUser] error:', error
      return { success: false, error: 'تعذّر إلغاء الحجب' }
    }

    return { success: true }
  } catch (e) {
    // [removed in production] '[unblockUser] error:', e
    return { success: false, error: 'حدث خطأ' }
  }
}

/**
 * التحقق مما إذا كان المستخدم محجوباً
 */
export async function isBlocked(
  blockerId: string,
  blockedId: string
): Promise<boolean> {
  try {
    const { data } = await supabase
      .from('blocks')
      .select('blocked_id')
      .eq('blocker_id', blockerId)
      .eq('blocked_id', blockedId)
      .maybeSingle()

    return !!data
  } catch (e) {
    // [removed in production] '[isBlocked] error:', e
    return false
  }
}

/**
 * جلب قائمة المستخدمين المحجوبين
 * يستخدم استعلامين منفصلين لأن blocks ليس لها FK مع profiles
 */
export async function fetchBlockedUsers(blockerId: string): Promise<Block[]> {
  try {
    // 1) جلب blocked_ids
    const { data: blockRows, error: blockError } = await supabase
      .from('blocks')
      .select('blocked_id, created_at')
      .eq('blocker_id', blockerId)
      .order('created_at', { ascending: false })

    if (blockError || !blockRows || blockRows.length === 0) {
      return []
    }

    // 2) جلب بيانات المستخدمين المحجوبين
    const blockedIds = blockRows.map((b: any) => b.blocked_id)
    const { data: profiles, error: profileError } = await supabase
      .from('profiles')
      .select('*')
      .in('id', blockedIds)

    if (profileError || !profiles) {
      // حتى لو فشل جلب البروفايلات، نُرجع الـ blocked_ids
      return blockRows.map((b: any) => ({
        blocker_id: blockerId,
        blocked_id: b.blocked_id,
        created_at: b.created_at,
        blocked: null,
      })) as Block[]
    }

    // 3) دمج النتائج
    const profileMap = new Map(profiles.map((p: any) => [p.id, p]))
    return blockRows.map((b: any) => ({
      blocker_id: blockerId,
      blocked_id: b.blocked_id,
      created_at: b.created_at,
      blocked: profileMap.get(b.blocked_id) || null,
    })) as Block[]
  } catch {
    return []
  }
}

/**
 * جلب قائمة IDs المستخدمين المحجوبين (للتصفية السريعة)
 */
export async function fetchBlockedUserIds(blockerId: string): Promise<Set<string>> {
  try {
    const { data, error } = await supabase
      .from('blocks')
      .select('blocked_id')
      .eq('blocker_id', blockerId)

    if (error || !data) {
      return new Set()
    }

    return new Set(data.map((b: { blocked_id: string }) => b.blocked_id))
  } catch (e) {
    // [removed in production] '[fetchBlockedUserIds] error:', e
    return new Set()
  }
}

/**
 * جلب قائمة IDs المستخدمين الذين حجبوني (للتصفية العكسية)
 */
export async function fetchBlockedByUserIds(userId: string): Promise<Set<string>> {
  try {
    const { data, error } = await supabase
      .from('blocks')
      .select('blocker_id')
      .eq('blocked_id', userId)

    if (error || !data) {
      return new Set()
    }

    return new Set(data.map((b: { blocker_id: string }) => b.blocker_id))
  } catch (e) {
    // [removed in production] '[fetchBlockedByUserIds] error:', e
    return new Set()
  }
}
