// src/lib/verification-requests.ts
// نظام طلبات التحقق (Verification Requests)

import { supabase } from './supabase/client'

export type VerificationType = 'official' | 'business' | 'creator' | 'early_adopter'
export type RequestStatus = 'pending' | 'approved' | 'rejected' | 'needs_info'

export interface VerificationRequest {
  id: string
  user_id: string
  requested_type: VerificationType
  reason: string | null
  contact_email: string | null
  social_links: string[] | null
  status: RequestStatus
  admin_notes: string | null
  created_at: string
  reviewed_at: string | null
}

const VERIFICATION_LABELS: Record<VerificationType, string> = {
  official: 'حساب رسمي',
  business: 'حساب تجاري',
  creator: 'صانع محتوى',
  early_adopter: 'مستخدم مبكر',
}

const VERIFICATION_DESCRIPTIONS: Record<VerificationType, string> = {
  official: 'للحسابات الرسمية للشركات والمؤسسات والعلامات التجارية المعروفة',
  business: 'للأعمال التجارية والمتاجر والخدمات',
  creator: 'لصنّاع المحتوى النشطين الذين ينتجون محتوى أصلي ومميز',
  early_adopter: 'للمستخدمين الذين انضموا مبكراً وساهموا في نمو المنصة',
}

export function getVerificationLabel(type: VerificationType): string {
  return VERIFICATION_LABELS[type]
}

export function getVerificationDescription(type: VerificationType): string {
  return VERIFICATION_DESCRIPTIONS[type]
}

// ========================================
// إنشاء طلب تحقق
// ========================================

export interface CreateRequestResult {
  success: boolean
  error?: string
  requestId?: string
}

export async function createVerificationRequest(
  userId: string,
  requestedType: VerificationType,
  reason: string,
  contactEmail?: string,
  socialLinks?: string[]
): Promise<CreateRequestResult> {
  if (reason.trim().length < 20) {
    return { success: false, error: 'يرجى تقديم سبب مفصّل (20 حرف على الأقل)' }
  }
  if (reason.length > 500) {
    return { success: false, error: 'السبب طويل جداً (حد أقصى 500 حرف)' }
  }
  if (contactEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(contactEmail)) {
    return { success: false, error: 'بريد إلكتروني غير صالح' }
  }

  try {
    const { data, error } = await supabase
      .from('verification_requests')
      .insert({
        user_id: userId,
        requested_type: requestedType,
        reason: reason.trim(),
        contact_email: contactEmail?.trim() || null,
        social_links: socialLinks?.length ? socialLinks : null,
      })
      .select('id')
      .single()

    if (error) {
      // إذا كان هناك طلب نشط بالفعل
      if (error.message.includes('duplicate') || error.message.includes('unique') || error.code === '23505') {
        return { success: false, error: 'لديك طلب تحقق قيد المراجعة بالفعل' }
      }
      // [removed in production] '[createVerificationRequest] error:', error
      return { success: false, error: 'تعذّر إرسال الطلب' }
    }

    return { success: true, requestId: data.id }
  } catch (e) {
    // [removed in production] '[createVerificationRequest] error:', e
    return { success: false, error: 'حدث خطأ غير متوقع' }
  }
}

// ========================================
// جلب طلبات المستخدم
// ========================================

export async function fetchMyVerificationRequests(userId: string): Promise<VerificationRequest[]> {
  try {
    const { data, error } = await supabase
      .from('verification_requests')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })

    if (error || !data) {
      // [removed in production] '[fetchMyVerificationRequests] error:', error
      return []
    }

    return data as VerificationRequest[]
  } catch (e) {
    // [removed in production] '[fetchMyVerificationRequests] error:', e
    return []
  }
}

// ========================================
// إلغاء طلب تحقق (المعلّق فقط)
// ========================================

export async function cancelVerificationRequest(
  userId: string,
  requestId: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const { error } = await supabase
      .from('verification_requests')
      .delete()
      .eq('id', requestId)
      .eq('user_id', userId)
      .eq('status', 'pending')

    if (error) {
      // [removed in production] '[cancelVerificationRequest] error:', error
      return { success: false, error: 'تعذّر إلغاء الطلب' }
    }

    return { success: true }
  } catch (e) {
    // [removed in production] '[cancelVerificationRequest] error:', e
    return { success: false, error: 'حدث خطأ' }
  }
}

// ========================================
// التحقق من وجود طلب نشط
// ========================================

export async function hasActiveVerificationRequest(userId: string): Promise<boolean> {
  try {
    const { data } = await supabase
      .from('verification_requests')
      .select('id')
      .eq('user_id', userId)
      .eq('status', 'pending')
      .maybeSingle()

    return !!data
  } catch (e) {
    // [removed in production] '[hasActiveVerificationRequest] error:', e
    return false
  }
}
