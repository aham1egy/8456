// src/lib/message-reactions.ts
// ردود الأفعال على الرسائل (emoji reactions)

import { supabase } from './supabase/client'

// ========================================
// أنواع البيانات
// ========================================

export type ReactionEmoji =
  | 'heart'
  | 'like'
  | 'laugh'
  | 'wow'
  | 'sad'
  | 'angry'
  | 'fire'
  | 'thumbsup'
  | 'celebrate'
  | 'thinking'

export interface MessageReaction {
  id: string
  message_id: string
  user_id: string
  emoji: ReactionEmoji
  created_at: string
}

export interface ReactionGroup {
  emoji: ReactionEmoji
  count: number
  reactedByMe: boolean
  userIds: string[]
}

// ========================================
// تعريف الـ emojis (مرئية + أسماء)
// ========================================

export const REACTION_EMOJIS: { id: ReactionEmoji; emoji: string; label: string }[] = [
  { id: 'heart', emoji: '❤️', label: 'حب' },
  { id: 'like', emoji: '👍', label: 'إعجاب' },
  { id: 'laugh', emoji: '😂', label: 'ضحك' },
  { id: 'wow', emoji: '😮', label: 'دهشة' },
  { id: 'sad', emoji: '😢', label: 'حزن' },
  { id: 'angry', emoji: '😠', label: 'غضب' },
  { id: 'fire', emoji: '🔥', label: 'رائع' },
  { id: 'thumbsup', emoji: '👏', label: 'تصفيق' },
  { id: 'celebrate', emoji: '🎉', label: 'احتفال' },
  { id: 'thinking', emoji: '🤔', label: 'تفكير' },
]

export function getReactionEmoji(emoji: ReactionEmoji): string {
  return REACTION_EMOJIS.find((r) => r.id === emoji)?.emoji || '❤️'
}

export function getReactionLabel(emoji: ReactionEmoji): string {
  return REACTION_EMOJIS.find((r) => r.id === emoji)?.label || ''
}

// ========================================
// إدارة ردود الأفعال
// ========================================

/**
 * جلب ردود الأفعال لرسالة واحدة
 */
export async function fetchMessageReactions(
  messageId: string,
  currentUserId?: string
): Promise<ReactionGroup[]> {
  try {
    const { data, error } = await supabase
      .from('message_reactions')
      .select('id, user_id, emoji')
      .eq('message_id', messageId)

    if (error || !data) {
      // [removed in production] '[fetchMessageReactions] error:', error
      return []
    }

    // تجميع حسب الـ emoji
    const groupsMap = new Map<ReactionEmoji, ReactionGroup>()
    for (const r of data as { user_id: string; emoji: ReactionEmoji }[]) {
      const existing = groupsMap.get(r.emoji)
      if (existing) {
        existing.count++
        existing.userIds.push(r.user_id)
        if (r.user_id === currentUserId) {
          existing.reactedByMe = true
        }
      } else {
        groupsMap.set(r.emoji, {
          emoji: r.emoji,
          count: 1,
          reactedByMe: r.user_id === currentUserId,
          userIds: [r.user_id],
        })
      }
    }

    return Array.from(groupsMap.values()).sort((a, b) => b.count - a.count)
  } catch (e) {
    // [removed in production] '[fetchMessageReactions] error:', e
    return []
  }
}

/**
 * جلب ردود الأفعال لعدة رسائل (batch)
 */
export async function fetchMessagesReactions(
  messageIds: string[],
  currentUserId?: string
): Promise<Record<string, ReactionGroup[]>> {
  if (messageIds.length === 0) return {}

  try {
    const { data, error } = await supabase
      .from('message_reactions')
      .select('id, message_id, user_id, emoji')
      .in('message_id', messageIds)

    if (error || !data) {
      // [removed in production] '[fetchMessagesReactions] error:', error
      return {}
    }

    // تجميع حسب message_id ثم emoji
    const result: Record<string, ReactionGroup[]> = {}
    for (const r of data as { id: string; message_id: string; user_id: string; emoji: ReactionEmoji }[]) {
      if (!result[r.message_id]) {
        result[r.message_id] = []
      }
      let group = result[r.message_id].find((g) => g.emoji === r.emoji)
      if (!group) {
        group = {
          emoji: r.emoji,
          count: 0,
          reactedByMe: false,
          userIds: [],
        }
        result[r.message_id].push(group)
      }
      group.count++
      group.userIds.push(r.user_id)
      if (r.user_id === currentUserId) {
        group.reactedByMe = true
      }
    }

    // ترتيب كل مجموعة حسب العدد
    for (const msgId of Object.keys(result)) {
      result[msgId].sort((a, b) => b.count - a.count)
    }

    return result
  } catch (e) {
    // [removed in production] '[fetchMessagesReactions] error:', e
    return {}
  }
}

/**
 * إضافة أو تبديل رد فعل
 * (إذا كان لديه رد فعل مختلف، يُحذف القديم ويُضاف الجديد)
 */
export async function toggleMessageReaction(
  messageId: string,
  userId: string,
  emoji: ReactionEmoji
): Promise<{ success: boolean; error?: string; action?: 'added' | 'removed' | 'changed' }> {
  try {
    // التحقق من رد فعل موجود حالياً
    const { data: existing } = await supabase
      .from('message_reactions')
      .select('id, emoji')
      .eq('message_id', messageId)
      .eq('user_id', userId)
      .maybeSingle()

    if (existing) {
      const existingEmoji = (existing as { emoji: ReactionEmoji }).emoji
      if (existingEmoji === emoji) {
        // نفس الـ emoji — حذف
        const { error } = await supabase
          .from('message_reactions')
          .delete()
          .eq('id', (existing as { id: string }).id)
        if (error) {
          // [removed in production] '[toggleMessageReaction] delete error:', error
          return { success: false, error: 'تعذّر إزالة رد الفعل' }
        }
        return { success: true, action: 'removed' }
      } else {
        // emoji مختلف — تحديث
        const { error } = await supabase
          .from('message_reactions')
          .update({ emoji })
          .eq('id', (existing as { id: string }).id)
        if (error) {
          // [removed in production] '[toggleMessageReaction] update error:', error
          return { success: false, error: 'تعذّر تحديث رد الفعل' }
        }
        return { success: true, action: 'changed' }
      }
    } else {
      // لا يوجد رد فعل — إضافة جديد
      const { error } = await supabase
        .from('message_reactions')
        .insert({
          message_id: messageId,
          user_id: userId,
          emoji,
        })
      if (error) {
        if (error.message.includes('duplicate') || error.message.includes('unique') || error.code === '23505') {
          return { success: true, action: 'added' }
        }
        // [removed in production] '[toggleMessageReaction] insert error:', error
        return { success: false, error: 'تعذّر إضافة رد الفعل' }
      }
      return { success: true, action: 'added' }
    }
  } catch (e) {
    // [removed in production] '[toggleMessageReaction] error:', e
    return { success: false, error: 'حدث خطأ' }
  }
}

/**
 * حذف رد فعل
 */
export async function removeMessageReaction(
  messageId: string,
  userId: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const { error } = await supabase
      .from('message_reactions')
      .delete()
      .eq('message_id', messageId)
      .eq('user_id', userId)

    if (error) {
      // [removed in production] '[removeMessageReaction] error:', error
      return { success: false, error: 'تعذّر حذف رد الفعل' }
    }
    return { success: true }
  } catch (e) {
    // [removed in production] '[removeMessageReaction] error:', e
    return { success: false, error: 'حدث خطأ' }
  }
}
