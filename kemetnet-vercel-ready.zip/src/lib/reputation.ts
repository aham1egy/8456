// src/lib/reputation.ts
// نظام النقاط والسمعة

import { supabase } from './supabase/client'

// ========================================
// أنواع البيانات
// ========================================

export type ActivityType =
  | 'post_created'
  | 'post_liked'
  | 'post_commented'
  | 'post_reposted'
  | 'post_saved'
  | 'comment_liked'
  | 'comment_replied'
  | 'follow_received'
  | 'mention_received'
  | 'message_received'
  | 'daily_login'
  | 'first_post'
  | 'verification'
  | 'early_adopter'
  | 'profile_completed'

export interface ReputationLogEntry {
  id: string
  user_id: string
  activity_type: ActivityType
  points_earned: number
  related_id: string | null
  related_type: string | null
  created_at: string
}

export interface ReputationInfo {
  currentPoints: number
  level: number
  totalEarned: number
  nextLevelPoints: number
  pointsToNextLevel: number
  progressPercent: number
}

// ========================================
// تعريف النقاط لكل نشاط
// ========================================

export const ACTIVITY_POINTS: Record<ActivityType, number> = {
  post_created: 5,
  post_liked: 2,
  post_commented: 3,
  post_reposted: 4,
  post_saved: 2,
  comment_liked: 1,
  comment_replied: 2,
  follow_received: 3,
  mention_received: 2,
  message_received: 1,
  daily_login: 10,
  first_post: 50,
  verification: 100,
  early_adopter: 25,
  profile_completed: 15,
}

export const ACTIVITY_LABELS: Record<ActivityType, string> = {
  post_created: 'منشور جديد',
  post_liked: 'حصل منشورك على إعجاب',
  post_commented: 'تعليق على منشورك',
  post_reposted: 'إعادة نشر منشورك',
  post_saved: 'حفظ منشورك',
  comment_liked: 'إعجاب بتعليقك',
  comment_replied: 'رد على تعليقك',
  follow_received: 'متابع جديد',
  mention_received: 'إشارة إليك',
  message_received: 'رسالة جديدة',
  daily_login: 'تسجيل دخول يومي',
  first_post: 'أول منشور',
  verification: 'الحصول على شارة التحقق',
  early_adopter: 'مكافأة المستخدم المبكر',
  profile_completed: 'إكمال الملف الشخصي',
}

export const ACTIVITY_ICONS: Record<ActivityType, string> = {
  post_created: '✍️',
  post_liked: '❤️',
  post_commented: '💬',
  post_reposted: '🔄',
  post_saved: '🔖',
  comment_liked: '👍',
  comment_replied: '↩️',
  follow_received: '👥',
  mention_received: '@',
  message_received: '✉️',
  daily_login: '📅',
  first_post: '🎉',
  verification: '✓',
  early_adopter: '⚡',
  profile_completed: '⭐',
}

// ========================================
// حساب المستوى
// ========================================

export function calculateLevel(points: number): number {
  return Math.max(1, Math.floor(Math.sqrt(points / 100)) + 1)
}

export function getPointsForLevel(level: number): number {
  if (level <= 1) return 0
  return Math.pow(level - 1, 2) * 100
}

export function getNextLevelPoints(currentPoints: number): number {
  const currentLevel = calculateLevel(currentPoints)
  return getPointsForLevel(currentLevel + 1)
}

export function getReputationInfo(
  currentPoints: number,
  level: number,
  totalEarned: number
): ReputationInfo {
  const nextLevelPoints = getNextLevelPoints(currentPoints)
  const currentLevelStart = getPointsForLevel(level)
  const pointsToNextLevel = nextLevelPoints - currentPoints
  const levelRange = nextLevelPoints - currentLevelStart
  const progressPercent = levelRange > 0
    ? Math.min(100, Math.round(((currentPoints - currentLevelStart) / levelRange) * 100))
    : 0

  return {
    currentPoints,
    level,
    totalEarned,
    nextLevelPoints,
    pointsToNextLevel,
    progressPercent,
  }
}

// ========================================
// ألقاب المستويات
// ========================================

export function getLevelTitle(level: number): string {
  if (level >= 50) return 'أسطورة KemetNet'
  if (level >= 40) return 'نجم KemetNet'
  if (level >= 30) return 'خبير KemetNet'
  if (level >= 20) return 'مبدع KemetNet'
  if (level >= 15) return 'كاتب مميز'
  if (level >= 10) return 'عضو نشط'
  if (level >= 7) return 'عضو مشارك'
  if (level >= 5) return 'عضو متفاعل'
  if (level >= 3) return 'عضو جديد'
  return 'مبتدئ'
}

export function getLevelColor(level: number): string {
  if (level >= 50) return '#A855F7' // بنفسجي
  if (level >= 40) return '#EC4899' // وردي
  if (level >= 30) return '#F59E0B' // ذهبي
  if (level >= 20) return '#10B981' // أخضر
  if (level >= 10) return '#3B82F6' // أزرق
  if (level >= 5) return '#06B6D4' // سماوي
  return '#6B7280' // رمادي
}

// ========================================
// جلب سجل النقاط
// ========================================

export async function fetchReputationLog(
  userId: string,
  limit = 20
): Promise<ReputationLogEntry[]> {
  try {
    const { data, error } = await supabase
      .from('reputation_log')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(limit)

    if (error || !data) {
      // [removed in production] '[fetchReputationLog] error:', error
      return []
    }

    return data as ReputationLogEntry[]
  } catch (e) {
    // [removed in production] '[fetchReputationLog] error:', e
    return []
  }
}

// ========================================
// جلب أعلى المستخدمين (Leaderboard)
// ========================================

export async function fetchTopUsers(limit = 10) {
  try {
    const { data, error } = await supabase
      .from('profiles')
      .select('id, username, display_name, avatar_url, avatar_color, reputation_points, reputation_level, is_verified, verified_type')
      .order('reputation_points', { ascending: false })
      .limit(limit)

    if (error || !data) {
      // [removed in production] '[fetchTopUsers] error:', error
      return []
    }

    return data
  } catch (e) {
    // [removed in production] '[fetchTopUsers] error:', e
    return []
  }
}

// ========================================
// منح نقاط يدوياً (للأحداث الخاصة)
// ========================================

export async function awardPointsManually(
  userId: string,
  activityType: ActivityType,
  relatedId?: string,
  relatedType?: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const { error } = await supabase.rpc('award_reputation_points', {
      target_user_id: userId,
      activity_type: activityType,
      related_id: relatedId || null,
      related_type: relatedType || null,
    })

    if (error) {
      // [removed in production] '[awardPointsManually] error:', error
      return { success: false, error: 'تعذّر منح النقاط' }
    }

    return { success: true }
  } catch (e) {
    // [removed in production] '[awardPointsManually] error:', e
    return { success: false, error: 'حدث خطأ' }
  }
}
