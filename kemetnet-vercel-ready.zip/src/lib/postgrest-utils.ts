// src/lib/postgrest-utils.ts
// أدوات تأمين استعلامات PostgREST — إعادة كتابة كاملة (V-03, V-13, V-14)
// يعتمد على whitelist بدل blacklist لضمان أمان كامل

/**
 * نمط UUID صارم (RFC 4122 v1-v5) — يرفض أي قيمة تحتوي على أحرف خاصة
 * تُستخدم للتحقق من المُعرّفات قبل إدراجها في فلاتر PostgREST مثل .or()
 */
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i

/**
 * التحقق من أن قيمة هي UUID صالح (يحمي من PostgREST filter injection)
 * يُرجع القيمة كما هي إذا كانت صالحة، أو سلسلة UUID "NULL" آمنة إذا لم تكن
 */
export function assertValidUUID(value: string): string {
  if (typeof value !== 'string') return '00000000-0000-0000-0000-000000000000'
  const trimmed = value.trim().toLowerCase()
  if (UUID_RE.test(trimmed)) return trimmed
  // إرجاع UUID صفر كقيمة آمنة (لن يطابق أي صف حقيقي)
  return '00000000-0000-0000-0000-000000000000'
}

/**
 * التحقق المباشر من UUID — يُرجع true فقط إذا كانت القيمة UUID صالح
 */
export function isValidUUID(value: string): boolean {
  if (typeof value !== 'string') return false
  return UUID_RE.test(value.trim().toLowerCase())
}

/**
 * تهريب قيمة للاستخدام في فلتر PostgREST (ilike, eq, إلخ)
 * يحتفظ فقط بالأحرف الآمنة: حروف عربية/إنجليزية، أرقام، مسافات، شرطات
 */
export function escapePostgrestValue(value: string): string {
  if (!value) return ''
  // whitelist: الأحرف الآمنة فقط
  const sanitized = value
    .replace(/[^\p{L}\p{N}\s_-]/gu, '') // إزالة كل ما ليس حرف/رقم/مسافة/شرطة
    .trim()
    .slice(0, 100)
  return sanitized
}

/**
 * تهريب قيمة ilike — يُهرب % و _ كـ wildcards
 */
export function escapeIlikePattern(value: string): string {
  if (!value) return '%'
  const sanitized = escapePostgrestValue(value)
  if (!sanitized) return '%'
  // تهريب wildcards
  const escaped = sanitized.replace(/[%_\\]/g, '\\$&')
  return `%${escaped}%`
}

/**
 * بناء فلتر or آمن — يستخدم قيم مُهربة
 */
export function safeOrFilter(columns: string[], value: string): string {
  const safe = escapePostgrestValue(value)
  if (!safe) return ''
  const pattern = `%${safe}%`
  return columns.map((col) => `${col}.ilike.${pattern}`).join(',')
}
