// src/lib/mentions.ts
import { escapeIlikePattern } from './postgrest-utils'
// نظام الإشارات @username - بحث + إبراز + استخراج

import { supabase, type Profile } from './supabase/client'

// ========================================
// استخراج الإشارات من نص
// ========================================

export interface ExtractedMention {
  /** اليوزرنيم بدون @ */
  username: string
  /** موضع بداية الإشارة في النص (مع @) */
  start: number
  /** موضع نهاية الإشارة */
  end: number
}

/**
 * استخراج كل الإشارات @username من نص
 * يدعم الأحرف اللاتينية + الأرقام + الشرطة السفلية (3-20 حرف)
 */
export function extractMentions(text: string): ExtractedMention[] {
  const regex = /@([a-zA-Z0-9_]{3,20})/g
  const mentions: ExtractedMention[] = []
  let match: RegExpExecArray | null

  while ((match = regex.exec(text)) !== null) {
    mentions.push({
      username: match[1].toLowerCase(),
      start: match.index,
      end: match.index + match[0].length,
    })
  }

  return mentions
}

// ========================================
// اكتشاف الإشارة في موضع المؤشر
// ========================================

export interface ActiveMention {
  /** اليوزرنيم المكتوب حالياً بدون @ */
  query: string
  /** موضع بداية @ */
  start: number
  /** موضع المؤشر الحالي */
  end: number
}

/**
 * يكتشف إذا كان المؤشر الحالي داخل إشارة @username قيد الكتابة
 * يُستخدم لعرض قائمة المستخدمين المقترحين
 */
export function detectActiveMention(text: string, cursorPos: number): ActiveMention | null {
  // ابحث عن @ قبل المؤشر مباشرة
  const before = text.slice(0, cursorPos)
  // نمط: @ متبوع بحروف/أرقام/_
  const match = before.match(/@([a-zA-Z0-9_]*)$/)
  if (!match) return null

  // تحقق من عدم وجود مسافة بعد @
  if (match[1].length === 0 && cursorPos < text.length && text[cursorPos] === ' ') {
    return null
  }

  // تحقق من أن ما قبل @ هو بداية النص أو مسافة/سطر جديد
  const atPos = before.length - match[0].length
  if (atPos > 0) {
    const charBefore = text[atPos - 1]
    if (!/\s/.test(charBefore)) return null
  }

  return {
    query: match[1].toLowerCase(),
    start: atPos,
    end: cursorPos,
  }
}

// ========================================
// البحث عن المستخدمين للاقتراح
// ========================================

export interface MentionSuggestion {
  id: string
  username: string
  display_name: string | null
  avatar_url: string | null
  avatar_color: string | null
}

/**
 * البحث عن مستخدمين باسم يطابق الاستعلام
 * يستخدم ILIKE للبحث الجزئي غير الحساس للحالة
 */
export async function searchUsersForMention(
  query: string,
  currentUserId?: string,
  limit = 5
): Promise<MentionSuggestion[]> {
  if (!query || query.length < 1) return []

  try {
    let dbQuery = supabase
      .from('profiles')
      .select('id, username, display_name, avatar_url, avatar_color')
      .ilike('username', escapeIlikePattern(query) + '%')
      .order('followers_count', { ascending: false })
      .limit(limit)

    // استبعاد المستخدم الحالي من الاقتراحات
    if (currentUserId) {
      dbQuery = dbQuery.neq('id', currentUserId)
    }

    const { data, error } = await dbQuery

    if (error || !data) {
      // [removed in production] '[searchUsersForMention] error:', error
      return []
    }

    return data as MentionSuggestion[]
  } catch (e) {
    // [removed in production] '[searchUsersForMention] error:', e
    return []
  }
}

// ========================================
// إدراج mention في النص عند الاختيار
// ========================================

export interface InsertMentionResult {
  /** النص الجديد بعد الإدراج */
  newText: string
  /** موضع المؤشر الجديد (بعد mention) */
  newCursorPos: number
}

/**
 * استبدال @query بـ @username المختار في النص
 */
export function insertMention(
  text: string,
  mention: ActiveMention,
  username: string
): InsertMentionResult {
  const before = text.slice(0, mention.start)
  const after = text.slice(mention.end)
  // أضف مسافة بعد mention لتسهيل الاستمرار في الكتابة
  const mentionText = `@${username} `
  const newText = before + mentionText + after
  const newCursorPos = before.length + mentionText.length

  return { newText, newCursorPos }
}

// ========================================
// إبراز الإشارات في نص (React nodes)
// ========================================

export interface MentionSegment {
  type: 'text' | 'mention'
  content: string
  /** فقط للإشارات: اليوزرنيم بدون @ */
  username?: string
}

/**
 * تقسيم نص إلى أجزاء: نص عادي + إشارات
 * يُستخدم لإبراز @mentions في عرض المنشورات والتعليقات
 */
export function parseMentions(text: string): MentionSegment[] {
  const regex = /@([a-zA-Z0-9_]{3,20})/g
  const segments: MentionSegment[] = []
  let lastIndex = 0
  let match: RegExpExecArray | null

  while ((match = regex.exec(text)) !== null) {
    // إضافة النص قبل الـ mention
    if (match.index > lastIndex) {
      segments.push({
        type: 'text',
        content: text.slice(lastIndex, match.index),
      })
    }
    // إضافة الـ mention
    segments.push({
      type: 'mention',
      content: match[0],
      username: match[1].toLowerCase(),
    })
    lastIndex = match.index + match[0].length
  }

  // إضافة ما تبقى من النص
  if (lastIndex < text.length) {
    segments.push({
      type: 'text',
      content: text.slice(lastIndex),
    })
  }

  return segments
}
