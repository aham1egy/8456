// src/lib/search-history.ts
// نظام حفظ سجل البحث + البحث المتقدم

const SEARCH_HISTORY_KEY = 'mishri-search-history'
const MAX_HISTORY = 10

export interface SearchHistoryEntry {
  query: string
  type: 'all' | 'people' | 'tags'
  timestamp: number
}

function safeGetItem(key: string): string | null {
  try {
    if (typeof window === 'undefined') return null
    return window.localStorage.getItem(key)
  } catch {
    return null
  }
}

function safeSetItem(key: string, value: string): void {
  try {
    if (typeof window === 'undefined') return
    window.localStorage.setItem(key, value)
  } catch {
    // ignore
  }
}

/**
 * تحميل سجل البحث
 */
export function loadSearchHistory(): SearchHistoryEntry[] {
  const raw = safeGetItem(SEARCH_HISTORY_KEY)
  if (!raw) return []
  try {
    const parsed = JSON.parse(raw) as SearchHistoryEntry[]
    if (!Array.isArray(parsed)) return []
    // ترتيب بالأحدث
    return parsed.sort((a, b) => b.timestamp - a.timestamp).slice(0, MAX_HISTORY)
  } catch {
    return []
  }
}

/**
 * إضافة عملية بحث للسجل
 */
export function addSearchHistory(query: string, type: 'all' | 'people' | 'tags' = 'all'): void {
  const trimmed = query.trim()
  if (!trimmed || trimmed.length < 2) return

  const current = loadSearchHistory()
  // إزالة التكرار (نفس الاستعلام + نفس النوع)
  const filtered = current.filter(
    (h) => !(h.query.toLowerCase() === trimmed.toLowerCase() && h.type === type)
  )
  // إضافة في المقدمة
  filtered.unshift({ query: trimmed, type, timestamp: Date.now() })
  // الاحتفاظ بآخر 10 فقط
  const limited = filtered.slice(0, MAX_HISTORY)
  safeSetItem(SEARCH_HISTORY_KEY, JSON.stringify(limited))
}

/**
 * حذف عنصر من السجل
 */
export function removeSearchHistory(query: string, type: 'all' | 'people' | 'tags'): void {
  const current = loadSearchHistory()
  const filtered = current.filter(
    (h) => !(h.query.toLowerCase() === query.toLowerCase() && h.type === type)
  )
  safeSetItem(SEARCH_HISTORY_KEY, JSON.stringify(filtered))
}

/**
 * مسح كل سجل البحث
 */
export function clearSearchHistory(): void {
  try {
    if (typeof window !== 'undefined') {
      window.localStorage.removeItem(SEARCH_HISTORY_KEY)
    }
  } catch {
    // ignore
  }
}

/**
 * بحث موصى به (اقتراحات سريعة)
 */
export const SUGGESTED_SEARCHES = [
  'إلهام',
  'فن',
  'سفر',
  'موسيقى',
  'تقنية',
  'طعام',
  'خواطر',
] as const

/**
 * تنسيق وقت آخر بحث
 */
export function formatSearchTime(timestamp: number): string {
  const diff = Date.now() - timestamp
  const sec = Math.floor(diff / 1000)
  if (sec < 60) return 'الآن'
  const min = Math.floor(sec / 60)
  if (min < 60) return `قبل ${min} د`
  const hour = Math.floor(min / 60)
  if (hour < 24) return `قبل ${hour} س`
  const day = Math.floor(hour / 24)
  if (day < 7) return `قبل ${day} ي`
  return `قبل ${Math.floor(day / 7)} أ`
}
