// src/lib/self-improving.ts
// نظام التحسين الذاتي — يراقب الأخطاء ويحلل الأداء ويعطي توصيات

interface ErrorReport {
  error: string
  context: string
  timestamp: number
  userAgent: string
  userId?: string
}

interface PerformanceMetric {
  name: string
  value: number
  timestamp: number
}

interface Recommendation {
  type: 'content' | 'user' | 'tag' | 'category'
  targetId: string
  score: number
  reason: string
}

// ========================================
// تجميع الأخطاء (Error Aggregation)
// ========================================

const ERROR_KEY = 'mishri-error-log'
const MAX_ERRORS = 50

export function logError(context: string, error: unknown): void {
  if (typeof window === 'undefined') return
  if (process.env.NODE_ENV !== 'production') return // فقط في الإنتاج

  try {
    const report: ErrorReport = {
      error: error instanceof Error ? error.message : String(error),
      context,
      timestamp: Date.now(),
      userAgent: navigator.userAgent.slice(0, 100),
    }

    const existing = JSON.parse(localStorage.getItem(ERROR_KEY) || '[]') as ErrorReport[]
    existing.unshift(report)
    if (existing.length > MAX_ERRORS) existing.length = MAX_ERRORS
    localStorage.setItem(ERROR_KEY, JSON.stringify(existing))

    // في الإنتاج: إرسال للخادم (يمكن إضافة endpoint لاحقاً)
    // fetch('/api/error-report', { method: 'POST', body: JSON.stringify(report) })
  } catch {
    // تجاهل أخطاء التسجيل نفسه
  }
}

// ========================================
// مراقبة الأداء (Performance Monitoring)
// ========================================

const PERF_KEY = 'mishri-perf-log'

export function logPerformance(name: string, value: number): void {
  if (typeof window === 'undefined') return
  try {
    const metric: PerformanceMetric = { name, value, timestamp: Date.now() }
    const existing = JSON.parse(localStorage.getItem(PERF_KEY) || '[]') as PerformanceMetric[]
    existing.push(metric)
    // الاحتفاظ بآخر 100 قياس فقط
    if (existing.length > 100) existing.shift()
    localStorage.setItem(PERF_KEY, JSON.stringify(existing))
  } catch {
    // ignore
  }
}

// قياس وقت تنفيذ دالة
export async function measureAsync<T>(name: string, fn: () => Promise<T>): Promise<T> {
  const start = performance.now()
  try {
    return await fn()
  } finally {
    const duration = performance.now() - start
    if (duration > 100) {
      logPerformance(name, duration)
    }
  }
}

// ========================================
// فحص صحة التطبيق (Health Check)
// ========================================

export interface HealthStatus {
  healthy: boolean
  issues: string[]
  lastCheck: number
}

export function checkAppHealth(): HealthStatus {
  const issues: string[] = []

  // 1. فحص الذاكرة
  if ('memory' in performance) {
    const mem = (performance as unknown as { memory: { usedJSHeapSize: number; jsHeapSizeLimit: number } }).memory
    const usagePercent = (mem.usedJSHeapSize / mem.jsHeapSizeLimit) * 100
    if (usagePercent > 80) {
      issues.push(`استخدام ذاكرة عالي: ${Math.round(usagePercent)}%`)
    }
  }

  // 2. فحص الاتصال
  if (typeof navigator !== 'undefined' && 'onLine' in navigator) {
    if (!navigator.onLine) {
      issues.push('لا يوجد اتصال بالإنترنت')
    }
  }

  // 3. فحص الأخطاء الأخيرة
  const errors = JSON.parse(localStorage.getItem(ERROR_KEY) || '[]') as ErrorReport[]
  const recentErrors = errors.filter((e) => Date.now() - e.timestamp < 60000) // آخر دقيقة
  if (recentErrors.length > 5) {
    issues.push(`${recentErrors.length} أخطاء في الدقيقة الأخيرة`)
  }

  // 4. فحص localStorage
  try {
    const testKey = '__health_check__'
    localStorage.setItem(testKey, '1')
    localStorage.removeItem(testKey)
  } catch {
    issues.push('localStorage غير متاح أو ممتلئ')
  }

  return {
    healthy: issues.length === 0,
    issues,
    lastCheck: Date.now(),
  }
}

// ========================================
// تنظيف تلقائي (Auto Cleanup)
// ========================================

export function autoCleanup(): void {
  if (typeof window === 'undefined') return

  const now = Date.now()
  const TTL = 7 * 24 * 60 * 60 * 1000 // 7 أيام

  // تنظيف سجل الأخطاء
  try {
    const errors = JSON.parse(localStorage.getItem(ERROR_KEY) || '[]') as ErrorReport[]
    const fresh = errors.filter((e) => now - e.timestamp < TTL)
    if (fresh.length !== errors.length) {
      localStorage.setItem(ERROR_KEY, JSON.stringify(fresh))
    }
  } catch {
    // ignore
  }

  // تنظيف سجل الأداء
  try {
    const perf = JSON.parse(localStorage.getItem(PERF_KEY) || '[]') as PerformanceMetric[]
    const fresh = perf.filter((p) => now - p.timestamp < TTL)
    if (fresh.length !== perf.length) {
      localStorage.setItem(PERF_KEY, JSON.stringify(fresh))
    }
  } catch {
    // ignore
  }

  // تنظيف مسودات قديمة
  try {
    const draftKeys = ['mishri-post-draft']
    for (const key of draftKeys) {
      const raw = localStorage.getItem(key)
      if (raw) {
        const draft = JSON.parse(raw)
        if (draft.updatedAt && now - draft.updatedAt > TTL) {
          localStorage.removeItem(key)
        }
      }
    }
  } catch {
    // ignore
  }
}

// ========================================
// خوارزمية التوصيات (Recommendation Engine)
// ========================================

interface UserPreferences {
  likedCategories: Record<string, number>
  likedTags: Record<string, number>
  followedUsers: string[]
  timeOfDay: number
}

/**
 * تحليل تفضيلات المستخدم بناءً على نشاطه
 */
export function analyzeUserPreferences(
  likedPosts: { category: string; tags: string[] | null }[],
  followedUsers: string[]
): UserPreferences {
  const likedCategories: Record<string, number> = {}
  const likedTags: Record<string, number> = {}

  for (const post of likedPosts) {
    likedCategories[post.category] = (likedCategories[post.category] || 0) + 1
    if (post.tags) {
      for (const tag of post.tags) {
        likedTags[tag] = (likedTags[tag] || 0) + 1
      }
    }
  }

  return {
    likedCategories,
    likedTags,
    followedUsers,
    timeOfDay: new Date().getHours(),
  }
}

/**
 * حساب درجة منشور لمستخدم معين
 */
export function scorePostForUser(
  post: { category: string; tags: string[] | null; likes_count: number; created_at: string },
  prefs: UserPreferences
): number {
  let score = 0

  // 1. تطابق الفئة (وزن عالي)
  const categoryScore = prefs.likedCategories[post.category] || 0
  score += categoryScore * 10

  // 2. تطابق الوسوم (وزن متوسط)
  if (post.tags) {
    for (const tag of post.tags) {
      const tagScore = prefs.likedTags[tag] || 0
      score += tagScore * 5
    }
  }

  // 3. التفاعل العام (وزن منخفض)
  score += Math.min(post.likes_count / 10, 10)

  // 4. الحداثة (وزن متغير حسب الوقت)
  const hoursAgo = (Date.now() - new Date(post.created_at).getTime()) / (1000 * 60 * 60)
  if (hoursAgo < 1) score += 15
  else if (hoursAgo < 6) score += 10
  else if (hoursAgo < 24) score += 5
  else if (hoursAgo < 72) score += 2

  // 5. تعديل حسب وقت اليوم
  const hour = prefs.timeOfDay
  if (hour >= 6 && hour < 12) score *= 1.1 // الصباح: نشاط أعلى
  else if (hour >= 18 && hour < 23) score *= 1.05 // المساء
  else if (hour >= 0 && hour < 6) score *= 0.8 // الليل: نشاط أقل

  return score
}

/**
 * ترتيب منشورات بناءً على التوصيات
 */
export function rankPostsForUser(
  posts: { id: string; category: string; tags: string[] | null; likes_count: number; created_at: string }[],
  prefs: UserPreferences,
  limit: number = 20
): { id: string; score: number }[] {
  return posts
    .map((post) => ({ id: post.id, score: scorePostForUser(post, prefs) }))
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
}

// ========================================
// كشف الأخطاء التلقائي (Auto Error Detection)
// ========================================

/**
 * فحص دوري للتطبيق وإصلاح المشاكل الشائعة
 */
export function startAutoRepair(): void {
  if (typeof window === 'undefined') return

  // فحص كل 30 ثانية
  setInterval(() => {
    autoCleanup()

    const health = checkAppHealth()
    if (!health.healthy) {
      for (const issue of health.issues) {
        logError('auto-repair', issue)
      }
    }
  }, 30000)

  // فحص عند العودة للتبويب
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') {
      autoCleanup()
    }
  })

  // التقاط الأخطاء غير المعالجة
  window.addEventListener('error', (event) => {
    logError('uncaught-error', event.error || event.message)
  })

  window.addEventListener('unhandledrejection', (event) => {
    logError('unhandled-promise', event.reason)
  })
}

// ========================================
// تحليلات الاستخدام (Usage Analytics)
// ========================================

const ANALYTICS_KEY = 'mishri-analytics'

interface AnalyticsEvent {
  type: string
  target?: string
  timestamp: number
  duration?: number
}

export function trackEvent(type: string, target?: string): void {
  if (typeof window === 'undefined') return
  if (process.env.NODE_ENV !== 'production') return

  try {
    const event: AnalyticsEvent = { type, target, timestamp: Date.now() }
    const existing = JSON.parse(localStorage.getItem(ANALYTICS_KEY) || '[]') as AnalyticsEvent[]
    existing.push(event)
    // الاحتفاظ بآخر 200 حدث
    if (existing.length > 200) existing.shift()
    localStorage.setItem(ANALYTICS_KEY, JSON.stringify(existing))
  } catch {
    // ignore
  }
}

/**
 * الحصول على إحصائيات الاستخدام
 */
export function getUsageStats(): {
  totalEvents: number
  topActions: Record<string, number>
  sessionDuration: number
} {
  try {
    const events = JSON.parse(localStorage.getItem(ANALYTICS_KEY) || '[]') as AnalyticsEvent[]
    const topActions: Record<string, number> = {}

    for (const event of events) {
      topActions[event.type] = (topActions[event.type] || 0) + 1
    }

    const sessionStart = events.length > 0 ? events[0].timestamp : Date.now()
    const sessionDuration = Date.now() - sessionStart

    return {
      totalEvents: events.length,
      topActions,
      sessionDuration,
    }
  } catch {
    return { totalEvents: 0, topActions: {}, sessionDuration: 0 }
  }
}
