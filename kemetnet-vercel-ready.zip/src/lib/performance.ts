// src/lib/performance.ts
// تحسينات الأداء للهواتف: تحميل كسول + cache ذكي

import { supabase } from './supabase/client'

// ========================================
// Cache بسيط للطلبات (تقليل الاستعلامات المتكررة)
// ========================================

interface CacheEntry<T> {
  data: T
  timestamp: number
  ttl: number // milliseconds
}

const memoryCache = new Map<string, CacheEntry<unknown>>()

export function getCached<T>(key: string): T | null {
  const entry = memoryCache.get(key) as CacheEntry<T> | undefined
  if (!entry) return null
  if (Date.now() - entry.timestamp > entry.ttl) {
    memoryCache.delete(key)
    return null
  }
  return entry.data
}

export function setCached<T>(key: string, data: T, ttlMs: number = 60000): void {
  memoryCache.set(key, { data, timestamp: Date.now(), ttl: ttlMs })
}

export function clearCache(key?: string): void {
  if (key) {
    memoryCache.delete(key)
  } else {
    memoryCache.clear()
  }
}

// ========================================
// جلب المنشورات مع cache (لا يُحدّث إلا المحتوى الجديد)
// ========================================

const POSTS_CACHE_KEY = 'feed-posts'
const POSTS_CACHE_TTL = 30000 // 30 ثانية

export async function fetchPostsWithCache(
  query: ReturnType<typeof supabase.from>['select'] extends (...args: never[]) => infer R ? R : never,
  cacheKey: string = POSTS_CACHE_KEY
): Promise<unknown[]> {
  // تحقق من cache
  const cached = getCached<unknown[]>(cacheKey)
  if (cached) {
    return cached
  }
  // إذا لا cache، نفّذ الاستعلام
  const { data, error } = await query
  if (error || !data) return []
  setCached(cacheKey, data, POSTS_CACHE_TTL)
  return data
}

// ========================================
// تحميل كسول للبيانات الثقيلة (paginate)
// ========================================

export interface PaginationParams {
  page: number
  pageSize: number
}

export function getPaginationParams(page: number, pageSize: number = 10) {
  const from = (page - 1) * pageSize
  const to = from + pageSize - 1
  return { from, to }
}

// ========================================
// prefetch ذكي — فقط للمسار التالي المحتمل
// ========================================

const prefetchedRoutes = new Set<string>()

export function smartPrefetch(route: string): void {
  if (prefetchedRoutes.has(route)) return
  prefetchedRoutes.add(route)
  // Next.js prefetch عبر link تلقائياً، لكن يمكننا تحفيزه
  // لا حاجة لفعل شيء إضافي — prefetch={false} في BottomNav يمنع التحميل المسبق غير الضروري
}

// ========================================
// تنظيف الذاكرة عند الخروج من صفحة
// ========================================

export function cleanupPageCache(pageRoute: string): void {
  // إزالة cache الصفحة السابقة
  const keysToDelete: string[] = []
  for (const key of memoryCache.keys()) {
    if (key.includes(pageRoute)) {
      keysToDelete.push(key)
    }
  }
  keysToDelete.forEach((k) => memoryCache.delete(k))
}

// ========================================
// تحسين الصور: lazy loading + placeholder
// ========================================

export function getOptimizedImageUrl(url: string, width: number = 400): string {
  if (!url) return ''
  // Supabase storage لا يدعم تحويل الصور تلقائياً في الـ free tier
  // لكن يمكننا استخدام width parameters في المستقبل
  return url
}

// ========================================
// debounce للطلبات المتكررة
// ========================================

const debounceTimers = new Map<string, ReturnType<typeof setTimeout>>()

export function debounce<T extends (...args: never[]) => void>(
  key: string,
  fn: T,
  delay: number = 300
): (...args: Parameters<T>) => void {
  return (...args: Parameters<T>) => {
    const existing = debounceTimers.get(key)
    if (existing) clearTimeout(existing)
    const timer = setTimeout(() => {
      fn(...args)
      debounceTimers.delete(key)
    }, delay)
    debounceTimers.set(key, timer)
  }
}
