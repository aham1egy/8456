// src/lib/daily-streak.ts
// نظام مكافآت تسجيل الدخول اليومي

import { supabase } from './supabase/client'

// ========================================
// أنواع البيانات
// ========================================

export interface StreakStatus {
  current_streak: number
  longest_streak: number
  last_login_date: string | null
  total_logins: number
  has_freeze_available: boolean
  claimed_today: boolean
  days_until_freeze: number
}

export interface ClaimResult {
  success: boolean
  streak: number
  day_in_cycle: number
  points_awarded: number
  reward_type: 'points' | 'streak_freeze' | 'bonus' | null
  is_new_streak: boolean
  streak_broken: boolean
}

// ========================================
// تعريف المكافآت اليومية
// ========================================

export const DAILY_REWARDS = [
  { day: 1, points: 10, label: 'البداية', icon: '🌱' },
  { day: 2, points: 15, label: 'تقدم', icon: '🌿' },
  { day: 3, points: 20, label: 'مثابرة', icon: '⭐' },
  { day: 4, points: 25, label: 'استمرار', icon: '💫' },
  { day: 5, points: 30, label: 'تفاني', icon: '🔥' },
  { day: 6, points: 40, label: 'إصرار', icon: '⚡' },
  { day: 7, points: 50, label: 'إكمال الأسبوع!', icon: '🏆', bonus: 'streak_freeze' },
]

export function getRewardForDay(day: number) {
  const dayInCycle = ((day - 1) % 7) + 1
  return DAILY_REWARDS[dayInCycle - 1]
}

// ========================================
// جلب حالة الـ streak
// ========================================

export async function fetchStreakStatus(userId: string): Promise<StreakStatus | null> {
  try {
    const { data, error } = await supabase.rpc('get_streak_status', {
      target_user_id: userId,
    })

    if (error || !data || data.length === 0) {
      // [removed in production] '[fetchStreakStatus] error:', error
      return null
    }

    const row = data[0]
    return {
      current_streak: row.current_streak || 0,
      longest_streak: row.longest_streak || 0,
      last_login_date: row.last_login_date || null,
      total_logins: row.total_logins || 0,
      has_freeze_available: row.has_freeze_available || false,
      claimed_today: row.claimed_today || false,
      days_until_freeze: row.days_until_freeze || 7,
    }
  } catch (e) {
    // [removed in production] '[fetchStreakStatus] error:', e
    return null
  }
}

// ========================================
// المطالبة بالمكافأة اليومية
// ========================================

export async function claimDailyReward(userId: string): Promise<ClaimResult> {
  try {
    const { data, error } = await supabase.rpc('claim_daily_reward', {
      target_user_id: userId,
    })

    if (error || !data || data.length === 0) {
      // [removed in production] '[claimDailyReward] error:', error
      return {
        success: false,
        streak: 0,
        day_in_cycle: 0,
        points_awarded: 0,
        reward_type: null,
        is_new_streak: false,
        streak_broken: false,
      }
    }

    const row = data[0]
    return {
      success: row.success || false,
      streak: row.streak || 0,
      day_in_cycle: row.day_in_cycle || 0,
      points_awarded: row.points_awarded || 0,
      reward_type: row.reward_type as ClaimResult['reward_type'],
      is_new_streak: row.is_new_streak || false,
      streak_broken: row.streak_broken || false,
    }
  } catch (e) {
    // [removed in production] '[claimDailyReward] error:', e
    return {
      success: false,
      streak: 0,
      day_in_cycle: 0,
      points_awarded: 0,
      reward_type: null,
      is_new_streak: false,
      streak_broken: false,
    }
  }
}

// ========================================
// جلب سجل المكافآت
// ========================================

export interface DailyRewardLogEntry {
  id: string
  user_id: string
  reward_date: string
  streak_day: number
  points_awarded: number
  reward_type: string
  created_at: string
}

export async function fetchRewardHistory(userId: string, limit = 14): Promise<DailyRewardLogEntry[]> {
  try {
    const { data, error } = await supabase
      .from('daily_rewards_log')
      .select('*')
      .eq('user_id', userId)
      .order('reward_date', { ascending: false })
      .limit(limit)

    if (error || !data) {
      // [removed in production] '[fetchRewardHistory] error:', error
      return []
    }

    return data as DailyRewardLogEntry[]
  } catch (e) {
    // [removed in production] '[fetchRewardHistory] error:', e
    return []
  }
}
