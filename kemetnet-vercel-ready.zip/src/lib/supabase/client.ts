// src/lib/supabase/client.ts
// عميل Supabase للمتصفح - مشروع KemetNet
import { createClient } from '@supabase/supabase-js'
import type { LucideIcon } from 'lucide-react'
import {
  Sparkles, Zap, Palette, Plane, UtensilsCrossed, Music, MessageCircle,
  Smile, Moon, Activity, Heart
} from 'lucide-react'

// نفس الـ fallback المستخدم في next.config.ts (مشروع Supabase الخاص بالتطبيق)
const FALLBACK_SUPABASE_URL = 'https://bhzrhvesrpyvrsshavow.supabase.co'
const FALLBACK_SUPABASE_ANON_KEY = 'sb_publishable_placeholder_key'

export const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || FALLBACK_SUPABASE_URL
export const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || FALLBACK_SUPABASE_ANON_KEY

// علم: هل البيئات مضبوطة فعلياً؟ (يستخدم لاتخاذ قرار تخطّي الاتصال في page.tsx)
export const isSupabaseConfigured =
  !!process.env.NEXT_PUBLIC_SUPABASE_URL &&
  !!process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY &&
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY !== FALLBACK_SUPABASE_ANON_KEY

if (!process.env.NEXT_PUBLIC_SUPABASE_URL || !process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY) {
  // تحذير في وضع التطوير فقط
  if (process.env.NODE_ENV !== 'production') {
    console.warn(
      '[KemetNet] Supabase env vars missing. Using fallback URL but auth will fail. ' +
      'Set NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY in .env'
    )
  }
}

export const supabase = createClient(
  supabaseUrl,
  supabaseAnonKey,
  {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true,
      storageKey: 'kemetnet-auth',
    },
    global: {
      headers: {
        'x-application-name': 'kemetnet-app',
      },
    },
  }
)

// أنواع البيانات
export interface Profile {
  id: string
  username: string
  display_name: string | null
  bio: string | null
  avatar_url: string | null
  avatar_color: string | null
  followers_count: number
  following_count: number
  posts_count: number
  last_seen: string | null
  show_last_seen: boolean
  show_online_status: boolean
  is_verified: boolean
  verified_type: 'official' | 'business' | 'creator' | 'early_adopter' | null
  verified_at: string | null
  reputation_points: number
  reputation_level: number
  total_earned_points: number
  login_streak: number
  longest_streak: number
  last_login_date: string | null
  total_logins: number
  streak_freeze_available: boolean
  streak_freeze_used: number
  created_at: string
  // إدارة الأدوار والصلاحيات
  role?: 'owner' | 'admin' | 'moderator' | 'custom' | 'user' | null
  is_admin?: boolean
  restricted_until?: string | null
  restriction_reason?: string | null
}

export interface Post {
  id: string
  user_id: string
  content: string
  category: string
  tags: string[] | null
  image_url: string | null
  mood: string | null
  repost_of: string | null
  is_pinned: boolean
  pinned_at: string | null
  is_featured: boolean
  featured_at: string | null
  featured_votes_count: number
  likes_count: number
  comments_count: number
  reposts_count: number
  created_at: string
  profile?: Profile
  user_liked?: boolean
  user_saved?: boolean
  user_voted_featured?: boolean
  original_post?: Post | null
}

export interface Like {
  id: string
  post_id: string
  user_id: string
  created_at: string
}

// الفئات الافتراضية - مع أيقونات Lucide بدل الإيموجي
export interface CategoryDef {
  id: string
  label: string
  icon: LucideIcon
  color: string
}

export const CATEGORIES: CategoryDef[] = [
  { id: 'all', label: 'الكل', icon: Sparkles, color: '#FBBF24' },
  { id: 'inspire', label: 'إلهام', icon: Sparkles, color: '#F59E0B' },
  { id: 'tech', label: 'تقنية', icon: Zap, color: '#FB7185' },
  { id: 'art', label: 'فن', icon: Palette, color: '#EC4899' },
  { id: 'travel', label: 'سفر', icon: Plane, color: '#34D399' },
  { id: 'food', label: 'طعام', icon: UtensilsCrossed, color: '#FB923C' },
  { id: 'music', label: 'موسيقى', icon: Music, color: '#A78BFA' },
  { id: 'thoughts', label: 'خواطر', icon: MessageCircle, color: '#60A5FA' },
]

// المود/الأجواء - مع أيقونات Lucide
export interface MoodDef {
  id: string
  label: string
  icon: LucideIcon
  color: string
}

export const MOODS: MoodDef[] = [
  { id: 'happy', label: 'سعيد', icon: Smile, color: '#FBBF24' },
  { id: 'calm', label: 'هادئ', icon: Moon, color: '#A78BFA' },
  { id: 'energetic', label: 'نشيط', icon: Activity, color: '#F43F5E' },
  { id: 'reflective', label: 'تأملي', icon: Moon, color: '#60A5FA' },
  { id: 'grateful', label: 'ممتن', icon: Heart, color: '#34D399' },
]

// دالة مساعدة لجلب أيقونة الفئة
export function getCategoryIcon(categoryId: string): LucideIcon {
  const cat = CATEGORIES.find((c) => c.id === categoryId)
  return cat?.icon || Sparkles
}

export function getMoodIcon(moodId: string): LucideIcon {
  const mood = MOODS.find((m) => m.id === moodId)
  return mood?.icon || Smile
}
