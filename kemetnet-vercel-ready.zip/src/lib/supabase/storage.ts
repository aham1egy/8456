// src/lib/supabase/storage.ts
// خدمة رفع الصور إلى Supabase Storage - مشروع KemetNet

import { supabase } from './client'

const AVATARS_BUCKET = 'avatars'
const POSTS_BUCKET = 'post-images'
const MESSAGES_BUCKET = 'message-images'

// ضمان أن البuckets موجودة (ينشئها إن لم تكن موجودة)
export async function ensureBucketsExist(): Promise<void> {
  // ملاحظة: هذا يتطلب service_role key عادةً
  // إذا فشل، المستخدم يجب أن ينشئ الbuckets يدويًا في لوحة تحكم Supabase
  try {
    // محاولة سرد الbuckets
    const { data, error } = await supabase.storage.listBuckets()
    if (error) {
      return
    }

    const bucketNames = data?.map((b) => b.name) || []
    if (!bucketNames.includes(AVATARS_BUCKET)) {
      // محاولة إنشاء (قد تفشل إذا لم يكن لدى المستخدم صلاحية service_role)
      const { error: createErr } = await supabase.storage.createBucket(AVATARS_BUCKET, {
        public: true,
        allowedMimeTypes: ['image/png', 'image/jpeg', 'image/webp', 'image/gif'],
        fileSizeLimit: 2 * 1024 * 1024, // 2MB
      })
      if (createErr) {
      }
    }
    if (!bucketNames.includes(POSTS_BUCKET)) {
      const { error: createErr } = await supabase.storage.createBucket(POSTS_BUCKET, {
        public: true,
        allowedMimeTypes: ['image/png', 'image/jpeg', 'image/webp', 'image/gif'],
        fileSizeLimit: 5 * 1024 * 1024, // 5MB
      })
      if (createErr) {
      }
    }
    if (!bucketNames.includes(MESSAGES_BUCKET)) {
      const { error: createErr } = await supabase.storage.createBucket(MESSAGES_BUCKET, {
        public: true,
        allowedMimeTypes: ['image/png', 'image/jpeg', 'image/webp', 'image/gif'],
        fileSizeLimit: 5 * 1024 * 1024, // 5MB
      })
      if (createErr) {
      }
    }
  } catch (e) {
    // [removed in production] 'ensureBucketsExist error:', e
  }
}

// V-10+V-25: التحقق من نوع وحجم الصورة + رفض SVG
export function validateImageFile(file: File): { valid: boolean; error?: string } {
  // 1) التحقق من النوع الأساسي
  if (!file.type.startsWith('image/')) {
    return { valid: false, error: 'الملف يجب أن يكون صورة' }
  }
  // V-25: رفض SVG صراحةً (خطر XSS)
  if (file.type === 'image/svg+xml') {
    return { valid: false, error: 'صور SVG غير مسموحة' }
  }
  // 2) التحقق من الأنواع المسموحة فقط (whitelist)
  const ALLOWED_MIME = new Set(['image/png', 'image/jpeg', 'image/jpg', 'image/webp', 'image/gif'])
  if (!ALLOWED_MIME.has(file.type)) {
    return { valid: false, error: 'نوع الصورة غير مدعوم. استخدم: PNG, JPG, WebP, GIF' }
  }
  // 3) التحقق من الحجم الأقصى (50MB hard limit)
  if (file.size > 50 * 1024 * 1024) {
    return { valid: false, error: 'حجم الصورة كبير جدًا (الحد الأقصى 50 ميجابايت)' }
  }
  // 4) التحقق من حجم أدنى (تجنب الملفات الفارغة)
  if (file.size < 100) {
    return { valid: false, error: 'الملف صغير جدًا أو تالف' }
  }
  // 5) التحقق من اسم الملف (anti-path-traversal)
  if (file.name && (file.name.includes('..') || file.name.includes('\0'))) {
    return { valid: false, error: 'اسم الملف غير صالح' }
  }
  return { valid: true }
}

/**
 * فحص أبعاد الصورة (يتطلب تحميل الصورة في الذاكرة)
 * يرفض الصور أكبر من 5000x5000 أو أصغر من 50x50
 */
export async function validateImageDimensions(
  file: File,
  options: { maxWidth?: number; maxHeight?: number; minWidth?: number; minHeight?: number } = {}
): Promise<{ valid: boolean; error?: string; width?: number; height?: number }> {
  const { maxWidth = 5000, maxHeight = 5000, minWidth = 50, minHeight = 50 } = options

  return new Promise((resolve) => {
    try {
      const img = new Image()
      const url = URL.createObjectURL(file)
      img.onload = () => {
        URL.revokeObjectURL(url)
        const { width, height } = { width: img.naturalWidth, height: img.naturalHeight }
        if (width > maxWidth || height > maxHeight) {
          resolve({ valid: false, error: `أبعاد الصورة كبيرة جدًا (الحد الأقصى ${maxWidth}×${maxHeight})` })
        } else if (width < minWidth || height < minHeight) {
          resolve({ valid: false, error: `أبعاد الصورة صغيرة جدًا (الحد الأدنى ${minWidth}×${minHeight})` })
        } else {
          resolve({ valid: true, width, height })
        }
      }
      img.onerror = () => {
        URL.revokeObjectURL(url)
        resolve({ valid: false, error: 'الصورة تالفة أو غير صالحة' })
      }
      img.src = url
    } catch (e) {
      resolve({ valid: false, error: 'فشل التحقق من الصورة' })
    }
  })
}

// V-26: استخراج امتداد آمن من اسم الملف (يحمي من path traversal)
const ALLOWED_IMAGE_EXTENSIONS = new Set(['png', 'jpg', 'jpeg', 'webp', 'gif'])

/**
 * استخراج امتداد آمن من اسم ملف
 * يرفض الأسماء التي تحتوي على مسارات نسبية أو أحرف غير صالحة
 * يُرجع امتداداً من القائمة البيضاء فقط (png/jpg/jpeg/webp/gif) أو 'jpg' كافتراضي
 */
function safeImageExtension(filename: string): string {
  if (typeof filename !== 'string' || !filename) return 'jpg'

  // V-26: رفض أي اسم يحتوي على فواصل مسار (path traversal)
  if (filename.includes('/') || filename.includes('\\') || filename.includes('..')) {
    return 'jpg'
  }

  // استخراج آخر جزء بعد النقطة
  const parts = filename.split('.')
  if (parts.length < 2) return 'jpg'

  const ext = parts[parts.length - 1].toLowerCase().trim()
  // التحقق من أن الامتداد يحتوي على أحرف فقط وأنه ضمن القائمة البيضاء
  if (!/^[a-z0-9]+$/.test(ext)) return 'jpg'
  return ALLOWED_IMAGE_EXTENSIONS.has(ext) ? ext : 'jpg'
}

// V-10: التحقق من أن URL يطابق Supabase Storage فقط
export function isValidImageUrl(url: string): boolean {
  if (!url) return true // null مقبول
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || ''
  return url.startsWith(supabaseUrl + '/storage/')
}

// رفع صورة الملف الشخصي
export async function uploadAvatar(userId: string, file: File): Promise<{ url: string | null; error?: string }> {
  try {
    // التحقق من النوع والحجم
    const validation = validateImageFile(file); if (!validation.valid) {
      return { url: null, error: validation.error }
    }
    if (file.size > 2 * 1024 * 1024) {
      return { url: null, error: 'حجم الصورة يجب ألا يتجاوز 2 ميجابايت' }
    }

    const ext = safeImageExtension(file.name)
    const filename = `${userId}/avatar-${crypto.randomUUID()}.${ext}`

    const { error: uploadError } = await supabase.storage
      .from(AVATARS_BUCKET)
      .upload(filename, file, {
        cacheControl: '3600',
        upsert: true,
        contentType: file.type,
      })

    if (uploadError) {
      // [removed in production] 'Upload avatar error:', uploadError
      return { url: null, error: translateStorageError(uploadError.message) }
    }

    // الحصول على الرابط العام
    const { data } = supabase.storage.from(AVATARS_BUCKET).getPublicUrl(filename)
    return { url: data.publicUrl }
  } catch (e) {
    // [removed in production] 'uploadAvatar error:', e
    return { url: null, error: 'حدث خطأ غير متوقع' }
  }
}

// رفع صورة منشور
export async function uploadPostImage(userId: string, file: File): Promise<{ url: string | null; error?: string }> {
  try {
    const validation = validateImageFile(file); if (!validation.valid) {
      return { url: null, error: validation.error }
    }
    if (file.size > 5 * 1024 * 1024) {
      return { url: null, error: 'حجم الصورة يجب ألا يتجاوز 5 ميجابايت' }
    }

    const ext = safeImageExtension(file.name)
    const filename = `${userId}/post-${crypto.randomUUID()}.${ext}`

    const { error: uploadError } = await supabase.storage
      .from(POSTS_BUCKET)
      .upload(filename, file, {
        cacheControl: '3600',
        contentType: file.type,
      })

    if (uploadError) {
      // [removed in production] 'Upload post image error:', uploadError
      return { url: null, error: translateStorageError(uploadError.message) }
    }

    const { data } = supabase.storage.from(POSTS_BUCKET).getPublicUrl(filename)
    return { url: data.publicUrl }
  } catch (e) {
    // [removed in production] 'uploadPostImage error:', e
    return { url: null, error: 'حدث خطأ غير متوقع' }
  }
}

// رفع صورة رسالة (محادثة)
export async function uploadMessageImage(userId: string, file: File): Promise<{ url: string | null; error?: string }> {
  try {
    const validation = validateImageFile(file); if (!validation.valid) {
      return { url: null, error: validation.error }
    }
    if (file.size > 5 * 1024 * 1024) {
      return { url: null, error: 'حجم الصورة يجب ألا يتجاوز 5 ميجابايت' }
    }

    const ext = safeImageExtension(file.name)
    const filename = `${userId}/msg-${crypto.randomUUID()}.${ext}`

    const { error: uploadError } = await supabase.storage
      .from(MESSAGES_BUCKET)
      .upload(filename, file, {
        cacheControl: '3600',
        contentType: file.type,
      })

    if (uploadError) {
      // [removed in production] 'Upload message image error:', uploadError
      return { url: null, error: translateStorageError(uploadError.message) }
    }

    const { data } = supabase.storage.from(MESSAGES_BUCKET).getPublicUrl(filename)
    return { url: data.publicUrl }
  } catch (e) {
    // [removed in production] 'uploadMessageImage error:', e
    return { url: null, error: 'حدث خطأ غير متوقع' }
  }
}

// ضغط الصورة قبل الرفع (للأداء) — يدعم نسبة 4:5 للمنشورات
export function compressImage(file: File, maxWidth = 1080, quality = 0.92): Promise<File> {
  return new Promise((resolve, reject) => {
    const validation = validateImageFile(file); if (!validation.valid) {
      resolve(file)
      return
    }

    // تخطي ضغط GIF (canvas لا يدعم GIF متحرك)
    if (file.type === 'image/gif') {
      resolve(file)
      return
    }

    const reader = new FileReader()
    reader.onload = (e) => {
      const img = new Image()
      img.onload = () => {
        const canvas = document.createElement('canvas')
        let width = img.width
        let height = img.height

        if (width > maxWidth) {
          height = (height * maxWidth) / width
          width = maxWidth
        }

        canvas.width = width
        canvas.height = height
        const ctx = canvas.getContext('2d')
        if (!ctx) {
          resolve(file)
          return
        }
        ctx.drawImage(img, 0, 0, width, height)

        canvas.toBlob(
          (blob) => {
            if (blob) {
              resolve(new File([blob], file.name, { type: 'image/jpeg' }))
            } else {
              resolve(file)
            }
          },
          'image/jpeg',
          quality
        )
      }
      img.onerror = () => resolve(file)
      img.src = e.target?.result as string
    }
    reader.onerror = () => resolve(file)
    reader.readAsDataURL(file)
  })
}

// قص الصورة بنسبة محددة (4:5 للمنشورات، 1:1 للبروفيل)
export function cropImageToAspect(
  file: File,
  aspectRatio: number = 4 / 5,
  maxWidth: number = 1080
): Promise<{ blob: Blob; url: string; width: number; height: number }> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = (e) => {
      const img = new Image()
      img.onload = () => {
        const canvas = document.createElement('canvas')
        const outW = maxWidth
        const outH = Math.round(maxWidth / aspectRatio)
        canvas.width = outW
        canvas.height = outH
        const ctx = canvas.getContext('2d')
        if (!ctx) {
          reject(new Error('Canvas not supported'))
          return
        }

        // حساب أبعاد القص للحفاظ على النسبة
        const imgRatio = img.width / img.height
        let sx = 0, sy = 0, sw = img.width, sh = img.height

        if (imgRatio > aspectRatio) {
          // الصورة أعرض من المطلوب — قص من الجانبين
          sw = img.height * aspectRatio
          sx = (img.width - sw) / 2
        } else {
          // الصورة أطول من المطلوب — قص من الأعلى والأسفل
          sh = img.width / aspectRatio
          sy = (img.height - sh) / 2
        }

        ctx.drawImage(img, sx, sy, sw, sh, 0, 0, outW, outH)

        canvas.toBlob(
          (blob) => {
            if (!blob) {
              reject(new Error('Failed to create blob'))
              return
            }
            resolve({
              blob,
              url: URL.createObjectURL(blob),
              width: outW,
              height: outH,
            })
          },
          'image/jpeg',
          0.92
        )
      }
      img.onerror = () => reject(new Error('Failed to load image'))
      img.src = e.target?.result as string
    }
    reader.onerror = () => reject(new Error('Failed to read file'))
    reader.readAsDataURL(file)
  })
}

// ترجمة أخطاء Supabase Storage
function translateStorageError(message: string): string {
  const lower = message.toLowerCase()
  if (lower.includes('bucket not found')) {
    return 'مجلد التخزين غير موجود. يجب إنشاء bucket "avatars" في لوحة تحكم Supabase'
  }
  if (lower.includes('unauthorized') || lower.includes('permission')) {
    return 'لا تملك صلاحية لرفع الصور'
  }
  if (lower.includes('payload too large')) {
    return 'حجم الصورة كبير جدًا'
  }
  return message
}
