// src/lib/supabase/auth.ts
// نظام المصادقة باستخدام اليوزرنيم - مشروع KemetNet
// يقوم بإنشاء مستخدمين ببريد إلكتروني وهمي(username@kemetnet.app.local)
// بحيث يكون تسجيل الدخول باليوزرنيم وكلمة المرور فقط

import { supabase, isSupabaseConfigured } from './client'
import type { Profile } from './client'

const FAKE_DOMAIN = 'kemetnet.app.local'

// ألوان افتراضية للصور الرمزية
const AVATAR_COLORS = [
  '#FBBF24', '#FB7185', '#A78BFA', '#34D399',
  '#60A5FA', '#FB923C', '#F472B6', '#FACC15',
]

// توليد بريد إلكتروني وهمي من اليوزرنيم
function usernameToEmail(username: string): string {
  return `${username.toLowerCase().trim()}@${FAKE_DOMAIN}`
}

// التحقق من صحة اليوزرنيم
export function validateUsername(username: string): { valid: boolean; error?: string } {
  const trimmed = username.trim()
  if (trimmed.length < 3) {
    return { valid: false, error: 'اليوزرنيم يجب أن يكون 3 أحرف على الأقل' }
  }
  if (trimmed.length > 20) {
    return { valid: false, error: 'اليوزرنيم يجب ألا يتجاوز 20 حرفًا' }
  }
  if (!/^[a-zA-Z0-9_]+$/.test(trimmed)) {
    return { valid: false, error: 'اليوزرنيم يجب أن يحتوي على أحرف وأرقام وشرطة سفلية فقط' }
  }
  return { valid: true }
}

// التحقق من توفر اليوزرنيم
export async function checkUsernameAvailability(username: string): Promise<boolean> {
  try {
    const { data, error } = await supabase
      .from('profiles')
      .select('username')
      .eq('username', username.toLowerCase().trim())
      .maybeSingle()

    if (error) {
      // [removed in production] 'Error checking username:', error
      // عند الخطأ، أعد false (غير متاح) بدل true لمنع التسجيل بحساب مكرر
      return false
    }
    return !data
  } catch (e) {
    // [removed in production] e
    return false
  }
}

// إنشاء ملف شخصي بعد التسجيل (في حال عدم وجود trigger)
async function ensureProfile(userId: string, username: string, displayName?: string): Promise<void> {
  try {
    const { data: existing } = await supabase
      .from('profiles')
      .select('id')
      .eq('id', userId)
      .maybeSingle()

    if (existing) return

    const color = AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)]

    // محاولة الإدراج بكل الأعمدة المتوقعة
    const { error } = await supabase.from('profiles').insert({
      id: userId,
      username: username.toLowerCase().trim(),
      display_name: displayName || username,
      avatar_color: color,
    })

    if (error) {
      // [removed in production] 'Error creating profile (full):', error
      // محاولة بحد أدنى من الأعمدة (في حال كانت البنية مختلفة)
      const { error: err2 } = await supabase.from('profiles').insert({
        id: userId,
        username: username.toLowerCase().trim(),
      })
      if (err2) {
        // [removed in production] 'Error creating profile (minimal):', err2
      }
    }
  } catch (e) {
    // [removed in production] 'ensureProfile error:', e
  }
}

// التسجيل باليوزرنيم وكلمة المرور
export async function signUpWithUsername(
  username: string,
  password: string,
  displayName?: string
): Promise<{ success: boolean; error?: string }> {
  const validation = validateUsername(username)
  if (!validation.valid) {
    return { success: false, error: validation.error }
  }

  if (password.length < 8) {
    return { success: false, error: 'كلمة المرور يجب أن تكون 8 أحرف على الأقل' }
  }
  // V-06: فحص تعقيد كلمة المرور
  if (!/[a-zA-Z]/.test(password) || !/[0-9]/.test(password)) {
    return { success: false, error: 'كلمة المرور يجب أن تحتوي على أحرف وأرقام' }
  }

  // فحص مبكر: هل Supabase مضبوط؟
  if (!isSupabaseConfigured) {
    return { success: false, error: 'التطبيق لم يُضبط بعد — يجب إضافة NEXT_PUBLIC_SUPABASE_ANON_KEY في ملف .env قبل التسجيل' }
  }

  const available = await checkUsernameAvailability(username)
  if (!available) {
    return { success: false, error: 'هذا اليوزرنيم محجوز، جرّب اسمًا آخر' }
  }

  const email = usernameToEmail(username)
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: {
        username: username.toLowerCase().trim(),
        display_name: displayName || username,
      },
    },
  })

  if (error) {
    return { success: false, error: translateAuthError(error.message) }
  }

  if (data.user) {
    await ensureProfile(data.user.id, username, displayName)
  }

  return { success: true }
}

// تسجيل الدخول باليوزرنيم وكلمة المرور
export async function signInWithUsername(
  username: string,
  password: string
): Promise<{ success: boolean; error?: string }> {
  // فحص مبكر: هل Supabase مضبوط؟
  if (!isSupabaseConfigured) {
    return { success: false, error: 'التطبيق لم يُضبط بعد — يجب إضافة NEXT_PUBLIC_SUPABASE_ANON_KEY في ملف .env قبل تسجيل الدخول' }
  }
  const email = usernameToEmail(username)
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  })

  if (error) {
    return { success: false, error: translateAuthError(error.message) }
  }

  if (data.user) {
    await ensureProfile(data.user.id, username)
    // تحديث آخر ظهور (يحترم إعداد show_last_seen)
    try {
      await supabase.rpc('update_last_seen', { target_user_id: data.user.id })
    } catch {
      // لا نريد إفشال تسجيل الدخول بسبب هذا
    }
  }

  return { success: true }
}

// تسجيل الخروج
export async function signOut(): Promise<void> {
  await supabase.auth.signOut()
}

// ترجمة أخطاء المصادقة للعربية
function translateAuthError(message: string): string {
  const lower = message.toLowerCase()
  if (lower.includes('invalid api key') || lower.includes('invalidapikey') || lower.includes('api key')) {
    return 'تعذّر الاتصال بالخادم — مفتاح Supabase غير صالح. أضِف NEXT_PUBLIC_SUPABASE_ANON_KEY الصحيح في ملف .env'
  }
  if (lower.includes('invalid login credentials') || lower.includes('invalid credentials')) {
    return 'اليوزرنيم أو كلمة المرور غير صحيحة'
  }
  if (lower.includes('user already registered') || lower.includes('already been registered')) {
    return 'هذا اليوزرنيم مسجل بالفعل'
  }
  if (lower.includes('email rate limit') || lower.includes('rate limit')) {
    return 'محاولات كثيرة، انتظر قليلًا ثم حاول مجددًا'
  }
  if (lower.includes('password should be at least')) {
    return 'كلمة المرور يجب أن تكون 8 أحرف على الأقل وتحتوي على أحرف وأرقام'
  }
  if (lower.includes('unable to validate email')) {
    return 'اليوزرنيم غير صالح'
  }
  if (lower.includes('signup disabled') || lower.includes('not allowed')) {
    return 'التسجيل غير مفعل حاليًا. تأكد من إعداد Supabase بشكل صحيح'
  }
  return message
}

// جلب الملف الشخصي للمستخدم الحالي
export async function getCurrentProfile(): Promise<Profile | null> {
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return null

  const username = (user.user_metadata?.username as string) || `user_${user.id.slice(0, 8)}`
  const displayName = (user.user_metadata?.display_name as string) || username

  const { data: profile, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', user.id)
    .maybeSingle()

  if (error) {
    // [removed in production] 'Error fetching profile:', error
    // إرجاع بيانات افتراضية من auth metadata حتى يستطيع المستخدم استخدام التطبيق
    return {
      id: user.id,
      username,
      display_name: displayName,
      bio: null,
      avatar_url: null,
      avatar_color: '#FBBF24',
      followers_count: 0,
      following_count: 0,
      posts_count: 0,
      last_seen: null,
      show_last_seen: true,
      show_online_status: true,
      is_verified: false,
      verified_type: null,
      verified_at: null,
      reputation_points: 0,
      reputation_level: 1,
      total_earned_points: 0,
      login_streak: 0,
      longest_streak: 0,
      last_login_date: null,
      total_logins: 0,
      streak_freeze_available: false,
      streak_freeze_used: 0,
      created_at: user.created_at || new Date().toISOString(),
    }
  }

  if (!profile) {
    // محاولة إنشاء profile
    await ensureProfile(user.id, username, displayName)
    const { data: newProfile } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', user.id)
      .maybeSingle()

    if (newProfile) return newProfile as Profile

    // إرجاع بيانات افتراضية من auth metadata
    return {
      id: user.id,
      username,
      display_name: displayName,
      bio: null,
      avatar_url: null,
      avatar_color: '#FBBF24',
      followers_count: 0,
      following_count: 0,
      posts_count: 0,
      last_seen: null,
      show_last_seen: true,
      show_online_status: true,
      is_verified: false,
      verified_type: null,
      verified_at: null,
      reputation_points: 0,
      reputation_level: 1,
      total_earned_points: 0,
      login_streak: 0,
      longest_streak: 0,
      last_login_date: null,
      total_logins: 0,
      streak_freeze_available: false,
      streak_freeze_used: 0,
      created_at: user.created_at || new Date().toISOString(),
    }
  }

  return profile as Profile
}

// تحديث الملف الشخصي
export async function updateProfile(updates: {
  display_name?: string
  bio?: string
  avatar_url?: string
  avatar_color?: string
  show_last_seen?: boolean
  show_online_status?: boolean
}): Promise<{ success: boolean; error?: string }> {
  // ✅ أمني: التحقق من طول المدخلات
  if (updates.bio !== undefined && updates.bio !== null && updates.bio.length > 500) {
    return { success: false, error: 'النبذة طويلة جدًا (حد أقصى 500 حرف)' }
  }
  if (updates.display_name !== undefined && updates.display_name !== null && updates.display_name.length > 30) {
    return { success: false, error: 'الاسم المعروض طويل جدًا (حد أقصى 30 حرف)' }
  }
  if (updates.avatar_color && !/^#[0-9A-Fa-f]{6}$/.test(updates.avatar_color)) {
    return { success: false, error: 'لون غير صالح' }
  }

  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { success: false, error: 'غير مسجل الدخول' }

  const { error } = await supabase
    .from('profiles')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', user.id)

  if (error) return { success: false, error: 'تعذّر تحديث الملف الشخصي' }
  return { success: true }
}
