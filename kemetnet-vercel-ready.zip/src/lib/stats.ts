// src/lib/stats.ts
// إحصائيات المستخدم + رسم بياني للنشاط

import { supabase } from './supabase/client'

// ========================================
// أنواع البيانات
// ========================================

export interface UserStats {
  totalPosts: number
  totalLikes: number
  totalComments: number
  totalFollowers: number
  totalFollowing: number
  // توزيع المنشورات حسب الفئة
  categoryDistribution: { category: string; count: number; color: string }[]
  // النشاط خلال آخر 7 أيام
  activityLast7Days: { day: string; date: string; posts: number; likes: number }[]
  // أكثر الفئات استخداماً
  topCategory: { category: string; count: number } | null
  // إجمالي التفاعل (إعجابات + تعليقات استلمها)
  engagementRate: number
}

export interface ProfileStats {
  totalPosts: number
  totalLikes: number
  totalComments: number
  categoryDistribution: { category: string; count: number }[]
}

// ========================================
// جلب الإحصائيات
// ========================================

const CATEGORY_COLORS: Record<string, string> = {
  inspire: '#F59E0B',
  tech: '#FB7185',
  art: '#EC4899',
  travel: '#34D399',
  food: '#FB923C',
  music: '#A78BFA',
  thoughts: '#60A5FA',
}

/**
 * جلب إحصائيات شاملة لمستخدم
 */
export async function fetchUserStats(userId: string): Promise<UserStats | null> {
  try {
    // جلب المنشورات مع الإحصائيات
    const { data: posts, error: postsErr } = await supabase
      .from('posts')
      .select('id, category, likes_count, comments_count, created_at')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })

    if (postsErr || !posts) {
      // [removed in production] '[fetchUserStats] posts error:', postsErr
      return null
    }

    // جلب إحصائيات الملف الشخصي
    const { data: profile } = await supabase
      .from('profiles')
      .select('followers_count, following_count, posts_count')
      .eq('id', userId)
      .maybeSingle()

    // توزيع الفئات
    const categoryMap: Record<string, number> = {}
    posts.forEach((p: { category: string }) => {
      categoryMap[p.category] = (categoryMap[p.category] || 0) + 1
    })

    const categoryDistribution = Object.entries(categoryMap)
      .map(([category, count]) => ({
        category,
        count,
        color: CATEGORY_COLORS[category] || '#888888',
      }))
      .sort((a, b) => b.count - a.count)

    // أكثر فئة استخداماً
    const topCategory = categoryDistribution[0]
      ? { category: categoryDistribution[0].category, count: categoryDistribution[0].count }
      : null

    // النشاط آخر 7 أيام
    const now = new Date()
    const days: { day: string; date: string; posts: number; likes: number }[] = []
    const dayNames = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت']

    for (let i = 6; i >= 0; i--) {
      const date = new Date(now)
      date.setDate(date.getDate() - i)
      const dateStr = date.toISOString().split('T')[0]
      const dayName = dayNames[date.getDay()]

      const dayPosts = posts.filter((p: { created_at: string }) =>
        p.created_at.startsWith(dateStr)
      )

      const dayLikes = dayPosts.reduce(
        (sum: number, p: { likes_count: number }) => sum + (p.likes_count || 0),
        0
      )

      days.push({
        day: dayName,
        date: dateStr,
        posts: dayPosts.length,
        likes: dayLikes,
      })
    }

    // إجمالي الإحصائيات
    const totalPosts = posts.length
    const totalLikes = posts.reduce(
      (sum: number, p: { likes_count: number }) => sum + (p.likes_count || 0),
      0
    )
    const totalComments = posts.reduce(
      (sum: number, p: { comments_count: number }) => sum + (p.comments_count || 0),
      0
    )

    // معدل التفاعل (متوسط الإعجابات لكل منشور)
    const engagementRate = totalPosts > 0 ? Math.round(totalLikes / totalPosts) : 0

    return {
      totalPosts,
      totalLikes,
      totalComments,
      totalFollowers: profile?.followers_count || 0,
      totalFollowing: profile?.following_count || 0,
      categoryDistribution,
      activityLast7Days: days,
      topCategory,
      engagementRate,
    }
  } catch (e) {
    // [removed in production] '[fetchUserStats] error:', e
    return null
  }
}

/**
 * جلب إحصائيات مبسطة لملف شخصي (للعرض العام)
 */
export async function fetchProfileStats(userId: string): Promise<ProfileStats | null> {
  try {
    const { data: posts, error } = await supabase
      .from('posts')
      .select('category, likes_count, comments_count')
      .eq('user_id', userId)

    if (error || !posts) return null

    const categoryMap: Record<string, number> = {}
    posts.forEach((p: { category: string }) => {
      categoryMap[p.category] = (categoryMap[p.category] || 0) + 1
    })

    const categoryDistribution = Object.entries(categoryMap).map(([category, count]) => ({
      category,
      count,
    }))

    return {
      totalPosts: posts.length,
      totalLikes: posts.reduce((s: number, p: { likes_count: number }) => s + (p.likes_count || 0), 0),
      totalComments: posts.reduce((s: number, p: { comments_count: number }) => s + (p.comments_count || 0), 0),
      categoryDistribution,
    }
  } catch (e) {
    // [removed in production] '[fetchProfileStats] error:', e
    return null
  }
}

/**
 * ترجمة أسماء الفئات
 */
export const CATEGORY_LABELS: Record<string, string> = {
  inspire: 'إلهام',
  tech: 'تقنية',
  art: 'فن',
  travel: 'سفر',
  food: 'طعام',
  music: 'موسيقى',
  thoughts: 'خواطر',
}

export function getCategoryLabel(category: string): string {
  return CATEGORY_LABELS[category] || category
}

export function getCategoryColor(category: string): string {
  return CATEGORY_COLORS[category] || '#888888'
}
