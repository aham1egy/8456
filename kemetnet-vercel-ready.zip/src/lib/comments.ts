// src/lib/comments.ts
// نظام التعليقات الكامل - مشابه لإنستجرام
// يدعم: ردود متداخلة، إعجاب، تثبيت، تعديل، حذف، بث مباشر

import { supabase, type Profile } from './supabase/client'

// ========================================
// الأنواع
// ========================================

export interface Comment {
  id: string
  post_id: string
  user_id: string
  parent_id: string | null
  content: string
  likes_count: number
  is_pinned: boolean
  is_edited: boolean
  edited_at: string | null
  deleted_at: string | null
  created_at: string
  profile?: Profile | null
  replies?: Comment[]
  user_liked?: boolean
}

export interface CommentWithReplies extends Comment {
  replies: Comment[]
  replies_count: number
}

// ========================================
// أداة الوقت النسبي (مثل إنستجرام)
// ========================================

export function getTimeAgoArabic(dateStr: string): string {
  const date = new Date(dateStr)
  const now = new Date()
  const diffMs = now.getTime() - date.getTime()
  const diffSec = Math.floor(diffMs / 1000)

  if (diffSec < 60) return 'الآن'

  const diffMin = Math.floor(diffSec / 60)
  if (diffMin < 60) return `${diffMin} د`

  const diffHour = Math.floor(diffMin / 60)
  if (diffHour < 24) return `${diffHour} س`

  const diffDay = Math.floor(diffHour / 24)
  if (diffDay < 7) return `${diffDay} ي`

  const diffWeek = Math.floor(diffDay / 7)
  if (diffWeek < 4) return `${diffWeek} أ`

  const diffMonth = Math.floor(diffDay / 30)
  if (diffMonth < 12) return `${diffMonth} ش`

  const diffYear = Math.floor(diffDay / 365)
  return `${diffYear} س`
}

// صيغة كاملة للوقت (تُستخدم في tooltip أو العرض المفصل)
export function getTimeAgoFull(dateStr: string): string {
  const date = new Date(dateStr)
  const now = new Date()
  const diffMs = now.getTime() - date.getTime()
  const diffSec = Math.floor(diffMs / 1000)

  if (diffSec < 60) return 'الآن'

  const diffMin = Math.floor(diffSec / 60)
  if (diffMin < 60) return `قبل ${diffMin} دقيقة`

  const diffHour = Math.floor(diffMin / 60)
  if (diffHour < 24) return `قبل ${diffHour} ساعة`

  const diffDay = Math.floor(diffHour / 24)
  if (diffDay < 7) return `قبل ${diffDay} يوم`

  const diffWeek = Math.floor(diffDay / 7)
  if (diffWeek < 4) return `قبل ${diffWeek} أسبوع`

  const diffMonth = Math.floor(diffDay / 30)
  if (diffMonth < 12) return `قبل ${diffMonth} شهر`

  const diffYear = Math.floor(diffDay / 365)
  return `قبل ${diffYear} سنة`
}

// ========================================
// جلب التعليقات
// ========================================

/**
 * جلب كل تعليقات المنشور (رئيسية + ردود) مع معلومات المستخدم
 * يعيد بنية شجرية: التعليق الرئيسي مع ردوده
 */
export async function fetchPostComments(postId: string, currentUserId?: string): Promise<CommentWithReplies[]> {
  const { data, error } = await supabase
    .from('comments')
    .select('*, profile:profiles(*)')
    .eq('post_id', postId)
    .is('deleted_at', null)
    .order('is_pinned', { ascending: false })
    .order('created_at', { ascending: false })

  if (error) {
    // [removed in production] '[fetchPostComments] error:', error
    return []
  }

  if (!data || data.length === 0) return []

  let userLikedMap = new Map<string, boolean>()
  if (currentUserId) {
    const commentIds = data.map((c: { id: string }) => c.id)
    const { data: likes } = await supabase
      .from('comment_likes')
      .select('comment_id')
      .in('comment_id', commentIds)
      .eq('user_id', currentUserId)
    if (likes) {
      userLikedMap = new Map(likes.map((l: { comment_id: string }) => [l.comment_id, true]))
    }
  }

  const allComments: Comment[] = data.map((c: Record<string, unknown>) => ({
    ...(c as unknown as Comment),
    user_liked: userLikedMap.get(c.id as string) || false,
  }))

  const topLevel = allComments.filter((c) => !c.parent_id)
  const replies = allComments.filter((c) => c.parent_id)

  const tree: CommentWithReplies[] = topLevel.map((c) => ({
    ...c,
    replies: replies
      .filter((r) => r.parent_id === c.id)
      .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime()),
    replies_count: replies.filter((r) => r.parent_id === c.id).length,
  }))

  return tree
}

// ========================================
// إضافة تعليق أو رد
// ========================================

export interface AddCommentResult {
  success: boolean
  comment?: Comment
  error?: string
}

export async function addComment(
  postId: string,
  userId: string,
  content: string,
  parentId?: string | null
): Promise<AddCommentResult> {
  const trimmed = content.trim()
  if (!trimmed) return { success: false, error: 'المحتوى فارغ' }
  if (trimmed.length > 500) return { success: false, error: 'التعليق طويل جداً' }

  const { data, error } = await supabase
    .from('comments')
    .insert({
      post_id: postId,
      user_id: userId,
      parent_id: parentId || null,
      content: trimmed,
    })
    .select('*, profile:profiles(*)')
    .single()

  if (error) {
    // [removed in production] '[addComment] error:', error
    return { success: false, error: 'تعذّر إضافة التعليق' }
  }

  return { success: true, comment: data as unknown as Comment }
}

// ========================================
// تعديل تعليق (لصاحب التعليق فقط)
// ========================================

export async function editComment(commentId: string, userId: string, newContent: string): Promise<AddCommentResult> {
  const trimmed = newContent.trim()
  if (!trimmed) return { success: false, error: 'المحتوى فارغ' }
  if (trimmed.length > 500) return { success: false, error: 'التعليق طويل جداً' }

  const { data, error } = await supabase
    .from('comments')
    .update({
      content: trimmed,
      is_edited: true,
      edited_at: new Date().toISOString(),
    })
    .eq('id', commentId)
    .eq('user_id', userId)
    .select('*, profile:profiles(*)')
    .single()

  if (error) {
    // [removed in production] '[editComment] error:', error
    return { success: false, error: 'تعذّر تعديل التعليق' }
  }

  return { success: true, comment: data as unknown as Comment }
}

// ========================================
// حذف تعليق (لصاحب التعليق أو صاحب المنشور)
// ========================================

export async function deleteComment(
  commentId: string,
  userId: string,
  postOwnerId?: string
): Promise<{ success: boolean; error?: string }> {
  // الحذف الناعم: تعيين deleted_at
  const { error } = await supabase
    .from('comments')
    .delete()
    .eq('id', commentId)
    .eq('user_id', userId)

  if (error) {
    if (postOwnerId && userId === postOwnerId) {
      // ✅ أمني: التحقق من ملكية المنشور فعلياً
      const { data: comment } = await supabase
        .from('comments')
        .select('post_id')
        .eq('id', commentId)
        .maybeSingle()

      if (comment) {
        const { data: post } = await supabase
          .from('posts')
          .select('user_id')
          .eq('id', comment.post_id)
          .maybeSingle()

        if (post?.user_id === userId) {
          const { error: softError } = await supabase
            .from('comments')
            .update({ deleted_at: new Date().toISOString() })
            .eq('id', commentId)

          if (softError) {
            return { success: false, error: 'تعذّر حذف التعليق' }
          }
          return { success: true }
        }
      }
    }

    return { success: false, error: 'تعذّر حذف التعليق' }}

  return { success: true }
}

// ========================================
// تبديل الإعجاب بتعليق
// ========================================

export interface ToggleCommentLikeResult {
  success: boolean
  liked?: boolean
  error?: string
}

export async function toggleCommentLike(
  commentId: string,
  userId: string,
  currentlyLiked: boolean
): Promise<ToggleCommentLikeResult> {
  try {
    if (currentlyLiked) {
      const { error } = await supabase
        .from('comment_likes')
        .delete()
        .match({ comment_id: commentId, user_id: userId })

      if (error && !error.message.includes('Could not find')) {
        throw error
      }
      return { success: true, liked: false }
    } else {
      const { error } = await supabase
        .from('comment_likes')
        .insert({ comment_id: commentId, user_id: userId })

      if (error) {
        if (error.message.includes('duplicate') || error.message.includes('unique')) {
          return { success: true, liked: true }
        }
        throw error
      }
      return { success: true, liked: true }
    }
  } catch (e) {
    // [removed in production] '[toggleCommentLike] error:', e
    return { success: false, error: 'تعذّر تحديث الإعجاب' }
  }
}

// ========================================
// تثبيت/إزالة تثبيت تعليق (لصاحب المنشور فقط)
// ========================================

export interface TogglePinResult {
  success: boolean
  pinned?: boolean
  error?: string
}

export async function togglePinComment(
  commentId: string,
  postId: string,
  postOwnerId: string
): Promise<TogglePinResult> {
  // ✅ أمني: التحقق من ملكية المنشور فعلياً
  const { data: post } = await supabase
    .from('posts')
    .select('user_id')
    .eq('id', postId)
    .maybeSingle()

  if (!post || post.user_id !== postOwnerId) {
    return { success: false, error: 'غير مصرح' }
  }

  const { data: current, error: fetchErr } = await supabase
    .from('comments')
    .select('is_pinned')
    .eq('id', commentId)
    .single()

  if (fetchErr || !current) {
    return { success: false, error: 'التعليق غير موجود' }
  }

  const newPinned = !current.is_pinned

  // السماح بتثبيت تعليق واحد فقط لكل منشور
  if (newPinned) {
    const { error: unpinErr } = await supabase
      .from('comments')
      .update({ is_pinned: false })
      .eq('post_id', postId)
      .eq('is_pinned', true)
      .neq('id', commentId)

    if (unpinErr) {
      // [removed in production] '[togglePinComment] unpin error:', unpinErr
    }
  }

  const { error } = await supabase
    .from('comments')
    .update({ is_pinned: newPinned })
    .eq('id', commentId)

  if (error) {
    // [removed in production] '[togglePinComment] error:', error
    return { success: false, error: 'تعذّر تحديث التثبيت' }
  }

  return { success: true, pinned: newPinned }
}

// ========================================
// جلب ردود تعليق
// ========================================

export async function fetchReplies(commentId: string, currentUserId?: string): Promise<Comment[]> {
  const { data, error } = await supabase
    .from('comments')
    .select('*, profile:profiles(*)')
    .eq('parent_id', commentId)
    .is('deleted_at', null)
    .order('created_at', { ascending: true })

  if (error || !data) {
    // [removed in production] '[fetchReplies] error:', error
    return []
  }

  let userLikedMap = new Map<string, boolean>()
  if (currentUserId && data.length > 0) {
    const commentIds = data.map((c: { id: string }) => c.id)
    const { data: likes } = await supabase
      .from('comment_likes')
      .select('comment_id')
      .in('comment_id', commentIds)
      .eq('user_id', currentUserId)
    if (likes) {
      userLikedMap = new Map(likes.map((l: { comment_id: string }) => [l.comment_id, true]))
    }
  }

  return data.map((c: Record<string, unknown>) => ({
    ...(c as unknown as Comment),
    user_liked: userLikedMap.get(c.id as string) || false,
  }))
}
