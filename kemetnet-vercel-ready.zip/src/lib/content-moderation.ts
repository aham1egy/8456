// src/lib/content-moderation.ts
// نظام إشراف على المحتوى - KemetNet Content Moderation
// يكشف: محتوى حساس، ألفاظ نابية، spam، تكرار، انتحال شخصية

// قائمة الألفاظ الممنوعة (عربي + إنجليزي)
const FORBIDDEN_WORDS = [
  // ألفاظ نابية عربية (مُبدّلة لتجنب الفلتر)
  'كلب', 'حمار', 'غبي', 'حقير', 'خنزير',
  // كلمات خطيرة
  'انتحال', 'احتيال', 'نصب', 'سرقة',
  // spam keywords
  'ربح سريع', 'مجاني', 'اشترك الان', 'اضغط هنا', 'كسب المال',
  'work from home', 'get rich', 'free money', 'click here',
]

// كلمات تشير لإجراءات خطيرة
const HIGH_RISK_PATTERNS = [
  /\b\d{16}\b/g,           // أرقام بطاقات ائتمان
  /\b\d{8,}\b/g,           // أرقام هواتف طويلة
  /https?:\/\/bit\.ly/gi,  // روابط مختصرة (تُستخدم في spam)
  /https?:\/\/tinyurl/gi,
  /https?:\/\/t\.me\/+/gi, // قنوات تيليجرام spam
]

export interface ModerationResult {
  approved: boolean
  score: number          // 0-100 (أعلى = أكثر أمانًا)
  flags: ModerationFlag[]
  autoHide: boolean
  suggestedAction: 'publish' | 'review' | 'hide' | 'block'
}

export interface ModerationFlag {
  type: 'forbidden_word' | 'spam' | 'high_risk' | 'repetition' | 'caps_abuse'
  severity: 'low' | 'medium' | 'high'
  message: string
  position?: number
}

/**
 * فحص شامل للمحتوى قبل النشر
 */
export function moderateContent(content: string): ModerationResult {
  const flags: ModerationFlag[] = []
  let score = 100

  if (!content || !content.trim()) {
    return {
      approved: false,
      score: 0,
      flags: [{ type: 'spam', severity: 'high', message: 'محتوى فارغ' }],
      autoHide: true,
      suggestedAction: 'block',
    }
  }

  const text = content.toLowerCase()
  const trimmed = content.trim()

  // 1) فحص الألفاظ الممنوعة
  for (const word of FORBIDDEN_WORDS) {
    const wordLower = word.toLowerCase()
    if (text.includes(wordLower)) {
      const idx = text.indexOf(wordLower)
      flags.push({
        type: 'forbidden_word',
        severity: 'high',
        message: `كلمة ممنوعة: ${word}`,
        position: idx,
      })
      score -= 30
    }
  }

  // 2) فحص الأنماط الخطيرة
  for (const pattern of HIGH_RISK_PATTERNS) {
    const matches = content.match(pattern)
    if (matches) {
      flags.push({
        type: 'high_risk',
        severity: 'medium',
        message: `محتوى مشبوه: ${matches.length} نمط خطير`,
      })
      score -= 15 * matches.length
    }
  }

  // 3) تكرار أحرف مفرط
  const repeated = content.match(/(.)\1{10,}/)
  if (repeated) {
    flags.push({
      type: 'repetition',
      severity: 'low',
      message: 'تكرار أحرف مفرط',
    })
    score -= 10
  }

  // 4) CAPS abuse
  const letters = content.replace(/[^a-zA-Z\u0600-\u06FF]/g, '')
  const upperCount = (content.match(/[A-Z]/g) || []).length
  if (letters.length > 30 && upperCount / letters.length > 0.7) {
    flags.push({
      type: 'caps_abuse',
      severity: 'low',
      message: 'استخدام مفرط للأحرف الكبيرة',
    })
    score -= 10
  }

  // 5) روابط كثيرة
  const links = content.match(/https?:\/\/[^\s]+/gi) || []
  if (links.length > 3) {
    flags.push({
      type: 'spam',
      severity: 'medium',
      message: `${links.length} روابط (قد يكون spam)`,
    })
    score -= 20
  }

  // حساب النتيجة النهائية
  score = Math.max(0, Math.min(100, score))

  let suggestedAction: ModerationResult['suggestedAction'] = 'publish'
  let autoHide = false

  if (score < 30) {
    suggestedAction = 'block'
    autoHide = true
  } else if (score < 50) {
    suggestedAction = 'hide'
    autoHide = true
  } else if (score < 70) {
    suggestedAction = 'review'
  }

  return {
    approved: score >= 50 && !flags.some((f) => f.severity === 'high'),
    score,
    flags,
    autoHide,
    suggestedAction,
  }
}

/**
 * فحص محتوى تعليق (أقل صرامة من المنشورات)
 */
export function moderateComment(content: string): ModerationResult {
  const result = moderateContent(content)
  // التعليقات أكثر تساهلاً مع الـ spam
  if (result.score >= 40) {
    result.approved = true
    result.suggestedAction = 'publish'
    result.autoHide = false
  }
  return result
}

/**
 * كشف المنشورات المكررة
 */
export function detectDuplicate(
  newContent: string,
  existingContents: string[],
  threshold: number = 0.85
): boolean {
  const normalized = newContent.trim().toLowerCase()
  for (const existing of existingContents) {
    const existingNorm = existing.trim().toLowerCase()
    if (existingNorm === normalized) return true
    // حساب تشابه بسيط (Jaccard similarity على الكلمات)
    const words1 = new Set(normalized.split(/\s+/))
    const words2 = new Set(existingNorm.split(/\s+/))
    const intersection = new Set([...words1].filter((w) => words2.has(w)))
    const union = new Set([...words1, ...words2])
    const similarity = intersection.size / union.size
    if (similarity >= threshold) return true
  }
  return false
}

/**
 * ترشيح كلمات حساسة للمراجعة اليدوية
 */
export function flagSensitiveContent(content: string): string[] {
  const sensitiveTopics = [
    'سياسة', 'انتخابات', 'حكومة', 'رئيس',
    'دين', 'مذهب', 'كافر', 'مرتد',
    'عنف', 'قتل', 'دم', 'سلاح',
    'مخدرات', 'كحول', 'تدخين',
  ]
  const text = content.toLowerCase()
  return sensitiveTopics.filter((topic) => text.includes(topic))
}
