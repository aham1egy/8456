import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}


// V-19: تسجيل آمن للأخطاء — لا يكشف تفاصيل في الإنتاج
export function secureError(context: string, error: unknown): void {
  if (process.env.NODE_ENV === 'production') {
    // في الإنتاج، سجل فقط السياق بدون تفاصيل
    // [removed in production] `[Error] ${context}`
  } else {
    // [removed in production] `[Error] ${context}:`, error
  }
}
