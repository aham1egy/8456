// src/lib/account.ts
// إدارة الحساب: تغيير اليوزرنيم + حذف الحساب

import { supabase } from './supabase/client'
import { validateUsername, checkUsernameAvailability } from './supabase/auth'

// ========================================
// تغيير اليوزرنيم
// ========================================

export interface ChangeUsernameResult {
  success: boolean
  error?: string
  newUsername?: string
}

export async function changeUsername(
  currentUserId: string,
  newUsername: string
): Promise<ChangeUsernameResult> {
  // 1. التحقق من صحة التنسيق
  const validation = validateUsername(newUsername)
  if (!validation.valid) {
    return { success: false, error: validation.error }
  }

  const normalized = newUsername.toLowerCase().trim()

  // 2. التحقق من أن اليوزرنيم مختلف عن الحالي
  const { data: currentProfile } = await supabase
    .from('profiles')
    .select('username')
    .eq('id', currentUserId)
    .maybeSingle()

  if (currentProfile?.username === normalized) {
    return { success: false, error: 'هذا هو يوزرنيمك الحالي' }
  }

  // 3. التحقق من التوفر
  const available = await checkUsernameAvailability(normalized)
  if (!available) {
    return { success: false, error: 'هذا اليوزرنيم محجوز، جرّب اسمًا آخر' }
  }

  // 4. تحديث profile
  const { error: profileErr } = await supabase
    .from('profiles')
    .update({
      username: normalized,
      updated_at: new Date().toISOString(),
    })
    .eq('id', currentUserId)

  if (profileErr) {
    // [removed in production] '[changeUsername] profile error:', profileErr
    return { success: false, error: 'تعذّر تحديث اليوزرنيم' }
  }

  // 5. تحديث بيانات المستخدم في auth (user_metadata)
  // ملاحظة: المستخدم يمكنه تحديث user_metadata الخاص به فقط
  const { error: authErr } = await supabase.auth.updateUser({
    data: { username: normalized },
  })

  if (authErr) {
    // نتابع لأن الـ profile هو المصدر الرئيسي
  }

  return { success: true, newUsername: normalized }
}

// ========================================
// حذف الحساب
// ========================================

export interface DeleteAccountResult {
  success: boolean
  error?: string
}

export async function deleteAccount(
  currentUserId: string,
  confirmationText: string
): Promise<DeleteAccountResult> {
  // 1. التحقق من نص التأكيد
  if (confirmationText.trim().toUpperCase() !== 'حذف') {
    return {
      success: false,
      error: 'يرجى كتابة "حذف" للتأكيد',
    }
  }

  try {
    // 2. استدعاء دالة SQL لحذف بيانات الحساب
    const { error: rpcError } = await supabase.rpc('delete_user_account', {
      target_user_id: currentUserId,
    })

    if (rpcError) {
      // [removed in production] '[deleteAccount] rpc error:', rpcError
      return { success: false, error: 'تعذّر حذف بيانات الحساب' }
    }

    // 3. محاولة حذف المستخدم من auth
    // ملاحظة: supabase-js لا يدعم حذف المستخدم من العميل مباشرة
    // لكن نحاول تسجيل الخروج على الأقل
    // الحذف الكامل من auth.users يتطلب service_role key (server-side)

    // 4. تسجيل الخروج
    await supabase.auth.signOut()

    return { success: true }
  } catch (e) {
    // [removed in production] '[deleteAccount] error:', e
    return { success: false, error: 'حدث خطأ أثناء حذف الحساب' }
  }
}

// ========================================
// التحقق من قوة كلمة المرور
// ========================================

export interface PasswordStrength {
  score: number // 0-4
  label: string
  color: string
  checks: {
    length: boolean
    hasLetter: boolean
    hasNumber: boolean
    hasSpecial: boolean
  }
}

export function checkPasswordStrength(password: string): PasswordStrength {
  const checks = {
    length: password.length >= 8,
    hasLetter: /[a-zA-Z]/.test(password),
    hasNumber: /[0-9]/.test(password),
    hasSpecial: /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password),
  }

  let score = 0
  if (checks.length) score++
  if (checks.hasLetter) score++
  if (checks.hasNumber) score++
  if (checks.hasSpecial) score++

  // إذا كان أقل من الحد الأدنى، اعتبره ضعيف جداً
  if (!checks.length || !checks.hasLetter || !checks.hasNumber) {
    score = Math.min(score, 1)
  }

  const labels = ['ضعيف جداً', 'ضعيف', 'متوسط', 'جيد', 'قوي']
  const colors = ['#ef4444', '#f97316', '#eab308', '#84cc16', '#22c55e']

  return {
    score,
    label: labels[score],
    color: colors[score],
    checks,
  }
}

// ========================================
// تغيير كلمة المرور
// ========================================

export interface ChangePasswordResult {
  success: boolean
  error?: string
}

export async function changePassword(
  currentPassword: string,
  newPassword: string
): Promise<ChangePasswordResult> {
  const strength = checkPasswordStrength(newPassword)
  if (strength.score < 2) {
    return {
      success: false,
      error: 'كلمة المرور ضعيفة. يجب أن تحتوي على 8 أحرف على الأقل، أحرف وأرقام',
    }
  }

  try {
    // ✅ أمني: التحقق من كلمة المرور الحالية قبل التحديث
    const { data: { user } } = await supabase.auth.getUser()
    if (!user?.email) {
      return { success: false, error: 'تعذّر التحقق من المستخدم' }
    }

    const { error: verifyError } = await supabase.auth.signInWithPassword({
      email: user.email,
      password: currentPassword,
    })

    if (verifyError) {
      return { success: false, error: 'كلمة المرور الحالية غير صحيحة' }
    }

    const { error } = await supabase.auth.updateUser({
      password: newPassword,
    })

    if (error) {
      return { success: false, error: 'تعذّر تحديث كلمة المرور' }
    }

    return { success: true }
  } catch (e) {
    // [removed in production] '[changePassword] error:', e instanceof Error ? e.message : 'unknown'
    return { success: false, error: 'حدث خطأ أثناء تحديث كلمة المرور' }
  }
}

