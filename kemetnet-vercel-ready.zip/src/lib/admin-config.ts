// src/lib/admin-config.ts
// إعدادات لوحة الإدارة - KemetNet
// نظام الأدوار والصلاحيات المتعدد المستويات

/**
 * الأدوار المتاحة في النظام
 */
export type UserRole = 'owner' | 'admin' | 'moderator' | 'custom' | 'user'

/**
 * الصلاحيات المتاحة (Permissions)
 * كل صلاحية تتحكم في عملية محددة
 */
export type Permission =
  | '*'                  // كل الصلاحيات (للمالك فقط)
  | 'manage_posts'       // حذف/تمييز/تثبيت المنشورات
  | 'manage_comments'    // حذف التعليقات
  | 'manage_users'       // توثيق/حذف/تقييد الحسابات
  | 'manage_reports'     // معالجة البلاغات
  | 'manage_verifications' // قبول/رفض طلبات التوثيق
  | 'manage_staff'       // إدارة الموظفين (إضافة/حذف/تعديل صلاحيات)
  | 'view_analytics'     // عرض الإحصائيات والتحليلات
  | 'manage_featured'    // تمييز المنشورات (feature)
  | 'pin_posts'          // تثبيت المنشورات
  | 'send_announcements'  // إرسال إشعارات للجميع
  | 'view_messages'      // عرض الرسائل (للمراقبة)

export const ALL_PERMISSIONS: { id: Permission; label: string; description: string; icon: string }[] = [
  { id: 'manage_posts', label: 'إدارة المنشورات', description: 'حذف، تمييز، تثبيت المنشورات', icon: '📝' },
  { id: 'manage_comments', label: 'إدارة التعليقات', description: 'حذف التعليقات المخالفة', icon: '💬' },
  { id: 'manage_users', label: 'إدارة الحسابات', description: 'توثيق، حذف، تقييد الحسابات', icon: '👤' },
  { id: 'manage_reports', label: 'معالجة البلاغات', description: 'مراجعة البلاغات واتخاذ إجراء', icon: '🚩' },
  { id: 'manage_verifications', label: 'طلبات التوثيق', description: 'قبول أو رفض طلبات التوثيق', icon: '✓' },
  { id: 'manage_staff', label: 'إدارة الفريق', description: 'إضافة/حذف الموظفين وتعديل صلاحياتهم', icon: '👥' },
  { id: 'view_analytics', label: 'عرض التحليلات', description: 'عرض إحصائيات التطبيق', icon: '📊' },
  { id: 'manage_featured', label: 'تمييز المنشورات', description: 'تمييز منشورات معينة لتظهر في الأعلى', icon: '⭐' },
  { id: 'pin_posts', label: 'تثبيت المنشورات', description: 'تثبيت منشورات في أعلى الخلاصة', icon: '📌' },
  { id: 'send_announcements', label: 'إرسال إعلانات', description: 'إرسال إشعارات لكل المستخدمين', icon: '📢' },
  { id: 'view_messages', label: 'مراقبة الرسائل', description: 'عرض الرسائل للأغراض الأمنية', icon: '👁' },
]

/**
 * الأدوار الافتراضية وصلاحياتها
 */
export const ROLE_PRESETS: Record<Exclude<UserRole, 'owner' | 'user' | 'custom'>, {
  label: string
  description: string
  permissions: Permission[]
}> = {
  admin: {
    label: 'مدير عام',
    description: 'صلاحيات شاملة (لا يدير الفريق)',
    permissions: [
      'manage_posts', 'manage_comments', 'manage_users',
      'manage_reports', 'manage_verifications', 'view_analytics',
      'manage_featured', 'pin_posts', 'send_announcements',
    ],
  },
  moderator: {
    label: 'مشرف',
    description: 'صلاحيات محدودة للإشراف على المحتوى',
    permissions: [
      'manage_posts', 'manage_comments', 'manage_reports',
    ],
  },
}

/**
 * قائمة اليوزرنيمات التي تُعتبر مالكة للتطبيق
 * (المالك الأساسي: kemetnet)
 */
export const OWNER_USERNAMES: string[] = [
  'kemetnet',
]

/**
 * قائمة اليوزرنيمات الإدارية الافتراضية (مع المالك)
 */
export const ADMIN_USERNAMES: string[] = [
  'kemetnet',          // المالك الأساسي
  'admin',
  'kemetnet_admin',
  'kemet_admin',
  'mohamed',
  // fallback: أي يوزرنيم يبدأ بـ kemetnet أو kemet_admin يُعتبر مالكًا
]

/**
 * فحص إذا كان المستخدم الحالي مالكًا (owner)
 */
export function isOwnerUsername(username: string | null | undefined): boolean {
  if (!username) return false
  return OWNER_USERNAMES.includes(username.toLowerCase().trim())
}

/**
 * فحص إذا كان المستخدم الحالي مديرًا (admin/owner/moderator)
 */
export function isAdminUsername(username: string | null | undefined): boolean {
  if (!username) return false
  return ADMIN_USERNAMES.includes(username.toLowerCase().trim())
}

/**
 * فحص إذا كان البروفايل يملك صلاحية الإدارة
 */
export function isAdminProfile(profile: {
  username?: string | null
  role?: UserRole | string | null
  is_verified?: boolean
  verified_type?: string | null
  is_admin?: boolean
} | null): boolean {
  if (!profile) return false
  // المالك
  if (isOwnerUsername(profile.username)) return true
  // role = owner أو admin
  if (profile.role === 'owner' || profile.role === 'admin') return true
  // is_admin = true
  if (profile.is_admin) return true
  // verified official
  if (profile.is_verified && profile.verified_type === 'official') return true
  return false
}

/**
 * فحص إذا كان البروفايل مالكًا (لإدارة الفريق)
 * يعتبر مالكًا إذا: username=kemetnet، role=owner، أو is_admin=true (fallback للمالك الذي لم يُحدّث username)
 */
export function isOwnerProfile(profile: {
  username?: string | null
  role?: UserRole | string | null
  is_admin?: boolean
} | null): boolean {
  if (!profile) return false
  // المالك الأساسي
  if (isOwnerUsername(profile.username)) return true
  // role = owner
  if (profile.role === 'owner') return true
  // fallback: is_admin = true (يُعتبر مالكًا إذا لم يوجد owner صريح)
  if (profile.is_admin === true) return true
  return false
}

/**
 * الحصول على صلاحيات دور معين
 */
export function getRolePermissions(role: UserRole): Permission[] {
  if (role === 'owner') return ['*']
  if (role === 'admin') return ROLE_PRESETS.admin.permissions
  if (role === 'moderator') return ROLE_PRESETS.moderator.permissions
  return []
}

/**
 * فحص إذا كان لديه صلاحية معينة
 * (يستخدم مع البيانات من staff_members)
 */
export function hasPermission(
  profile: { role?: UserRole | string | null; username?: string | null } | null,
  permissions: Permission[] | string[] | null,
  perm: Permission
): boolean {
  if (!profile) return false
  // المالك يملك كل الصلاحيات
  if (isOwnerUsername(profile.username)) return true
  if (profile.role === 'owner') return true
  // الأدمن العام
  if (profile.role === 'admin') {
    return perm === 'manage_staff' ? false : true
  }
  // التحقق من قائمة الصلاحيات
  if (!permissions || permissions.length === 0) return false
  return permissions.includes('*') || permissions.includes(perm)
}
