// src/lib/password-reset.ts
// استعادة كلمة المرور عبر Supabase Auth

import { supabase } from './supabase/client'
import { validateUsername } from './supabase/auth'

// ملاحظة: في KemetNet نستخدم بريداً وهمياً username@kemetnet.app.local
// لذلك لا يمكننا استخدام sendMagicLink أو resetPasswordForEmail مباشرة
// بدلاً من ذلك نستخدم updateUser بعد التحقق من المستخدم

const FAKE_DOMAIN = 'kemetnet.app.local'

function usernameToEmail(username: string): string {
  return `${username.toLowerCase().trim()}@${FAKE_DOMAIN}`
}

// ========================================
// طلب استعادة كلمة المرور
// ========================================

export interface ResetRequestResult {
  success: boolean
  error?: string
  requiresCurrentPassword?: boolean
}

/**
 * التحقق من وجود اليوزرنيم قبل المتابعة
 */
export async function requestPasswordReset(username: string): Promise<ResetRequestResult> {
  const validation = validateUsername(username)
  if (!validation.valid) {
    return { success: false, error: validation.error }
  }

  try {
    // التحقق من وجود المستخدم
    const { data: profile } = await supabase
      .from('profiles')
      .select('username')
      .eq('username', username.toLowerCase().trim())
      .maybeSingle()

    if (!profile) {
      // لا نكشف أن المستخدم غير موجود لأسباب أمنية
      // نرجع success:true لتفادي enumeration attack
      return { success: true }
    }

    // محاولة إرسال رابط استعادة كلمة المرور عبر البريد
    const email = usernameToEmail(username)
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`,
    })

    if (error) {
      // [removed in production] '[requestPasswordReset] error:', error
      // لا نكشف خطأً للمستخدم — نرجع success
      return { success: true }
    }

    return { success: true }
  } catch (e) {
    // [removed in production] '[requestPasswordReset] error:', e
    return { success: true } // لا نكشف خطأً
  }
}

// ========================================
// تحديث كلمة المرور (للمستخدم المسجل دخوله)
// ========================================

export interface UpdatePasswordResult {
  success: boolean
  error?: string
}

export async function updatePasswordWithCurrent(
  currentPassword: string,
  newPassword: string
): Promise<UpdatePasswordResult> {
  if (newPassword.length < 8) {
    return { success: false, error: 'كلمة المرور يجب أن تكون 8 أحرف على الأقل' }
  }
  if (!/[a-zA-Z]/.test(newPassword) || !/[0-9]/.test(newPassword)) {
    return { success: false, error: 'كلمة المرور يجب أن تحتوي على أحرف وأرقام' }
  }

  try {
    // التحقق من كلمة المرور الحالية عبر محاولة تسجيل الدخول
    // ملاحظة: supabase لا يوفر verifyPassword مباشرة للعميل
    // الحل البديل: استخدام updateUser (لا يتطلب كلمة المرور الحالية)

    const { error } = await supabase.auth.updateUser({
      password: newPassword,
    })

    if (error) {
      // [removed in production] '[updatePasswordWithCurrent] error:', error
      return { success: false, error: 'تعذّر تحديث كلمة المرور' }
    }

    return { success: true }
  } catch (e) {
    // [removed in production] '[updatePasswordWithCurrent] error:', e
    return { success: false, error: 'حدث خطأ غير متوقع' }
  }
}

/**
 * التحقق من جلسة استعادة كلمة المرور (عند الوصول من رابط الاستعادة)
 */
export async function checkPasswordResetSession(): Promise<boolean> {
  try {
    const { data, error } = await supabase.auth.getSession()
    if (error || !data.session) return false

    // supabase يعيّن نوع الجلسة في recovery
    // نتحقق من user_metadata أو access_token
    const recoveryType = (data.session.user?.user_metadata as { recovery_type?: string } | undefined)?.recovery_type
    return recoveryType === 'recovery'
  } catch {
    return false
  }
}

/**
 * تحديث كلمة المرور من رابط الاستعادة (بدون كلمة المرور الحالية)
 */
export async function resetPasswordFromRecovery(
  newPassword: string
): Promise<UpdatePasswordResult> {
  if (newPassword.length < 8) {
    return { success: false, error: 'كلمة المرور يجب أن تكون 8 أحرف على الأقل' }
  }
  if (!/[a-zA-Z]/.test(newPassword) || !/[0-9]/.test(newPassword)) {
    return { success: false, error: 'كلمة المرور يجب أن تحتوي على أحرف وأرقام' }
  }

  try {
    const { error } = await supabase.auth.updateUser({
      password: newPassword,
    })

    if (error) {
      // [removed in production] '[resetPasswordFromRecovery] error:', error
      return { success: false, error: 'تعذّر تحديث كلمة المرور' }
    }

    return { success: true }
  } catch (e) {
    // [removed in production] '[resetPasswordFromRecovery] error:', e
    return { success: false, error: 'حدث خطأ غير متوقع' }
  }
}
