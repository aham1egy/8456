// src/lib/security.ts
// طبقة أمان شاملة - KemetNet Security Layer
// - تنظيف المدخلات (XSS prevention)
// - rate limiting على العميل
// - فحص المحتوى
// - تشفير وفك تشفير بسيط

// ============= Sanitization =============

const XSS_PATTERNS = [
  /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,
  /<iframe\b[^>]*>.*?<\/iframe>/gi,
  /<object\b[^>]*>.*?<\/object>/gi,
  /<embed\b[^>]*>/gi,
  /javascript:/gi,
  /on\w+\s*=\s*"[^"]*"/gi,
  /on\w+\s*=\s*'[^']*'/gi,
  /on\w+\s*=\s*[^\s>]+/gi,
  /data:text\/html/gi,
  /vbscript:/gi,
]

/**
 * تنظيف نص من أكواد XSS الخطرة
 */
export function sanitizeText(input: string): string {
  if (!input || typeof input !== 'string') return ''
  let cleaned = input
  for (const pattern of XSS_PATTERNS) {
    cleaned = cleaned.replace(pattern, '')
  }
  // إزالة وسوم HTML ما عدا الآمنة
  cleaned = cleaned.replace(/<(?!\/?(b|i|u|s|strong|em|br|p|span)\b)[^>]*>/gi, '')
  return cleaned.trim()
}

/**
 * تنظيف المحتوى للعرض (تتضمن تحويل < > & لكيانات HTML)
 */
export function escapeHtml(input: string): string {
  if (!input) return ''
  return input
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;')
}

/**
 * فحص رابط URL — يرفض javascript: و data:text/html
 */
export function isSafeUrl(url: string): boolean {
  if (!url || typeof url !== 'string') return false
  try {
    const parsed = new URL(url)
    const safeProtocols = ['http:', 'https:']
    if (!safeProtocols.includes(parsed.protocol)) return false
    // رفض localhost/IPs الداخلية (SSRF prevention)
    const blocked = ['localhost', '127.0.0.1', '0.0.0.0', '169.254.169.254']
    if (blocked.some((b) => parsed.hostname.includes(b))) return false
    return true
  } catch {
    return false
  }
}

/**
 * فحص وتنظيف الوسوم (tags)
 */
export function sanitizeTags(tags: string[]): string[] {
  if (!Array.isArray(tags)) return []
  return tags
    .map((t) => String(t || '').trim().replace(/^#/, '').toLowerCase())
    .filter((t) => t.length >= 2 && t.length <= 30 && /^[a-z0-9_\u0600-\u06FF]+$/.test(t))
    .slice(0, 5)
}

// ============= Rate Limiting (client-side) =============

interface RateLimitEntry {
  count: number
  firstAttempt: number
  lastAttempt: number
}

const RATE_LIMIT_KEY = 'kemetnet-rate-limits'

function loadRateLimits(): Record<string, RateLimitEntry> {
  try {
    return JSON.parse(localStorage.getItem(RATE_LIMIT_KEY) || '{}')
  } catch {
    return {}
  }
}

function saveRateLimits(limits: Record<string, RateLimitEntry>): void {
  try {
    // الاحتفاظ بآخر 50 عملية فقط
    const entries = Object.entries(limits).slice(-50)
    localStorage.setItem(RATE_LIMIT_KEY, JSON.stringify(Object.fromEntries(entries)))
  } catch {
    // ignore
  }
}

export interface RateLimitResult {
  allowed: boolean
  remaining: number
  resetAt: number
}

/**
 * فحص rate limit لإجراء معين
 * @param action اسم الإجراء (مثلاً 'login', 'signup', 'post')
 * @param maxAttempts الحد الأقصى للمحاولات
 * @param windowMs النافذة الزمنية (ms)
 */
export function checkRateLimit(
  action: string,
  maxAttempts: number = 5,
  windowMs: number = 60_000
): RateLimitResult {
  const now = Date.now()
  const limits = loadRateLimits()
  const entry = limits[action]

  if (!entry || now - entry.firstAttempt > windowMs) {
    // نافذة جديدة
    limits[action] = { count: 1, firstAttempt: now, lastAttempt: now }
    saveRateLimits(limits)
    return { allowed: true, remaining: maxAttempts - 1, resetAt: now + windowMs }
  }

  if (entry.count >= maxAttempts) {
    // تجاوز الحد
    return {
      allowed: false,
      remaining: 0,
      resetAt: entry.firstAttempt + windowMs,
    }
  }

  entry.count++
  entry.lastAttempt = now
  saveRateLimits(limits)
  return {
    allowed: true,
    remaining: maxAttempts - entry.count,
    resetAt: entry.firstAttempt + windowMs,
  }
}

/**
 * إعادة تعيين rate limit لإجراء معين (بعد النجاح)
 */
export function resetRateLimit(action: string): void {
  const limits = loadRateLimits()
  delete limits[action]
  saveRateLimits(limits)
}

/**
 * انتظار حتى إعادة التعيين (للعرض في UI)
 */
export function getRateLimitResetTime(action: string): number {
  const limits = loadRateLimits()
  const entry = limits[action]
  if (!entry) return 0
  // حساب reset time بناءً على firstAttempt + windowMs
  // (نحتاج لتخزين windowMs أو استنتاجها — نستخدم آخر قيمة مستخدمة)
  // fallback: نعيد lastAttempt + 60 ثانية كتقدير
  return entry.lastAttempt + 60_000
}

// ============= Content Validation =============

export interface ValidationResult {
  valid: boolean
  errors: string[]
  warnings: string[]
}

/**
 * فحص شامل لمحتوى المنشور
 */
export function validatePostContent(content: string): ValidationResult {
  const errors: string[] = []
  const warnings: string[] = []

  if (!content || !content.trim()) {
    errors.push('المحتوى فارغ')
    return { valid: false, errors, warnings }
  }

  const trimmed = content.trim()

  // فحص الطول
  if (trimmed.length < 1) {
    errors.push('المحتوى قصير جدًا')
  } else if (trimmed.length > 2000) {
    errors.push('المحتوى يتجاوز 2000 حرف')
  }

  // فحص التكرار المفرط
  const repeatedMatch = trimmed.match(/(.)\1{10,}/)
  if (repeatedMatch) {
    warnings.push('يوجد تكرار مفرط لأحرف')
  }

  // فحص CAPS
  const letters = trimmed.replace(/[^a-zA-Z\u0600-\u06FF]/g, '')
  const upperCount = (trimmed.match(/[A-Z]/g) || []).length
  if (letters.length > 20 && upperCount / letters.length > 0.7) {
    warnings.push('استخدام مفرط للأحرف الكبيرة')
  }

  // فحص روابط كثيرة
  const links = trimmed.match(/https?:\/\/[^\s]+/gi) || []
  if (links.length > 3) {
    warnings.push('روابط كثيرة قد تُعتبر spam')
  }

  // فحص كلمات حساسة (تحذير فقط)
  const sensitiveWords = ['انتحال', 'احتيال', 'مخدرات', 'اسلحة']
  const found = sensitiveWords.filter((w) => trimmed.includes(w))
  if (found.length > 0) {
    warnings.push('محتوى قد يحتاج مراجعة')
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings,
  }
}

/**
 * فحص يوزرنيم
 */
export function validateUsername(username: string): ValidationResult {
  const errors: string[] = []
  const warnings: string[] = []

  if (!username || !username.trim()) {
    errors.push('اليوزرنيم فارغ')
    return { valid: false, errors, warnings }
  }

  const trimmed = username.trim().toLowerCase()

  if (trimmed.length < 3) {
    errors.push('اليوزرنيم يجب أن يكون 3 أحرف على الأقل')
  } else if (trimmed.length > 20) {
    errors.push('اليوزرنيم يجب ألا يتجاوز 20 حرف')
  }

  if (!/^[a-z0-9_]+$/.test(trimmed) && !/^[\u0600-\u06FFa-z0-9_]+$/.test(trimmed)) {
    errors.push('اليوزرنيم يجب أن يحتوي أحرف وأرقام فقط')
  }

  // كلمات محجوزة
  const reserved = ['admin', 'root', 'kemetnet', 'official', 'support', 'help', 'api']
  if (reserved.includes(trimmed)) {
    errors.push('هذا اليوزرنيم محجوز')
  }

  return { valid: errors.length === 0, errors, warnings }
}

// ============= Password Strength =============

export interface PasswordStrength {
  score: number  // 0-4
  label: string
  color: string
  suggestions: string[]
}

export function checkPasswordStrength(password: string): PasswordStrength {
  if (!password) return { score: 0, label: 'فارغ', color: '#6B7280', suggestions: [] }

  let score = 0
  const suggestions: string[] = []

  if (password.length >= 8) score++
  else suggestions.push('استخدم 8 أحرف على الأقل')

  if (/[a-z]/.test(password) && /[A-Z]/.test(password)) score++
  else suggestions.push('امزج بين الأحرف الكبيرة والصغيرة')

  if (/\d/.test(password)) score++
  else suggestions.push('أضف أرقامًا')

  if (/[^a-zA-Z0-9]/.test(password)) score++
  else suggestions.push('أضف رموزًا خاصة (!@#$)')

  // عقوبات
  if (/(.)\1{2,}/.test(password)) {
    score = Math.max(0, score - 1)
    suggestions.push('تجنب تكرار الأحرف')
  }

  const labels = ['ضعيف جدًا', 'ضعيف', 'متوسط', 'جيد', 'قوي']
  const colors = ['#EF4444', '#F97316', '#EAB308', '#84CC16', '#22C55E']

  return {
    score,
    label: labels[score],
    color: colors[score],
    suggestions,
  }
}

// ============= Session Security =============

const SESSION_TIMEOUT = 30 * 60 * 1000  // 30 دقيقة

export function checkSessionTimeout(): boolean {
  const lastActivity = localStorage.getItem('kemetnet-last-activity')
  if (!lastActivity) return false
  const elapsed = Date.now() - parseInt(lastActivity, 10)
  return elapsed > SESSION_TIMEOUT
}

export function updateSessionActivity(): void {
  localStorage.setItem('kemetnet-last-activity', Date.now().toString())
}

// تحديث النشاط عند أي تفاعل
if (typeof window !== 'undefined') {
  const events = ['click', 'keydown', 'touchstart', 'scroll']
  let throttleTimer: ReturnType<typeof setTimeout> | null = null
  events.forEach((event) => {
    window.addEventListener(event, () => {
      if (throttleTimer) return
      throttleTimer = setTimeout(() => {
        updateSessionActivity()
        throttleTimer = null
      }, 10_000)  // تحديث كل 10 ثواني فقط
    }, { passive: true })
  })
}

// ============= Hash Utility (للتحقق من سلامة البيانات) =============

export async function hashString(input: string): Promise<string> {
  if (typeof crypto === 'undefined' || !crypto.subtle) {
    // fallback بسيط
    let hash = 0
    for (let i = 0; i < input.length; i++) {
      hash = ((hash << 5) - hash) + input.charCodeAt(i)
      hash |= 0
    }
    return Math.abs(hash).toString(16)
  }
  const encoder = new TextEncoder()
  const data = encoder.encode(input)
  const hashBuffer = await crypto.subtle.digest('SHA-256', data)
  return Array.from(new Uint8Array(hashBuffer))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('')
}
