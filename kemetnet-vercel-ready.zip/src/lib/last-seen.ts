// src/lib/last-seen.ts
// تنسيق وقت آخر ظهور (Last Seen) للمستخدمين

import type { Profile } from './supabase/client'

/**
 * تنسيق وقت آخر ظهور بالعربية
 */
export function formatLastSeen(dateStr: string | null): string {
  if (!dateStr) return 'آخر ظهور غير متاح'

  const date = new Date(dateStr)
  const now = new Date()
  const diffMs = now.getTime() - date.getTime()
  const diffSec = Math.floor(diffMs / 1000)

  if (diffSec < 60) return 'آخر ظهور: الآن'

  const diffMin = Math.floor(diffSec / 60)
  if (diffMin < 60) return `آخر ظهور: قبل ${diffMin} دقيقة`

  const diffHour = Math.floor(diffMin / 60)
  if (diffHour < 24) return `آخر ظهور: قبل ${diffHour} ساعة`

  const diffDay = Math.floor(diffHour / 24)
  if (diffDay < 7) return `آخر ظهور: قبل ${diffDay} يوم`

  const diffWeek = Math.floor(diffDay / 7)
  if (diffWeek < 4) return `آخر ظهور: قبل ${diffWeek} أسبوع`

  const diffMonth = Math.floor(diffDay / 30)
  if (diffMonth < 12) return `آخر ظهور: قبل ${diffMonth} شهر`

  const diffYear = Math.floor(diffDay / 365)
  return `آخر ظهور: قبل ${diffYear} سنة`
}

/**
 * تنسيق مختصر للوقت النسبي
 */
export function formatTimeAgo(dateStr: string | null): string {
  if (!dateStr) return ''

  const date = new Date(dateStr)
  const now = new Date()
  const diffSec = Math.floor((now.getTime() - date.getTime()) / 1000)

  if (diffSec < 60) return 'الآن'
  if (diffSec < 3600) return `قبل ${Math.floor(diffSec / 60)} د`
  if (diffSec < 86400) return `قبل ${Math.floor(diffSec / 3600)} س`
  if (diffSec < 604800) return `قبل ${Math.floor(diffSec / 86400)} ي`
  if (diffSec < 2592000) return `قبل ${Math.floor(diffSec / 604800)} أ`
  if (diffSec < 31536000) return `قبل ${Math.floor(diffSec / 2592000)} ش`
  return `قبل ${Math.floor(diffSec / 31536000)} س`
}

/**
 * تحديث last_seen للمستخدم الحالي
 */
export async function updateMyLastSeen(userId: string): Promise<void> {
  try {
    const { supabase } = await import('./supabase/client')
    await supabase.rpc('update_last_seen', { target_user_id: userId })
  } catch (e) {
    // لا نريد إزعاج المستخدم بأخطاء هذا الـ update
  }
}

/**
 * هل يجب إظهار آخر ظهور لهذا المستخدم؟
 * يعتمد على إعداداته الشخصية + إعدادات المستخدم الحالي
 */
export function shouldShowLastSeen(targetProfile: Profile): boolean {
  return targetProfile.show_last_seen !== false && targetProfile.last_seen !== null
}

/**
 * هل يجب إظهار حالة الاتصال؟
 */
export function shouldShowOnlineStatus(targetProfile: Profile): boolean {
  return targetProfile.show_online_status !== false
}
