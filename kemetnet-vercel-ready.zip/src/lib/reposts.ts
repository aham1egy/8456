// src/lib/reposts.ts
// نظام إعادة النشر + المنشورات المحفوظة

import { supabase, type Post } from './supabase/client'

// ========================================
// إعادة النشر (Repost)
// ========================================

export interface RepostResult {
  success: boolean
  error?: string
  postId?: string
}

/**
 * إعادة نشر منشور (مع أو بدون تعليق)
 */
export async function repostPost(
  userId: string,
  originalPostId: string,
  content?: string
): Promise<RepostResult> {
  try {
    // التحقق من عدم إعادة نشر منشور نفسه
    const { data: original } = await supabase
      .from('posts')
      .select('user_id')
      .eq('id', originalPostId)
      .maybeSingle()

    if (!original) {
      return { success: false, error: 'المنشور الأصلي غير موجود' }
    }

    if (original.user_id === userId) {
      return { success: false, error: 'لا يمكنك إعادة نشر منشورك' }
    }

    // التحقق من عدم إعادة النشر مسبقاً
    const { data: existing } = await supabase
      .from('posts')
      .select('id')
      .eq('user_id', userId)
      .eq('repost_of', originalPostId)
      .maybeSingle()

    if (existing) {
      return { success: false, error: 'لقد أعدت نشر هذا المنشور مسبقاً' }
    }

    // إنشاء المنشور المعاد
    const { data, error } = await supabase
      .from('posts')
      .insert({
        user_id: userId,
        content: content?.trim() || '',
        repost_of: originalPostId,
        category: 'thoughts',
      })
      .select('id')
      .single()

    if (error) {
      // [removed in production] '[repostPost] error:', error
      return { success: false, error: 'تعذّر إعادة النشر' }
    }

    return { success: true, postId: data.id }
  } catch (e) {
    // [removed in production] '[repostPost] error:', e
    return { success: false, error: 'حدث خطأ غير متوقع' }
  }
}

/**
 * إلغاء إعادة النشر (حذف المنشور المعاد)
 */
export async function undoRepost(
  userId: string,
  originalPostId: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const { error } = await supabase
      .from('posts')
      .delete()
      .eq('user_id', userId)
      .eq('repost_of', originalPostId)

    if (error) {
      // [removed in production] '[undoRepost] error:', error
      return { success: false, error: 'تعذّر إلغاء إعادة النشر' }
    }

    return { success: true }
  } catch (e) {
    // [removed in production] '[undoRepost] error:', e
    return { success: false, error: 'حدث خطأ' }
  }
}

/**
 * التحقق مما إذا كان المستخدم قد أعاد نشر منشور
 */
export async function hasReposted(
  userId: string,
  originalPostId: string
): Promise<boolean> {
  try {
    const { data } = await supabase
      .from('posts')
      .select('id')
      .eq('user_id', userId)
      .eq('repost_of', originalPostId)
      .maybeSingle()

    return !!data
  } catch (e) {
    // [removed in production] '[hasReposted] error:', e
    return false
  }
}

// ========================================
// المنشورات المحفوظة (Saved Posts)
// ========================================

export interface SaveResult {
  success: boolean
  error?: string
  saved?: boolean
}

/**
 * حفظ منشور
 */
export async function savePost(userId: string, postId: string): Promise<SaveResult> {
  try {
    const { error } = await supabase
      .from('saved_posts')
      .insert({
        user_id: userId,
        post_id: postId,
      })

    if (error) {
      if (error.message.includes('duplicate') || error.message.includes('unique') || error.code === '23505') {
        return { success: true, saved: true }
      }
      // [removed in production] '[savePost] error:', error
      return { success: false, error: 'تعذّر حفظ المنشور' }
    }

    return { success: true, saved: true }
  } catch (e) {
    // [removed in production] '[savePost] error:', e
    return { success: false, error: 'حدث خطأ' }
  }
}

/**
 * إلغاء حفظ منشور
 */
export async function unsavePost(userId: string, postId: string): Promise<SaveResult> {
  try {
    const { error } = await supabase
      .from('saved_posts')
      .delete()
      .eq('user_id', userId)
      .eq('post_id', postId)

    if (error) {
      // [removed in production] '[unsavePost] error:', error
      return { success: false, error: 'تعذّر إلغاء الحفظ' }
    }

    return { success: true, saved: false }
  } catch (e) {
    // [removed in production] '[unsavePost] error:', e
    return { success: false, error: 'حدث خطأ' }
  }
}

/**
 * تبديل حالة الحفظ
 */
export async function toggleSavePost(
  userId: string,
  postId: string,
  currentlySaved: boolean
): Promise<SaveResult> {
  return currentlySaved ? unsavePost(userId, postId) : savePost(userId, postId)
}

/**
 * جلب المنشورات المحفوظة
 */
export async function fetchSavedPosts(userId: string): Promise<Post[]> {
  try {
    // استعلام أبسط: أولاً جلب IDs، ثم جلب المنشورات
    const { data: savedData, error: savedErr } = await supabase
      .from('saved_posts')
      .select('post_id')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })

    if (savedErr || !savedData || savedData.length === 0) {
      return []
    }

    const postIds = savedData.map((s: { post_id: string }) => s.post_id)

    const { data: posts, error: postsErr } = await supabase
      .from('posts')
      .select('*, profile:profiles(*)')
      .in('id', postIds)

    if (postsErr || !posts) {
      // [removed in production] '[fetchSavedPosts] posts error:', postsErr
      return []
    }

    // ترتيب بنفس ترتيب saved_posts
    const orderedMap = new Map(posts.map((p: Post) => [p.id, p]))
    return postIds.map((id) => orderedMap.get(id)).filter((p): p is Post => !!p)
  } catch (e) {
    // [removed in production] '[fetchSavedPosts] error:', e
    return []
  }
}

/**
 * جلب قائمة IDs المنشورات المحفوظة (للتصفية السريعة)
 */
export async function fetchSavedPostIds(userId: string): Promise<Set<string>> {
  try {
    const { data, error } = await supabase
      .from('saved_posts')
      .select('post_id')
      .eq('user_id', userId)

    if (error || !data) {
      return new Set()
    }

    return new Set(data.map((s: { post_id: string }) => s.post_id))
  } catch (e) {
    // [removed in production] '[fetchSavedPostIds] error:', e
    return new Set()
  }
}
