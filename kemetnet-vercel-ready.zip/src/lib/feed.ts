// src/lib/feed.ts
// خلاصة مخصصة (For You) + خلاصة المتابعين

import { supabase, type Post, type Profile } from './supabase/client'
import { fetchBlockedUserIds } from './moderation'

// ========================================
// أنواع البيانات
// ========================================

export type FeedType = 'for-you' | 'following' | 'trending'

export interface FeedResult {
  posts: Post[]
  hasMore: boolean
}

// ========================================
// خلاصة "لك" (For You) — مخصصة حسب النشاط
// ========================================

export async function fetchForYouFeed(
  userId: string,
  limit = 20,
  offset = 0
): Promise<FeedResult> {
  try {
    // 1. جلب قائمة المستخدمين المحجوبين (للتصفية)
    const blockedIds = await fetchBlockedUserIds(userId)

    // 2. جلب الفئات التي يتفاعل معها المستخدم أكثر
    // (بناءً على منشورات أعجب بها + علّق عليها + حفظها)
    const [likedPosts, savedPosts] = await Promise.all([
      supabase
        .from('likes')
        .select('post_id')
        .eq('user_id', userId)
        .limit(100),
      supabase
        .from('saved_posts')
        .select('post_id')
        .eq('user_id', userId)
        .limit(100),
    ])

    const interactedPostIds = new Set<string>([
      ...(likedPosts.data || []).map((l: { post_id: string }) => l.post_id),
      ...(savedPosts.data || []).map((s: { post_id: string }) => s.post_id),
    ])

    // 3. جلب فئات المنشورات التي تفاعل معها
    let preferredCategories: string[] = []
    if (interactedPostIds.size > 0) {
      const { data: interactedPosts } = await supabase
        .from('posts')
        .select('category')
        .in('id', Array.from(interactedPostIds))

      if (interactedPosts && interactedPosts.length > 0) {
        const categoryCount: Record<string, number> = {}
        interactedPosts.forEach((p: { category: string }) => {
          categoryCount[p.category] = (categoryCount[p.category] || 0) + 1
        })
        preferredCategories = Object.entries(categoryCount)
          .sort((a, b) => b[1] - a[1])
          .slice(0, 3)
          .map(([cat]) => cat)
      }
    }

    // 4. جلب المستخدمين الذين يتابعهم
    const { data: following } = await supabase
      .from('follows')
      .select('following_id')
      .eq('follower_id', userId)

    const followingIds = (following || []).map((f: { following_id: string }) => f.following_id)
    // أضف المستخدم نفسه ليشمل منشوراته
    followingIds.push(userId)

    // 5. بناء الاستعلام
    let query = supabase
      .from('posts')
      .select('*, profile:profiles(*)')
      .is('repost_of', null) // لا تشمل إعادة النشر

    // تصفية المستخدمين المحجوبين
    if (blockedIds.size > 0) {
      query = query.not('user_id', 'in', Array.from(blockedIds))
    }

    // 6. ترتيب ذكي:
    // - أولوية للفئات المفضلة
    // - أولوية لمنشورات المتابعين
    // - ترتيب حسب التفاعل (إعجابات + تعليقات) + الحداثة
    if (preferredCategories.length > 0) {
      // جلب منشورات الفئات المفضلة أولاً
      const { data: preferredData, error: preferredErr } = await query
        .in('category', preferredCategories)
        .order('likes_count', { ascending: false })
        .range(offset, offset + limit - 1)

      if (preferredErr) throw preferredErr

      // إذا لم نحصل على ما يكفي، جلب المزيد من منشورات عامة
      let allPosts = preferredData || []
      if (allPosts.length < limit) {
        const remaining = limit - allPosts.length
        const excludeIds = allPosts.map((p) => p.id)
        let fallbackQuery = supabase
          .from('posts')
          .select('*, profile:profiles(*)')
          .is('repost_of', null)
          .order('likes_count', { ascending: false })
          .range(0, remaining - 1)

        if (excludeIds.length > 0) {
          fallbackQuery = fallbackQuery.not('id', 'in', `(${excludeIds.join(',')})`)
        }
        if (blockedIds.size > 0) {
          fallbackQuery = fallbackQuery.not('user_id', 'in', `(${Array.from(blockedIds).join(',')})`)
        }

        const { data: fallbackData } = await fallbackQuery
        allPosts = [...allPosts, ...(fallbackData || [])]
      }

      // ترتيب نهائي: مزج المتابعين مع غيرهم
      const sorted = allPosts.sort((a, b) => {
        const aFollowing = followingIds.includes(a.user_id) ? 1 : 0
        const bFollowing = followingIds.includes(b.user_id) ? 1 : 0
        if (aFollowing !== bFollowing) return bFollowing - aFollowing
        // ثم بالحداثة
        return new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
      })

      return {
        posts: sorted.slice(0, limit),
        hasMore: allPosts.length === limit,
      }
    }

    // إذا لم تكن هناك فئات مفضلة، استخدم الترتيب العام بالتفاعل
    const { data, error } = await query
      .order('likes_count', { ascending: false })
      .range(offset, offset + limit - 1)

    if (error) throw error

    // ترتيب: المتابعين أولاً ثم بالتفاعل
    const sorted = (data || []).sort((a, b) => {
      const aFollowing = followingIds.includes(a.user_id) ? 1 : 0
      const bFollowing = followingIds.includes(b.user_id) ? 1 : 0
      if (aFollowing !== bFollowing) return bFollowing - aFollowing
      return new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
    })

    return {
      posts: sorted,
      hasMore: data?.length === limit,
    }
  } catch (e) {
    // [removed in production] '[fetchForYouFeed] error:', e
    return { posts: [], hasMore: false }
  }
}

// ========================================
// خلاصة المتابعين (Following)
// ========================================

export async function fetchFollowingFeed(
  userId: string,
  limit = 20,
  offset = 0
): Promise<FeedResult> {
  try {
    const blockedIds = await fetchBlockedUserIds(userId)

    // جلب قائمة المتابعين
    const { data: following } = await supabase
      .from('follows')
      .select('following_id')
      .eq('follower_id', userId)

    const followingIds = (following || []).map((f: { following_id: string }) => f.following_id)

    if (followingIds.length === 0) {
      return { posts: [], hasMore: false }
    }

    let query = supabase
      .from('posts')
      .select('*, profile:profiles(*)')
      .in('user_id', followingIds)
      .is('repost_of', null)
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1)

    const { data, error } = await query

    if (error) throw error

    // تصفية المحجوبين
    const filtered = (data || []).filter(
      (p) => !blockedIds.has(p.user_id)
    )

    return {
      posts: filtered,
      hasMore: data?.length === limit,
    }
  } catch (e) {
    // [removed in production] '[fetchFollowingFeed] error:', e
    return { posts: [], hasMore: false }
  }
}

// ========================================
// خلاصة الرائج (Trending)
// ========================================

export async function fetchTrendingFeed(
  userId: string,
  limit = 20,
  offset = 0
): Promise<FeedResult> {
  try {
    const blockedIds = await fetchBlockedUserIds(userId)

    // منشورات آخر 24 ساعة مرتبة بالتفاعل
    const yesterday = new Date()
    yesterday.setDate(yesterday.getDate() - 1)

    let query = supabase
      .from('posts')
      .select('*, profile:profiles(*)')
      .is('repost_of', null)
      .gte('created_at', yesterday.toISOString())
      .order('likes_count', { ascending: false })
      .range(offset, offset + limit - 1)

    const { data, error } = await query

    if (error) throw error

    const filtered = (data || []).filter(
      (p) => !blockedIds.has(p.user_id)
    )

    return {
      posts: filtered,
      hasMore: data?.length === limit,
    }
  } catch (e) {
    // [removed in production] '[fetchTrendingFeed] error:', e
    return { posts: [], hasMore: false }
  }
}

// ========================================
// دالة موحدة لجلب الخلاصة
// ========================================

export async function fetchFeed(
  type: FeedType,
  userId: string,
  limit = 20,
  offset = 0
): Promise<FeedResult> {
  switch (type) {
    case 'for-you':
      return fetchForYouFeed(userId, limit, offset)
    case 'following':
      return fetchFollowingFeed(userId, limit, offset)
    case 'trending':
      return fetchTrendingFeed(userId, limit, offset)
    default:
      return fetchForYouFeed(userId, limit, offset)
  }
}
