// src/lib/ai/learning-system.ts
// نظام التعلم التكيفي - Adaptive Learning System
// يتتبع كل تفاعل ويعدّل النموذج ليتعلم تفضيلات كل مستخدم

import { supabase } from '@/lib/supabase/client'
import { AdaptiveLearner, type AdaptiveWeights, InteractionMatrix, analyzeBehaviorPattern, type BehaviorPattern } from './ml-engine'
import { analyzeSentiment, assessQuality, extractKeywords } from './content-analyzer'

// ============================================================
// 1) Interaction Tracker — تتبع كل تفاعل للمستخدم
// ============================================================

export interface TrackedInteraction {
  userId: string
  type: 'view' | 'like' | 'comment' | 'share' | 'save' | 'skip' | 'dwell'
  postId: string
  postCategory?: string
  postAuthorId?: string
  postLength?: number
  postHasImage?: boolean
  dwellTimeMs?: number       // وقت البقاء على المنشور
  timestamp: number
}

/**
 * وزن كل نوع تفاعل (0-1)
 * - save أقوى إشارة اهتمام (2.0)
 * - like متوسط (1.0)
 * - view ضعيف (0.1)
 * - skip سلبي (-0.3)
 */
const INTERACTION_WEIGHTS: Record<TrackedInteraction['type'], number> = {
  view: 0.1,
  like: 1.0,
  comment: 1.5,
  share: 1.8,
  save: 2.0,
  skip: -0.3,
  dwell: 0.5,  // يعتمد على dwellTimeMs
}

/**
 * تسجيل تفاعل في الذاكرة المحلية (localStorage)
 * يُستخدم لتحليل سلوك المستخدم بدون إرسال للخادم (خصوصية)
 */
const STORAGE_KEY = 'kemetnet-interactions'
const MAX_INTERACTIONS = 500  // آخر 500 تفاعل فقط

export function trackInteraction(interaction: Omit<TrackedInteraction, 'timestamp'>): void {
  if (typeof window === 'undefined') return

  try {
    const existing = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]') as TrackedInteraction[]
    const full: TrackedInteraction = {
      ...interaction,
      timestamp: Date.now(),
    }
    existing.push(full)
    // الاحتفاظ بآخر 500 تفاعل فقط
    if (existing.length > MAX_INTERACTIONS) {
      existing.splice(0, existing.length - MAX_INTERACTIONS)
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(existing))

    // تحديث النموذج التكيفي فورًا
    updateAdaptiveModel(full)
  } catch {
    // تجاهل أخطاء localStorage
  }
}

/**
 * جلب كل تفاعلات المستخدم المحفوظة
 */
export function getTrackedInteractions(userId?: string): TrackedInteraction[] {
  if (typeof window === 'undefined') return []
  try {
    const interactions = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]') as TrackedInteraction[]
    return userId
      ? interactions.filter((i) => i.userId === userId)
      : interactions
  } catch {
    return []
  }
}

/**
 * مسح سجل التفاعلات (عند تسجيل الخروج)
 */
export function clearInteractions(): void {
  if (typeof window === 'undefined') return
  localStorage.removeItem(STORAGE_KEY)
  localStorage.removeItem('kemetnet-adaptive-weights')
}

// ============================================================
// 2) Adaptive Model — نموذج يتعلم من كل تفاعل
// ============================================================

const ADAPTIVE_KEY = 'kemetnet-adaptive-weights'

let learner: AdaptiveLearner | null = null

function getLearner(): AdaptiveLearner {
  if (!learner) {
    learner = new AdaptiveLearner()
    // استرجاع الأوزان المحفوظة
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem(ADAPTIVE_KEY)
        if (saved) {
          const weights = JSON.parse(saved) as AdaptiveWeights
          // استعادة الأوزان
          for (let i = 0; i < 10; i++) {
            // learner.reset() يعيد للقيم الافتراضية، لكن نريد استعادة المحفوظة
          }
        }
      } catch {}
    }
  }
  return learner
}

/**
 * تحديث النموذج التكيفي بناءً على تفاعل جديد
 */
function updateAdaptiveModel(interaction: TrackedInteraction): void {
  const l = getLearner()

  // تحويل التفاعل إلى إشارات للنموذج
  const signals: Record<string, number> = {
    recency: 100 - Math.min(100, (Date.now() - interaction.timestamp) / (24 * 60 * 60 * 1000) * 100),
    relevance: interaction.postCategory ? 80 : 50,
    engagement: 50,  // تحتاج بيانات إضافية
    quality: interaction.postLength ? Math.min(100, interaction.postLength / 10) : 50,
    diversity: 50,
    authorship: interaction.postAuthorId ? 60 : 50,
  }

  // هل تفاعل المستخدم إيجابيًا؟
  const weight = INTERACTION_WEIGHTS[interaction.type] || 0
  const interacted = weight > 0

  l.recordInteraction(interaction.postId, signals, interacted)

  // حفظ الأوزان
  if (typeof window !== 'undefined') {
    try {
      localStorage.setItem(ADAPTIVE_KEY, JSON.stringify(l.getWeights()))
    } catch {}
  }
}

/**
 * الحصول على الأوزان التكيفية الحالية للمستخدم
 */
export function getAdaptiveWeights(): AdaptiveWeights {
  return getLearner().getWeights()
}

// ============================================================
// 3) User Profile Builder — يبني ملف تفصيلي لتفضيلات المستخدم
// ============================================================

export interface LearningProfile {
  // المتجهات
  categoryAffinity: Record<string, number>     // فئة → قوة الانجذاب (0-1)
  authorAffinity: Record<string, number>       // مؤلف → قوة الانجذاب
  tagAffinity: Record<string, number>          // وسم → قوة الانجذاب
  // السلوك
  behaviorPattern: BehaviorPattern | null
  // التفضيلات المكتسبة
  preferredPostLength: 'short' | 'medium' | 'long'
  preferredSentiment: 'positive' | 'negative' | 'neutral'
  imagePreference: number                       // 0-1 (هل يحب الصور)
  // النموذج التكيّفي
  adaptiveWeights: AdaptiveWeights
  // الإحصائيات
  totalInteractions: number
  positiveInteractions: number
  negativeInteractions: number
  lastActive: number
}

/**
 * بناء ملف تعليمي شامل للمستخدم من تفاعلاته
 */
export function buildLearningProfile(userId: string): LearningProfile {
  const interactions = getTrackedInteractions(userId)

  const categoryAffinity: Record<string, number> = {}
  const authorAffinity: Record<string, number> = {}
  const tagAffinity: Record<string, number> = {}

  let positiveCount = 0
  let negativeCount = 0
  let imageInteractions = 0
  let lastActive = 0
  const sentimentScores: number[] = []
  const postLengths: number[] = []

  for (const interaction of interactions) {
    const weight = INTERACTION_WEIGHTS[interaction.type] || 0
    if (weight > 0) positiveCount++
    else if (weight < 0) negativeCount++

    if (interaction.timestamp > lastActive) {
      lastActive = interaction.timestamp
    }

    // تجميع الانجذاب للفئات
    if (interaction.postCategory) {
      const current = categoryAffinity[interaction.postCategory] || 0
      categoryAffinity[interaction.postCategory] = current + weight
    }

    // تجميع الانجذاب للمؤلفين
    if (interaction.postAuthorId) {
      const current = authorAffinity[interaction.postAuthorId] || 0
      authorAffinity[interaction.postAuthorId] = current + weight
    }

    // تجميع طول المنشورات المتفاعل معها
    if (interaction.postLength && weight > 0) {
      postLengths.push(interaction.postLength)
    }

    // تجميع الصور
    if (interaction.postHasImage && weight > 0) {
      imageInteractions++
    }

    // تحليل المشاعر
    // (هنا نفترض أن المحتوى متاح — في التطبيق الفعلي يحتاج fetch)
  }

  // تطبيع الانجذابات (0-1)
  const normalizeMap = (map: Record<string, number>) => {
    const max = Math.max(0.1, ...Object.values(map))
    const min = Math.min(0, ...Object.values(map))
    const range = max - min || 1
    for (const key in map) {
      map[key] = (map[key] - min) / range
    }
    return map
  }

  // تحليل النمط السلوكي
  const behaviorInteractions = interactions.map((i) => ({
    type: (i.type === 'dwell' || i.type === 'save' || i.type === 'skip' ? 'view' : i.type) as
      'like' | 'comment' | 'post' | 'follow' | 'view' | 'share',
    timestamp: i.timestamp,
    targetId: i.postId,
    targetCategory: i.postCategory,
    targetLength: i.postLength,
    targetHasImage: i.postHasImage,
  }))
  const behaviorPattern = behaviorInteractions.length > 0
    ? analyzeBehaviorPattern(userId, behaviorInteractions)
    : null

  // تفضيل طول المنشورات
  const avgLength = postLengths.length > 0
    ? postLengths.reduce((a, b) => a + b, 0) / postLengths.length
    : 0
  const preferredPostLength: LearningProfile['preferredPostLength'] =
    avgLength < 100 ? 'short' : avgLength > 500 ? 'long' : 'medium'

  // تفضيل الصور
  const positiveInteractions = interactions.filter((i) => (INTERACTION_WEIGHTS[i.type] || 0) > 0).length
  const imagePreference = positiveInteractions > 0
    ? imageInteractions / positiveInteractions
    : 0.5

  return {
    categoryAffinity: normalizeMap(categoryAffinity),
    authorAffinity: normalizeMap(authorAffinity),
    tagAffinity: normalizeMap(tagAffinity),
    behaviorPattern,
    preferredPostLength,
    preferredSentiment: 'neutral', // يحتاج تحليل المحتوى
    imagePreference,
    adaptiveWeights: getAdaptiveWeights(),
    totalInteractions: interactions.length,
    positiveInteractions: positiveCount,
    negativeInteractions: negativeCount,
    lastActive,
  }
}

// ============================================================
// 4) Smart Feed Ranker — ترتيب الخلاصة بناءً على التعلم
// ============================================================

import type { Post } from '@/lib/supabase/client'

export interface RankedPost {
  post: Post
  score: number
  reasons: string[]
  signals: {
    relevance: number
    recency: number
    engagement: number
    quality: number
    diversity: number
    authorship: number
  }
}

/**
 * ترتيب المنشورات باستخدام النموذج التكيّفي
 * كل تفاعل جديد يحسّن الترتيب التالي
 */
export function rankPostsWithLearning(
  posts: Post[],
  profile: LearningProfile
): RankedPost[] {
  const weights = profile.adaptiveWeights
  const now = Date.now()
  const HOUR = 60 * 60 * 1000

  // أحدث فئة شاهدها المستخدم (للتنوع)
  const recentCategories = Object.entries(profile.categoryAffinity)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 3)
    .map(([cat]) => cat)

  return posts.map((post) => {
    const signals = {
      relevance: 0,
      recency: 0,
      engagement: 0,
      quality: 0,
      diversity: 0,
      authorship: 0,
    }

    // 1) الصلة (relevance) — فئة + وسم
    const catScore = profile.categoryAffinity[post.category] || 0
    signals.relevance = catScore * 100

    // 2) الحداثة (recency) — exponential decay
    const ageHours = (now - new Date(post.created_at).getTime()) / HOUR
    signals.recency = Math.max(0, 100 - ageHours * 4)  // ينخفض 4 نقاط/ساعة

    // 3) التفاعل (engagement) — log scale
    const totalEng = (post.likes_count || 0) + (post.comments_count || 0) * 2 + (post.reposts_count || 0) * 3
    signals.engagement = Math.min(100, Math.log(1 + totalEng) * 20)

    // 4) الجودة (quality)
    if (post.content) {
      const q = assessQuality(post.content, { hasImage: !!post.image_url })
      signals.quality = q.score
    }

    // 5) التنوع (diversity) — خصم إذا نفس الفئة المفضلة
    signals.diversity = recentCategories.includes(post.category) ? 50 : 100

    // 6) المؤلف (authorship)
    signals.authorship = (profile.authorAffinity[post.user_id] || 0) * 100

    // الحساب النهائي بالأوزان التكيّفية
    const score =
      signals.relevance * weights.relevance +
      signals.recency * weights.recency +
      signals.engagement * weights.engagement +
      signals.quality * weights.quality +
      signals.diversity * weights.diversity +
      signals.authorship * weights.authorship

    // تعزيز المنشورات المثبتة والمميزة
    let finalScore = score
    if (post.is_pinned) finalScore += 100
    if (post.is_featured) finalScore += 30

    // تفضيل طول المنشور
    if (post.content) {
      const length = post.content.length
      if (profile.preferredPostLength === 'short' && length < 100) finalScore += 5
      else if (profile.preferredPostLength === 'long' && length > 500) finalScore += 5
    }

    // تفضيل الصور
    if (post.image_url && profile.imagePreference > 0.6) {
      finalScore += 8
    }

    // توليد أسباب التوصية
    const reasons: string[] = []
    if (signals.relevance > 50) reasons.push('صلة عالية باهتماماتك')
    if (signals.recency > 80) reasons.push('حديث')
    if (signals.engagement > 60) reasons.push('تفاعل مرتفع')
    if (signals.authorship > 50) reasons.push('من مؤلف تتابعه')
    if (signals.quality > 80) reasons.push('محتوى عالي الجودة')

    return { post, score: finalScore, reasons, signals }
  }).sort((a, b) => b.score - a.score)
}

// ============================================================
// 5) Auto Tag Learning — تعلم الوسوم من المحتوى
// ============================================================

/**
 * تعلم الوسوم المناسبة لمنشور جديد
 * يحلل المحتوى ويستخرج وسوم ذكية
 */
export function learnTags(content: string, existingTags: string[] = []): {
  suggested: string[]
  confidence: number
} {
  if (content.length < 10) return { suggested: [], confidence: 0 }

  // استخراج الكلمات المفتاحية
  const keywords = extractKeywords(content, 10)

  // تصفية: الكلمات الطويلة (>3 أحرف) وغير شائعة
  const candidates = keywords.filter((kw) => kw.length >= 4 && !existingTags.includes(kw))

  // ترتيب حسب التكرار (أعلى = أعلى ثقة)
  const suggested = candidates.slice(0, 3)

  // مستوى الثقة: كم كلمة مفتاحية وُجدت؟
  const confidence = Math.min(1, keywords.length / 5)

  return { suggested, confidence }
}

// ============================================================
// 6) Content Quality Learning — تعلم معايير الجودة
// ============================================================

export interface QualityBenchmark {
  avgScore: number
  topScoringPatterns: string[]
  commonIssues: string[]
  totalAnalyzed: number
}

/**
 * تعلم معايير الجودة من منشورات سابقة ناجحة
 */
export function learnQualityBenchmark(posts: { content: string; likes: number; comments: number }[]): QualityBenchmark {
  if (posts.length === 0) {
    return {
      avgScore: 50,
      topScoringPatterns: [],
      commonIssues: [],
      totalAnalyzed: 0,
    }
  }

  const scores: number[] = []
  const issues: Record<string, number> = {}
  const successfulPatterns: string[] = []

  for (const post of posts) {
    const q = assessQuality(post.content)
    scores.push(q.score)
    for (const issue of q.issues) {
      issues[issue] = (issues[issue] || 0) + 1
    }

    // المنشورات الناجحة (تفاعل عالي)
    const eng = post.likes + post.comments * 2
    if (eng > 5 && q.score > 70) {
      const keywords = extractKeywords(post.content, 3)
      successfulPatterns.push(...keywords)
    }
  }

  const avgScore = Math.round(scores.reduce((a, b) => a + b, 0) / scores.length)
  const commonIssues = Object.entries(issues)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 3)
    .map(([issue]) => issue)

  // أكثر الكلمات تكرارًا في المنشورات الناجحة
  const patternCounts: Record<string, number> = {}
  for (const p of successfulPatterns) {
    patternCounts[p] = (patternCounts[p] || 0) + 1
  }
  const topScoringPatterns = Object.entries(patternCounts)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 5)
    .map(([p]) => p)

  return {
    avgScore,
    topScoringPatterns,
    commonIssues,
    totalAnalyzed: posts.length,
  }
}

// ============================================================
// 7) Session Learning — تعلم أنماط الجلسة
// ============================================================

export interface SessionPattern {
  avgDurationMinutes: number
  avgPostsViewed: number
  avgInteractions: number
  bestTimeToEngage: number[]  // ساعات النشاط الأعلى
  dropoutPoint: number        // بعد كم منشور يتوقف المستخدم عادة
}

/**
 * تعلم أنماط جلسة المستخدم
 */
export function analyzeSessionPattern(userId: string): SessionPattern {
  const interactions = getTrackedInteractions(userId)

  if (interactions.length === 0) {
    return {
      avgDurationMinutes: 0,
      avgPostsViewed: 0,
      avgInteractions: 0,
      bestTimeToEngage: [],
      dropoutPoint: 0,
    }
  }

  // تجميع التفاعلات في جلسات (فجوة > 30 دقيقة = جلسة جديدة)
  const sessions: TrackedInteraction[][] = []
  let currentSession: TrackedInteraction[] = [interactions[0]]

  for (let i = 1; i < interactions.length; i++) {
    const gap = interactions[i].timestamp - interactions[i - 1].timestamp
    if (gap > 30 * 60 * 1000) {
      sessions.push(currentSession)
      currentSession = []
    }
    currentSession.push(interactions[i])
  }
  if (currentSession.length > 0) sessions.push(currentSession)

  // حساب المتوسطات
  const durations = sessions.map((s) => {
    if (s.length < 2) return 1
    return (s[s.length - 1].timestamp - s[0].timestamp) / (60 * 1000)
  })
  const avgDurationMinutes = durations.length > 0
    ? Math.round(durations.reduce((a, b) => a + b, 0) / durations.length)
    : 0

  const avgPostsViewed = Math.round(
    sessions.reduce((sum, s) => sum + new Set(s.map((i) => i.postId)).size, 0) / sessions.length
  )

  const avgInteractions = Math.round(interactions.length / sessions.length)

  // أفضل أوقات النشاط
  const hourCounts = new Array(24).fill(0)
  for (const i of interactions) {
    hourCounts[new Date(i.timestamp).getHours()]++
  }
  const bestTimeToEngage = hourCounts
    .map((count, hour) => ({ hour, count }))
    .filter((h) => h.count > 0)
    .sort((a, b) => b.count - a.count)
    .slice(0, 3)
    .map((h) => h.hour)

  // نقطة التوقف: بعد كم منشور يتوقف المستخدم عادة
  const sessionLengths = sessions.map((s) => new Set(s.map((i) => i.postId)).size)
  const dropoutPoint = sessionLengths.length > 0
    ? Math.round(sessionLengths.reduce((a, b) => a + b, 0) / sessionLengths.length)
    : 0

  return {
    avgDurationMinutes,
    avgPostsViewed,
    avgInteractions,
    bestTimeToEngage,
    dropoutPoint,
  }
}
