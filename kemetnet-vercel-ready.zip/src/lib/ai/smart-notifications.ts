// src/lib/ai/smart-notifications.ts
// محرك الإشعارات الذكي - Smart Notification Engine
// - ترتيب حسب الأولوية
// - تجميع الإشعارات المتشابهة
// - احترام ساعات الهدوء
// - تقليل الضوضاء (anti-fatigue)

import type { Post, Profile } from '@/lib/supabase/client'

export type NotificationPriority = 'critical' | 'high' | 'medium' | 'low'

export interface SmartNotification {
  id: string
  type: 'like' | 'comment' | 'follow' | 'mention' | 'message' | 'system' | 'verified'
  priority: NotificationPriority
  title: string
  body: string
  actor?: Profile
  post?: Post
  timestamp: number
  shouldBatch: boolean
  batchId?: string
  shouldHideUntil?: number  // timestamp لإظهار لاحقًا
}

export interface UserQuietHours {
  start: number   // 0-23 (ساعة)
  end: number     // 0-23
  enabled: boolean
}

export interface UserNotificationPrefs {
  quietHours: UserQuietHours
  maxPerHour: number           // الحد الأقصى للإشعارات/ساعة
  criticalOverride: boolean    // الإشعارات الحرجة تتجاوز ساعات الهدوء
  batched: boolean              // دمج الإشعارات المتشابهة
}

const DEFAULT_PREFS: UserNotificationPrefs = {
  quietHours: { start: 23, end: 7, enabled: true },
  maxPerHour: 8,
  criticalOverride: true,
  batched: true,
}

/**
 * حساب أولوية الإشعار بناءً على عوامل متعددة
 */
export function calculatePriority(
  type: SmartNotification['type'],
  actor?: Profile,
  context?: { isReplyToMe?: boolean; isVerifiedActor?: boolean; isMutualFollow?: boolean }
): NotificationPriority {
  // الإشارات الحرجة دائمًا
  if (type === 'mention' && context?.isReplyToMe) return 'critical'
  if (type === 'message') return 'high'

  // الإشعارات من حسابات موثقة = أولوية أعلى
  const verifiedBoost = context?.isVerifiedActor ? 1 : 0

  // المتابعات المتبادلة = أولوية أعلى
  const mutualBoost = context?.isMutualFollow ? 1 : 0

  switch (type) {
    case 'like':
      // إعجاب بسيط = أولوية منخفضة (إلا إذا من حساب موثق أو متبادل)
      if (verifiedBoost || mutualBoost) return 'medium'
      return 'low'
    case 'comment':
      // تعليق = متوسط (إلا إذا رد عليّ = حرج)
      if (context?.isReplyToMe) return 'critical'
      if (verifiedBoost || mutualBoost) return 'high'
      return 'medium'
    case 'follow':
      // متابعة = متوسط
      if (verifiedBoost) return 'high'
      return 'medium'
    case 'mention':
      return 'critical'
    case 'verified':
      return 'critical'
    case 'system':
      return 'medium'
    default:
      return 'low'
  }
}

/**
 * دمج الإشعارات المتشابهة (Batching)
 * مثال: 3 إعجابات من نفس المنشور → "أحمد وعلي وآخرون أعجبوا بمنشورك"
 */
export function batchNotifications(
  notifications: SmartNotification[]
): SmartNotification[] {
  const batches: Record<string, SmartNotification[]> = {}

  for (const notif of notifications) {
    // دمج الإشعارات من نفس النوع على نفس المنشور خلال آخر ساعة
    const batchKey = notif.shouldBatch
      ? `${notif.type}:${notif.post?.id || 'no-post'}`
      : notif.id

    if (!batches[batchKey]) batches[batchKey] = []
    batches[batchKey].push(notif)
  }

  const result: SmartNotification[] = []
  for (const group of Object.values(batches)) {
    if (group.length === 1) {
      result.push(group[0])
    } else {
      // دمج في إشعار واحد
      const first = group[0]
      const count = group.length
      const actors = group
        .map((g) => g.actor)
        .filter(Boolean)
        .slice(0, 3) as Profile[]

      const actorNames = actors.map((a) => a.display_name || a.username).join(' و')
      const othersCount = count - actors.length

      let title = first.title
      if (count === 2) title = `${actorNames} ${first.type === 'like' ? 'أعجبا' : 'فعلا'}`
      else if (count > 2 && othersCount > 0) {
        title = `${actorNames} و ${othersCount} آخرون`
      } else if (count > 2) {
        title = `${actorNames} وآخرون`
      }

      result.push({
        ...first,
        id: `batch-${first.id}-${count}`,
        title,
        body: count > 1
          ? `${count} ${first.type === 'like' ? 'إعجابات' : first.type === 'comment' ? 'تعليقات' : 'إشعارات'}`
          : first.body,
        batchId: first.id,
      })
    }
  }

  return result
}

/**
 * تطبيق ساعات الهدوء
 */
export function applyQuietHours(
  notifications: SmartNotification[],
  prefs: UserNotificationPrefs = DEFAULT_PREFS,
  currentHour: number = new Date().getHours()
): SmartNotification[] {
  if (!prefs.quietHours.enabled) return notifications

  const inQuietHours = isInQuietHours(currentHour, prefs.quietHours)

  if (!inQuietHours) return notifications

  return notifications.map((n) => {
    // الإشعارات الحرجة تتجاوز ساعات الهدوء
    if (prefs.criticalOverride && n.priority === 'critical') return n

    // تأجيل الإشعارات الأخرى حتى نهاية ساعات الهدوء
    const showAt = computeNextQuietEnd(currentHour, prefs.quietHours)
    return { ...n, shouldHideUntil: showAt }
  })
}

function isInQuietHours(hour: number, qh: UserQuietHours): boolean {
  if (qh.start < qh.end) {
    return hour >= qh.start && hour < qh.end
  } else {
    // معاملة عبر منتصف الليل (مثال: 23 → 7)
    return hour >= qh.start || hour < qh.end
  }
}

function computeNextQuietEnd(currentHour: number, qh: UserQuietHours): number {
  const tomorrow = new Date()
  tomorrow.setHours(qh.end, 0, 0, 0)
  if (qh.end <= currentHour) {
    tomorrow.setDate(tomorrow.getDate() + 1)
  }
  return tomorrow.getTime()
}

/**
 * الحد من عدد الإشعارات في الساعة (anti-fatigue)
 */
export function rateLimitNotifications(
  notifications: SmartNotification[],
  prefs: UserNotificationPrefs = DEFAULT_PREFS
): SmartNotification[] {
  // ترتيب حسب الأولوية (critical أولاً)
  const priorityOrder: NotificationPriority[] = ['critical', 'high', 'medium', 'low']
  const sorted = [...notifications].sort((a, b) => {
    const ai = priorityOrder.indexOf(a.priority)
    const bi = priorityOrder.indexOf(b.priority)
    if (ai !== bi) return ai - bi
    return b.timestamp - a.timestamp
  })

  // إبقاء فقط maxPerHour
  return sorted.slice(0, prefs.maxPerHour)
}

/**
 * معالجة شاملة للإشعارات
 */
export function processNotifications(
  raw: SmartNotification[],
  prefs: UserNotificationPrefs = DEFAULT_PREFS
): SmartNotification[] {
  let result = raw

  // 1) دمج المتشابهة
  if (prefs.batched) {
    result = batchNotifications(result)
  }

  // 2) تطبيق ساعات الهدوء
  result = applyQuietHours(result, prefs)

  // 3) الحد من العدد
  result = rateLimitNotifications(result, prefs)

  // 4) ترتيب نهائي: الإشعارات الظاهرة أولاً ثم المؤجلة
  result.sort((a, b) => {
    // الإشعارات غير المؤجلة أولاً
    if (a.shouldHideUntil && !b.shouldHideUntil) return 1
    if (!a.shouldHideUntil && b.shouldHideUntil) return -1
    // ثم حسب الأولوية
    const order = ['critical', 'high', 'medium', 'low']
    const ai = order.indexOf(a.priority)
    const bi = order.indexOf(b.priority)
    if (ai !== bi) return ai - bi
    // ثم الأحدث
    return b.timestamp - a.timestamp
  })

  return result
}

/**
 * حساب عدد الإشعارات غير المقروءة المعروضة فعليًا
 * (مع تجاهل المؤجلة بسبب ساعات الهدوء)
 */
export function countVisibleUnread(
  notifications: SmartNotification[],
  readIds: Set<string>
): number {
  const now = Date.now()
  return notifications.filter(
    (n) => !readIds.has(n.id) && (!n.shouldHideUntil || n.shouldHideUntil <= now)
  ).length
}
