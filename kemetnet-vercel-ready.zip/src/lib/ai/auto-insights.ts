// src/lib/ai/auto-insights.ts
// مولد الرؤى الذكية - Auto Insights Generator
// يحلل نشاط المستخدم ويولّد رؤى أسبوعية ذكية:
//   - أكثر الفئات تفاعلًا
//   - أفضل وقت للنشر
//   - نمو التفاعل
//   - اقتراحات لتحسين المحتوى
//   - مقارنة بالأسبوع السابق

import { supabase } from '@/lib/supabase/client'
import { analyzeSentiment, assessQuality, autoCategorize } from './content-analyzer'

export interface WeeklyInsight {
  id: string
  type: 'top_category' | 'best_time' | 'engagement_growth' | 'tip' |
        'milestone' | 'trend_join' | 'audience_insight' | 'comparison'
  title: string
  body: string
  value?: number
  delta?: number           // نسبة التغيير عن الأسبوع الماضي
  icon: string              // emoji or icon name
  severity: 'positive' | 'neutral' | 'warning'
  actionable?: {
    label: string
    target?: string         // URL to navigate
  }
}

const WEEK = 7 * 24 * 60 * 60 * 1000
const DAY = 24 * 60 * 60 * 1000

/**
 * توليد رؤى أسبوعية كاملة للمستخدم
 */
export async function generateWeeklyInsights(userId: string): Promise<WeeklyInsight[]> {
  const insights: WeeklyInsight[] = []

  // جلب بيانات الأسبوع الحالي والسابق بالتوازي
  const now = Date.now()
  const weekAgo = new Date(now - WEEK).toISOString()
  const twoWeeksAgo = new Date(now - 2 * WEEK).toISOString()

  const [
    myPosts, myLikes, myComments, myFollowers, myFollowing,
    lastWeekPosts, lastWeekFollowers,
    likedPosts,
  ] = await Promise.all([
    // منشوراتي هذا الأسبوع
    supabase
      .from('posts')
      .select('id, category, tags, content, image_url, likes_count, comments_count, reposts_count, created_at')
      .eq('user_id', userId)
      .gte('created_at', weekAgo)
      .order('created_at', { ascending: false }),
    // إعجابات بمنشوراتي
    supabase
      .from('likes')
      .select(`
        id, created_at,
        post:posts!likes_post_id_fkey(user_id)
      `)
      .eq('post.user_id', userId)
      .gte('created_at', weekAgo),
    // تعليقات على منشوراتي
    supabase
      .from('comments')
      .select('id, created_at')
      .eq('post.user_id', userId)  // هذا قد لا يعمل مباشرة
      .gte('created_at', weekAgo),
    // متابعون جدد
    supabase
      .from('follows')
      .select('follower_id, created_at')
      .eq('followed_id', userId)
      .gte('created_at', weekAgo),
    // متابعاتي الجديدة
    supabase
      .from('follows')
      .select('followed_id, created_at')
      .eq('follower_id', userId)
      .gte('created_at', weekAgo),
    // منشورات الأسبوع الماضي
    supabase
      .from('posts')
      .select('id, likes_count, comments_count')
      .eq('user_id', userId)
      .gte('created_at', twoWeeksAgo)
      .lt('created_at', weekAgo),
    // متابعون الأسبوع الماضي
    supabase
      .from('follows')
      .select('follower_id')
      .eq('followed_id', userId)
      .gte('created_at', twoWeeksAgo)
      .lt('created_at', weekAgo),
    // المنشورات التي أعجبت بها (لتحليل اهتماماتي)
    supabase
      .from('likes')
      .select(`
        post:posts!likes_post_id_fkey(
          id, category, tags, content, created_at
        )
      `)
      .eq('user_id', userId)
      .gte('created_at', twoWeeksAgo),
  ])

  // ====== Insight 1: أكثر فئة تفاعلًا ======
  if (likedPosts.data && likedPosts.data.length > 0) {
    const catCount: Record<string, number> = {}
    for (const like of likedPosts.data) {
      const post = like.post as any
      if (post && post.category) {
        catCount[post.category] = (catCount[post.category] || 0) + 1
      }
    }
    const top = Object.entries(catCount).sort(([, a], [, b]) => b - a)[0]
    if (top) {
      const catLabels: Record<string, string> = {
        inspire: 'إلهام', tech: 'تقنية', art: 'فن', travel: 'سفر',
        food: 'طعام', music: 'موسيقى', thoughts: 'خواطر',
      }
      insights.push({
        id: 'top_category',
        type: 'top_category',
        title: 'اهتمامك الأبرز هذا الأسبوع',
        body: `تفاعلت مع ${top[1]} منشور في فئة "${catLabels[top[0]] || top[0]}"`,
        value: top[1],
        icon: '🎯',
        severity: 'neutral',
      })
    }
  }

  // ====== Insight 2: أفضل وقت للنشر ======
  if (myPosts.data && myPosts.data.length > 0) {
    const hourStats: Record<number, { count: number; engagement: number }> = {}
    for (const post of myPosts.data) {
      const hour = new Date(post.created_at).getHours()
      if (!hourStats[hour]) hourStats[hour] = { count: 0, engagement: 0 }
      hourStats[hour].count++
      hourStats[hour].engagement += (post.likes_count || 0) + (post.comments_count || 0) * 2
    }

    // حساب أعلى ساعة تفاعلًا (بمعدل لكل منشور)
    let bestHour = -1
    let bestRate = 0
    for (const [h, stats] of Object.entries(hourStats)) {
      const rate = stats.engagement / stats.count
      if (rate > bestRate) {
        bestRate = rate
        bestHour = parseInt(h)
      }
    }
    if (bestHour >= 0) {
      const period = bestHour < 12 ? 'صباحًا' : 'مساءً'
      insights.push({
        id: 'best_time',
        type: 'best_time',
        title: 'أفضل وقت للنشر',
        body: `منشوراتك تحقق تفاعلًا أعلى عند النشر الساعة ${bestHour}:00 ${period}`,
        value: bestHour,
        icon: '⏰',
        severity: 'positive',
        actionable: { label: 'جدولة منشور', target: '/create' },
      })
    }
  }

  // ====== Insight 3: نمو المتابعين ======
  const newFollowers = myFollowers.data?.length || 0
  const lastWeekFollowersCount = lastWeekFollowers.data?.length || 0
  const followerDelta = newFollowers - lastWeekFollowersCount

  if (newFollowers > 0) {
    const deltaPercent = lastWeekFollowersCount > 0
      ? ((followerDelta / lastWeekFollowersCount) * 100).toFixed(0)
      : '∞'

    insights.push({
      id: 'followers_growth',
      type: 'engagement_growth',
      title: followerDelta > 0 ? 'نمو في المتابعين! 🎉' : 'متابعون جدد',
      body: `${newFollowers} متابع جديد هذا الأسبوع ${followerDelta > 0 ? `(+${deltaPercent}%)` : ''}`,
      value: newFollowers,
      delta: parseFloat(deltaPercent.toString()) || 0,
      icon: '📈',
      severity: followerDelta > 0 ? 'positive' : 'neutral',
    })
  }

  // ====== Insight 4: مقارنة التفاعل بالأسبوع الماضي ======
  if (myPosts.data && lastWeekPosts.data) {
    const thisWeekEng = myPosts.data.reduce(
      (sum, p) => sum + (p.likes_count || 0) + (p.comments_count || 0) * 2,
      0
    )
    const lastWeekEng = lastWeekPosts.data.reduce(
      (sum, p) => sum + (p.likes_count || 0) + (p.comments_count || 0) * 2,
      0
    )
    if (lastWeekEng > 0) {
      const growthPercent = ((thisWeekEng - lastWeekEng) / lastWeekEng) * 100
      if (Math.abs(growthPercent) > 10) {
        insights.push({
          id: 'engagement_growth',
          type: 'comparison',
          title: growthPercent > 0 ? 'تفاعلك في تحسّن!' : 'تفاعلك انخفض',
          body: `${growthPercent > 0 ? 'زيادة' : 'انخفاض'} ${Math.abs(growthPercent).toFixed(0)}% مقارنة بالأسبوع الماضي`,
          delta: growthPercent,
          icon: growthPercent > 0 ? '🚀' : '📉',
          severity: growthPercent > 0 ? 'positive' : 'warning',
        })
      }
    }
  }

  // ====== Insight 5: نصيحة جودة المحتوى ======
  if (myPosts.data && myPosts.data.length > 0) {
    const avgQuality = myPosts.data.reduce((sum, p) => {
      const q = assessQuality(p.content || '')
      return sum + q.score
    }, 0) / myPosts.data.length

    if (avgQuality < 70) {
      const tips: string[] = []
      // تحليل المشاكل الشائعة
      const issuesCount: Record<string, number> = {}
      for (const p of myPosts.data) {
        const q = assessQuality(p.content || '', { hasImage: !!p.image_url })
        for (const issue of q.issues) {
          issuesCount[issue] = (issuesCount[issue] || 0) + 1
        }
      }
      const topIssue = Object.entries(issuesCount).sort(([, a], [, b]) => b - a)[0]
      if (topIssue) {
        insights.push({
          id: 'quality_tip',
          type: 'tip',
          title: 'نصيحة لتحسين محتواك',
          body: topIssue[0],
          icon: '💡',
          severity: 'warning',
          actionable: { label: 'تعديل المنشورات', target: '/profile' },
        })
      }
    } else if (avgQuality > 85) {
      insights.push({
        id: 'quality_praise',
        type: 'milestone',
        title: 'محتوى عالي الجودة! ⭐',
        body: `متوسط جودة منشوراتك ${avgQuality.toFixed(0)}/100 هذا الأسبوع`,
        value: avgQuality,
        icon: '⭐',
        severity: 'positive',
      })
    }
  }

  // ====== Insight 6: تحليل المشاعر ======
  if (myPosts.data && myPosts.data.length >= 3) {
    const sentiments = myPosts.data.map((p) => analyzeSentiment(p.content || ''))
    const avgSentiment = sentiments.reduce((sum, s) => sum + s.score, 0) / sentiments.length

    if (avgSentiment > 0.3) {
      insights.push({
        id: 'positive_vibes',
        type: 'audience_insight',
        title: 'طاقة إيجابية! 🌟',
        body: 'منشوراتك هذا الأسبوع إيجابية في معظمها — جمهورك يحب ذلك',
        value: avgSentiment,
        icon: '🌟',
        severity: 'positive',
      })
    } else if (avgSentiment < -0.2) {
      insights.push({
        id: 'mood_check',
        type: 'tip',
        title: 'تحقق من حالتك',
        body: 'منشوراتك هذا الأسبوع تميل للحزن. خذ وقتًا لنفسك 💚',
        icon: '💚',
        severity: 'neutral',
      })
    }
  }

  // ====== Insight 7: إنجاز (Milestone) ======
  if (myPosts.data && myPosts.data.length >= 5) {
    insights.push({
      id: 'milestone_posts',
      type: 'milestone',
      title: `+${myPosts.data.length} منشور هذا الأسبوع!`,
      body: 'نشاط ممتاز! استمر في المشاركة',
      value: myPosts.data.length,
      icon: '🏆',
      severity: 'positive',
    })
  }

  // ====== Insight 8: اقتراح انضمام لترند ======
  try {
    const { detectTrends } = await import('./smart-feed')
    const trends = await detectTrends()
    if (trends.length > 0 && myPosts.data) {
      const myTags = new Set(myPosts.data.flatMap((p) => p.tags || []))
      const matchingTrend = trends.find((t) => myTags.has(t.tag))
      if (matchingTrend) {
        insights.push({
          id: 'trend_join',
          type: 'trend_join',
          title: 'أنت جزء من ترند! 🔥',
          body: `وسم "${matchingTrend.tag}" يرتفع (${matchingTrend.postsCount} منشور في 24 ساعة)`,
          value: matchingTrend.postsCount,
          icon: '🔥',
          severity: 'positive',
        })
      }
    }
  } catch {
    // تجاهل
  }

  return insights
}

/**
 * توليد رؤى سريعة (للعرض في الـ home dashboard)
 */
export async function generateQuickInsights(userId: string): Promise<WeeklyInsight[]> {
  const all = await generateWeeklyInsights(userId)
  // أبرز 3 رؤى فقط
  return all.slice(0, 3)
}
