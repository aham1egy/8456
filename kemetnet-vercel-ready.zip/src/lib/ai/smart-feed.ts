// src/lib/ai/smart-feed.ts
// محرك الخلاصة الذكي - Smart Feed Algorithm
// يحسب ترتيب المنشورات بناءً على إشارات متعددة:
//   1) الصلة بالمستخدم (Personalization)
//   2) الحداثة (Recency decay)
//   3) التفاعل (Engagement velocity)
//   4) التنوع (Diversity - منع التكرار)
//   5) جودة المحتوى (Quality score)
//   6) العدالة (Fairness - منع هيمنة مستخدم واحد)

import { supabase } from '@/lib/supabase/client'
import { assessQuality, analyzeSentiment, autoCategorize } from './content-analyzer'
import type { Post, Profile } from '@/lib/supabase/client'

// ============= Types =============

export interface UserProfile {
  userId: string
  interestVector: Record<string, number>   // category → weight (0-1)
  favoriteTags: Record<string, number>      // tag → weight
  favoriteUsers: Record<string, number>     // userId → weight
  preferredAuthors: string[]                 // top followed authors
  avgSessionLength: number                  // minutes
  bestTimeToEngage: number[]                // hours [0-23]
  preferredContentLength: 'short' | 'medium' | 'long'
  sentimentBias: number                      // -1 (sad) → 1 (happy)
  diversityWeight: number                   // 0-1
  lastSeenCategories: string[]               // آخر فئات شوهدت (للتنوع)
}

export interface ScoredPost {
  post: Post
  score: number
  reasons: string[]
  signals: {
    relevance: number       // 0-100
    recency: number         // 0-100
    engagement: number      // 0-100
    quality: number         // 0-100
    diversity: number       // 0-100 (higher = more diverse)
    authorship: number      // 0-100 (familiarity with author)
  }
}

// ============= User Profile Builder =============

/**
 * يبني ملف اهتمامات المستخدم من نشاطه
 * يستخدم آخر 50 إعجاب + آخر 20 متابعة
 */
export async function buildUserProfile(userId: string): Promise<UserProfile> {
  // 1) إعجابات المستخدم (مع تفاصيل المنشور)
  const { data: likes } = await supabase
    .from('likes')
    .select(`
      post:posts!likes_post_id_fkey(
        id, category, tags, content, user_id, created_at
      )
    `)
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .limit(50)

  // 2) المتابعات
  const { data: follows } = await supabase
    .from('follows')
    .select('followed_id')
    .eq('follower_id', userId)
    .limit(50)

  // 3) المنشورات المحفوظة
  const { data: saved } = await supabase
    .from('saved_posts')
    .select(`
      post:posts!saved_posts_post_id_fkey(
        id, category, tags, content, user_id, created_at
      )
    `)
    .eq('user_id', userId)
    .limit(30)

  // بناء متجه الاهتمامات
  const interestVector: Record<string, number> = {}
  const favoriteTags: Record<string, number> = {}
  const favoriteUsers: Record<string, number> = {}
  const sentimentScores: number[] = []
  const seenHours: number[] = []

  // وزن مختلف لكل نوع تفاعل
  const WEIGHTS = {
    like: 1.0,
    save: 2.5,           // الحفظ أقوى إشارة اهتمام
    follow: 1.5,
    comment: 1.8,
  }

  const processPost = (post: any, weight: number) => {
    if (!post) return
    // الفئة
    if (post.category) {
      interestVector[post.category] = (interestVector[post.category] || 0) + weight
    }
    // الوسوم
    if (post.tags && Array.isArray(post.tags)) {
      for (const tag of post.tags) {
        favoriteTags[tag] = (favoriteTags[tag] || 0) + weight
      }
    }
    // المؤلف
    if (post.user_id) {
      favoriteUsers[post.user_id] = (favoriteUsers[post.user_id] || 0) + weight
    }
    // المشاعر
    if (post.content) {
      const s = analyzeSentiment(post.content)
      sentimentScores.push(s.score * weight)
    }
    // الوقت
    if (post.created_at) {
      seenHours.push(new Date(post.created_at).getHours())
    }
  }

  // معالجة كل مصدر
  for (const like of likes || []) processPost(like.post, WEIGHTS.like)
  for (const save of saved || []) processPost(save.post, WEIGHTS.save)

  // المتابعات
  for (const follow of follows || []) {
    if (follow.followed_id) {
      favoriteUsers[follow.followed_id] = (favoriteUsers[follow.followed_id] || 0) + WEIGHTS.follow
    }
  }

  // تطبيع متجه الاهتمامات (0-1)
  const maxInterest = Math.max(1, ...Object.values(interestVector))
  for (const cat in interestVector) {
    interestVector[cat] /= maxInterest
  }

  // تطبيع الوسوم
  const maxTag = Math.max(1, ...Object.values(favoriteTags))
  for (const tag in favoriteTags) {
    favoriteTags[tag] /= maxTag
  }

  // تطبيع المستخدمين
  const maxUser = Math.max(1, ...Object.values(favoriteUsers))
  for (const u in favoriteUsers) {
    favoriteUsers[u] /= maxUser
  }

  // أفضل المؤلفين
  const preferredAuthors = Object.entries(favoriteUsers)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 10)
    .map(([id]) => id)

  // أنسب الأوقات للتفاعل
  const hourCount = new Array(24).fill(0)
  for (const h of seenHours) hourCount[h]++
  const maxHour = Math.max(1, ...hourCount)
  const bestTimeToEngage = hourCount
    .map((c, h) => ({ h, w: c / maxHour }))
    .filter((x) => x.w > 0.5)
    .map((x) => x.h)

  // متوسط المشاعر
  const sentimentBias = sentimentScores.length > 0
    ? sentimentScores.reduce((a, b) => a + b, 0) / sentimentScores.length
    : 0

  return {
    userId,
    interestVector,
    favoriteTags,
    favoriteUsers,
    preferredAuthors,
    avgSessionLength: 10,
    bestTimeToEngage,
    preferredContentLength: 'medium',
    sentimentBias,
    diversityWeight: 0.6,
    lastSeenCategories: [],
  }
}

// ============= Multi-Signal Scoring =============

const HOUR = 60 * 60 * 1000
const DAY = 24 * HOUR

/**
 * حساب درجة الصلة (Relevance) - 0-100
 */
function scoreRelevance(post: Post, profile: UserProfile): number {
  let score = 0
  const reasons: string[] = []

  // 1) تطابق الفئة (وزن عالي - 40 نقطة)
  const catWeight = profile.interestVector[post.category] || 0
  score += catWeight * 40
  if (catWeight > 0.5) reasons.push(`فئة "${post.category}" مفضلة`)

  // 2) تطابق الوسوم (وزن متوسط - 30 نقطة)
  if (post.tags && Array.isArray(post.tags)) {
    let tagScore = 0
    for (const tag of post.tags) {
      const w = profile.favoriteTags[tag] || 0
      tagScore += w
    }
    tagScore = Math.min(1, tagScore / 3) // تطبيع
    score += tagScore * 30
    if (tagScore > 0.3) reasons.push('وسوم تهمك')
  }

  // 3) المؤلف المفضل (وزن عالٍ - 25 نقطة)
  const authorWeight = profile.favoriteUsers[post.user_id] || 0
  score += authorWeight * 25
  if (authorWeight > 0.5) reasons.push('من مؤلف تتابعه')

  // 4) انحياز المشاعر (5 نقاط)
  if (post.content && profile.sentimentBias !== 0) {
    const sentiment = analyzeSentiment(post.content)
    const match = 1 - Math.abs(sentiment.score - profile.sentimentBias) / 2
    score += match * 5
  }

  return Math.min(100, score)
}

/**
 * حساب درجة الحداثة (Recency decay) - 0-100
 * يستخدم exponential decay
 */
function scoreRecency(post: Post): number {
  const ageMs = Date.now() - new Date(post.created_at).getTime()
  const hoursAgo = ageMs / HOUR

  // exponential decay: 100 → 0 خلال 7 أيام
  if (hoursAgo < 1) return 100           // آخر ساعة
  if (hoursAgo < 6) return 95 - (hoursAgo - 1) * 2   // آخر 6 ساعات
  if (hoursAgo < 24) return 85 - (hoursAgo - 6) * 1.5 // اليوم
  if (hoursAgo < 72) return 65 - (hoursAgo - 24) * 0.7 // 3 أيام
  if (hoursAgo < 168) return 35 - (hoursAgo - 72) * 0.3 // أسبوع
  if (hoursAgo < 720) return 15 - (hoursAgo - 168) * 0.02 // شهر
  return 5
}

/**
 * حساب درجة التفاعل (Engagement velocity) - 0-100
 * يقيس معدل التفاعل الساعي
 */
function scoreEngagement(post: Post): number {
  const ageMs = Math.max(HOUR, Date.now() - new Date(post.created_at).getTime())
  const ageHours = ageMs / HOUR

  // معدل التفاعل لكل ساعة
  const totalEngagement = (post.likes_count || 0) +
                          (post.comments_count || 0) * 2 +
                          (post.reposts_count || 0) * 3
  const engagementRate = totalEngagement / ageHours

  // log scale لمنع هيمنة المنشورات الفيروسية
  const score = Math.min(100, Math.log(1 + engagementRate * 10) * 25)
  return score
}

/**
 * حساب درجة الجودة (Quality) - 0-100
 */
function scoreQuality(post: Post): number {
  if (!post.content) return 50
  const q = assessQuality(post.content, { hasImage: !!post.image_url })
  return q.score
}

/**
 * حساب درجة التنوع (Diversity) - 0-100
 * منشورات من فئات/مؤلفين مختلفين عن آخر ما شوهد
 */
function scoreDiversity(
  post: Post,
  profile: UserProfile,
  recentlySeenAuthors: string[],
  recentlySeenCategories: string[]
): number {
  let diversity = 100

  // خصم إذا كان من نفس مؤلف آخر منشور
  if (recentlySeenAuthors.includes(post.user_id)) {
    diversity -= 30
  }

  // خصم إذا كان من نفس فئة آخر منشور
  if (recentlySeenCategories.includes(post.category)) {
    diversity -= 25
  }

  // خصم إذا كان repost (نُفضّل المحتوى الأصلي)
  if (post.repost_of) {
    diversity -= 15
  }

  return Math.max(0, diversity)
}

/**
 * حساب درجة الألفة مع المؤلف - 0-100
 */
function scoreAuthorship(post: Post, profile: UserProfile): number {
  const weight = profile.favoriteUsers[post.user_id] || 0
  return weight * 100
}

// ============= Main Ranking Function =============

const FINAL_WEIGHTS = {
  relevance: 0.30,    // 30% صلة
  recency: 0.20,      // 20% حداثة
  engagement: 0.20,   // 20% تفاعل
  quality: 0.15,      // 15% جودة
  diversity: 0.10,    // 10% تنوع
  authorship: 0.05,   // 5% مؤلف مفضل
}

/**
 * ترتيب المنشورات بناءً على الخوارزمية الذكية
 */
export function rankPosts(
  posts: Post[],
  profile: UserProfile,
  options: { recentlySeenAuthors?: string[]; recentlySeenCategories?: string[] } = {}
): ScoredPost[] {
  const recentAuthors = options.recentlySeenAuthors || []
  const recentCategories = options.recentlySeenCategories || []

  const scored = posts.map((post) => {
    const signals = {
      relevance: scoreRelevance(post, profile),
      recency: scoreRecency(post),
      engagement: scoreEngagement(post),
      quality: scoreQuality(post),
      diversity: scoreDiversity(post, profile, recentAuthors, recentCategories),
      authorship: scoreAuthorship(post, profile),
    }

    const score =
      signals.relevance * FINAL_WEIGHTS.relevance +
      signals.recency * FINAL_WEIGHTS.recency +
      signals.engagement * FINAL_WEIGHTS.engagement +
      signals.quality * FINAL_WEIGHTS.quality +
      signals.diversity * FINAL_WEIGHTS.diversity +
      signals.authorship * FINAL_WEIGHTS.authorship

    // تعزيز المنشورات المثبتة والمميزة
    let finalScore = score
    if (post.is_pinned) finalScore += 100
    if (post.is_featured) finalScore += 30

    // توليد أسباب التوصية
    const reasons: string[] = []
    if (signals.relevance > 50) reasons.push('صلة عالية باهتماماتك')
    if (signals.recency > 80) reasons.push('حديث')
    if (signals.engagement > 60) reasons.push('تفاعل مرتفع')
    if (signals.authorship > 50) reasons.push('من مؤلف تتابعه')
    if (signals.quality > 80) reasons.push('محتوى عالي الجودة')

    return { post, score: finalScore, reasons, signals }
  })

  // ترتيب تنازلي
  scored.sort((a, b) => b.score - a.score)
  return scored
}

/**
 * تطبيق تنوع إضافي - منع ظهور أكثر من 2 منشور من نفس المؤلف في أول 10
 */
export function applyDiversityBoost(
  scored: ScoredPost[],
  maxPerAuthor = 2
): ScoredPost[] {
  const result: ScoredPost[] = []
  const authorCounts: Record<string, number> = {}

  for (const item of scored) {
    const author = item.post.user_id
    if ((authorCounts[author] || 0) < maxPerAuthor) {
      result.push(item)
      authorCounts[author] = (authorCounts[author] || 0) + 1
    } else {
      // أضفه لاحقًا بعد المنشورات الأخرى
      // (نضعه في نهاية القائمة)
    }
  }
  return result
}

// ============= Trend Detection =============

export interface TrendingTopic {
  tag: string
  postsCount: number
  growthRate: number         // نسبة الزيادة آخر 24 ساعة
  velocity: number           // معدل التفاعل
  category: string
  sentiment: number          // متوسط المشاعر
}

/**
 * كشف الوسوم الرائجة في آخر 24 ساعة
 */
export async function detectTrends(): Promise<TrendingTopic[]> {
  const yesterday = new Date(Date.now() - DAY).toISOString()

  const { data: recentPosts } = await supabase
    .from('posts')
    .select('tags, likes_count, comments_count, reposts_count, category, content, created_at')
    .gte('created_at', yesterday)
    .not('tags', 'is', null)

  if (!recentPosts || recentPosts.length === 0) return []

  // تجميع حسب الوسم
  const tagStats: Record<string, {
    count: number
    engagement: number
    category: string
    sentimentSum: number
    sentimentCount: number
    hoursAgo: number[]
  }> = {}

  for (const post of recentPosts) {
    if (!post.tags || !Array.isArray(post.tags)) continue
    for (const tag of post.tags) {
      if (!tagStats[tag]) {
        tagStats[tag] = {
          count: 0, engagement: 0, category: 'thoughts',
          sentimentSum: 0, sentimentCount: 0, hoursAgo: [],
        }
      }
      tagStats[tag].count++
      tagStats[tag].engagement += (post.likes_count || 0) + (post.comments_count || 0) * 2 + (post.reposts_count || 0) * 3
      tagStats[tag].category = post.category
      if (post.content) {
        const s = analyzeSentiment(post.content)
        tagStats[tag].sentimentSum += s.score
        tagStats[tag].sentimentCount++
      }
      tagStats[tag].hoursAgo.push((Date.now() - new Date(post.created_at).getTime()) / HOUR)
    }
  }

  // حساب النمو والـ velocity
  const trends: TrendingTopic[] = []
  for (const [tag, stats] of Object.entries(tagStats)) {
    if (stats.count < 2) continue
    const avgAge = stats.hoursAgo.reduce((a, b) => a + b, 0) / stats.hoursAgo.length
    const velocity = stats.engagement / Math.max(1, avgAge)
    const growthRate = stats.count / Math.max(1, avgAge / 6) // نمو لكل 6 ساعات

    trends.push({
      tag,
      postsCount: stats.count,
      growthRate,
      velocity,
      category: stats.category,
      sentiment: stats.sentimentCount > 0 ? stats.sentimentSum / stats.sentimentCount : 0,
    })
  }

  // ترتيب: النمو أولاً، ثم الـ velocity
  trends.sort((a, b) => (b.growthRate + b.velocity / 10) - (a.growthRate + a.velocity / 10))
  return trends.slice(0, 20)
}

// ============= Recommended Users =============

export interface RecommendedUser {
  profile: Profile
  score: number
  reason: string
}

/**
 * توصية بمستخدمين للمتابعة (Collaborative filtering)
 * بناءً على: متابعين متبادلين + اهتمامات مشتركة
 */
export async function recommendUsers(
  userId: string,
  limit = 5
): Promise<RecommendedUser[]> {
  // 1) بناء ملف المستخدم
  const profile = await buildUserProfile(userId)

  // 2) جلب متابعات المستخدم (لإستبعادهم)
  const { data: myFollows } = await supabase
    .from('follows')
    .select('followed_id')
    .eq('follower_id', userId)
  const myFollowing = new Set((myFollows || []).map((f) => f.followed_id))
  myFollowing.add(userId) // استبعاد نفسه

  // 3) جلب المستخدمين الذين يتابعهم اهتماماتي المشتركة
  // المستخدمون الذين لديهم منشورات في فئاتي المفضلة
  const topCategories = Object.entries(profile.interestVector)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 3)
    .map(([cat]) => cat)

  if (topCategories.length === 0) return []

  const { data: candidates } = await supabase
    .from('profiles')
    .select('*')
    .not('id', 'in', `(${Array.from(myFollowing).join(',')})`)
    .limit(50)

  if (!candidates || candidates.length === 0) return []

  // 4) ترتيب المرشحين
  const recommendations: RecommendedUser[] = []
  for (const candidate of candidates) {
    // جلب آخر 5 منشورات للمستخدم المرشح
    const { data: candidatePosts } = await supabase
      .from('posts')
      .select('category, tags, likes_count')
      .eq('user_id', candidate.id)
      .order('created_at', { ascending: false })
      .limit(5)

    if (!candidatePosts || candidatePosts.length === 0) continue

    let score = 0
    let reason = ''

    // تطابق الفئة
    const matchingCats = candidatePosts.filter((p) =>
      topCategories.includes(p.category)
    ).length
    score += matchingCats * 20
    if (matchingCats > 0) reason = `${matchingCats} منشورات في فئاتك المفضلة`

    // عدد المتابعين (مؤثر)
    score += Math.min(20, (candidate.followers_count || 0) / 50)

    // التحقق
    if (candidate.is_verified) score += 15

    // التفاعل
    const totalEng = candidatePosts.reduce((sum, p) => sum + (p.likes_count || 0), 0)
    score += Math.min(15, totalEng / 10)

    if (score > 30) {
      recommendations.push({
        profile: candidate as Profile,
        score,
        reason: reason || 'مستخدم نشط',
      })
    }
  }

  recommendations.sort((a, b) => b.score - a.score)
  return recommendations.slice(0, limit)
}

// ============= Predictive Cache =============

/**
 * تنبؤ بالمنشورات التي سيفتحها المستخدم (للتخزين المؤقت)
 */
export function predictNextViews(
  feed: ScoredPost[],
  recentlyViewed: string[],
  limit = 5
): string[] {
  // المنشورات عالية الدرجات + غير مفتوحة بعد
  return feed
    .filter((sp) => !recentlyViewed.includes(sp.post.id))
    .slice(0, limit)
    .map((sp) => sp.post.id)
}
