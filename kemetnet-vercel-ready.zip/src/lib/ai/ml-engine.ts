// src/lib/ai/ml-engine.ts
// محرك التعلم الآلي - KemetNet ML Engine
// خوارزميات متقدمة: TF-IDF, Cosine Similarity, K-Means clustering,
// Collaborative Filtering, Behavioral Pattern Recognition

import { tokenize, extractKeywords } from './content-analyzer'

// ============================================================
// 1) TF-IDF Vectorizer — تحويل النص إلى متجه عددي
// ============================================================

export interface DocumentVector {
  id: string
  vector: Map<string, number>
  magnitude: number
}

/**
 * بناء متجهات TF-IDF لمجموعة مستندات
 * TF (Term Frequency): تكرار الكلمة / إجمالي الكلمات
 * IDF (Inverse Document Frequency): log(N / df) — N=عدد المستندات، df=عدد المستندات التي تحتوي الكلمة
 */
export class TFIDFVectorizer {
  private documents: Map<string, string> = new Map()
  private df: Map<string, number> = new Map()  // Document Frequency
  private idf: Map<string, number> = new Map()
  private vectors: Map<string, DocumentVector> = new Map()
  private isComputed = false

  /** إضافة مستند للمجموعة */
  addDocument(id: string, content: string): void {
    this.documents.set(id, content)
    this.isComputed = false
  }

  /** إضافة عدة مستندات */
  addDocuments(docs: { id: string; content: string }[]): void {
    for (const doc of docs) {
      this.documents.set(doc.id, doc.content)
    }
    this.isComputed = false
  }

  /** حساب IDF لكل كلمة */
  computeIDF(): void {
    this.df.clear()
    const N = this.documents.size

    for (const content of this.documents.values()) {
      const tokens = new Set(tokenize(content))
      for (const token of tokens) {
        this.df.set(token, (this.df.get(token) || 0) + 1)
      }
    }

    // IDF = log(N / (df + 1))  +1 لتجنب القسمة على صفر
    this.idf.clear()
    for (const [token, df] of this.df) {
      this.idf.set(token, Math.log((N + 1) / (df + 1)) + 1)
    }
    this.isComputed = true
  }

  /** تحويل مستند إلى متجه TF-IDF */
  vectorize(id: string): DocumentVector | null {
    if (!this.isComputed) this.computeIDF()

    const content = this.documents.get(id)
    if (!content) return null

    const tokens = tokenize(content)
    const tf = new Map<string, number>()
    const total = tokens.length || 1

    // TF = count / total
    for (const token of tokens) {
      tf.set(token, (tf.get(token) || 0) + 1)
    }
    tf.forEach((v, k) => tf.set(k, v / total))

    // TF-IDF = TF * IDF
    const vector = new Map<string, number>()
    let magnitude = 0
    for (const [token, tfVal] of tf) {
      const idfVal = this.idf.get(token) || 0
      const tfidf = tfVal * idfVal
      if (tfidf > 0) {
        vector.set(token, tfidf)
        magnitude += tfidf * tfidf
      }
    }
    magnitude = Math.sqrt(magnitude)

    return { id, vector, magnitude }
  }

  /** تحويل كل المستندات */
  vectorizeAll(): Map<string, DocumentVector> {
    this.vectors.clear()
    for (const id of this.documents.keys()) {
      const vec = this.vectorize(id)
      if (vec) this.vectors.set(id, vec)
    }
    return this.vectors
  }

  /** حساب التشابه Cosine بين متجهين */
  static cosineSimilarity(a: DocumentVector, b: DocumentVector): number {
    if (a.magnitude === 0 || b.magnitude === 0) return 0

    let dot = 0
    // التكرار على المتجه الأصغر لكفاءة أعلى
    const smaller = a.vector.size < b.vector.size ? a : b
    const larger = smaller === a ? b : a

    for (const [token, val] of smaller.vector) {
      const otherVal = larger.vector.get(token)
      if (otherVal) {
        dot += val * otherVal
      }
    }

    return dot / (a.magnitude * b.magnitude)
  }
}

// ============================================================
// 2) K-Means Clustering — تجميع المحتوى/Mستخدمين تلقائيًا
// ============================================================

export interface Cluster {
  id: number
  centroid: Map<string, number>
  members: string[]
  label?: string
}

/**
 * K-Means clustering لـ DocumentVectors
 * يجمّع المستندات المتشابهة في k مجموعات
 */
export function kMeansCluster(
  vectors: Map<string, DocumentVector>,
  k: number = 5,
  maxIterations: number = 20
): Cluster[] {
  const ids = Array.from(vectors.keys())
  if (ids.length < k) {
    // إذا عدد المستندات أقل من k، نُنشئ cluster لكل مستند
    return ids.slice(0, ids.length).map((id, i) => ({
      id: i,
      centroid: vectors.get(id)!.vector,
      members: [id],
    }))
  }

  // 1) اختيار k نقاط عشوائية كـ centroids أولية
  const centroids: Map<string, number>[] = []
  const usedIndices = new Set<number>()
  while (centroids.length < k) {
    const idx = Math.floor(Math.random() * ids.length)
    if (!usedIndices.has(idx)) {
      usedIndices.add(idx)
      centroids.push(new Map(vectors.get(ids[idx])!.vector))
    }
  }

  let clusters: Cluster[] = []
  let converged = false
  let iteration = 0

  while (!converged && iteration < maxIterations) {
    iteration++
    // 2) إسناد كل مستند لأقرب centroid
    const newClusters: Cluster[] = centroids.map((c, i) => ({
      id: i,
      centroid: c,
      members: [],
    }))

    for (const id of ids) {
      const vec = vectors.get(id)!
      let bestCluster = 0
      let bestSim = -1

      for (let i = 0; i < centroids.length; i++) {
        const centroidVec: DocumentVector = {
          id: `centroid-${i}`,
          vector: centroids[i],
          magnitude: Math.sqrt(
            Array.from(centroids[i].values()).reduce((s, v) => s + v * v, 0)
          ),
        }
        const sim = TFIDFVectorizer.cosineSimilarity(vec, centroidVec)
        if (sim > bestSim) {
          bestSim = sim
          bestCluster = i
        }
      }

      newClusters[bestCluster].members.push(id)
    }

    // 3) إعادة حساب centroids (متوسط أعضاء كل cluster)
    const newCentroids: Map<string, number>[] = []
    for (const cluster of newClusters) {
      const newCentroid = new Map<string, number>()
      const memberCount = cluster.members.length || 1

      for (const memberId of cluster.members) {
        const memberVec = vectors.get(memberId)!.vector
        for (const [token, val] of memberVec) {
          newCentroid.set(token, (newCentroid.get(token) || 0) + val / memberCount)
        }
      }

      newCentroids.push(newCentroid)
    }

    // فحص التقارب: هل تغيرت الـ centroids؟
    converged = true
    for (let i = 0; i < k; i++) {
      const oldCentroid = centroids[i]
      const newCentroid = newCentroids[i]
      // فحص بسيط: هل نفس الأعضاء؟
      if (clusters.length > 0 && clusters[i]) {
        const oldMembers = new Set(clusters[i].members)
        const newMembers = new Set(newClusters[i].members)
        if (oldMembers.size !== newMembers.size) {
          converged = false
          break
        }
        for (const m of oldMembers) {
          if (!newMembers.has(m)) {
            converged = false
            break
          }
        }
      } else {
        converged = false
      }
    }

    centroids.length = 0
    centroids.push(...newCentroids)
    clusters = newClusters
  }

  // 4) إضافة labels تلقائية (أكثر الكلمات تكرارًا في كل cluster)
  for (const cluster of clusters) {
    if (cluster.members.length > 0) {
      const topKeywords: Record<string, number> = {}
      for (const memberId of cluster.members) {
        const memberVec = vectors.get(memberId)!.vector
        for (const [token, val] of memberVec) {
          topKeywords[token] = (topKeywords[token] || 0) + val
        }
      }
      const sortedKeywords = Object.entries(topKeywords)
        .sort(([, a], [, b]) => b - a)
        .slice(0, 3)
        .map(([k]) => k)
      cluster.label = sortedKeywords.join(', ')
    }
  }

  return clusters
}

// ============================================================
// 3) Collaborative Filtering — توصيات تعاونية
// ============================================================

export interface UserInteraction {
  userId: string
  itemId: string
  rating: number  // 0-1 (0=لا تفاعل، 1=تفاعل قوي)
  timestamp: number
}

/**
 * بناء مصفوفة تفاعل المستخدمين مع العناصر
 * مصفوفة users × items
 */
export class InteractionMatrix {
  private data: Map<string, Map<string, number>> = new Map()  // userId → (itemId → rating)

  addInteraction(userId: string, itemId: string, rating: number): void {
    if (!this.data.has(userId)) {
      this.data.set(userId, new Map())
    }
    // آخر تفاعل له أعلى وزن
    const existing = this.data.get(userId)!.get(itemId) || 0
    this.data.get(userId)!.set(itemId, Math.max(existing, rating))
  }

  /** الحصول على كل المستخدمين */
  getUsers(): string[] {
    return Array.from(this.data.keys())
  }

  /** الحصول على كل العناصر */
  getItems(): string[] {
    const items = new Set<string>()
    for (const userItems of this.data.values()) {
      for (const itemId of userItems.keys()) {
        items.add(itemId)
      }
    }
    return Array.from(items)
  }

  /** الحصول على تقييم مستخدم لعنصر */
  getRating(userId: string, itemId: string): number {
    return this.data.get(userId)?.get(itemId) || 0
  }

  /** الحصول على كل تقييمات مستخدم */
  getUserRatings(userId: string): Map<string, number> {
    return this.data.get(userId) || new Map()
  }

  /**
   * إيجاد مستخدمين مشابهين (User-based collaborative filtering)
   * يحسب Cosine Similarity بين المستخدم المحدد وكل المستخدمين الآخرين
   */
  findSimilarUsers(userId: string, limit: number = 10): { userId: string; similarity: number }[] {
    const targetRatings = this.getUserRatings(userId)
    if (targetRatings.size === 0) return []

    const targetMag = Math.sqrt(
      Array.from(targetRatings.values()).reduce((s, v) => s + v * v, 0)
    )
    if (targetMag === 0) return []

    const similarities: { userId: string; similarity: number }[] = []

    for (const otherUserId of this.data.keys()) {
      if (otherUserId === userId) continue

      const otherRatings = this.getUserRatings(otherUserId)
      if (otherRatings.size === 0) continue

      // Cosine similarity
      let dot = 0
      let otherMag = 0
      for (const [itemId, rating] of otherRatings) {
        otherMag += rating * rating
        const targetVal = targetRatings.get(itemId)
        if (targetVal) {
          dot += targetVal * rating
        }
      }
      otherMag = Math.sqrt(otherMag)
      if (otherMag === 0) continue

      const sim = dot / (targetMag * otherMag)
      if (sim > 0) {
        similarities.push({ userId: otherUserId, similarity: sim })
      }
    }

    similarities.sort((a, b) => b.similarity - a.similarity)
    return similarities.slice(0, limit)
  }

  /**
   * توصية عناصر لمستخدم (بناءً على مستخدمين مشابهين)
   * User-based CF: أعلى العناصر التي تفاعل معها المستخدمون المشابهون
   */
  recommendItems(userId: string, limit: number = 10): { itemId: string; score: number }[] {
    const similarUsers = this.findSimilarUsers(userId, 20)
    if (similarUsers.length === 0) return []

    const userItems = new Set(this.getUserRatings(userId).keys())
    const recommendations: Map<string, number> = new Map()

    // تجميع تقييمات المستخدمين المشابهين موزونة بالتشابه
    for (const { userId: otherId, similarity } of similarUsers) {
      const otherRatings = this.getUserRatings(otherId)
      for (const [itemId, rating] of otherRatings) {
        // استبعاد العناصر التي تفاعل معها المستخدم بالفعل
        if (userItems.has(itemId)) continue

        const current = recommendations.get(itemId) || 0
        recommendations.set(itemId, current + similarity * rating)
      }
    }

    return Array.from(recommendations.entries())
      .map(([itemId, score]) => ({ itemId, score }))
      .sort((a, b) => b.score - a.score)
      .slice(0, limit)
  }

  /**
   * Item-based CF: إيجاد عناصر مشابهة لعنصر محدد
   * يحسب التشابه بين العناصر بناءً على من تفاعل معها
   */
  findSimilarItems(itemId: string, limit: number = 10): { itemId: string; similarity: number }[] {
    const itemRatings: Map<string, { userId: string; rating: number }[]> = new Map()

    // تجميع تقييمات كل مستخدم لهذا العنصر
    for (const [userId, ratings] of this.data) {
      const rating = ratings.get(itemId)
      if (rating) {
        if (!itemRatings.has(itemId)) itemRatings.set(itemId, [])
        itemRatings.get(itemId)!.push({ userId, rating })
      }
    }

    const targetInteractions = itemRatings.get(itemId) || []
    if (targetInteractions.length === 0) return []

    // حساب التشابه بين العنصر المحدد وكل العناصر الأخرى
    const allItems = this.getItems()
    const similarities: { itemId: string; similarity: number }[] = []

    for (const otherItemId of allItems) {
      if (otherItemId === itemId) continue

      let dot = 0
      let magA = 0
      let magB = 0

      for (const { userId, rating } of targetInteractions) {
        magA += rating * rating
        const otherRating = this.getRating(userId, otherItemId)
        if (otherRating) {
          dot += rating * otherRating
        }
      }

      // حساب magnitude للعنصر الآخر
      for (const userId of this.data.keys()) {
        const r = this.getRating(userId, otherItemId)
        if (r) magB += r * r
      }

      if (magA > 0 && magB > 0) {
        const sim = dot / (Math.sqrt(magA) * Math.sqrt(magB))
        if (sim > 0) {
          similarities.push({ itemId: otherItemId, similarity: sim })
        }
      }
    }

    similarities.sort((a, b) => b.similarity - a.similarity)
    return similarities.slice(0, limit)
  }
}

// ============================================================
// 4) Behavioral Pattern Recognition — التعلم من سلوك المستخدم
// ============================================================

export interface BehaviorPattern {
  userId: string
  // أنماط الوقت
  activeHours: number[]               // ساعات النشاط (0-23)
  activeDays: number[]                // أيام الأسبوع (0-6)
  avgSessionMinutes: number
  // أنماط التفاعل
  preferredCategories: string[]
  avgPostLength: number
  avgReadTime: number                 // متوسط وقت القراءة
  // أنماط التفضيل
  likesLongPosts: boolean
  likesImages: boolean
  likesQuestions: boolean
  // أنماط النشر
  postingFrequency: 'high' | 'medium' | 'low'
  avgPostsPerWeek: number
  // نموذج النشاط
  engagementScore: number             // 0-100
  influenceScore: number              // 0-100
}

/**
 * تحليل سلوك مستخدم من نشاطه التاريخي
 */
export function analyzeBehaviorPattern(
  userId: string,
  interactions: {
    type: 'like' | 'comment' | 'post' | 'follow' | 'view' | 'share'
    timestamp: number
    targetId: string
    targetCategory?: string
    targetLength?: number
    targetHasImage?: boolean
  }[]
): BehaviorPattern {
  const hourCounts = new Array(24).fill(0)
  const dayCounts = new Array(7).fill(0)
  const categoryCounts: Record<string, number> = {}
  const postLengths: number[] = []
  let imageInteractions = 0
  let totalInteractions = 0
  let postsCount = 0

  for (const interaction of interactions) {
    const date = new Date(interaction.timestamp)
    hourCounts[date.getHours()]++
    dayCounts[date.getDay()]++

    if (interaction.targetCategory) {
      categoryCounts[interaction.targetCategory] =
        (categoryCounts[interaction.targetCategory] || 0) + 1
    }

    if (interaction.targetLength) {
      postLengths.push(interaction.targetLength)
    }

    if (interaction.targetHasImage) {
      imageInteractions++
    }

    totalInteractions++

    if (interaction.type === 'post') {
      postsCount++
    }
  }

  // أنماط الوقت (أعلى 5 ساعات نشاط)
  const activeHours = hourCounts
    .map((count, hour) => ({ hour, count }))
    .filter((h) => h.count > 0)
    .sort((a, b) => b.count - a.count)
    .slice(0, 5)
    .map((h) => h.hour)

  // أيام الأسبوع النشطة
  const activeDays = dayCounts
    .map((count, day) => ({ day, count }))
    .filter((d) => d.count > 0)
    .sort((a, b) => b.count - a.count)
    .slice(0, 3)
    .map((d) => d.day)

  // الفئات المفضلة (أعلى 3)
  const preferredCategories = Object.entries(categoryCounts)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 3)
    .map(([cat]) => cat)

  // متوسط طول المنشورات المتفاعل معها
  const avgPostLength = postLengths.length > 0
    ? Math.round(postLengths.reduce((a, b) => a + b, 0) / postLengths.length)
    : 0

  // تقدير متوسط وقت القراءة (بناءً على طول المنشورات)
  const avgReadTime = Math.round(avgPostLength / 200) // 200 كلمة/دقيقة

  // تفضيل الصور
  const likesImages = totalInteractions > 0 && (imageInteractions / totalInteractions) > 0.4

  // تفضيل المنشورات الطويلة
  const likesLongPosts = avgPostLength > 300

  // تفضيل الأسئلة (إذا وُجدت "؟" في المنشورات)
  const likesQuestions = false  // يحتاج بيانات إضافية

  // تكرار النشر
  const avgPostsPerWeek = Math.round((postsCount / Math.max(1, interactions.length / 10)) * 7)
  const postingFrequency: BehaviorPattern['postingFrequency'] =
    avgPostsPerWeek >= 10 ? 'high' : avgPostsPerWeek >= 3 ? 'medium' : 'low'

  // درجة التفاعل (0-100)
  const engagementScore = Math.min(100, Math.round(totalInteractions / 10))

  // درجة التأثير (بناءً على عدد المنشورات + التفاعل)
  const influenceScore = Math.min(100, Math.round((postsCount * 5 + totalInteractions) / 5))

  return {
    userId,
    activeHours,
    activeDays,
    avgSessionMinutes: Math.round(totalInteractions * 2), // تقدير: 2 دقيقة لكل تفاعل
    preferredCategories,
    avgPostLength,
    avgReadTime,
    likesLongPosts,
    likesImages,
    likesQuestions,
    postingFrequency,
    avgPostsPerWeek,
    engagementScore,
    influenceScore,
  }
}

// ============================================================
// 5) Engagement Velocity Predictor — التنبؤ بـ viral posts
// ============================================================

export interface PostVelocity {
  postId: string
  currentEngagement: number
  velocity: number             // تفاعل/ساعة
  acceleration: number        // تغيير في الـ velocity
  predictedFinalEngagement: number
  isViral: boolean
  viralProbability: number    // 0-1
}

/**
 * التنبؤ بـ viral posts بناءً على معدل النمو
 * يستخدم: velocity + acceleration + time decay
 */
export function predictViralPosts(
  posts: {
    id: string
    createdAt: string
    likes: number
    comments: number
    reposts: number
    // تاريخ القياسات السابقة (اختياري)
    historical?: { timestamp: number; total: number }[]
  }[]
): PostVelocity[] {
  const HOUR = 60 * 60 * 1000
  const now = Date.now()

  return posts
    .map((post) => {
      const ageMs = now - new Date(post.createdAt).getTime()
      const ageHours = Math.max(1, ageMs / HOUR)

      const currentEngagement =
        (post.likes || 0) + (post.comments || 0) * 2 + (post.reposts || 0) * 3

      // velocity: تفاعل/ساعة
      const velocity = currentEngagement / ageHours

      // acceleration: تغيير velocity (إذا وُجد تاريخ)
      let acceleration = 0
      if (post.historical && post.historical.length >= 2) {
        const recent = post.historical[post.historical.length - 1]
        const previous = post.historical[post.historical.length - 2]
        const timeDiff = (recent.timestamp - previous.timestamp) / HOUR
        if (timeDiff > 0) {
          const recentVelocity = recent.total / Math.max(0.1, (now - recent.timestamp) / HOUR)
          const prevVelocity = previous.total / Math.max(0.1, (now - previous.timestamp) / HOUR)
          acceleration = (recentVelocity - prevVelocity) / timeDiff
        }
      }

      // التنبؤ بالتفاعل النهائي (بناءً على نموذج logistic)
      // منشور viral عادةً يحقق 80% من تفاعله النهائي خلال 24 ساعة
      const hoursAgo = ageHours
      let predictedFinalEngagement: number
      if (hoursAgo < 24) {
        // في أول 24 ساعة: التنبؤ بناءً على النمو الحالي
        const growthRate = velocity * 24 // إذا استمر بنفس المعدل
        predictedFinalEngagement = Math.round(currentEngagement + growthRate * 0.5)
      } else {
        // بعد 24 ساعة: التباطؤ الطبيعي
        predictedFinalEngagement = Math.round(currentEngagement * 1.2)
      }

      // احتمالية Viral: بناءً على velocity مقارنة بـ threshold
      // viral = velocity > 5 تفاعلات/ساعة في أول 24 ساعة
      const isViral = hoursAgo < 24 && velocity > 5
      const viralProbability = Math.min(1, velocity / 10)

      return {
        postId: post.id,
        currentEngagement,
        velocity: Math.round(velocity * 10) / 10,
        acceleration: Math.round(acceleration * 10) / 10,
        predictedFinalEngagement,
        isViral,
        viralProbability: Math.round(viralProbability * 100) / 100,
      }
    })
    .sort((a, b) => b.viralProbability - a.viralProbability)
}

// ============================================================
// 6) Adaptive Learning — تعديل النموذج بناءً على التغذية الراجعة
// ============================================================

export interface AdaptiveWeights {
  recency: number        // وزن الحداثة
  relevance: number      // وزن الصلة
  engagement: number     // وزم التفاعل
  quality: number        // وزن الجودة
  diversity: number      // وزن التنوع
  authorship: number     // وزم المؤلف
}

/**
 * نموذج تعلم تكيّفي — يعدّل أوزان خوارزمية الترتيب
 * بناءً على تفاعل المستخدم مع المنشورات المُقترحة
 *
 * إذا تفاعل المستخدم مع منشور عالي الصلة → زِد وزن الصلة
 * إذا تفاعل مع منشور حديث → زِد وزن الحداثة
 * إذا تجاهل منشور عالي التفاعل → قلّل وزن التفاعل
 */
export class AdaptiveLearner {
  private weights: AdaptiveWeights = {
    recency: 0.20,
    relevance: 0.30,
    engagement: 0.20,
    quality: 0.15,
    diversity: 0.10,
    authorship: 0.05,
  }

  private learningRate = 0.02
  private interactions: { postId: string; signals: Record<string, number>; interacted: boolean }[] = []

  /** تسجيل تفاعل المستخدم مع منشور */
  recordInteraction(postId: string, signals: Record<string, number>, interacted: boolean): void {
    this.interactions.push({ postId, signals, interacted })

    // تعديل الأوزان فورًا
    if (interacted) {
      // إذا تفاعل، زِد أوزان الإشارات العالية
      for (const [key, value] of Object.entries(signals)) {
        if (value > 50 && key in this.weights) {
          (this.weights as any)[key] = Math.min(0.5, (this.weights as any)[key] + this.learningRate)
        }
      }
    } else {
      // إذا تجاهل، قلّل أوزان الإشارات العالية
      for (const [key, value] of Object.entries(signals)) {
        if (value > 70 && key in this.weights) {
          (this.weights as any)[key] = Math.max(0.05, (this.weights as any)[key] - this.learningRate * 0.5)
        }
      }
    }

    // تطبيع الأوزان (المجموع = 1)
    const total = Object.values(this.weights).reduce((a, b) => a + b, 0)
    if (total > 0) {
      for (const key of Object.keys(this.weights)) {
        (this.weights as any)[key] /= total
      }
    }
  }

  getWeights(): AdaptiveWeights {
    return { ...this.weights }
  }

  /** إعادة تعيين الأوزان للقيم الافتراضية */
  reset(): void {
    this.weights = {
      recency: 0.20,
      relevance: 0.30,
      engagement: 0.20,
      quality: 0.15,
      diversity: 0.10,
      authorship: 0.05,
    }
    this.interactions = []
  }
}

// ============================================================
// 7) Semantic Search — بحث دلالي بدلاً من بحث الكلمات فقط
// ============================================================

export interface SearchResult {
  id: string
  score: number
  matchedTerms: string[]
}

/**
 * بحث دلالي باستخدام TF-IDF + Cosine Similarity
 * يدعم:
 *  - البحث عن كلمات مفتاحية (مثل البحث التقليدي)
 *  - البحث عن منشورات مشابهة (find similar)
 *  - البحث الغامض (fuzzy matching) — يتحمل الأخطاء الإملائية البسيطة
 */
export class SemanticSearch {
  private vectorizer: TFIDFVectorizer
  private vectors: Map<string, DocumentVector>
  private contents: Map<string, string> = new Map()

  constructor(documents: { id: string; content: string }[]) {
    this.vectorizer = new TFIDFVectorizer()
    for (const doc of documents) {
      this.vectorizer.addDocument(doc.id, doc.content)
      this.contents.set(doc.id, doc.content)
    }
    this.vectors = this.vectorizer.vectorizeAll()
  }

  /**
   * بحث عن استعلام نصي
   */
  search(query: string, limit: number = 10): SearchResult[] {
    // تحويل الاستعلام إلى متجه مؤقت
    const queryId = '__query__'
    this.vectorizer.addDocument(queryId, query)
    const queryVec = this.vectorizer.vectorize(queryId)

    if (!queryVec) return []

    const results: SearchResult[] = []
    for (const [id, docVec] of this.vectors) {
      const score = TFIDFVectorizer.cosineSimilarity(queryVec, docVec)
      if (score > 0.01) {
        // استخراج الكلمات المتطابقة
        const matchedTerms: string[] = []
        const queryTokens = new Set(tokenize(query))
        for (const token of docVec.vector.keys()) {
          if (queryTokens.has(token)) {
            matchedTerms.push(token)
          }
        }
        results.push({ id, score, matchedTerms })
      }
    }

    // إزالة الاستعلام المؤقت
    this.vectorizer.addDocuments([]) // clear doesn't exist, but addDocuments([]) is no-op
    this.contents.delete(queryId)

    results.sort((a, b) => b.score - a.score)
    return results.slice(0, limit)
  }

  /**
   * إيجاد مستندات مشابهة لمستند محدد
   */
  findSimilar(id: string, limit: number = 5): SearchResult[] {
    const targetVec = this.vectors.get(id)
    if (!targetVec) return []

    const results: SearchResult[] = []
    for (const [otherId, otherVec] of this.vectors) {
      if (otherId === id) continue
      const score = TFIDFVectorizer.cosineSimilarity(targetVec, otherVec)
      if (score > 0.05) {
        results.push({ id: otherId, score, matchedTerms: [] })
      }
    }

    results.sort((a, b) => b.score - a.score)
    return results.slice(0, limit)
  }

  /**
   * بحث غامض (Fuzzy matching) — يتحمل الأخطاء الإملائية
   * يستخدم Levenshtein distance
   */
  static fuzzyMatch(query: string, target: string, maxDistance: number = 2): boolean {
    const q = query.toLowerCase().trim()
    const t = target.toLowerCase().trim()
    if (q === t) return true
    if (Math.abs(q.length - t.length) > maxDistance) return false

    // Levenshtein distance
    const matrix: number[][] = []
    for (let i = 0; i <= q.length; i++) {
      matrix[i] = [i]
    }
    for (let j = 0; j <= t.length; j++) {
      matrix[0][j] = j
    }
    for (let i = 1; i <= q.length; i++) {
      for (let j = 1; j <= t.length; j++) {
        const cost = q[i - 1] === t[j - 1] ? 0 : 1
        matrix[i][j] = Math.min(
          matrix[i - 1][j] + 1,        // deletion
          matrix[i][j - 1] + 1,        // insertion
          matrix[i - 1][j - 1] + cost   // substitution
        )
      }
    }

    return matrix[q.length][t.length] <= maxDistance
  }
}

// ============================================================
// 8) Anomaly Detection — كشف السلوك الشاذ (spam/bots)
// ============================================================

export interface AnomalyScore {
  userId: string
  score: number              // 0-100 (أعلى = أكثر شذوذًا)
  reasons: string[]
}

/**
 * كشف السلوك الشاذ (spambots، حسابات وهمية، إساءة)
 * يفحص: معدل النشر، تكرار المحتوى، أوقات النشاط غير الطبيعية
 */
export function detectAnomalies(
  users: {
    userId: string
    postsCount: number
    commentsCount: number
    likesCount: number
    followersCount: number
    followingCount: number
    accountAgeHours: number
    activeHours: number[]
    avgPostLength: number
  }[]
): AnomalyScore[] {
  return users.map((user) => {
    const reasons: string[] = []
    let score = 0

    // 1) معدل نشر مرتفع جدًا (أكثر من 50 منشور/ساعة)
    const postingRate = user.postsCount / Math.max(1, user.accountAgeHours)
    if (postingRate > 5) {
      score += 30
      reasons.push(`معدل نشر مرتفع: ${postingRate.toFixed(1)} منشور/ساعة`)
    }

    // 2) نسبة متابعين/متابَعين غير طبيعية (يتبع الكثير لكن لا يتابعه أحد)
    const followRatio = user.followingCount / Math.max(1, user.followersCount)
    if (followRatio > 10 && user.followingCount > 50) {
      score += 25
      reasons.push(`يتبع ${user.followingCount} لكن لديه ${user.followersCount} متابع فقط`)
    }

    // 3) نشاط في ساعات غير طبيعية (2-5 صباحًا)
    const lateNightActivity = user.activeHours.filter((h) => h >= 2 && h <= 5).length
    if (lateNightActivity > 3) {
      score += 15
      reasons.push(`نشاط في سوات غير طبيعية (${lateNightActivity} ساعات 2-5 صباحًا)`)
    }

    // 4) منشورات قصيرة جدًا (أقل من 10 أحرف في المتوسط)
    if (user.avgPostLength > 0 && user.avgPostLength < 10) {
      score += 20
      reasons.push(`متوسط طول المنشورات قصير جدًا (${user.avgPostLength} حرف)`)
    }

    // 5) حساب جديد لكن نشاط مرتفع
    if (user.accountAgeHours < 24 && user.postsCount > 20) {
      score += 25
      reasons.push(`حساب جديد (${Math.round(user.accountAgeHours)} ساعة) لكن ${user.postsCount} منشور`)
    }

    // 6) تفاعل منخفض رغم النشر الكثير (لا أحد يهتم بمنشوراته)
    const engagementRatio = user.likesCount / Math.max(1, user.postsCount)
    if (user.postsCount > 10 && engagementRatio < 0.5) {
      score += 15
      reasons.push(`تفاعل منخفض (${engagementRatio.toFixed(1)} إعجاب/منشور)`)
    }

    return {
      userId: user.userId,
      score: Math.min(100, score),
      reasons,
    }
  }).sort((a, b) => b.score - a.score)
}
