// src/lib/ai/content-analyzer.ts
// محرك تحليل المحتوى الذكي - KemetNet AI Engine
// يحلل النص العربي ويستخرج: كلمات مفتاحية، جودة، مشاعر، تصنيف تلقائي

// ============= أدوات معالجة النص العربي =============

const ARABIC_STOPWORDS = new Set([
  'في', 'من', 'على', 'الى', 'عن', 'مع', 'هذا', 'هذه', 'ذلك', 'تلك', 'الذي',
  'التي', 'الذين', 'اللاتي', 'اللواتي', 'ما', 'ماذا', 'لماذا', 'كيف', 'اين',
  'متى', 'هل', 'كم', 'انا', 'انت', 'هو', 'هي', 'نحن', 'هم', 'هن', 'كان',
  'كانت', 'يكون', 'تكون', 'قد', 'لقد', 'كل', 'بعض', 'غير', 'بين', 'حول',
  'لكن', 'او', 'ثم', 'حتى', 'اذا', 'عند', 'عندما', 'سوف', 'سيتم', 'يمكن',
  'يجب', 'ال', 'و', 'ف', 'ب', 'ل', 'ك', 'لـ', 'ان', 'انه', 'انها', 'بها',
  'به', 'لها', 'له', 'فيه', 'فيها', 'عليه', 'عليها', 'منه', 'منها',
])

const POSITIVE_WORDS = new Set([
  'جميل', 'رائع', 'ممتاز', 'جيد', 'سعيد', 'فرح', 'حب', 'احب', 'مذهل',
  'ابداع', 'رائعة', 'جميلة', 'مميز', 'فريد', 'سعادة', 'امل', 'تفاؤل',
  'نجاح', 'ناجح', 'تطور', 'تقدم', 'انجاز', 'فخر', 'اعتزاز', 'شكرا', 'ممنون',
])

const NEGATIVE_WORDS = new Set([
  'سيء', 'سيئة', 'كره', 'اكره', 'حزين', 'حزن', 'غضب', 'غاضب', 'فشل',
  'مشكلة', 'صعب', 'صعبة', 'تعب', 'متعب', 'مرهق', 'يأس', 'احباط', 'قلق',
  'خوف', 'خائف', 'مؤلم', 'الم', 'مرض', 'مرير', 'كارثة', 'فضيحة', 'عار',
])

const SPAM_LINK_RE = /(http|https):\/\/[^\s]+/gi
const SPAM_PHONE_RE = /\b\d{8,}\b/g
const SPAM_REPEAT_RE = /(.)\1{4,}/g
const SPAM_CAPS_RE = /[A-Z]{5,}/
const SPAM_PHRASE_RE = /(مجاني|ربح\s*سريع|اجعل\s*مليون|اشترك\s*الان|اضغط\s*هنا|كسب\s*المال)/gi

export const CONTENT_CATEGORIES = [
  'inspire', 'tech', 'art', 'travel', 'food', 'music', 'thoughts',
] as const
export type ContentCategory = typeof CONTENT_CATEGORIES[number]

const CATEGORY_KEYWORDS: Record<ContentCategory, Set<string>> = {
  inspire: new Set(['الهام', 'تطوير', 'نجاح', 'تحفيز', 'حكمة', 'اقتباس', 'تفاؤل', 'حلم', 'طموح', 'هدف', 'اصرار', 'عزيمة', 'انجاز']),
  tech: new Set(['تقنية', 'تكنولوجيا', 'برمجة', 'كود', 'تطبيق', 'برنامج', 'ذكاء', 'اصطناعي', 'كمبيوتر', 'انترنت', 'موبايل', 'تطوير', 'تحديث', 'تقني']),
  art: new Set(['فن', 'رسم', 'تصميم', 'ابداع', 'الوان', 'لوحة', 'فنان', 'تصوير', 'موسيقى', 'فيلم', 'سينما', 'مسرح', 'شعر', 'ادب']),
  travel: new Set(['سفر', 'سياحة', 'رحلة', 'مغامرة', 'اكتشاف', 'مدينة', 'دولة', 'شاطئ', 'جبل', 'صحراء', 'معالم', 'ثقافة', 'تاريخ']),
  food: new Set(['طعام', 'اكل', 'طبخ', 'وصفة', 'مطبخ', 'مطعم', 'وجبة', 'فطور', 'غداء', 'عشاء', 'حلويات', 'مطبخي', 'طبخي', 'مذاق']),
  music: new Set(['موسيقى', 'اغنية', 'طرب', 'لحن', 'الحان', 'سيمفونية', 'بيانو', 'جيتار', 'كونسرت', 'مطرب', 'مغني', 'فرقة', 'البوم']),
  thoughts: new Set(['خواطر', 'تأمل', 'حياة', 'موت', 'حب', 'وفاء', 'صبر', 'امل', 'حكمة', 'فلسفة', 'روح', 'قلب', 'رومانسية', 'ذكريات']),
}

// ============= Tokenization =============

export function tokenize(text: string): string[] {
  if (!text) return []
  const normalized = text
    .replace(/[\u064B-\u0652\u0670]/g, '')
    .replace(/[إأآا]/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/ة/g, 'ه')
    .replace(/[^\u0600-\u06FFa-zA-Z0-9\s]/g, ' ')
    .toLowerCase()
    .trim()
  return normalized.split(/\s+/).filter((w) => w.length > 2 && !ARABIC_STOPWORDS.has(w))
}

export function extractKeywords(text: string, limit = 5): string[] {
  const tokens = tokenize(text)
  const freq: Record<string, number> = {}
  for (const token of tokens) {
    freq[token] = (freq[token] || 0) + 1
  }
  return Object.entries(freq)
    .sort(([, a], [, b]) => b - a)
    .slice(0, limit)
    .map(([word]) => word)
}

export function suggestTags(text: string, limit = 3): string[] {
  const keywords = extractKeywords(text, 15)
  return keywords
    .filter((w) => w.length >= 4)
    .slice(0, limit)
    .map((w) => w.replace(/[^\u0600-\u06FFa-zA-Z0-9]/g, ''))
}

// ============= TF-IDF Similarity =============

function termFrequencies(text: string): Map<string, number> {
  const tokens = tokenize(text)
  const tf = new Map<string, number>()
  const total = tokens.length || 1
  for (const t of tokens) {
    tf.set(t, (tf.get(t) || 0) + 1)
  }
  tf.forEach((v, k) => tf.set(k, v / total))
  return tf
}

export function similarity(textA: string, textB: string): number {
  const tfA = termFrequencies(textA)
  const tfB = termFrequencies(textB)
  let dot = 0
  let magA = 0
  let magB = 0
  for (const [term, va] of tfA) {
    magA += va * va
    if (tfB.has(term)) {
      dot += va * (tfB.get(term) || 0)
    }
  }
  for (const vb of tfB.values()) {
    magB += vb * vb
  }
  if (magA === 0 || magB === 0) return 0
  return dot / (Math.sqrt(magA) * Math.sqrt(magB))
}

export function findSimilar(
  target: string,
  candidates: { id: string; text: string }[],
  threshold = 0.3
): { id: string; score: number }[] {
  return candidates
    .map((c) => ({ id: c.id, score: similarity(target, c.text) }))
    .filter((r) => r.score >= threshold)
    .sort((a, b) => b.score - a.score)
}

// ============= Sentiment Analysis =============

export interface SentimentResult {
  score: number
  label: 'positive' | 'negative' | 'neutral'
  positiveWords: number
  negativeWords: number
}

export function analyzeSentiment(text: string): SentimentResult {
  const tokens = tokenize(text)
  let positive = 0
  let negative = 0
  for (const t of tokens) {
    if (POSITIVE_WORDS.has(t)) positive++
    if (NEGATIVE_WORDS.has(t)) negative++
  }
  const total = positive + negative
  let score = 0
  if (total > 0) {
    score = (positive - negative) / total
  }
  let label: SentimentResult['label'] = 'neutral'
  if (score > 0.2) label = 'positive'
  else if (score < -0.2) label = 'negative'
  return { score, label, positiveWords: positive, negativeWords: negative }
}

// ============= Quality Score =============

export interface ContentQuality {
  score: number
  length: 'too_short' | 'short' | 'good' | 'long' | 'too_long'
  hasHashtags: boolean
  hasImage: boolean
  readability: number
  uniqueness: number
  issues: string[]
}

export function assessQuality(
  content: string,
  options: { hasImage?: boolean; existingContents?: string[] } = {}
): ContentQuality {
  const issues: string[] = []
  const text = content.trim()
  const length = text.length
  const words = text.split(/\s+/).filter(Boolean).length

  let lengthCat: ContentQuality['length'] = 'good'
  if (length < 10) { lengthCat = 'too_short'; issues.push('محتوى قصير جدًا') }
  else if (length < 50) { lengthCat = 'short'; issues.push('محتوى قصير') }
  else if (length > 2000) { lengthCat = 'too_long'; issues.push('محتوى طويل جدًا') }
  else if (length > 1000) lengthCat = 'long'

  const hasHashtags = /#[^\s#]+/.test(text)
  if (!hasHashtags && words > 10) issues.push('لا توجد وسوم — أضف وسومًا لزيادة الوصول')

  const hasImage = !!options.hasImage
  if (!hasImage && words > 30) issues.push('أضف صورة لزيادة التفاعل')

  const sentences = text.split(/[.!?\n]+/).filter((s) => s.trim().length > 0)
  const avgSentenceLength = sentences.length > 0 ? words / sentences.length : words
  let readability = 70
  if (avgSentenceLength > 25) { readability -= 20; issues.push('جمل طويلة جدًا') }
  if (avgSentenceLength < 5 && words > 20) { readability -= 10; issues.push('جمل قصيرة جدًا') }

  let uniqueness = 100
  if (options.existingContents && options.existingContents.length > 0) {
    const maxSim = Math.max(
      ...options.existingContents.slice(0, 50).map((c) => similarity(text, c))
    )
    uniqueness = Math.max(0, 100 - maxSim * 100)
    if (uniqueness < 50) issues.push('محتوى مشابه لمنشورات أخرى')
  }

  const capsRatio = (text.match(/[A-Z\u0621-\u064A]/g) || []).length / Math.max(1, length)
  if (capsRatio > 0.7 && length > 30) { issues.push('استخدام مفرط للأحرف الكبيرة'); readability -= 15 }

  let score = 60
  score += hasHashtags ? 10 : 0
  score += hasImage ? 15 : 0
  score += (readability - 70) * 0.3
  score += (uniqueness - 50) * 0.2
  if (lengthCat === 'good') score += 10
  if (lengthCat === 'too_short' || lengthCat === 'too_long') score -= 15

  return {
    score: Math.max(0, Math.min(100, Math.round(score))),
    length: lengthCat,
    hasHashtags,
    hasImage,
    readability: Math.max(0, Math.min(100, Math.round(readability))),
    uniqueness: Math.round(uniqueness),
    issues,
  }
}

// ============= Auto-Categorization =============

export function autoCategorize(content: string): {
  category: ContentCategory
  confidence: number
  scores: Record<ContentCategory, number>
} {
  const tokens = tokenize(content)
  const scores: Record<ContentCategory, number> = {
    inspire: 0, tech: 0, art: 0, travel: 0, food: 0, music: 0, thoughts: 0,
  }
  for (const token of tokens) {
    for (const cat of CONTENT_CATEGORIES) {
      if (CATEGORY_KEYWORDS[cat].has(token)) {
        scores[cat] += 1
      }
    }
  }
  let bestCat: ContentCategory = 'thoughts'
  let bestScore = 0
  for (const cat of CONTENT_CATEGORIES) {
    if (scores[cat] > bestScore) {
      bestScore = scores[cat]
      bestCat = cat
    }
  }
  const total = Object.values(scores).reduce((a, b) => a + b, 0) || 1
  return {
    category: bestCat,
    confidence: bestScore / total,
    scores,
  }
}

// ============= Spam Detection =============

export interface SpamCheckResult {
  isSpam: boolean
  score: number
  reasons: string[]
}

export function detectSpam(content: string): SpamCheckResult {
  const reasons: string[] = []
  let score = 0

  const links = content.match(SPAM_LINK_RE) || []
  if (links.length >= 2) { score += 25; reasons.push('روابط كثيرة') }
  if (links.length >= 4) { score += 25; reasons.push('روابط مفرطة') }

  const phones = content.match(SPAM_PHONE_RE) || []
  if (phones.length >= 1) { score += 15; reasons.push('أرقام هاتف') }

  if (SPAM_REPEAT_RE.test(content)) {
    score += 20
    reasons.push('تكرار أحرف مفرط')
  }

  const capsRatio = (content.match(/[A-Z]/g) || []).length / Math.max(1, content.length)
  if (capsRatio > 0.5 && content.length > 30) {
    score += 15
    reasons.push('استخدام مفرط للأحرف الكبيرة')
  }

  if (SPAM_PHRASE_RE.test(content)) {
    score += 30
    reasons.push('كلمات مشبوهة (ربح/مجاني/إعلان)')
  }

  if (content.trim().length < 3) {
    score += 20
    reasons.push('محتوى قصير جدًا')
  }

  return {
    isSpam: score >= 50,
    score: Math.min(100, score),
    reasons,
  }
}

// ============= Reading Time =============

export function estimateReadingTime(content: string): number {
  const words = content.trim().split(/\s+/).filter(Boolean).length
  return Math.max(3, Math.round((words / 200) * 60))
}
