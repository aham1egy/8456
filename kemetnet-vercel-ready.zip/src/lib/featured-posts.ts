// src/lib/featured-posts.ts
// نظام المنشورات المميزة + التصويت

import { supabase, type Post } from './supabase/client'

// عتبة التصويت للتميز التلقائي
export const FEATURE_VOTE_THRESHOLD = 10

// ========================================
// التصويت على تمييز منشور
// ========================================

export async function voteForFeatured(
  postId: string,
  userId: string
): Promise<{ success: boolean; error?: string; voted?: boolean }> {
  try {
    // التحقق من عدم تصويت سابق
    const { data: existing } = await supabase
      .from('feature_votes')
      .select('id')
      .match({ post_id: postId, user_id: userId })
      .maybeSingle()

    if (existing) {
      // إلغاء التصويت
      const { error } = await supabase
        .from('feature_votes')
        .delete()
        .match({ post_id: postId, user_id: userId })

      if (error) {
        // [removed in production] '[voteForFeatured] delete error:', error
        return { success: false, error: 'تعذّر إلغاء التصويت' }
      }
      return { success: true, voted: false }
    }

    // إضافة تصويت
    const { error } = await supabase
      .from('feature_votes')
      .insert({ post_id: postId, user_id: userId })

    if (error) {
      if (error.message.includes('duplicate') || error.message.includes('unique') || error.code === '23505') {
        return { success: true, voted: true }
      }
      // [removed in production] '[voteForFeatured] insert error:', error
      return { success: false, error: 'تعذّر التصويت' }
    }

    return { success: true, voted: true }
  } catch (e) {
    // [removed in production] '[voteForFeatured] error:', e
    return { success: false, error: 'حدث خطأ' }
  }
}

// ========================================
// جلب المنشورات المميزة
// ========================================

export async function fetchFeaturedPosts(limit = 20): Promise<Post[]> {
  try {
    const { data, error } = await supabase
      .from('posts')
      .select('*, profile:profiles(*)')
      .eq('is_featured', true)
      .order('featured_at', { ascending: false })
      .limit(limit)

    if (error || !data) {
      // [removed in production] '[fetchFeaturedPosts] error:', error
      return []
    }

    return data as Post[]
  } catch (e) {
    // [removed in production] '[fetchFeaturedPosts] error:', e
    return []
  }
}

// ========================================
// جلب المنشورات المرشحة للتميز (أعلى التصويتات)
// ========================================

export async function fetchTrendingForFeature(
  limit = 10
): Promise<Post[]> {
  try {
    const { data, error } = await supabase
      .from('posts')
      .select('*, profile:profiles(*)')
      .eq('is_featured', false)
      .is('repost_of', null)
      .order('featured_votes_count', { ascending: false })
      .limit(limit)

    if (error || !data) {
      // [removed in production] '[fetchTrendingForFeature] error:', error
      return []
    }

    return data as Post[]
  } catch (e) {
    // [removed in production] '[fetchTrendingForFeature] error:', e
    return []
  }
}

// ========================================
// جلب حالة تصويت المستخدم على منشورات
// ========================================

export async function fetchUserVotes(
  userId: string,
  postIds: string[]
): Promise<Set<string>> {
  if (postIds.length === 0) return new Set()

  try {
    const { data, error } = await supabase
      .from('feature_votes')
      .select('post_id')
      .eq('user_id', userId)
      .in('post_id', postIds)

    if (error || !data) {
      return new Set()
    }

    return new Set(data.map((v: { post_id: string }) => v.post_id))
  } catch (e) {
    // [removed in production] '[fetchUserVotes] error:', e
    return new Set()
  }
}
